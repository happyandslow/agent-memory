#!/usr/bin/env python3
"""Experiment A (M1-S3 perf, worker A) -- generate ONE measured point's static
config + per-round runtime sidecar for the qwen3_1p7b-decode reuse path.

Policy-independent: it exercises the PRODUCTION planner/commit flow
(`launch.run(..., round_runtime_inputs=<sidecar>, auto_replace_slots=True)`) at
the ACTUAL Qwen3-1.7B model-size geometry (2x4, dim2048, 28 layers, vocab151936).
It never edits production code.

Each "point" is a 2-round config:
  * round 0  -- SETUP: establishes the resident KV the measured round reuses
    (a miss that force-decodes a synthetic prefix and commits its ledger).
  * round 1  -- MEASURED: the reuse round whose LAST-round TSC burst survives in
    device_verdict.json. It is a miss / content-prefix hit / exact-id hit
    depending on --mode.

Cost-model target:  T(round1) = fixed(M) + F*C_forced(M) + G*C_free(M)
  M   = bsz (batch / active lanes)
  F   = forced_decode_len  = prompt_len - start   (the known suffix)
  G   = decode_budget - F   = newly generated FREE tokens (held constant)
  budget = F + G  must be a multiple of P_BLOCK_SIZE.

start is ALWAYS P_BLOCK_SIZE aligned. Lanes are equal-length (no ragged) and
each lane has its own disjoint token range so the one-to-one slot assignment is
unambiguous. Exact mode preserves F == 1 by construction.
"""
import argparse
import json
from pathlib import Path

# ---- fixed ACTUAL Qwen3-1.7B geometry (from test_device_dreal_L256_base) ---- #
BASE_GEO = {
    "Pw": 512, "Ph": 1024, "P_X_BLOCK_NUM": 2, "P_Y_BLOCK_NUM": 4,
    "group_num": 16, "dim": 2048, "head_dim": 128, "ffn_dim": 6144,
    "n_heads": 16, "n_kv_heads": 8, "n_layers": 28, "vocab_size": 151936,
    "HT_WIDTH_tail": 128, "TOP_K": 20, "temperature": 0.6, "top_p": 0.95,
    "KV_TRANSFER": 1,
}
P_BLOCK_SIZE = BASE_GEO["Pw"] // BASE_GEO["P_X_BLOCK_NUM"]   # 256
VOCAB = BASE_GEO["vocab_size"]


def _pre_tok(lane, pos):
    """Resident/prefix token for a lane -- deterministic, valid embedding idx."""
    return (lane * 131 + pos * 7 + 11) % VOCAB


def _div_tok(lane, pos, start):
    """Divergent-suffix token (round1 positions >= start). Guaranteed to differ
    from the resident token at the fork position so LCP is EXACTLY `start`."""
    t = (lane * 131 + pos * 7 + 11 + 300000) % VOCAB
    if pos == start and t == _pre_tok(lane, pos):
        t = (t + 1) % VOCAB
    return t


def _setup_tok(lane, pos):
    """Round-0 SETUP token for the MISS point -- disjoint constant so the
    measured miss never accidentally shares a 256-block with the resident."""
    return (lane * 131 + pos * 7 + 11 + 900000) % VOCAB


def build(mode, M, prompt_len, gfree, max_seq_len, start=None):
    assert prompt_len >= 2
    slot_count = M
    if mode == "miss":
        start = 0
    elif mode == "exact":
        start = ((prompt_len - 1) // P_BLOCK_SIZE) * P_BLOCK_SIZE
    elif mode == "partial":
        assert start is not None, "partial mode needs --start"
        assert 0 < start < prompt_len - 1 and start % P_BLOCK_SIZE == 0
    else:
        raise SystemExit(f"bad mode {mode}")
    return _finish(mode, M, prompt_len, gfree, max_seq_len, start, slot_count)


def _finish(mode, M, prompt_len, gfree, max_seq_len, start, slot_count):
    F = prompt_len - start
    budget1 = F + gfree
    assert budget1 % P_BLOCK_SIZE == 0, (
        f"budget {budget1} (F={F}+G={gfree}) must be a multiple of {P_BLOCK_SIZE}; "
        f"pick prompt_len and gfree so F+G aligns.")
    assert 1 <= F <= budget1
    worst = max_seq_len - P_BLOCK_SIZE
    assert budget1 <= worst, f"budget {budget1} > max_output_len_worst {worst}"
    end1 = start + budget1
    assert end1 <= max_seq_len, f"end {end1} > MAX_SEQ_LEN {max_seq_len}"

    cfg = dict(BASE_GEO)
    cfg.update({
        "bsz": M, "SLOT_COUNT": slot_count, "MAX_SEQ_LEN": max_seq_len,
        "WARMUP": 0, "PREFILL_LEN": P_BLOCK_SIZE, "NUM_ROUNDS": 2,
        "PREFILL_LENS": [0, 0], "DECODE_LENS": [P_BLOCK_SIZE, P_BLOCK_SIZE],
        "RETAIN_ROUNDS": [0, 0], "RETAINED_LENS": [0, 0],
        "FORCED_DECODE_LENS": [1, 1],
    })

    # ---- round 1 measured prompts (per lane, equal length) ---- #
    if mode == "miss":
        r1_prompts = [[_pre_tok(m, p) for p in range(prompt_len)] for m in range(M)]
    else:  # partial / exact share `start` resident tokens then diverge
        r1_prompts = [
            [_pre_tok(m, p) for p in range(start)]
            + [_div_tok(m, p, start) for p in range(start, prompt_len)]
            for m in range(M)]

    # ---- round 0 setup: establishes the resident the measured round reuses ---- #
    if mode == "miss":
        setup_len = P_BLOCK_SIZE
        r0_prompts = [[_setup_tok(m, p) for p in range(setup_len)] for m in range(M)]
        budget0 = setup_len
        r0_seqs = [10000 + m for m in range(M)]
        r1_seqs = [20000 + m for m in range(M)]
    elif mode == "partial":
        r0_prompts = [[_pre_tok(m, p) for p in range(start)] for m in range(M)]
        budget0 = start
        r0_seqs = [10000 + m for m in range(M)]
        r1_seqs = [20000 + m for m in range(M)]     # new request -> content hit
    else:  # exact: same sequence id continues; resident = prompt[:start]
        r0_prompts = [[_pre_tok(m, p) for p in range(start)] for m in range(M)]
        budget0 = start
        r0_seqs = [10000 + m for m in range(M)]
        r1_seqs = [10000 + m for m in range(M)]     # SAME id -> exact continuation

    assert budget0 % P_BLOCK_SIZE == 0 and budget0 <= worst and budget0 >= P_BLOCK_SIZE
    evictable = list(range(slot_count))
    sidecar = {
        "schema": "round_runtime_inputs/v1",
        "rounds": [
            {"sequence_ids": r0_seqs, "prompt_token_histories": r0_prompts,
             "evictable_slots": evictable, "decode_budget_tokens": budget0},
            {"sequence_ids": r1_seqs, "prompt_token_histories": r1_prompts,
             "evictable_slots": evictable, "decode_budget_tokens": budget1},
        ],
    }
    meta = {"mode": mode, "M": M, "prompt_len": prompt_len, "start_tokens": start,
            "F": F, "G_free": gfree, "budget_measured": budget1,
            "budget_setup": budget0, "MAX_SEQ_LEN": max_seq_len,
            "P_BLOCK_SIZE": P_BLOCK_SIZE, "WARMUP": 0,
            "measured_round_index": 1,
            "counted_tokens_expected": budget1 - 1}
    return cfg, sidecar, meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", required=True, choices=["miss", "partial", "exact"])
    ap.add_argument("--M", type=int, required=True)
    ap.add_argument("--prompt-len", type=int, required=True)
    ap.add_argument("--gfree", type=int, required=True)
    ap.add_argument("--start", type=int, default=None, help="partial mode only")
    ap.add_argument("--max-seq-len", type=int, default=1792)
    ap.add_argument("--name", required=True, help="basename for sidecar/meta")
    ap.add_argument("--config-name", default=None,
                    help="basename for the static config (default: --name). One shared "
                         "config per M lets all its points reuse the same compile.")
    ap.add_argument("--config-dir", default="model_config")
    ap.add_argument("--sidecar-dir", default="round_inputs")
    args = ap.parse_args()

    cfg, sidecar, meta = build(
        args.mode, args.M, args.prompt_len, args.gfree, args.max_seq_len, args.start)
    meta["config_name"] = args.config_name or args.name

    here = Path(__file__).resolve().parents[1]
    cfg_p = here / args.config_dir / f"{args.config_name or args.name}.json"
    side_p = here / args.sidecar_dir / f"{args.name}.json"
    meta_p = here / args.sidecar_dir / f"{args.name}.meta.json"
    cfg_p.parent.mkdir(parents=True, exist_ok=True)
    side_p.parent.mkdir(parents=True, exist_ok=True)
    cfg_p.write_text(json.dumps(cfg, indent=2))
    side_p.write_text(json.dumps(sidecar, indent=2))
    meta_p.write_text(json.dumps(meta, indent=2))
    print(json.dumps({"config": str(cfg_p), "sidecar": str(side_p),
                      "meta": meta}, indent=2))


if __name__ == "__main__":
    main()
