#!/usr/bin/env python3
"""Experiment A AUTHORITATIVE evidence parser (worker A).

The device_verdict.json stays on the worker (VERDICT_PATH=NONE is EXPECTED), so
the streamed remote stdout log is the authoritative evidence. This parser turns
one point's remote log + its meta into a machine-readable row and FAILS CLOSED
unless every device fact is present and consistent:

  * EXIT=0 and DONE=0 both present (launch_device.py + remote helper succeeded);
  * exactly ONE final TSC block;
  * span_cycles > 0, repeat > 0, and repeat == budget_measured - 1
      (WARMUP=0 -> warmup_cycles=1 -> the timed window excludes step 0, so the
       fitted forced-step count is F-1 and timed_steps = N-1);
  * the MEASURED round's reuse-ledger line matches the intended start / F / kind
      (miss -> REBUILD ; content-prefix or exact-id hit -> PREFIX-REUSE);
  * the measured round generated all N steps and every slot ledger is OK.

RAW span_cycles is preserved; conversion is at 1.1 GHz only. Exit 0 + print
`EXPA_POINT PASS ...` iff valid, else `EXPA_POINT FAIL ...` and exit 1.
"""
import argparse
import json
import re
import sys
from pathlib import Path

CLOCK_HZ = 1.1e9   # WSE-3 fabric; RAW span_cycles preserved, converted here only


def parse_log(text, mr):
    """Extract the device facts from the remote log for measured round `mr`."""
    d = {}
    exits = re.findall(r'^EXIT=(-?\d+)', text, re.M)
    dones = re.findall(r'^DONE=(-?\d+)', text, re.M)
    d["exit"] = int(exits[-1]) if exits else None
    d["done"] = int(dones[-1]) if dones else None

    spans = re.findall(r'Span cycles \(end - start\):\s*(\d+)', text)
    reps = re.findall(r'Repeat \(timed rounds\):\s*(\d+)', text)
    pstep_cyc = re.findall(r'Per-round cycles \(span / repeat\):\s*([\d.]+)', text)
    pstep_us = re.findall(r'Per-round time @ 1\.1 GHz:\s*([\d.]+)', text)
    d["n_tsc_blocks"] = len(spans)
    d["span_cycles"] = int(spans[-1]) if spans else None
    d["repeat"] = int(reps[-1]) if reps else None
    d["per_step_cyc"] = float(pstep_cyc[-1]) if pstep_cyc else None
    d["per_step_us"] = float(pstep_us[-1]) if pstep_us else None

    # measured round reuse-ledger line
    m = re.search(
        rf'\[reuse-ledger-verify\] round {mr}:.*?start=(\d+)\s+F=(\d+)\s+steps=(\d+)'
        rf'\s+prefill=(\d+)\s*->\s*(\S+)', text)
    if m:
        d["rl_start"] = int(m.group(1)); d["rl_F"] = int(m.group(2))
        d["rl_steps"] = int(m.group(3)); d["rl_prefill"] = int(m.group(4))
        d["rl_kind"] = m.group(5)
    # round summary for the measured round
    ms = re.search(rf'\[round {mr}\] prefill=(\d+) N=(\d+): generated (\d+) steps', text)
    if ms:
        d["rs_prefill"] = int(ms.group(1)); d["rs_N"] = int(ms.group(2))
        d["rs_generated"] = int(ms.group(3))
    # slot ledger OK lines
    d["ledger_ok"] = re.findall(r'\[reuse-ledger-verify\] slot \d+:.*->\s*OK', text)
    d["ledger_bad"] = re.findall(r'\[reuse-ledger-verify\] slot \d+:.*->\s*(?!OK)\S+', text)
    return d


def validate(d, meta):
    p = []
    mr = meta["measured_round_index"]
    if d["exit"] != 0: p.append(f"EXIT={d['exit']!r} (need 0)")
    if d["done"] != 0: p.append(f"DONE={d['done']!r} (need 0)")
    if d["n_tsc_blocks"] != 1: p.append(f"{d['n_tsc_blocks']} TSC blocks (need exactly 1)")
    if not (isinstance(d["span_cycles"], int) and d["span_cycles"] > 0):
        p.append(f"span_cycles={d['span_cycles']!r} (need >0)")
    if not (isinstance(d["repeat"], int) and d["repeat"] > 0):
        p.append(f"repeat={d['repeat']!r} (need >0)")
    exp_rep = meta["budget_measured"] - 1
    if d["repeat"] != exp_rep:
        p.append(f"repeat={d['repeat']!r} != budget-1={exp_rep}")
    # reuse-ledger line
    want_kind = "REBUILD" if meta["mode"] == "miss" else "PREFIX-REUSE"
    if "rl_start" not in d:
        p.append(f"no reuse-ledger round {mr} line")
    else:
        if d["rl_start"] != meta["start_tokens"]:
            p.append(f"ledger start={d['rl_start']} != {meta['start_tokens']}")
        if d["rl_F"] != meta["F"]:
            p.append(f"ledger F={d['rl_F']} != {meta['F']}")
        if d["rl_steps"] != meta["budget_measured"]:
            p.append(f"ledger steps={d['rl_steps']} != budget {meta['budget_measured']}")
        if d["rl_kind"] != want_kind:
            p.append(f"ledger kind={d['rl_kind']} != {want_kind}")
        if d["rl_prefill"] != 0:
            p.append(f"ledger prefill={d['rl_prefill']} != 0 (must skip prefill / meta-only)")
    # round summary complete execution
    if "rs_N" not in d:
        p.append(f"no round-summary for round {mr}")
    else:
        if d["rs_N"] != meta["budget_measured"]:
            p.append(f"round N={d['rs_N']} != budget {meta['budget_measured']}")
        if d["rs_generated"] != d["rs_N"]:
            p.append(f"generated {d['rs_generated']} of N={d['rs_N']}")
    # ledgers OK
    if d["ledger_bad"]:
        p.append(f"{len(d['ledger_bad'])} non-OK slot ledger(s)")
    if len(d["ledger_ok"]) != meta["M"]:
        p.append(f"{len(d['ledger_ok'])} OK ledgers (need M={meta['M']})")
    return p


def row(name, d, meta):
    span = d["span_cycles"]
    span_s = (span / CLOCK_HZ) if span else None
    N = meta["budget_measured"]; M = meta["M"]
    timed = d["repeat"]  # == N-1
    return {
        "name": name, "mode": meta["mode"], "M": M, "prompt_len": meta["prompt_len"],
        "R_resident": meta["start_tokens"], "F_forced": meta["F"], "G_free": meta["G_free"],
        "budget_N": N, "timed_steps": timed, "warmup_cycles": 1,
        "setup_resident_len": meta["start_tokens"], "budget_setup": meta["budget_setup"],
        # RAW device TSC preserved
        "span_cycles_raw": span,
        "per_step_cyc": d["per_step_cyc"], "per_step_us_at_1p1GHz": d["per_step_us"],
        "T_round_us_at_1p1GHz": (span_s * 1e6) if span_s else None,
        "T_round_s_at_1p1GHz": span_s,
        # aggregate lane-token throughput over the timed window (M lanes x (N-1) steps)
        "lane_tok_throughput_at_1p1GHz": (M * timed / span_s) if span_s else None,
        "ledger_kind": d.get("rl_kind"),
        "reuse_ledger_start": d.get("rl_start"), "reuse_ledger_F": d.get("rl_F"),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--log", required=True)
    ap.add_argument("--meta", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    text = Path(args.log).read_text(errors="replace")
    meta = json.loads(Path(args.meta).read_text())
    d = parse_log(text, meta["measured_round_index"])
    problems = validate(d, meta)
    r = row(args.name, d, meta)
    r["validation"] = {"pass": not problems, "problems": problems}
    Path(args.out).write_text(json.dumps(r, indent=2))
    if problems:
        print("EXPA_POINT FAIL " + json.dumps({"name": args.name, "problems": problems}))
        return 1
    print("EXPA_POINT PASS " + json.dumps(
        {"name": args.name, "M": meta["M"], "F": meta["F"], "R": meta["start_tokens"],
         "span_cycles": r["span_cycles_raw"], "T_us": round(r["T_round_us_at_1p1GHz"], 1)}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
