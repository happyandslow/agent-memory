#!/usr/bin/env bash
# Experiment A -- runs ON the CS-3 login/control node (staged via rsync).
# Detached target for setsid+nohup: activate csl, drive launch_device.py under a
# hard `timeout`, tee everything into a durable log, then record EXIT=<rc> and,
# if produced, inline the worker's device_verdict.json so the result survives a
# client drop and is retrievable by a short poll RPC.
#
# usage: expA_remote_launch.sh <cfg_base> <side_base> <name> <staging> <timeout_s> <logfile>
set -u
CFG_BASE="$1"; SIDE_BASE="$2"; NAME="$3"; STAGING="$4"; TIMEOUT_S="$5"; LOG="$6"
MODEL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$MODEL_DIR" || { echo "EXIT=97 (no model dir)" >>"$LOG"; exit 97; }

source ~/miniconda3/etc/profile.d/conda.sh 2>/dev/null
conda activate csl 2>/dev/null

{
  echo "=== expA remote launch $(date -u +%FT%TZ) ==="
  echo "cfg=$CFG_BASE side=$SIDE_BASE name=$NAME staging=$STAGING timeout=${TIMEOUT_S}s host=$(hostname)"
} >>"$LOG" 2>&1

timeout "${TIMEOUT_S}" python ./launch_device.py \
    --config "model_config/${CFG_BASE}.json" \
    --round-inputs "round_inputs/${SIDE_BASE}.json" \
    --auto-replace-slots \
    --name "$NAME" \
    --staging "$STAGING" >>"$LOG" 2>&1
rc=$?
echo "EXIT=$rc" >>"$LOG"

# Inline the durable verdict (worker CWD == staging dir) if SdkLauncher left it
# under the control-node staging tree; also dump any found copy for retrieval.
VERDICT="$(find "$MODEL_DIR/$STAGING" "$MODEL_DIR/$NAME" -name device_verdict.json 2>/dev/null | head -1)"
if [ -n "$VERDICT" ] && [ -f "$VERDICT" ]; then
    echo "VERDICT_PATH=$VERDICT" >>"$LOG"
    echo "VERDICT_BEGIN" >>"$LOG"; cat "$VERDICT" >>"$LOG"; echo "" >>"$LOG"; echo "VERDICT_END" >>"$LOG"
else
    echo "VERDICT_PATH=NONE" >>"$LOG"
fi
echo "DONE=$rc" >>"$LOG"
