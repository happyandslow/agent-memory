#!/usr/bin/env python3
"""Experiment A aggregator: results.jsonl (per-rep rows, RAW span cycles) ->
machine-readable summary + human tables.

Reports, per (M, point):
  * median / mean / stdev of RAW span_cycles, T_round (s @1.1GHz), per-step us,
    and aggregate lane-token throughput M*(N-1)/T;
  * speedup vs the SAME-M miss baseline, computed from TOTAL SPAN CYCLES
    (median_span[miss@M] / median_span[point@M]).

Cost model  T = fixed(M) + F*C_forced(M) + G*C_free(M).  WARMUP=0 => the TSC
timed window excludes step 0, so timed_steps = N-1 and the fitted forced-step
count is F-1. The constant-G family (miss + partial hits, G=255) gives, per M, a
line  span_cycles ~= intercept + slope*(F-1); slope = C_forced (cycles/forced
step), intercept = G*C_free + fixed_window. The exact-id family (F=1, G=255, R
varying) isolates the resident-context / attention-length cost at fixed F.
"""
import json
import statistics as st
import sys
from pathlib import Path

CLOCK_HZ = 1.1e9


def load(path):
    rows = []
    for line in Path(path).read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        r = json.loads(line)
        if r.get("validation", {}).get("pass"):
            rows.append(r)
    return rows


def stats(vals):
    vals = list(vals)
    return {
        "n": len(vals),
        "median": st.median(vals) if vals else None,
        "mean": st.fmean(vals) if vals else None,
        "stdev": st.pstdev(vals) if len(vals) > 1 else 0.0,
        "min": min(vals) if vals else None,
        "max": max(vals) if vals else None,
    }


def linfit(xs, ys):
    """Ordinary least squares y = a + b x. Returns (a, b, r2)."""
    n = len(xs)
    if n < 2:
        return None
    mx = sum(xs) / n; my = sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    if sxx == 0:
        return None
    b = sxy / sxx; a = my - b * mx
    ss_tot = sum((y - my) ** 2 for y in ys)
    ss_res = sum((y - (a + b * x)) ** 2 for x, y in zip(xs, ys))
    r2 = (1 - ss_res / ss_tot) if ss_tot else 1.0
    return a, b, r2


def main():
    src = sys.argv[1] if len(sys.argv) > 1 else "results.jsonl"
    out = sys.argv[2] if len(sys.argv) > 2 else "expA_summary.json"
    rows = load(src)
    # group by (M, mode, R)
    groups = {}
    for r in rows:
        key = (r["M"], r["mode"], r["R_resident"])
        groups.setdefault(key, []).append(r)

    summary = {"points": [], "per_M": {}}
    for key in sorted(groups):
        M, mode, R = key
        g = groups[key]
        spans = [x["span_cycles_raw"] for x in g]
        Ts = [x["T_round_s_at_1p1GHz"] for x in g]
        pstep = [x["per_step_us_at_1p1GHz"] for x in g]
        thr = [x["lane_tok_throughput_at_1p1GHz"] for x in g]
        summary["points"].append({
            "M": M, "mode": mode, "R_resident": R,
            "F_forced": g[0]["F_forced"], "G_free": g[0]["G_free"],
            "budget_N": g[0]["budget_N"], "timed_steps": g[0]["timed_steps"],
            "reps": len(g),
            "span_cycles": stats(spans),
            "T_round_s": stats(Ts),
            "per_step_us": stats(pstep),
            "lane_tok_throughput": stats(thr),
        })

    # speedup vs same-M miss (median total span cycles) + cost-model fits
    def median_span(M, mode, R):
        g = groups.get((M, mode, R))
        return st.median([x["span_cycles_raw"] for x in g]) if g else None

    for M in sorted({k[0] for k in groups}):
        miss = median_span(M, "miss", 0)
        per_pt = []
        for p in summary["points"]:
            if p["M"] != M:
                continue
            msp = p["span_cycles"]["median"]
            p["speedup_vs_miss_span"] = (miss / msp) if (miss and msp) else None
            per_pt.append(p)
        # constant-G family: miss + partials (G=255). x = F-1 (forced steps in window)
        fam = [(p["F_forced"] - 1, p["span_cycles"]["median"])
               for p in per_pt if p["mode"] in ("miss", "partial")]
        fam.sort()
        fit = linfit([x for x, _ in fam], [y for _, y in fam]) if len(fam) >= 2 else None
        # exact family: F=1, R varies -> attention-length cost at fixed F,G
        exact = sorted((p["R_resident"], p["span_cycles"]["median"])
                       for p in per_pt if p["mode"] == "exact")
        exfit = linfit([x for x, _ in exact], [y for _, y in exact]) if len(exact) >= 2 else None
        entry = {"miss_median_span": miss}
        if fit:
            a, b, r2 = fit
            entry["constG_fit"] = {
                "form": "span_cycles = intercept + slope*(F-1)  [G=255 const]",
                "slope_C_forced_cyc_per_step": b,
                "slope_C_forced_us_per_step": b / CLOCK_HZ * 1e6,
                "intercept_cyc": a, "r2": r2,
                "points_F_minus_1": [x for x, _ in fam],
            }
        if exfit:
            a, b, r2 = exfit
            entry["exact_vs_R_fit"] = {
                "form": "span_cycles = intercept + slope*R  [F=1,G=255]",
                "slope_cyc_per_resident_tok": b,
                "slope_us_per_resident_tok": b / CLOCK_HZ * 1e6,
                "intercept_cyc": a, "r2": r2,
                "R_points": [x for x, _ in exact],
            }
        summary["per_M"][str(M)] = entry

    Path(out).write_text(json.dumps(summary, indent=2))

    # ---- human tables ----
    print("== Experiment A summary (ACTUAL 2x4 Qwen3-1.7B, real WSE-3, RAW TSC @1.1 GHz) ==")
    print(f"{'M':>2} {'point':>8} {'R':>5} {'F':>5} {'G':>4} {'N':>5} {'reps':>4} "
          f"{'span_cyc(med)':>14} {'T_ms(med)':>9} {'us/step':>8} {'laneTok/s':>10} {'spdup':>6}")
    for p in summary["points"]:
        sp = p["span_cycles"]["median"]; T = p["T_round_s"]["median"]
        print(f"{p['M']:>2} {p['mode']:>8} {p['R_resident']:>5} {p['F_forced']:>5} "
              f"{p['G_free']:>4} {p['budget_N']:>5} {p['reps']:>4} {int(sp):>14} "
              f"{T*1e3:>9.2f} {p['per_step_us']['median']:>8.2f} "
              f"{p['lane_tok_throughput']['median']:>10.1f} "
              f"{(p.get('speedup_vs_miss_span') or 0):>6.3f}")
    print()
    for M, e in summary["per_M"].items():
        print(f"-- M={M} cost-model --")
        if "constG_fit" in e:
            f = e["constG_fit"]
            print(f"   const-G (G=255) line span=intercept+slope*(F-1): "
                  f"C_forced={f['slope_C_forced_us_per_step']:.3f} us/step "
                  f"({f['slope_C_forced_cyc_per_step']:.1f} cyc), "
                  f"intercept={f['intercept_cyc']:.0f} cyc, R2={f['r2']:.5f}")
        if "exact_vs_R_fit" in e:
            f = e["exact_vs_R_fit"]
            print(f"   exact (F=1) span vs resident R: "
                  f"{f['slope_us_per_resident_tok']*1e3:.4f} us/1000-resident-tok "
                  f"({f['slope_cyc_per_resident_tok']:.2f} cyc/tok), R2={f['r2']:.5f}")


if __name__ == "__main__":
    main()
