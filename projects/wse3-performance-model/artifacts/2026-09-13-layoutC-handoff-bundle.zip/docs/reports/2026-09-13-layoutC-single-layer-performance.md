# CS-3: LayoutC versus original ATTN + FFN single-layer latency

Date: 2026-09-13. All latency samples below are **measured on real CS-3**.
Units are raw device cycles; no target clock-frequency assumption or host-wall
conversion is needed. The target is one complete decoder layer, batch 1, using
one layer bank in each region. This is not five-layer feedback, multi-token
pipeline throughput, trained-model inference, or end-to-end 36-layer performance.

## Result

The current A1/A2/A3 layout saves half the reserved compute-block area but has
about **3.7–3.9× the serialized layer-completion latency** in these tests.
The scope includes a common on-wafer START/all-row-completion measurement
boundary, detailed below; it must not be relabeled pure compute latency.

| Initial prefill | Original cycles: median [range of run medians] | Tall cycles: median [range of run medians] | Tall / original |
|---|---:|---:|---:|
| 1,280 | 26,377 [26,376, 26,377] | 102,511 [102,510, 102,622] | 3.886× |
| 5,120 | 28,000 [27,998, 28,001] | 104,330 [104,328, 104,331] | 3.726× |

Each cell summarizes **three independent CS-3 jobs**. Each job executes 33
consecutive decode tokens, drops the first 4 timing samples, and measures 29.
Context grows by one per decode, identically in both layouts. No completed
sample/run was discarded after inspecting its timing. Ranges are not confidence
intervals. Every one of the 1,013,760 normal measured-run output elements matches
its own geometry/operator-order reference exactly, including warmup outputs.
This does not mean that different layouts are bit-identical to each other.

![Measured layer completion latency](/home/lexu/wse3-performance-model/docs/reports/2026-09-13-layoutC-single-layer-performance.png)

## Identical workload and baseline identity

| Setting | Original | Current tall |
|---|---|---|
| Compute regions | 256×256 ATTN + 256×256 FFN | 128×80 A1 + 128×256 A2 + 128×160 A3 |
| Reserved compute-block PEs | 131,072 | 65,536 |
| Active compute PEs | 131,072 | 63,488 (16 left-half rows idle) |
| Measurement collector PEs, excluded from above | 256 | 256 |
| Batch / local layers / dtype | 1 / 1 / BF16 | same |
| Hidden / attention / KV / head / FFN dimensions | 2560 / 4096 / 1024 / 128 / 9728 | same |
| Cache capacity / initial prefill | 8192 / {1280,5120} | same |
| Compute reduction grouping | 16 PEs per subgroup | 16 PEs per subgroup |

Weights are dense random synthetic BF16 tensors (seed910). Inputs, all weights,
norm parameters and initial K/V tensors are logically identical across layouts;
per-tensor hashes are checked. Storage sharding differs. No trained checkpoint
or head/tail code executes in the timed path. The last FFN result leaves a row
through one selected output PE, then remains in the measurement collector SRAM.

Original identity is `happyandslow/WaferEngine` commit
`b136ab64b3f5575c72fb722fb972ef5c77f4c9fe`, subtree `models/qwen3_4b-decode`.
Pinned original `src/decode.csl` SHA-256:
`c3da0e464dfefb8831dc17c32c8eee27485919e5b54a1d9374b0838af774272b`.
The [local pinned source](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/src/decode.csl)
and [prior attribution](/home/lexu/wse3-performance-model/docs/reports/2026-09-11-layoutC-upstream-numerical-attribution.md)
establish its identity. Its measurement adapter disables only default init-task
activation; the wrapper calls the original layer bodies/collectives unchanged.

Tall source is the just-verified first-group implementation, with feedback
turned off and one layer bank for the matched single-layer question. Its
[tall stage schedule](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:185)
and its QKV/X/Z paths remain in use. Measurement gating was added only to an
isolated copy. The maintained source tree is unchanged. Both variants use the
same SDK2.10 compiler wrapper, maximum inlined iterations8 and `.csl_dcache`
placement option. Original and tall prefill chronology follows the prior
matched-fixture adapter, not the production host mock-cache generator.

## Timing boundary and measurement overhead

One bottom collector PE samples its own TSC immediately before enqueuing START.
START reaches all input PEs; no input PE begins its next layer before this
credit. All output rows are received into collector SRAM. Each collector row
joins a completion chain only after its own output arrived. The same bottom
PE samples the end after the chain accounts for every row. It then permits the
next token. **No host operation releases a token.** All result/TSC D2H occurs
after the 33 measured/warmup intervals have finished. The result collection
path therefore cannot acquire host-backpressure stalls during measurement.

Implementation: temporary
[collector](/tmp/layoutc-layer-perf-20260913/package/perf_collector.csl:35) and
[route/port setup](/tmp/layoutc-layer-perf-20260913/package/measurement.py:9),
permanently preserved as `package/perf_collector.csl` and `package/measurement.py`
in the reproduction archive. No subtraction of unsynchronized cross-PE TSCs
is used. Counter deltas are unsigned low32 differences over short intervals.
Back-to-back timer reads cost 9 cycles in these runs; this is not subtracted.

The empty boundary control instantiates the same 256 collector rows, START and
completion chain, with no model computation/output wait. Its steady median is
**8,231 cycles original / 8,232 cycles tall**. This is substantial (about31% of
the original 1280-prefill measured interval), so it is explicitly shown.
It is **not subtracted** to invent pure-kernel timing: completion acknowledgment
may overlap different rows' computation, and the empty case does not reproduce
that overlap or the compute-side START/output paths. The raw ratio above is the
ratio for the declared common measurement boundary, not a calibrated pure-
compute speed ratio. Output collection and release topology also differ in
horizontal direction/distance between geometries.

A timer positive control inserts 1,000,000 cycles of local waiting inside this
same interval. The observed increase is 1,000,026 cycles; the extra 26 are polling/
branch overhead. The idle-floor controls have constant steady samples. A
corrupted output element fails the exact checker. No threshold was relaxed.

## Interpretation and limits

Reducing whole-group PE reservation by 2× does not imply 2× fewer PEs for each
individual phase. Analytically, the QKV phase moves from 65,536 ATTN PEs to 10,240
A1 PEs: its per-PE weight tile is 6.4× larger. FFN moves from 65,536 to 20,480 A3
PEs, with a 3.2× larger per-PE weight tile. These are geometry/tile-size ratios,
not measured stage slowdowns. The source dimensions are the
[tall stage parameters](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:22).
Tall additionally performs X/Z redistribution, including the current
[two-element transfer loops](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:133).
This experiment does not separate arithmetic, collective, queue-switch and
redistribution time; no one of them is claimed as the measured cause.

The result supports an area/latency tradeoff for the current implementation.
It cannot predict complete-model pipeline throughput, feedback/reset cost,
multiple requests, larger batches, Head/Tail overhead or capacity at 36 layers.
The next useful diagnostic is per-stage and X/Z-path timing with compatible
boundaries, before choosing a performance optimization.

## Evidence and reproduction

- [Evidence JSON](/home/lexu/wse3-performance-model/docs/reports/2026-09-13-layoutC-single-layer-performance-evidence.json): every job, sample, setting, source/fixture hash, validation and summary.
- [Reproduction archive](/home/lexu/wse3-performance-model/docs/reports/2026-09-13-layoutC-single-layer-performance-repro.tgz): staged source closures, raw outputs/timing, references, launchers, controls and analysis.

The archive README gives bounded CS-3 commands; each run owns its SdkLauncher
context and job cleanup. The first pair predates the optional delay-control
parameter (zero for all normal runs); its original collector source is also
preserved. No production kernel, launcher or tracking document was edited.
No stage, commit, push or history-changing Git operation was performed.
