# Unequal-height Layout C: implemented transport, numerical gate still open

2026-09-10. **Simulator / compiler evidence, not hardware measurements.**

The authorized single-group QKV/X/Z datapath is implemented. A1/A2/A3 use
heights 80/256/160 at width 128, with spare rows 80..95 between A1 and A3.
The full-size group compiles with five layer banks. A proportional miniature
passes exact 33-step transport tests. Complete compute correctness does **not**
pass the existing absolute-error threshold; no group/head/tail integration or
performance testing was started.

## Implementation

- [launch_tall.py](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:165)
  paints two fixed horizontal QKV colors, H0=8 and H1=9. Source and destination
  column c both use row c mod A1_height. Intermediate routers forward; only
  the matching A2 column consumes. Color 11 multicasts within that column.
- [tall_stage.csl:118](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:118)
  implements X's ordered stream; [line 137](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:137)
  implements Z. Each edge PE consumes its feature interval, forwards the
  remainder, and inserts its own source interval in order. Fixed two-element
  atoms avoid odd fabric-to-fabric extents. Only A2 edge PEs allocate the
  64-byte hidden staging buffer. This is a correctness-first schedule; atom
  coalescing and distributed relay lanes have not been performance-tested.
- [tall_fixture.py:64](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/tall_fixture.py:64)
  uses contiguous hidden slices, changes the corresponding weight input/output
  axes, retains attention/FFN column ownership, and bases delta-P RoPE on A1's
  actual height. The oracle receives unsharded tensors, not packed PE tiles.
- [tall_layout.py](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/tall_layout.py:1)
  defines miniature/full geometries and rejects incompatible dimensions.
- [comm_pe.csl:1687](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/comm_lib/comm_pe.csl:1687)
  leaves the queue-flush handler to the external wrapper when external_io is
  enabled. The vanilla path keeps its original handler and bindings.

### Queue ownership and the failed first schedule

Collectives use queues 3..7. A2 permanently reserves IQ0 for its horizontal
QKV color, IQ1 for column QKV, and IQ2 for X entry (edge) or row broadcast
(interior). OQ0 sends Z, OQ1 broadcasts QKV, and OQ2 broadcasts X. Edge IQ3/OQ3
are borrowed for the color-12/13 vertical parity chain between computations.
Transport routes stay static; only queue bindings change.

An early probe exposed a real invalid rebind: after Z[t], an upstream PE may
already send X[t+1]. The simulator reported input queue 3 still holding
wavelets when rebound C12->C0. Flushing the output queue does not prove that
input queue empty. The final
[schedule](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:192)
keeps the vertical binding across Z[t] -> X[t+1], and restores the compute
binding only after consuming/forwarding all X[t+1], before releasing its row
broadcast. The intervening synchronous compute Y collective prevents Z from
starting before the X phase is complete. The transport-only probe retains a
scalar Y collective to preserve this required phase boundary.

The color-audit extractor was attempted on this worktree but refused to parse
an existing multiline encode_output_queue call at comm_pe.csl:790. No clean
automated audit is claimed. The bindings above were reviewed from source and
validated by compiler plus positive/negative simulator executions.

## Validation

Miniature geometry: width 16; heights 10/32/20; A3 origin row 12; hidden 320;
attention 512; KV width 128; head dimension 16; FFN 1216; batch 1; prefill 160;
capacity 224. It has the full target's 32/10/16 hidden elements per PE and
32/8/76 attention/KV/FFN column widths. It folds 16 columns onto 10 A1 rows.

| Case | Result |
|---|---|
| Pure transport, 33 steps | PASS: different QKV payloads per column and step; QKV and X snapshots exact at all 512 A2 PEs for every step; all 33x320 output elements exact |
| Negative QKV, 3 steps | Expected FAIL: duplicate the low-column source into each H1 source; QKV checker fails while X and output identity checks pass |
| Negative X, 3 steps | Expected FAIL: rotate destination offsets by two elements within every A2 hidden shard; X/output checks fail while QKV passes |
| Full compute, 33 steps | Executes to completion, but numerical gate FAIL: output relative L2 0.0070751966; max absolute error 0.25 exceeds unchanged 0.05 threshold |
| KV during full compute | PASS: all 512 A2 PE prefixes/unused slots exact; V appends exact; K append relative L2 0.0027129315, max absolute error 0.015625; decode crosses a 32-row ownership wrap |
| Vanilla regression | PASS; sampled IDs, top-k IDs, and raw top-k values are bit-identical to the historical vanilla baseline |
| Host checks | Ruff check / formatting, Python syntax, ordered-stream enumeration for mini and full dimensions pass |

The numerical fixture uses synthetic random weights (scale 0.1), input scale
0.5, seed 910. The larger miniature differs from the previous hidden-64 test;
its output-error number is not a same-workload regression comparison. An
initial two-step compute run also failed max-absolute error (0.125; relative
L2 0.00633933). Neither threshold nor fixture scale was relaxed to obtain a
pass. The discrepancy remains **unattributed**. Exact transport tests certify
movement, not the arithmetic or pretrained-model correctness.

Temporary device injection/snapshot code and deliberate faults lived only in
disposable copies. They were removed after retaining arrays, hashes, logs, and
reproduction diffs in the evidence JSON. No probe/fault branch remains in the
kernel. Existing maintained host fixture/checker functions remain available.

## Full-size compile and SRAM

The final source compiles a southbound group with width 128, heights
80/256/160, true hidden 2560, attention 4096, KV 1024, head 128, FFN 9728,
batch 1, cache capacity 8192, and five weight/cache banks. Coordinates are
A1 (2,1), A2 (130,1), A3 (2,97). The collector is a boundary harness, not the
model tail. No full-size simulation or hardware execution was run.

Compiler ELF main-memory usage (`cs_readelf -m`, 49152-byte denominator):

| Binary role | Bytes | Percentage |
|---|---:|---:|
| A1 | 26752 | 54.43% |
| A2 edge | 22272 | 45.31% |
| A2 interior H0 / H1 | 20992 | 42.71% |
| A3 | 47264 | 96.16% |

Symbol sizes verify the five banks: A1 Q=10240 B, A2 O=3200 B and K cache=2560 B,
A3 UP/DOWN=12160 B each. These are real-dimension compiled allocations, unlike
the older fake-hidden-dimension SRAM scaffold. A3 has only 1888 B below the
reported 48-KiB main-memory capacity; later ingress/feedback changes must
recheck the linker, code, data, and task-table limits. Placeholder buffers
still exist in the imported compute kernel; complete ownership cleanup is open.

Five banks compiled does not mean five layers executed. The current runtime
schedule selects local layer 0, uses baked prefill/input fixtures, and does
not implement local feedback, request ingress/rearm, or northbound execution.

## Next gate

Attribute the output discrepancy at A1, attention/residual, and FFN/residual
boundaries with a matched-operation reference, retaining the unsharded model
reference as a separate check. Then complete real KV ingress and two-layer
local feedback, followed by the four/five-layer group. Only complete group
correctness permits inter-group/head/tail integration; e2e performance remains
last.

## Reproduction and artifacts

From `/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code`:

```sh
SINGULARITYENV_CSL_SUPPRESS_SIMFAB_TRACE=1 timeout 180 cs_python launch_tall.py --steps 33 --output /tmp/layoutc-compute33
SINGULARITYENV_CSL_SUPPRESS_SIMFAB_TRACE=1 timeout 240 cs_python launch_tall.py --profile full --layers 5 --compile-only --output /tmp/layoutc-full5
```

The first command currently returns failure for the documented numerical
threshold; the second is compile-only. The accompanying `-evidence.json`
contains source/ELF hashes, probe diffs, raw outcomes, and cleanup inventory.
`-arrays.npz` retains exact probe snapshots, numeric outputs/cache, and vanilla
records. `-runs.log` retains the relevant command output and queue-rebind
counterexample. No performance claim is derived from simulator wall time.
