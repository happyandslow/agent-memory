# Claude Code review and disposition: LayoutC routing plan

Date: 2026-09-13. Scope: documents only. No source/configuration/tracker edits,
compiler runs, simulator runs or device tests.

[Implementation plan](/home/lexu/wse3-performance-model/docs/plans/2026-09-13-layoutC-full-model-routing-allocation.md).

## Review provenance

The first two completed Claude Code reviews examined revision 1, SHA256
`dcb43a968f6e2a3d94fdc6aba766d4f0efc3841027c3968e60e374026fcb53f0`.
The first used only Read/Glob/Grep against the plan, source and SDK checkout;
it completed 38 turns with zero permission denials. The second was a bounded
single-response review of the full plan plus numbered critical source excerpts.
Both ran with customizations/hooks/MCP disabled and no write/command tools.
Their application-level error flags were false. Neither performed compilation
or hardware validation. The long first review completed; it was not replaced
by a connectivity check. A separate one-word connectivity check is not counted
as a review.

## Disposition incorporated into revisions 2 and 3

| Finding | Resolution / remaining scope |
|---|---|
| Neighbor-source collision from an out-of-group sentinel terminal | Accepted. Final target remains pointed into its row; final tail is ROW_DONE then STREAM_END with no final TARGET_ADV. Every receiver consumes the control event; the designated last-column receiver initiates terminal bookkeeping. Test this new terminal behavior before integration. |
| Head overlapping source/target zones cannot use the demonstrated guard protocol | Accepted. Select fenced fragment epochs with router-only payload transit for initial H correctness. Preserve diagonal Head senders. Keep intraregion Head resharding as an optimization alternative; do not silently add a corridor CE payload collector. |
| A3 supposedly needs a third output mode | Corrected. Each group has exactly local+exit output: G0–2 U/D, G3 U/B, G4–6 D/U, G7 D/T. Use two fixed payload OQs and a separate R OQ. |
| Two-pass R needed because A1 lacks a START IQ | Corrected. START goes to A3 IQ2 on C15; A1 computes from local readiness and arms next receive after consumers finish. Keep a single completion/reset pass. |
| R topology/per-frame scheduling omitted | Specify parallel row acknowledgments, strip aggregation and router-only return; replace monolithic loops with per-frame scheduling and asynchronous source sends in future implementation. Add C23 as the third R color: a static row/vertical CE merge cannot assume the reviewer’s two-color proposal suffices for both receives and onward injection. |
| Last-column receiver alone proves all recipients complete | **Not accepted.** It does not prove every other CE consumed input or released its buffer. Keep an acknowledgment predicate at every A1 receiver. |
| K21 row reset / full write acknowledgment missing | Add one counted bootstrap RESET_K word on existing C16, a C5/C7 A2 ACK chain into injector IQ5, input restoration before ACK, output-flush/local compute gate, and separate C22 injector reset closure. All are proposed, not measured. |
| Request metadata has no assigned path | Choose typed CONFIG records on the control plane. Reserve A1/A3 C19 bus + R row chains, A2 K metadata, Head IQ2/C7, Tail IQ7/C19. Explicitly require complete controller/credit/mux-header traces before external integration. |
| Init-time Head/Tail queue rebind language | Corrected to compile-time color parameters plus matching route paint. |
| C7 color/queue wording | Corrected: tall collectives are C0–4 on IQ/OQ3–7. |
| Bounded review could not verify inactive legacy paints | The full source-reading review verified external_io and UNUSED route skips. Keep the generated-map assertion as a future compilation gate. |
| Bounded review omits straight exit colors for G0–2/G4–6 | Not accepted; corrected by the explicit fixed-output table. |
| Proposed generic token-count bound | Not accepted as a proof. Initial correctness scope is one model token/request context at a time; multi-request credit scheduling is outside this plan’s validation claim. |
| CENTER combined injector/R program | Accepted. Explicit combined IQ/OQ ownership; task-table and source hashes belong to the manifest. |

## Follow-up review and final disposition

A third completed, tool-free Claude Code review examined revision 2. It found
R topology and queue ownership consistent and requested corrections to K-ACK
predicates, the C22 return/acknowledgment route, old Head rebind wording, C7
producer ownership, the CONFIG bus reservation and the H control network.
Revision 3 incorporates those findings:

- K ACK now has one explicit conjunction: own stores, RESET_K, C21 clear and
  upstream ACK; restore IQ0/IQ1 before forwarding, then flush/restore OQ0 before
  local compute can run.
- C22 return paths are specified. K_REARM reuses fenced per-group R aggregation,
  adds an EAST return in column646, and returns four counted K_READY records per
  side on C13 to adaptor IQ6. C13 gathering is an unvalidated control protocol
  using the agreed upstream-first switches; it is not measured evidence.
- CONFIG roots/rightmost-column buses and service queues are listed. Tail's
  existing per-column token-source PEs are the sole C7 injectors. Head control
  fields use SDK-supported 16-bit arguments, not arbitrary u32 payloads.
- H request C14 and response C11 connect the service PE to the G0 root; strip
  route updates reuse R in a separate H phase. Tail credit handlers cannot block
  on the Z whose production needs their credit. H fragment receipt ACK precedes
  the row's collective; full-frame buffer reuse remains a separate predicate.
- Physical direction alone no longer determines half offsets: mirrored local
  D and non-mirrored local U use16/0; straight inter-group streams use0/16.

These are post-review corrections and explicit resource reservations, not a
claim that Claude compiled or independently revalidated revision 3. The
remaining status is **reviewed planning complete; full-model allocation and
protocol validation remain open**. The first-group manifest is the next bounded
implementation task. No implementation began in this session.

## Remaining gates

The plan is a reviewed options/implementation document, **not a closed full-model
allocation**. First-group manifest and f16 protocol validation are next. New
in-row termination, R hierarchy and source-credit handling require testing.
H endpoint-control trace, full-column control composition, CONFIG/credit/mux
header acknowledgments, exact host-port IDs, and linked SRAM remain external
integration gates. Complete group correctness precedes their integration.

## First review: verbatim findings

I've finished reading; writing the review now.

# Review: LayoutC full-model communication plan

**Verdict.** (a) First-group planning is ready to move to the manifest/checker step after three corrections below. (b) Full-model allocation is not closed: two geometry-level problems and one unbudgeted data path must be resolved before the plan can claim all external components are budgeted.

## Findings

**1. High, blocks (b). Local-feedback stream terminals collide with the neighbouring group's first source junction on the same color.**
Plan: `/home/lexu/wse3-performance-model/docs/plans/2026-09-13-layoutC-full-model-routing-allocation.md:170` and protocol report `/home/lexu/wse3-performance-model/docs/reports/2026-09-12-layoutc-marker-reset-verification.md:80` require STREAM_END to end at "a dedicated terminal PE beyond the target zone". Groups are stacked with no gap between one group's last A3 row and the next group's first A1 row, per the diagram JSON. The terminal cell therefore lands on a junction that already has a switch on the same color:

| Stream | Terminal cell | Existing claim on that cell |
|---|---|---|
| G1 local U16 | `(131,257)` | G0 U16 first source, rx EAST to NORTH |
| G2 local U16 | `(131,513)` | G1 U16 first source |
| G3 local U16 | `(131,769)` | G2 U16 first source |
| G5 local D17 | `(388,770)` | G4 D17 first source |
| G6 local D17 | `(388,514)` | G5 D17 first source |
| G7 local D17 | `(388,258)` | G6 D17 first source |

A routing position is one input set fanned to one output set, so rx SOUTH to RAMP cannot coexist with rx EAST to NORTH on one color at one cell. Inter-group D17/U16, B5 and T12 terminals fall in gap rows or corridors and are fine.
Correction: end every stream inside its last destination row. The final source tail becomes ROW_DONE then STREAM_END with no final TARGET_ADV, the last target junction stays at pos0, and a designated PE of the last A1 row acts as terminal and R initiator. This needs no extra queue, since A1 rows already take ROW_DONE as a control task on the same IQ. Adopt it in the first-group test so the group shape matches the full model.

**2. High, blocks (b). Option 1 for H hides an impossible assumption for Head rows 0 to 79.**
Plan `:240-246` prefers a single continuous C6 stream with a generated junction trace. Under the documented pop semantics at `/home/lexu/CSL-Demo-Code/versions/v2.10/Cerebras_Docs/csl/language/builtins.md:3525-3532` this cannot work for the overlapping part:
- Every junction at `y=2..81` is an A1 target. Every target except row 0 is traversed after service by later markers of the same stream, so it must be pop_on_advance. An always_pop junction there would execute and consume the leading command of every later wavelet.
- A TARGET_ADV from an in-zone Head source must pass served junctions in pass state and arrive at the current target with ADV leading. A leading NOP passes them but is never stripped. A leading ADV advances the first served junction into its inject position, which is a false grant. Counting NOPs needs one per junction crossed, up to about 55, against MAX_CMDS of 8 in `/home/lexu/CSL-Demo-Code/versions/v2.10/source-code/csl_libraries/control.csl:82`.
- A Head-internal detour cannot fix ordering: an in-band grant only flows downstream, so any detour column delivers ascending features, while the northbound target order needs descending.
Head rows 80 to 255 feeding A1 rows 25 to 79 are a clean instance of the verified disjoint-zone protocol, with the always_pop boundary at `(131,82)`.
Correction: rescope option 1 to Head rows 80 to 255 now. For rows 0 to 79, decide between option 2 with CE-hop endpoint control on `x=131, y=2..26`, and a two-PE staging relay in the north corridor at `(132,0)` and `(132,1)` running three sequential C6 streams: out-of-zone rows to A1, in-zone rows north into the corridor, then corridor south into A1 rows 0 to 24. The second reuses the verified protocol three times and needs four switch positions on `y=0..26`, but it is a CE payload relay for 800 of 2560 features and so needs the explicit decision the plan already names for option 3. T and B are correctly scoped: source and target zones are disjoint and the stream orders I derived are monotone.

**3. Medium, affects (a) and (b). The two-pass R premise is wrong; the validated structure fits without a fourth A1 IQ.**
Plan `:178-191` replaces the prototype's START broadcast with a second ring pass because "A1 has no fourth free IQ". In the prototype, `/home/lexu/.cache/layoutc-marker-reset-20260912/pe.csl:92-98`, START is acted on only by sources. Destinations are armed by the reset pass alone, which the plan itself states at `:189`. A3 has spare IQ2 per plan `:148` and `tall_stage.csl:251-252`. Head is gated by token admission already.
Correction: keep the verified single reset pass and send START as a static tree into A3 IQ2 on a non-switch color such as the freed C15. This deletes the "new and unvalidated" two-pass protocol and halves ring latency. Two related gaps should be fixed in the same step: the plan never states the R topology, and a single snake over about 30,000 PEs per group is not a viable design even for correctness testing, so specify per-row chains in parallel plus one strip chain on the same C18/C19 pair. Also, A1 and A3 run the whole decode inside one synchronous task at `/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:176` and `:223`, so R and per-wavelet receive tasks cannot run mid-frame; step 3 of §8 must restructure main into per-frame activations.

**4. Medium, affects (a). A3 needs two fixed payload OQs, not a per-layer rebind.**
Plan `:148` rejects two fixed OQs because a "third G7 exit mode" would be needed. Every group's A3 emits exactly two colors: local plus exit. G7 emits D17 and T12 and never emits U16, which is its input. With OQ0 for R, binding OQ1 and OQ2 to the two colors removes the output-empty callback from the hot path required by the row at `:203`.

**5. Medium, blocks (b). Request-scope metadata has no assigned path.**
Tail receives its step-budget header on the Z drain at `/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/ht_tail.csl:181-185`; T12 replaces that drain with an ordered switch stream from G7 A3, which has no header source. A1 derives its RoPE base from the prefill length at `/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:394-405`, which today arrives with KV metadata; K21 terminates in A2 per plan `:115`. Plan `:285-289` lists "length header" as an external task without a path.
Correction: carry a one-word per-request header in-band as the first word of the first frame on H6 and forward it as the first word of each U/D/B/T frame, or carry it in the R word, which is already CE-relayed. Pick one and add it to the manifest and to the count/ROW_DONE predicates.

**6. Low. Pop modes are under-described.** Report `:9-13` and plan `:169` describe two modes; the SDK defines no_pop, always_pop, pop_on_advance and pop_on_advance_nop. The checker in §8 step 1 should pin pop_mode per junction and reject pop_on_advance_nop on pass junctions, since it would strip TARGET_ADV's guard NOP at the first pass junction.

**7. Low. Unnecessary runtime rebinds.** Head's post-embed color is a launcher parameter at `/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/ht_head.csl:47` and `:462`, and Tail's Z drain color at `ht_tail.csl:1432`. Set them to 6 and 12 at compile time instead of the rebinds at plan `:150-151`. Also, plan `:118` says "compute collective C7 queues"; tall collectives are C0 to C4 on IQ/OQ 3 to 7, so this conflates color 7 with queue 7.

## Positives verified against source

- A1 OQ reuse rule is correct: the sender predicate at `tall_stage.csl:183-185` and routes at `launch_tall.py:165-171` show C9 has no route at H0 senders and C8 only transits at H1 senders, so binding the non-sending OQ to R is clean. Both OQ0 and OQ1 are free on the 10,112 non-sender PEs.
- A1 IQ0 to IQ2, A3 IQ1/IQ2 and OQ0/OQ1 are genuinely free: `comm_pe.csl:1702-1724` skips those initializations under external I/O, and `route_util.csl:91-95` skips UNUSED route entries, so legacy C5/C6/C7 are not written at boot.
- C16 spatial separation holds: A2's last column is WEST to RAMP at `launch_tall.py:237-247`, and the A2 edge has no WEST input.
- Mirrored indexing is consistent for A1, A2 and A3, for the C14 Z hand-off row, and for the B example; U, D, T and predecessor stream orders are monotone under the stated maps.
- Head and Tail queue inventories, injector and adaptor queue namespaces, and the switch-capable ID list match source and SDK.
- A2 bootstrap on IQ0 is consistent with the C8/C9 routes; only root PEs ever receive on IQ0, and K21 westbound uses different colors from all A2 row routes.

## Unverified scope

- The K-feed link from the service reserve to the north corridor is unnamed; it needs either static C20 transit on `x=131` or the host columns. Not checked.
- Host, demux and mux stream IDs remain a manifest output, as the plan states.
- Per-PE SRAM for the A1 frame buffer, the A2 KV bootstrap staging, and the injector row buffers was not assessed.
- Everything above is analytical against the cited source and SDK text. No compile, simulator or device evidence exists for any full-model route, and the in-row terminal, START tree and H rescoping proposed here are unvalidated changes to be tested at §8 step 2.

## Bounded review: verbatim findings

# Review: LayoutC full-model communication plan (rev. draft 1)

**Verdict, first group (G0 alone: U16 feedback, R ring, A1/A2/A3 compute):** usable as a planning baseline once findings 1, 3, 5 and 6 are folded in. No hard color collision exists inside a single group.

**Verdict, full-model closure:** not closed. The H mechanism as "preferred" cannot be implemented with the verified switch semantics (finding 2), the local-feedback terminals of six groups land on a neighbor's source junction (finding 1), and the K-scatter reset is undefined (finding 4).

## P1 findings

**1. Same-color terminal overrun between adjacent groups.** The verified protocol parks STREAM_END "in a dedicated terminal PE beyond the target zone." For local feedback that PE is outside the group. G1's U16 target zone ends at y=258; its terminal is y=257, which is G0's first U16 source junction on WEST, parked at pos1 (accept EAST) with no from-south path. Same for G2/G3 on WEST and for D17 local feedback in G5/G6/G7 on CENTER (terminals at y=770, 514, 258 hit the northern neighbor's A3 source rows). Only G0 (terminal in the north corridor) and G4 (bottom corridor) survive. Predecessor links (D17 G0→G1 etc., U16 G4→G5) are fine because their terminals fall in the next group's spare rows.
*Correction:* make the last target junction absorb. Its pos1 becomes strip→RAMP instead of pass, so STREAM_END is delivered to that strip CE and no stream ever leaves its group's y-range. Apply the same rule to B, H, T. This also gives the manifest a hard check: no U/D/B/H/T route may cross a group boundary except on its declared bridge segment.

**2. H "preferred direction 1" is not implementable.** The report's semantics are: each junction inspects only the first command, pops only on advance, and the single always_pop final source strips the NOP so ADV is exposed only in the target zone. H is purely northbound (target row 10y'/32 ≤ y'), but sources y'=0..79 sit on the same WEST junctions as targets 0..79. Each such junction needs turn→pass→accept→pass, and a TARGET_ADV from source y' must cross up to ~50 junctions in pass state that must later advance again. There is no place for an always_pop junction that serves all of them; splitting into disjoint-zone lanes recurses (255→80→25→8→3→1) and costs about six switch-capable colors. The plan's own caveat ("cannot copy unchanged") understates this: the mechanism has no command-consumption trace that can work.
*Correction:* pick one of two concrete mechanisms now. (a) Re-shard inside Head using its existing UP/DOWN vertical network (IQ4–7, OQ3/4/6/7 on C21/22 and C8/9) so Head's east column emits 32-element rows already aligned to physical y=2..81; H then becomes row-straight links with no strip switches, and C6 needs only WEST→EAST turns at x=131. (b) Alternative 2 (fenced epochs with control-network reconfiguration). Either way, Head OQ2 cannot be "rebound at initialization": `post_embed_x_color` is the parameter that paints the RAMP→EAST/WEST→EAST routes at ht_head.csl:300–305, so the color must change as a compile parameter, not a runtime queue rebind.

**3. C5/C6/C7 inside compute rectangles are unverified.** comm_pe.csl:1702 and :1719 skip the intra-row (C5) and inter-block (C6/C7) queue bindings under `!external_io`, but tall_stage.csl passes `external_schedule = true` (line 32) and still passes `intra_row_bcast_color = 5`, `inter_block_a/b_color = 6/7` (lines 52–53). Nothing in the cited evidence shows that decode.csl/route_calc suppress painting those routes. B=C5 must enter every G4 A1 row and H=C6 every G0 A1 row; Tail→Head C7 crosses x3–130 only, but if A1 also paints C7 the manifest must prove no shared PE. Gate: dump the generated routes of one A1 image under the external schedule and assert C5/C6/C7 absent, and confirm `external_schedule` maps to `external_io`.

**4. K-scatter C21 has no reset or terminal path.** Per-column switches (pos0 take, pos1 forward) stay at pos1 until the whole row is delivered, so 127 columns need a clearing word after the last column's terminal marker. R excludes A2, and the existing ingress machinery (T29 handler, IQ7 rebind, comm_pe.csl:1687–1692) is compiled out under `external_io`, so K is a full replacement, not a reuse. The A2 CE cannot self-clear because it cannot observe the row completing.
*Correction:* use the already-painted C16 X-row route (edge OQ2 → non-edge IQ2) for one extent-1 bootstrap word before the first X frame. Every A2 PE receives it with an explicit one-wavelet DSD, calls `clear_current_position(C21)`, then restores IQ0 to C8/C9. This keeps the exact-count invariant on C16 and needs no new color or queue.

## P2 findings

**5. A3 OQ2 per-token rebinding is unnecessary.** No group needs three payload colors: G0–G2 use U16 only, G3 U16+B5, G4–G6 D17 only, G7 D17+T12. The "third G7 exit mode" statement is wrong. Bind OQ1 to the exit color and OQ2 to the local color at comptime, keep OQ0 for R, and delete the flush/empty-callback path and its "no active DSD" hazard on 160 PEs per group per token.

**6. R ring membership is undefined and, as written, on the critical path with ~30k hops.** Only three classes of nodes hold state that must be reset: strip junction routers, column-0 A3 sources, and the last-column A1 receiver of each row (the last CE to see the multicast; its count==32 plus ROW_DONE proves the row's wavelets left the strip). Interior A1 PEs are protected by IQ FIFO and router backpressure, never overwritten, as the plan's "buffered, not overwritten" sentence already says. Visit ~500 nodes, not 30k. Interior PEs then need no R queue at all; they trigger on count and ROW_DONE.

**7. Pass-1 ordering must be stated.** Strip CEs cannot observe their router. Order per stream: terminal (STREAM_END received) → each row's last-column receiver → that row's target junction → source junctions (after their own send flush) → root. This mirrors the verified snake; the plan's "visits source, target and strip nodes" leaves the order open.

**8. "Arm before admit" vs "buffered" are both stated; pick one.** With pass 1 fully complete before pass 2, destinations are armed and buffering is only a safety margin. But predecessor streams (D17, U16 cross-group) are not fenced by the receiving group's ring. A stalled receiver back-pressures the sending A3's synchronous `@fmovh`, which then cannot forward its own group's R word. Around the eight-group loop plus Tail/Head this is a classic pipeline deadlock unless in-flight tokens are credit-limited. Define the credit (tokens in flight ≤ groups minus one is the conservative bound).

**9. CENTER strip PEs run two roles in one image.** Injector (IQ2/3, OQ3/4, local tasks 8–15 at kv_ingress_injector.csl:73–80) and R relay (IQ0/OQ0) must share one program; task 8 is `emit_scatter` there, not main. Enumerate the merged task table in the manifest.

**10. T is structurally sound but Tail-side handling is thin.** Sources t=0..159 on CENTER (y=161 down to 2) and targets Tail rows 0..255 on WEST are disjoint with consistent order; the mid-source TARGET_ADV for rows split three ways (t=1 → rows 1,2,3) works under first-command semantics. Tail IQ0 today drains one multicast result; it now needs per-row 10-element frames with offsets, a ROW_DONE control entry, and a fence against the ysafe/collective phases (ht_tail.csl:343–355). Reserve IQ7 for the completion handshake now rather than "if required".

## Confirmed as consistent

- Mirrored row mapping matches `a3_origin = a2_height − a3_height` (A2 row 96+t ↔ A3 row t) in both orientations; A1→A2 edge rows stay physically aligned.
- B index example (G3 rows 0/1 → G4 y=1025) checks out; the final-source guard at y=1025 on WEST precedes all CENTER targets.
- Existing queue table matches tall_stage.csl:238–253, ht_head.csl:96–112, ht_tail.csl:158–173 and :1432–1449. Tail IQ7 is genuinely unclaimed.
- A2 C16 and bridge C16 coexist only if the x=387 (and x=644) route is WEST→RAMP with no EAST; keep that as a manifest assertion.
- C18/C19 for R never enter Head or Tail; Tail logits C18 and Head pre-embed C18 stay inside x≤130.

## What the first-group patch may take as settled

U16 on IQ0, R on IQ2 plus the non-sending QKV OQ, A3 two fixed payload OQs, ring restricted per finding 6, terminal-at-last-target per finding 1, and the C5/6/7 route gate from finding 3 as the first manifest check. H, T, B and K remain design items, not blockers, provided the H decision (finding 2) is made before any Head work starts.


## Follow-up review: verbatim findings on revision 2

**R topology and queue ownership: consistent.** With column 127 starting each chain on C18, a 128-hop row ends at column 0 on C19 for A1 rows, and A3 column 0 as sole ACK sender also emits C19, so strip IQ0=C19 holds. The 256-node even strip gives root OQ0=C18, top OQ0=C23, root IQ1=C23 from the x=132 return, and no WEST router carries one color in two conflicting directions. One gap, not a contradiction: the "rightmost-column C19 bus" is a new static vertical route on x=259 (x=516 mirrored) that transits upstream groups, and it is absent from the §3 route table.

**K-ACK bootstrap: three contradictions.**

- **IQ0 restore has two triggers.** §7 bullet 2 restores IQ0 when the RESET_K word is consumed; bullet 3 restores it only after own K data and ACK input are consumed. State one predicate (both conditions).
- **ACK does not prove C21 clear.** RESET_K rides C16 router multicast; the ACK is a CE relay on C5/C7. They are unordered across colors, and the ACK-forward predicate never mentions RESET_K or C21 clear. So "injector waits for all row ACKs before declaring K ingress complete" does not imply every column switch is cleared, and nothing else acknowledges it. Gate ACK forwarding on RESET_K consumed, C21 cleared, IQ0/IQ1 restored.
- **C22 route and reset acknowledgments.** §3 claims K-reset on "CENTER/EAST/service" only, but the left adaptor at (130,515) is reachable from CENTER only via WEST or a corridor, which §7 claims for C20 and not C22. READY also requires "injector switch-reset acknowledgments" that have no color or queue anywhere.

**Old-text contradictions.**

- **Head OQ2.** §2 says rebind at initialization; §4 says compile-time parameter with route paint. Pick one.
- **Head IQ2 C7 ordering.** §3 relies on "ordered task dispatch" on OQ7→IQ2, which assumes one producer (Tail). §7 adds controller-injected credits for forced mode, first-token admission, and per-fragment H credits. Two producers on one ordered queue, with no stated ordering.
- **H control network unassigned.** §6 says H has reserved resources, but the network that reconfigures WEST C6 endpoints per fragment has no color or strip IQ in §3/§4, and strip IQ0–5 are all claimed. Reusing the idle R vertical chain during H is plausible but unstated.

**Verdict.** The revision closes the prior findings. R now allocates cleanly for the first group. Before the first-group manifest, fix the K-ACK predicate and the two Head items. The C19 bus, C22 return route, and H control queue are resource claims the plan must state explicitly rather than defer.


## Final document and no-code-change validation

Review line references in verbatim sections refer to the reviewed draft, not the final document line numbers.

- Revision 2 supplied to follow-up SHA256: `ae126eb04a4c40ba21bfb5d565ac3497dce6dac520aca4bc0d3c65a8a5d8878f`.
- Final revision 3 plan SHA256: `4c4e47becb493599543149a238faac81e07f131ef5d7352383fc21f4ac674ca2`.
- Absolute linked paths/line bounds and trailing-whitespace checks passed for both documents.
- Analytical interval checks: 160 (16→32), 320 (10→32), 384 (16→10) fragments; each mapping covers all 2560 features exactly once, with even fragment lengths.
- All 160 G3 source-row intersections map to the 80 mirrored G4 destination rows under the proposed coordinates. Six outside-target terminal collisions were confirmed analytically. These checks do not execute a router state machine.
- All 449 protected source/configuration/tracker files and their file set match the pre-write snapshot. No compiler, simulator, hardware, performance or end-to-end correctness test ran.
- agent-memory preflight passed. One compact inbox capture records only the conditional stacked-group terminal collision and its evidence limits; no generated view or tracker was edited.
- Work repo: 7 pre-existing unstaged tracked modifications, 54 collapsed untracked entries, 0 staged. Memory: 7 untracked entries (one new capture), no tracked modification or staged entry. SDK evidence repo: 2 pre-existing untracked entries, no tracked/staged modifications. No Git mutation was performed.
