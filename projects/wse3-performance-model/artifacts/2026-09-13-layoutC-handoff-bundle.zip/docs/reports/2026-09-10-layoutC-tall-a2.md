# Layout C: full-height A2 miniature and rebuilt stage transfers

2026-09-10. Implemented and validated in **SDK 2.10.0 local simfab**, BF16,
one layer, batch 1, hidden 64, attention 128, KV width 32, FFN 128,
8 Q heads / 2 KV heads, head dimension 16, prefix 16, capacity 64.
Weights and boundary inputs are deterministic synthetic fixtures (seed 910),
not Qwen3-4B pretrained weights. No hardware or performance result is claimed.

## Implemented geometry

The new [launcher](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:67)
places the following regions. The compiler placement agrees with these bounds.

| Region | Fabric x, inclusive | Fabric y, inclusive | Size |
|---|---|---|---|
| A1 | 2..9 | 1..8 | 8 x 8 |
| A2 | 10..17 | 1..16 | 8 x 16 |
| A3 | 2..9 | 9..16 | 8 x 8 |
| Boundary output collector | 1 | 9..16 | 1 x 8 |
| SDK output adaptor | 0 | 0 | 1 x 1 |

The core has 256 PEs, no relay quadrant, and no overlap. This scales Le's
256x256 target: A1/A3 share the 128-wide left half; A2 occupies the entire
128x256 right half. It does not implement the older 80/256/160 height proposal.
The [editable diagram](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-10-layoutC-tall-a2.excalidraw)
has adjacent SVG/PNG exports. The old sim_cut3 diagram remains historical.

## Data ownership and communication

- **QKV:** local column c in A1 maps to local column c in A2. A1's diagonal
  PE (c,c) forwards its 24-value QKV shard east to the A1 boundary. A2 row c
  receives that shard horizontally; only PE (c,c) redistributes it along the
  entire A2 column. See [transfer schedule](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:110)
  and [static routes](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:79).
  A1 completes K normalization/RoPE on every row before diagonal selection;
  that replicated work is explicit in [decode.csl](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1860).
- **Residual X:** A1 row r owns features [8r,8r+8). A2 row r keeps its first
  four features; a southward shift sends its last four to row 8+r.
- **Z:** after attention/O-projection, the same shift moves the upper four
  features to row 8+r, which concatenates its own lower four. The leftmost
  A2 PE sends all eight west to A3 row r. See [shift primitive](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:84)
  and [X/Z schedule](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:136).
  The [O-weight packing](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/tall_fixture.py:51)
  uses this interleaved row ownership, not contiguous `row * 4` features.
- **KV:** cache positions are round-robin over all 16 A2 rows. Prefix 16
  gives one initial slot per PE; decode positions 16..32 exercise every row
  and then wrap to row 0. Prefix data is **baked into the test image**;
  this does not validate an actual prefill ingress transport.

[Region-local coordinate tables](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:27)
keep A2 Y in 0..15. The wrapper passes height 16 and independent Y collective
groups/roots to the existing math kernel; it does not reuse the legacy
serpentine coordinate decomposition.

Queue ownership is explicit: the new wrapper uses queues 0..2; existing
collectives retain queues 3..7. New transfers do not rebind queues. Colors
0..4 serve collectives; 8 is the A1 diagonal seam; 10 carries QKV/X east;
11 distributes QKV vertically; 12/13 alternate down the X/Z shift;
14 carries Z west; 15 carries the A3 boundary result. The shift forwards
exact counts using fabric-to-fabric transfers of four BF16 elements and an
eight-element local X/Z staging buffer, with no long-span SRAM queue.
See [bindings](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:166)
and [legacy I/O suppression](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/comm_lib/comm_pe.csl:1702).

The `csl-color-audit` automatic probe did not validate this entry: its default
config discovery failed, and its launcher probe targets the legacy launch.py.
The queue/route account above comes from manual source inspection plus actual
compiler/simulator runs, not a passing automated color audit.

## Validation

The numerical reference operates on unsharded full tensors using the existing
BF16 scalar arithmetic model. It shares fixture weights, but not PE packing
or communication. Output and appended-cache gates require relative L2 < 2%
and maximum absolute error < 0.05; prefix and unused cache regions must match
bit-for-bit. All 128 A2 PEs are read after simulator stop, with no new device
probe symbols or diagnostic branches.

| Case | Result | Output relative L2 | Maximum absolute error |
|---|---|---:|---:|
| First 2-step bring-up | PASS (output only) | 0.004977 | 0.0078125 |
| Final 17-step run | PASS (output + cache) | 0.005753 | 0.015625 |
| Injected QKV column collapse, 2 steps | FAIL as required | 0.662295 | 1.7734375 |

For the final run, K append relative L2 is 0.001909 (max 0.015625); V append
is identical to the reference. Prefix and unused regions are exact. The
negative control changes every A2 column's vertical source from row c to
row 7, reproducing repeated-column QKV without changing the prefill fixture.
It preserves prefix/unused regions but fails K/V append and output checks.
The injected source exists only in a disposable copy and is removed afterward.

The legacy vanilla model/request also passes; its three D2H arrays are
bit-identical to the pre-change baseline preserved in the KV-fix evidence.
This covers the default-false external scheduler/I/O flags.

Four distinct linked compute images are present: A1, A2 even rows, A2 odd
rows, and A3. This is stage specialization, not proof of complete ownership
cleanup: sampled A2/A3 images still contain 4-byte `cos_cur_f32` placeholders
and 2-byte non-owned weight placeholders. The complete SRAM audit remains open.

Reproduce the final positive case from the code directory:

```bash
SINGULARITYENV_CSL_SUPPRESS_SIMFAB_TRACE=1 timeout 180 \
  cs_python launch_tall.py --steps 17 --output out_tall_reproduce
```

[Evidence JSON](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-tall-a2-evidence.json)
records source hashes, exact negative intervention, compiler placement, image
identities, metrics, and cleanup. [Raw arrays](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-tall-a2-arrays.npz)
and [run logs](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-tall-a2-runs.log)
preserve the observations after disposable binaries/cores are removed.

## Current boundary and next task

The target geometry and **single-layer QKV/X/Z stage transfers** have passed
their miniature gates. The full A1/A2/A3 group gate is still open.

1. Add real prefill KV ingress to the full-height A2 region and validate
   reset/rearm against the baked-fixture baseline.
2. Implement A3-to-A1 local feedback and layer-bank selection; validate at
   least two local layers before claiming group correctness.
3. Remove non-owned buffers/exports, resolve the pre-existing A3 D-cache
   probe, and check full-model dimensions, linked SRAM, and context capacity.
4. Only after the complete group gate: inter-group/head-tail wiring, then
   full 4B on-chip end-to-end performance testing.

The current fixture entry is fixed to miniature batch 1, prefix 16, and
capacity 64; it accepts 1..48 forced embedding steps. It has no autoregressive
feedback, head/tail kernel, reset/rearm protocol, or performance timer.
