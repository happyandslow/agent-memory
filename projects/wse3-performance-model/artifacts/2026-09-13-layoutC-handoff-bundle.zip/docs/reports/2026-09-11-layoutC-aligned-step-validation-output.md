# LayoutC aligned-step validation — Output, 2026-09-11

## Result and evidence boundary

The user's proposed separation is useful: **make the logical output of each order-sensitive step identical, then compare the subsequent computation before the next such step can overwrite or hide its error**. This task implemented and executed that intervention offline. It does not change the production operator or demand that different reduction trees produce identical native results.

For integer and random synthetic full-size 4B single-layer fixtures, 33 steps each, both square128 and tall128 pass **6,668 deterministic checkpoint instances / 5,804,436 checked values per comparison**, bit for bit, after alignment to upstream256. There are four aligned comparisons in total. Checks include intermediate inputs and outputs; this value count is not a count of independent experiments. A deliberate BF16 bit flip in SwiGLU is rejected **before** the subsequent DOWN-output injection, demonstrating that a later replacement cannot turn that failed intermediate check into a pass.

This is **analytical CPU evidence**, not a new on-device aligned-input experiment. The new instrumentation also runs with replacement disabled: all six native model outputs (three geometries × two fixtures) remain bitwise identical to the existing CS-3 output arrays. This anchors the calculation to prior measurements but does not independently certify compiled transport or each device intermediate. The underlying arithmetic helpers are shared source-derived diagnostic models, not an independent implementation of the operators.

No numerical threshold changed. Native tall/upstream output equality is not the new requirement. Original operators remain unchanged; the canonical-value replacement exists only in this diagnostic.

## Inputs and provenance

- Work repository inspected at `38ac5b7a7d999689fe472c766e233fe545502c95`, branch `main`, origin `https://github.com/happyandslow/wse3-performance-model.git`. Seven existing tracked unstaged modifications and unrelated untracked files were preserved.
- Pinned original 4B reference: `happyandslow/WaferEngine`, commit `b136ab64b3f5575c72fb722fb972ef5c77f4c9fe`, `models/qwen3_4b-decode`. Identity and prior hardware jobs are in the [upstream attribution report](/home/lexu/wse3-performance-model/docs/reports/2026-09-11-layoutC-upstream-numerical-attribution.md:16).
- Prior reproduction archive SHA-256: `b1988bb4a260fc42763ed16c5ac34a620b511ad2ac2ece1a4801757feb6d4d09`. The new archive freezes the analysis helpers, final prediction arrays, measured arrays, and audited source sites used here.
- Logical dimensions: hidden 2560, attention 4096, KV 1024, head 128, FFN 9728, batch 1, one layer, prefill 1280, capacity 1536, 33 supplied independent input embeddings. Integer-valued BF16 seed 911 and random BF16 seed 910 match the prior fixtures. No trained checkpoint or autoregressive embedding feedback is used.
- Upstream: 256×256 ATTN beside 256×256 FFN. Square control: 128×128 beside 128×128. Tall: A1 128×80, A2 128×256, A3 128×160, A3 origin row 96. All arithmetic models use 16 PEs per reduction group, matching the successful prior hardware controls.
- No new CS-3 job, simulator run, or performance measurement was submitted by this subtask.

## Which boundaries need alignment

Local partial sum length and fabric reduction length must be treated together. Replacing only the final all-reduce tree without accounting for the changed local accumulation is insufficient. The intervention records a **global logical FP32 tensor**, then supplies those same values to both layouts at the boundary. Real-device replay would repartition this tensor into each layout's own PE buffers; it must not reuse physical offsets from the other layout.

| Boundary | Upstream256 → tall128 change | Canonical value to supply | Deterministic work checked before the next replacement |
|---|---|---|---|
| Input RMS sum and Q/K/V projections | Hidden terms per A1 PE 10 → 32; Y participants 256 → 80 | Global FP32 sumsq and Q/K/V projection outputs, before fused scale/cast | rsqrt, scale, BF16 cast; weighted input checked separately |
| Q/K head norm | Four → eight head features per PE; head-band participants 32 → 16 | Per-head FP32 sumsq | rsqrt, normalization, cast, norm-weight multiply |
| RoPE state | Startup stride 256 → 80; prefill recurrence 5 → 16 iterations | Same FP32 sin/cos state at each token | BF16 pair products and add/subtract, Q/K logical output |
| Attention QK score | Four → eight terms per head-band PE; participants 32 → 16 | FP32 score for every live logical position | max subtraction, scale, approximate exp, BF16 exponential cast |
| Attention numerator and denominator | A2 remains height 256; same local sequence distribution in this tall comparison | FP32 unnormalized value sum and FP32 exponential sum | approximate reciprocal, multiply, BF16 attention output |
| O projection | 16 → 32 attention features per PE; X participants 256 → 128 | Global FP32 O projection output | BF16 cast and addition to the identical residual X |
| FFN RMS, UP/GATE projections | Hidden terms per A3 PE 10 → 16; Y participants 256 → 160 | FP32 sumsq, UP, GATE before scale/cast | rsqrt, scale, BF16 casts, original polynomial SiLU, SwiGLU multiply |
| DOWN projection | FFN terms per PE 38 → 76; X participants 256 → 128 | Global FP32 DOWN output | BF16 cast and residual Z addition |

The source implementation sites are:

- [Input RMS and weighted input](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1094), [QKV local GEMV](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1160), [fused reduction then scale/cast](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1849).
- [Q/K local sum](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1283), [head-scoped collective](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1350), [post-sum normalization](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1311).
- [RoPE initialization](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:837), [token advance](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:760), [rotation arithmetic](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1212).
- [Score computation](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1419), [softmax max/exp/sum](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1557), [value numerator/denominator collective](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1609), [O projection and residual](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1663).
- [FFN fused norm scale](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1689), [UP/GATE local GEMV](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1705), [SiLU](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1717), [SwiGLU/DOWN/residual](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1744).

For finite fixture values the maximum reduction selects the same maximum independent of parenthesization. The diagnostic therefore checks its downstream result without replacing max separately. NaNs, signed-zero selection rules, and other untested edge cases are not covered.

## Executed aligned replay

Each layout first performs its own local partial sums and reduction order. The script records the mismatch against the upstream checkpoint **before** replacing that sensitive result. It then runs and checks the remaining arithmetic. Entire layer outputs are never replaced. QKV, Z, and Y are comparison points, not injected final answers. Missing or duplicated checkpoint calls fail the checker.

The diagnostic explicitly checks weighted inputs; projected/scaled QKV; head-normalized Q/K; RoPE inputs/outputs; newly appended K/V and unchanged prefill; softmax exp inputs/outputs; reciprocal inputs/outputs and normalized attention output; Z; FFN scaled UP/GATE; SiLU input/output; SwiGLU; and final Y. The collection contains 10,049 total boundary/checkpoint calls per reference pass, of which 6,668 are non-replacement checks in each candidate pass.

| Fixture | Candidate | Native model still exactly matches prior device array | Aligned deterministic checks | Aligned Y vs upstream |
|---|---|---|---|---|
| Integer | Square128 | Yes | 0 unequal / 5,804,436 values | Bitwise equal |
| Integer | Tall128 | Yes | 0 unequal / 5,804,436 values | Bitwise equal |
| Random | Square128 | Yes | 0 unequal / 5,804,436 values | Bitwise equal |
| Random | Tall128 | Yes | 0 unequal / 5,804,436 values | Bitwise equal |

Selected **analytical, conditioned** random mismatch counts before replacement:

| Sensitive output | Square128 unequal elements | Tall128 unequal elements |
|---|---:|---:|
| Input RMS sumsq | 11 | 16 |
| FP32 Q projection | 97,104 | 98,956 |
| Head norm sums | 480 | 480 |
| FP32 score sums | 187,105 | 187,105 |
| Attention value numerator | 99,760 | **0** |
| Attention denominator | 428 | **0** |
| FP32 O projection | 62,687 | 62,687 |
| FP32 DOWN projection | 67,998 | 67,998 |

These counts are not additive error contributions. Earlier sensitive outputs have already been aligned, so each row asks about the local step on matched inputs. The tall numerator/denominator equality is a useful control: tall A2 retains the upstream 256-row sequence partition and reduction group size, whereas square128 changes that axis. The score and O axes change in both candidate layouts.

Integer input does not eliminate all FP32 order sensitivity: despite native final equality, head norm sums, scores, and some FFN norm sums still differ before BF16 rounding. Therefore, an integer-only final-output comparison can miss differences in intermediate operations.

## Separate ownership/redistribution check

No arithmetic reduction is replaced or used as an oracle for this check. An independent global feature ID defines its source and final destination. A host transcription of the maintained X/Z two-element atom loops records every receive, retain, and forward action; it must exactly match the independent per-feature path and leave no missing/extra atoms.

| Host-only check | Completed coverage | Result |
|---|---|---|
| X, A1 row shards 32 → A2 row shards 10 | All 2,560 feature IDs; 112,640 vertical atom-hops | Exact destination contents; all row receive/send counts agree |
| Z, A2 row shards 10 → A3 row shards 16 at origin 96 | All 2,560 feature IDs; 61,440 vertical atom-hops | Exact destination contents; all row receive/send counts agree |
| QKV column ownership | 128 sender identities, 48 values/sender; closed-form Q/K pairing and V contiguous indexing | Every one of 6,144 logical IDs belongs to exactly one column; recipient map covers 256 rows/column |
| Tagged KV append | 1,280 prefill positions + all 256 legal append positions; next position rejected | Prefill unchanged, each append unique and in range |

An atom-hop means one two-value atom forwarded across one neighboring row edge; these are **computed counts**, not measured network traffic or timing. The QKV check certifies the host ownership/map, not 32,768 real PE receives. The KV check uses tagged host slots, not device cache readback. It covers the full remaining capacity as an analytical address test; it does not extend the 33-step hardware measurement.

Source sites: [X atom loop](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:118), [Z atom loop](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:137), [QKV sender and receiver](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:179), [logical column packing](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/tall_fixture.py:44), [device KV append](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1379).

Negative controls reject: one BF16-bit change in SwiGLU before DOWN; two swapped feature IDs at either X or Z destination; wrong QKV destination column with unchanged counts; and an append cursor that overwrites prefill. Neither a correct total length nor an aligned final output can substitute for these checks.

## Remaining device intervention and failure gates

The offline result specifies where to intervene; it does not complete on-device intermediate certification. The next bounded hardware validation should keep three questions separate:

1. **Native reduction arithmetic:** feed the same logical inputs; capture each layout's local FP32 partials and post-collective FP32 result. Compare each with its own source-order expectation. Cross-layout bitwise equality is not required here. A mismatch to that layout's expected partial or collective result fails and is investigated, rather than classified as expected layout drift.
2. **Deterministic computation on aligned state:** in disposable diagnostic copies, pause after a selected collective, provide the same canonical logical FP32 result and any live-in residual/state to each geometry, then execute the original downstream arithmetic. Read back before the next sensitive collective. Require bitwise equality at that boundary. Do not bypass the operation being tested. RoPE needs identical sin/cos state as well as Q/K; softmax needs the identical score/live-position mask; residuals need the identical X/Z.
3. **Actual fabric transport:** inject canonical QKV into the actual 128 A1 sender tiles after computation, run the existing east/column dissemination, and read A2 receiver buffers before consumption. Likewise inject X/Z into their producer buffers and read every destination shard before any later replacement. Compare raw BF16 bits and logical IDs at every destination, including multiple-source destination rows. Counts, ordering, route turns, queue drain/rebind, and consecutive-token isolation must all remain exercised. No CPU direct assignment may stand in for the link under test.

Instrumentation must use existing buffers or bounded taps, freeze source/config hashes, preserve all real wavelet counts, and be removed from maintained code afterward. Use the demonstrated group-size-16 configuration for the initial correctness intervention; it does not resolve or silently adopt a fix for the separately observed large-group blocking. Multi-layer/bank state, feedback, trained-weight inference, inter-group/head/tail paths, and end-to-end performance are not passed by this report.

The parent task can discuss end-to-end wiring while this validation remains bounded. Acceptance of a complete A1/A2/A3 layer group still precedes downstream integration claims.

## Artifacts and reproduction

- [Output document](/home/lexu/wse3-performance-model/docs/reports/2026-09-11-layoutC-aligned-step-validation-output.md): this result, source inventory, and device gap.
- [Evidence JSON](/home/lexu/wse3-performance-model/docs/reports/2026-09-11-layoutC-aligned-step-validation-output-evidence.json): every checkpoint aggregate, intervention mismatch, row atom count, negative control, dimensions, source hashes, and runtime versions.
- [Aligned arrays](/home/lexu/wse3-performance-model/docs/reports/2026-09-11-layoutC-aligned-step-validation-output-arrays.npz): computed canonical and aligned final arrays, explicitly not new hardware measurements.
- [Reproduction archive](/home/lexu/wse3-performance-model/docs/reports/2026-09-11-layoutC-aligned-step-validation-output-repro.tgz): scripts, frozen analytical helpers, prior hardware anchors, audited source snapshots, and manifest. Run `OPENBLAS_NUM_THREADS=1 python verify.py` after extraction.

This subtask added only these four report/evidence artifacts. It changed no maintained kernel, launcher, configuration, test, tracking document, or memory file. No stage, commit, push, or history operation was run. Memory capture is delegated to the parent to avoid duplicate captures for the same user decision.

Validation: offline `verify.py` passed in the packaged environment; all 63 archive manifest entries matched after extraction; every source link resolves. Archive SHA-256: `1f4e3746eafd52a12312e8e3b7a88b638484785ac3e90bc9e3f6031e5b3a485c`.
