# Layout C: real CS-3 three-way numerical comparison

Date: 2026-09-11. Scope: the unequal-height single-layer group, before layer-bank feedback, inter-group wiring, head/tail, or performance measurement.

## Outcome and acceptance status

A missing A2 column-readiness barrier was isolated and fixed. The final maintained source was compiled and executed on CS-3 without numerical probes. Its output is identical to the instrumented fixed version for both fixtures below. The original NumPy gate remains **FAIL** (`relative_l2 < 0.02 AND max_abs < 0.05`); no tolerance was widened and no acceptance checkbox was closed.

The requested three-way comparison is now explicit: (1) the unchanged NumPy oracle, (2) the original combined ATTN body beside the original FFN body, and (3) tall A1/A2/A3. Both chip implementations consume byte-identical logical input, weights, and initial KV. They use different PE packing and compute geometry. This is a one-layer numerical baseline, not a replay of the old complete 4B model or its production scheduling performance.

| CS-3 fixture, 33 decode steps | Old ATTN+FFN vs NumPy relative L2 | Tall vs NumPy relative L2 | Tall vs old relative L2 | Tall vs old maximum absolute difference |
| --- | ---: | ---: | ---: | ---: |
| Sparse integer-valued input/parameters, seed 911 | 0.37717477% | 0.37717477% | 0 | 0 |
| Random BF16, seed 910 | 0.70737130% | 0.70751966% | 0.07007564% | 0.125 |

Each output contains 33 x 320 = 10,560 elements. Integer outputs agree exactly; random outputs differ in 191 elements on zero-based steps 5, 11, 29, 30. Maximum absolute error versus the original NumPy oracle is 0.125 for integer and 0.25 for random, for both layouts.

These are outputs measured on CS-3, with metrics computed on the host from those outputs. No simulator result is represented as hardware evidence. No device latency or bandwidth claim is made.

## Geometry, fixtures, and reference independence

- Tall mini: width 16; A1/A2/A3 heights 10/32/20; A3 starts at local row 12.
- Old mini: ATTN 32 x 32 directly beside FFN 32 x 32.
- Both: hidden 320, attention 512, KV 128, head dimension 16, FFN 1,216, batch 1, one layer, prefill 160, capacity 224, 33 externally supplied decode embeddings. Step 32 crosses the A2 KV-owner row wrap.
- Integer fixture: sparse projection matrices with two nonzero signed unit entries per output, integer input magnitudes 1..3, integer prefill values in {-1,0,1}, norm weights 1. Nonlinear intermediates are still floating point; this is not integer-only execution.
- Random fixture: the existing seed-910 synthetic BF16 fixture. Neither fixture uses trained Qwen3-4B weights.
- `fixture_identity.json` in the reproduction archive records shape, dtype and SHA256 for every logical array for both geometries (integer/random, steps 2/33); every corresponding pair is identical.

The fixed NumPy baseline works on unsharded logical tensors and does not consume packed PE weight tiles. Its entry is [tall_fixture.reference](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/tall_fixture.py:121), calling the [NumPy layer body](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/oracle_fp16.py:286). It includes BF16 casts and approximate scalar helpers; it is not a pure FP32 mathematical golden implementation.

Separate operation-order diagnostics match device arithmetic, and are explicitly **not replacement acceptance oracles**. They must not be used as independent validation of transformations that they share with the host packer. The unsharded baseline, logical array identities, cross-layout device comparison, negative checker control, and cache readback remain separate evidence.

## Maintained change and causal controls

Only [tall_stage.csl:157](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:157) changed: `a2_compute()` now calls `kernel.round_barrier()` before `a2_layer_body()`. The synchronous Y collective waits for column peers to finish X redistribution and restore the edge queue before attention switches the shared collective axis. The barrier implementation is [decode.csl:414](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:414); A2's first axis switch is [decode.csl:1887](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1887).

Initial tall integer-2 output had first-step max absolute error 0.2265625 against NumPy. A2 alone had first-step error 0.2421875. Feeding the measured QKV into a conditional attention reference still left that 0.2421875 first-step error; the second A2 step matched. QKV rounding could not account for the startup failure.

A runtime-selected control in the same CSL source separated synchronization from descriptor priming:

| Mode | Result on integer-2 |
| --- | --- |
| No barrier | Exactly reproduced the initial failing tall output |
| Actual Y column collective | Exactly matched old ATTN+FFN output |
| DSR descriptor priming without communication | Exactly reproduced the initial failing output |

This supports a missing readiness synchronization as the cause. Individual offending fabric wavelets were not traced. Source identity was recorded; linked `.text` identity between the runtime-control builds was not independently verified.

Final maintained `tall_stage.csl` SHA256:
`c44e382a11fc7622edba4ad04aa14bc2e79bbe0bf38e63e657f095c839c47288`.
Initial SHA256:
`5470a43c5ed03c0773acb0235646e4db99a3ecce11c895f94dc78b1635fa32fc`.

## Separating shared arithmetic from layout differences

For integer-33, an independent unsharded diagnostic using FP32 scores, BF16 RoPE products/adds, and the actual fused-FMA SiLU polynomial reproduces all output elements exactly. This explains the sampled residual versus the original NumPy formulation; it does not establish trained-model accuracy.

The shared [SiLU polynomial](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1717) returns 0.007537841796875 at input zero, whereas mathematical SiLU(0) is zero. A real CS-3 control with all GATE weights zero produced 470 nonzero FFN contributions in 640 output elements; maximum contribution 0.0390625. The polynomial-matched reference reproduces that output exactly. The polynomial was not changed in this session.

Random-33 stage controls:

- A2 outputs differ between layouts in 24 / 10,560 elements, only at zero-based step 29; maximum absolute difference 0.0078125.
- Feeding the **same measured tall A2 Z** into the two FFN geometries gives 20 differing output elements on steps 5, 11, 30, max absolute difference 0.0625, relative L2 0.01957272%.
- An operation-order diagnostic using each layout's local FP32 accumulation, two-level reduction, scalar Newton rsqrt, BF16 casts and SiLU polynomial reproduces both same-Z FFN device outputs exactly. This accounts for the sampled FFN differences through a concrete arithmetic path, rather than labeling an unexplained remainder “precision.” See [FFN reduction](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/comm_lib/comm_pe.csl:1448), [local GEMV accumulation](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:474), and [rsqrt](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/approx_math.csl:17).

QKV capture covers all 33 x (512 + 128 + 128) = 25,344 values in each layout. K and V agree exactly across layouts. Q differs in three elements: step 27 / feature 296, and step 29 / features 499 and 507. The largest Q difference is 0.0078125. The tall QKV output agrees exactly with the operation-order diagnostic recomputed from input and weights.

Starting from the measured QKV boundary, operation-order attention and FFN diagnostics reproduce **all** A2 and final device outputs for both layouts. The observed A2 difference is reproduced exactly. This localizes the observed cross-layout discrepancy to the Q boundary and the separately verified same-Z FFN arithmetic differences. The old projection diagnostic itself still differs from its device capture in three Q elements (max 0.001953125); their exact upstream instruction-level cause remains open. They are not silently absorbed into a claimed fully exact old-layout replica.

The old combined attention body was also run with post-body readback from its actual KV-owner row. QKV chunks 320 and 640 (including all observed differing Q values) match the projection-only captures exactly. This verifies the relevant boundary values in the original combined compute path.

## KV preservation and build coverage

Post-decode readback covers all 512 A2 PEs after 33 integer steps. Prefill and unused cache locations remain exactly unchanged. Appended V is exact against the original logical reference. Appended K has max absolute difference 0.015625 and relative L2 0.25342077% against the original RoPE formulation; matching the device's BF16 RoPE gives **exact full K and V caches**. Probe output agrees with the normal fixed output. The original cache checks and the conditioned checks are recorded separately.

Full geometry (width 128; heights 80/256/160; hidden 2,560; attention 4,096; KV 1,024; head 128; FFN 9,728; capacity 8,192; prefill 1,280; five allocated layer banks) compiled with the final maintained patch in the local SDK 2.10 container. `executed:false`: no claim of full-geometry or five-layer execution is made. The active mini driver computes bank 0 only and uses baked input, not layer feedback or live prefill ingress.

## Driver controls, failed attempts, and provenance limits

The initial disposable old-layout driver lacked completion pacing. Short 2/3-step runs completed; the streamed 33-step driver returned six correct outputs then stopped making progress. Those exact owned jobs were canceled. Adding a static color-9 per-row completion multicast allowed 33 steps and preserved the short-run values exactly. Original ATTN and FFN compute bodies remain unchanged. This is a diagnostic schedule; it is not evidence that the original production model hangs or a timing baseline. `legacy-ack-audit.md` records color/queue ownership and token counts. A custom-layout automatic color audit was unsupported; its refusal is not a pass.

The shifted-feature negative checker control fails strongly (relative L2 1.41265857, max absolute error 20.375). It demonstrates that the original checker does not accept an arbitrary nonzero vector. No failed run was silently discarded: the evidence index includes compile failures, canceled/incomplete attempts, and numeric failures after successful output collection.

Hardware jobs used the cluster's available CS-3 systems; do not assume all samples used one physical system. Client/server logs report multiple version identifiers (client semantic 1.14.0, server semantic 1.13.2, worker package 2.10.0); the actual remote compiler version was not separately captured. The final and diagnostic uploaded source hashes and job IDs are recorded. A few earliest cases predate per-case closure capture; the reproduction notes distinguish those provenance limits. A version warning is not treated as a numerical diagnosis.

## Remaining gate and next action

1. Keep the original NumPy gate failed. Decide and implement a consistent mathematical/reference contract for the shared compute, especially score/RoPE rounding and SiLU approximation, then validate it without widening tolerances to fit these data. The original unsharded reference and diagnostic replicas must remain distinguishable.
2. Complete unequal-height group correctness at the intended dimensions and multi-layer bank/feedback schedule, including runtime ingress and repeated rounds. The present evidence is miniature, one-layer, externally supplied embeddings.
3. Only after that group gate passes: block-to-block connections, head/tail, and finally end-to-end performance.

No tracking milestone was marked complete. Temporary numerical taps and controls live only in the frozen reproduction archive, outside maintained source. The only maintained code addition is the A2 barrier; no diagnostic buffer, alternate arithmetic path, or temporary export was left in the kernel.

## Artifacts and selected jobs

- [Machine-readable evidence index](2026-09-11-layoutC-cs3-three-way-evidence.json): per-case job IDs, numerical verdicts, three-way metrics and diagnostic controls.
- [Primary raw numerical arrays](2026-09-11-layoutC-cs3-three-way-arrays.npz): unchanged NumPy, old CS-3 and final tall CS-3 outputs for both 33-step fixtures.
- [Frozen reproduction archive](2026-09-11-layoutC-cs3-three-way-repro.tgz): original worker evidence archives, disposable source snapshots, analysis scripts, SHA256 manifest, driver audit and `REPRODUCE.md`.

| Case | CS-3 job |
| --- | --- |
| Initial tall integer-2 | `wsjob-bvmfkgpkoozyab6gnwmt56` |
| Runtime no-barrier control | `wsjob-a7tg4jtdecokvqpsn6av6d` |
| Runtime barrier control | `wsjob-mloxejbtf4nvrlwthazeza` |
| Descriptor-only control | `wsjob-m4ndcw7tnjbzyrykvmh8dm` |
| Final clean integer-33 | `wsjob-8zothsxtuamfggjvgbvqwg` |
| Old integer-33 | `wsjob-dkqjutubdu8i5hkm3rpyhd` |
| Final clean random-33 | `wsjob-esjkhwbwahdvard6itk9wm` |
| Old random-33 | `wsjob-cq8e6xjgcpcrpihemmnaag` |
| Full cache readback after integer-33 | `wsjob-lucndcoaww8hw9bpeu7nkd` |

Workspace base revision: `38ac5b7a7d999689fe472c766e233fe545502c95` on `main`; the demo source is untracked, so the revision alone does not identify the tested code. Use source hashes and the frozen archive. Pre-existing unrelated tracking changes were preserved. No Git stage, commit, push or history-changing operation was performed.
