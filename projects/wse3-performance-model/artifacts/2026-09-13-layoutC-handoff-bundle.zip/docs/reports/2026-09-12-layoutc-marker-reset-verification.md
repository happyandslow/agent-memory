# LayoutC source/target markers and repeated-frame reset

Date: 2026-09-12. Scope: one isolated, feasible A3-to-A1 communication protocol.
No maintained numerical kernel was instrumented or changed. This is a transport
correctness experiment, not model numerical validation or a performance result.

## SDK contract

A control wavelet carries up to eight commands, each with a CE-ignore bit.
Popping removes the leading command, not the whole wavelet. `pop_on_advance`
pops only when the local switch actually advances; `always_pop` removes the
leading command at every traversal. A NOP can therefore hide a later ADV until
a designated junction removes the NOP.

Authoritative local source:

- [SDK control encoder, including MAX_CMDS and encode_payload](/home/lexu/CSL-Demo-Code/versions/v2.10/source-code/csl_libraries/control.csl:78).
- [SDK pop-mode specification](/home/lexu/CSL-Demo-Code/versions/v1.4/Cerebras_Docs/csl/language/builtins.md:1935).
- [Runtime switch-position update](/home/lexu/CSL-Demo-Code/versions/v2.10/source-code/csl_libraries/tile_config/switch_config.csl:133).
- Online cross-check: [SDK builtins, pop_mode](https://cerebras-sdk-docs-130.netlify.app/csl/language/builtins#pop-mode).

The checked source checkout is `/home/lexu/CSL-Demo-Code`, revision
`aecfdd0942bb5003b7ab4f583fdd0db60771dfcc`.
The archived spec is v1.4; the local simulator uses SDK 2.10.0. Do not conflate
those versions with the appliance server version recorded in device logs.

## Concrete protocol

Use four source compute PEs S0..S3 in *travel order*, feeding destination rows
R0 and R1. Each source owns 16 different values; each destination row receives
two halves, multicast to every column. Payload never enters a strip CE.

- Normal source junction: pos0 passes upstream, pos1 selects EAST (local source).
  No ring wrap; pop_on_advance. First source starts at pos1, others at pos0.
- The final source junction, immediately before the destination zone, uses the
  same two positions but **always_pop**. It strips one command prefix.
- Each target junction: pos0 turns toward EAST, pos1 passes along the strip.
  No ring wrap; pop_on_advance. Targets start at pos0 and are visited in stream
  order; already-served targets stay at pos1.
- Destination row: WEST -> RAMP+EAST; final column WEST -> RAMP.

Exact source tails (all operations use the same ordered data output queue):

| Source | Sequence after its 16 payload words |
|---|---|
| S0 | GRANT `[ADV]` |
| S1 | ROW_DONE `[NOP,NOP]`; TARGET_ADV `[NOP,ADV]`; GRANT `[ADV]` |
| S2 | GRANT `[ADV]` |
| S3 | ROW_DONE `[NOP,NOP]`; TARGET_ADV `[NOP,ADV]`; STREAM_END `[NOP,NOP]` |

GRANT has CE-ignore set throughout. It advances the next source and its ADV
is popped there. TARGET_ADV has CE-ignore set throughout. Its first NOP passes
normal sources unchanged, is removed by the final source junction, and exposes
ADV only in the target zone. Thus it advances the current receiving row instead
of opening an unintended source. TARGET_ADV precedes GRANT, so new-source data
cannot overtake the destination-boundary marker on their shared path.

ROW_DONE and STREAM_END use CE-ignore bits `[true,false]` and distinct control
entrypoints; the final source junction exposes the CE-enabled NOP. ROW_DONE
follows the current row's data into its horizontal multicast. STREAM_END follows
the final target advance into a dedicated terminal PE beyond the target zone.

A naive `[ADV,ADV]` is insufficient: its second ADV can advance another source
before reaching any target. Multiple commands are useful, but their pop sites
must be deliberately assigned. The prefix scheme needs no CE payload relay and
no explicit destination address.

Implementation in the isolated experiment:
[marker encodings](/home/lexu/.cache/layoutc-marker-reset-20260912/pe.csl:36),
[source tail](/home/lexu/.cache/layoutc-marker-reset-20260912/pe.csl:82),
[source and target switches](/home/lexu/.cache/layoutc-marker-reset-20260912/layout.csl:40).
A source snapshot and checksums are retained in the verification bundle; these
cache-path references are convenient live views, not the immutable archive.

## Sentinel and recovery

STREAM_END proves that the main-strip terminal observed the ordered tail. It
does **not**, alone, prove every horizontal receiver has committed its data.
Each receiving compute PE separately requires `count == 32 && row_done`.
A source must have completed its own payload and marker sequence.

The implemented conservative reset is a control-only token through all 21 PEs:
terminal -> a fixed snake visiting receivers and source junctions -> start root.
A PE holds this token until its local completion conditions hold. Holding it is
nonblocking: later receive/completion tasks can still run. Each PE then restores
its data switch, clears counters, advances its epoch, and forwards the token.
Only the final reset node broadcasts START for epoch two. No host round-trip
starts the second epoch. No new data frame can reach a partially restored route.

The reset chain uses CE consume/re-emit for **one control word**, on two static
alternating colors; payload transport remains router-only. This is deliberately
a conservative correctness baseline, not a claim about optimal reset latency.
It also does not imply that every future compute launch needs a global barrier.

[Reset predicate and state transitions](/home/lexu/.cache/layoutc-marker-reset-20260912/pe.csl:49).
A real kernel must additionally preserve X buffer ownership until its residual
and other consumers finish; this microtest has no such arithmetic consumers.

## Resource audit

The existing tall launcher declares collective C0..C4, H0/H1 C8/C9, X-entry C10,
QKV-column C11, edge vertical C12/C13, Z C14, output C15, X-row C16.
[Launcher inventory](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:148).
Collective IQ/OQ3..7 are explicit in
[comm_pe.csl](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/comm_lib/comm_pe.csl:97).

| Purpose | Isolated compiled experiment | Candidate tall allocation |
|---|---|---|
| Payload, source handoff, target marker, sentinels | C17 | C17 north; C20 south |
| Reset token | C18/C19 | C18/C19 |
| START broadcast | C16 | C21 (existing C16 remains X-row) |
| Collective | absent | retain C0..C4 unchanged |

The isolated experiment uses four colors per tested direction. The candidate
static north+south design reserves five distinct additional colors (17..21),
sharing a serialized reset/start phase. This is not a compiled full-model budget.
C17 and C20 are switch-capable; C18/C19/C21 only require static routing.

The standalone memcpy harness reserves IQ0/1, so its data/reset/start queues are
IQ/OQ2/3/4. **Do not transplant those bindings into tall:** they overlap current
collective queues. For tall, new ingress can use input queues 0..2; its output
queues 0..2 already serve A1 H0/H1/X-entry, and A3 OQ2 serves C15.
[Existing per-stage bindings](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:238).
A conservative integrated schedule must finish the communication-control epoch
and drain/rebind the non-collective output queues before their next owner uses
them. Early local arithmetic does not authorize queue reconfiguration. Preserve
IQ/OQ3..7 and collective colors throughout ingress; do not derive global drain
from one PE's local-ready flag.

The prototype control entrypoint 40 aliases local task slot 8, which tall already
uses for main. Integration must assign a different task slot; this is another
reason the microtest is not a drop-in kernel patch.
[Tall main task ID](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:67).

The color-audit parser refused the existing multiline
`tile_config.output_queue_config.encode_output_queue` call at
[comm_pe.csl:790](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/comm_lib/comm_pe.csl:790).
No parser fallback was used. The inventory above is manual source inspection;
compiler acceptance applies only to the isolated experiment.

## Validation contract and results

Geometry: 3 x 7 logical PEs, four sources, two destination rows, two receiving
columns per row, one final terminal, 16 u32 values per source. North mirrors the
physical Y coordinates and writes incoming high/low halves at offsets 16/0.
South writes offsets 0/16. Epoch two adds 10000 to each source's values.

Pass requires exact integer equality at all four receivers, exactly 32 values
and one ROW_DONE per receiver per epoch, two STREAM_END events, all reset nodes
at epoch two, and no error flags. That checks 256 received u32 values per positive
case. No tolerance, floating-point reference, or performance measurement is used.

Negative control: omit the first row's ROW_DONE while still delivering all its
data and the final STREAM_END. Verify all first-frame payloads are correct but
reset/START cannot complete and no second-frame values appear. Separately mutate
one output value and confirm the equality checker rejects it.

Simulator: SDK 2.10.0, WSE-3 target, south/north/withheld-sentinel checks PASS.
Real CS-3: south PASS, north PASS, withheld-row-sentinel negative control PASS.
Both positive hardware cases checked 256 receiver values, exactly, over two
automatically sequenced epochs. The source/data words and state checks agree
with the simulator. The negative case received every first-frame payload and
the main-strip tail, but correctly withheld epoch two. The altered-value checker
was rejected in each positive case on both backends.

Appliance client 1.14.0, server 1.13.2 (reported version warning); cluster system
software 2.10.0. North execution was observed on xs20741. Hardware compile uses
762x1172 fabric, offsets (4,1), active rectangle 3x7, target WSE-3. These are real
device correctness results; no cycles, bandwidth or model accuracy are claimed.

| Hardware case | Execution job | Result |
|---|---|---|
| South, two epochs | wsjob-leryfcyzzariwqhwrk4ebk | exact pass |
| North, two epochs | wsjob-n3mjwuqpskrydh95sgcos2 | exact pass |
| Withheld ROW_DONE | wsjob-bkngqjrqmabqukpzfdkmtb | restart blocked as required |

[Structured evidence](2026-09-12-layoutc-marker-reset-evidence.json) includes
raw receiver values, counters, compile artifact identities and source hashes.
[Verification bundle](2026-09-12-layoutc-marker-reset-verification.zip) contains
the isolated sources, launch/check scripts and raw logs.

Reproduction from the adjacent verification bundle:

```sh
# Local SDK 2.10 simulator, from the extracted bundle:
cd src
cslc --arch=wse3 layout.csl --fabric-dims=10,9 --fabric-offsets=4,1 -o out \
  --memcpy --channels=1 --width-west-buf=0 --width-east-buf=0 \
  --params=MIRROR:0,OMIT_ROW:0
cs_python ../run.py --name out
# North: MIRROR:1 plus --north 1. Negative: OMIT_ROW:1 plus --omit-row.
# On the authenticated launcher, from the bundle root, using csl Python:
cd ..
python guard.py
```

`device.py` compiles all three cases with the full 762x1172 fabric (the active
program rectangle remains 3x7), preserves the SDK-generated archive basename by
downloading into a pre-created directory, and runs with `simulator=False`.
The guard bounds the batch to 1200 seconds and cancels only job IDs emitted by
its own child on timeout/failure. These IDs and raw results are in the logs.
Earlier host-wrapper attempts failed before `main_fn`: bare output pathname,
renamed archive, and a small simulator fabric whose memcpy ingress was not at
the hardware fabric edge. They are excluded from protocol results, retained as
raw logs, and are not numerical/communication failures.

Compile/run commands, source hashes, raw logs and case outputs are in the
adjacent verification bundle. Temporary validation code was kept outside the
maintained kernel tree. No timing result or full A1 collective coexistence is
claimed. Remaining integration checks: packed f16 receive path, actual tall
queue/task allocation, larger row/column fanout and skew, then multi-layer
feedback. Full group correctness still precedes intergroup/head/tail integration.
