# First-group feedback: Claude Code review

Date: 2026-09-13. Read-only Claude Code review, not a Codex self-review.
Session: `35c4d1f7-5e3f-4662-b61b-edd5c9511845`. Tools restricted to
Read/Glob/Grep, hooks disabled, no MCP tools. No reviewer write or Git operation.

## Final disposition

Claude Code reported **no remaining blocking findings** after the targeted
follow-up. It accepted a bounded-process timeout instead of permanent device
probe exports, with the explicit limitation that an exact faulting PE/error
code cannot be recovered from maintained images after timeout. Hardware job
teardown remains the responsibility of the enclosing SdkLauncher context.
The independent cache-probe evidence was reported to the reviewer; the
reviewer explicitly did not inspect those JSONs. This is not independent
reviewer verification of every numerical result.

A final non-blocking request to hash all protocol sources was implemented in
`launch_tall.py`: source_manifest.json plus protocol hashes in the startup
record. This host-only logging addition came after the follow-up.
The report preserves compiler per-image queue parameters and executed source
snapshots. Production source contains no temporary cache/diagnostic probes.

## Initial review, verbatim

I've finished reading. Writing up the review now.

# LayoutC first-group implementation review (read-only)

**Verdict.** I found no ordering bug that would corrupt a frame or deadlock the U16/R/START loop under the one-token-in-flight regime the contract admits. The control composition is consistent for any layer count of two or more and for consecutive fixture tokens. The findings below are guards that are missing, a diagnosability hole that turns every protocol error into a silent hang, a verification gap on the KV banks, and one launcher-order question I could not settle from source. I did not read any hardware result and make no claim about one.

## Findings

| # | Severity | Location | Mechanism | Correction |
|---|---|---|---|---|
| 1 | Medium | `/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:261-265`, `.../src/group_link.csl:112` | The half packing and marker parity silently assume four relations that nothing asserts: `a3_height == 2*a1_height`, `a1_shard == 2*a3_shard`, `a3_height` even, `a2_height` even. `sent()` at `group_link.csl:104-109` uses A3 row parity to decide ROW_DONE; the bottom source must be odd so it emits GRANT only. With odd `a3_height` the first source would emit ROW_DONE, TARGET_ADV, GRANT, advancing the first target before its second half exists. With odd `a2_height` the bottom strip row is even, so `group_strip.csl:66` binds its IQ1 to C18 while the return corridor delivers C23 to it, and START is never emitted. With `a3 != 2*a1` the bottom-up pairing at row `r` from sources `2r+1, 2r` no longer lands on A1 row `r`. Both live geometries satisfy all four, so this is a guard, not a live failure. | Add to the stage comptime block: `a3_height == 2*a1_height`, `2*a3_shard == a1_shard`, `a2_height % 2 == 0`; add `source_rows % 2 == 0` in `group_link.csl` (the `source_rows` param is currently unused); mirror in `host/tall_layout.py:28` `validate()`. |
| 2 | Medium | `.../src/group_link.csl:48`, `.../src/group_strip.csl:23`, `.../launch_tall.py:312-320` | Every protocol error path sets a local `error` and drops the event: `start` at `group_link.csl:100-103` drops the credit, `receive_token` at `group_strip.csl:43-50` drops the token, `receive_ack` drops the ack. None of these variables is exported and the launcher only blocks on the output stream, so any epoch mismatch, duplicate ROW_DONE, or double token becomes an unbounded hang with no readable cause. Contract §4 requires unexpected frames to be errors; they are, but unobservably. | Export `error`, `epoch`, `halves`, `credit_epoch` from both modules (a small `state` array as in the prototype at `/home/lexu/.cache/layoutc-marker-reset-20260912/pe.csl:27`). In `launch_tall.py`, use a bounded `receive` and on timeout sweep `read_symbol` over the strip column and A1/A3 column 0, printing the first nonzero error with its coordinates. |
| 3 | Medium (coverage) | `.../launch_tall.py:332`, `.../host/tall_fixture.py:170-181` | In feedback mode the KV cache readback is skipped. `check_cache` hardcodes A2 at `2 + g.width + x`, but with feedback A2 is placed at `2 + width + 1` (`launch_tall.py:139`), so it could not be enabled as-is. Consequence: the per-layer bank layout (host concatenation at `host/group_fixture.py:22-26` versus the device stride at `decode.csl:737-738`) and prefix/unused-region preservation across banks are only tested indirectly through the final output. A stride error that keeps the attended positions correct in every bank would pass. `summary["scope"]` nevertheless says "distinct layer banks". | Parametrize `check_cache` with the A2 origin and a layer index, slice `XKCache_tile`/`XVCache_tile` by `l * kv_cols * kv_len_per_pe`, and compare each bank to `expected_k[l]` / `expected_v[l]` already returned by `reference_group_order`. Until then, state in the summary that bank contents are unverified. |
| 4 | Low (verify) | `.../launch_tall.py:263-266`, `.../host/group_routing.py:52-69` | Regions A1/A3 are `place()`d inside the stage loop, and only afterwards `configure()` paints C16/18/19/23 on them and sets `r_in`, `r_out`, `r_oq`, `h0_sender_flag`. If SdkLayout freezes a region at `place()`, either the compile fails loudly (fine) or the params keep defaults. In the second case every H0 sender would get `r_oq=0` from the default, `tall_stage.csl:267` would then leave OQ0 bound to C19 via `group_link.csl:113`, and `horizontal_0` would push QKV into the R chain. I could not determine the SDK behaviour from source. | Move the `configure()` call before the `rg.place()` calls, or confirm from the SDK that post-place paint and `set_param` are honoured. A `--compile-only --feedback` run does not settle the param question by itself. |
| 5 | Low | `.../src/tall_stage.csl:192-211` and `group_link.csl:82-85` | Layer-0 frames generate no ACK, and the receive for the next feedback frame is armed on `ptr_X` after the last local layer, so the async receive is live across the entire layer-0 compute of the next token. This is safe today only because every X read in `a1_layer_body` precedes the column all-reduce that gates the QKV senders (`decode.csl:1844-1853`), which in turn gates A2, A3 and therefore the frame. Any future change that reads X after that reduce in A1 would let the feedback frame overwrite X mid-compute with no protocol error. | Document the invariant at the `release_input` call site, or arm after the layer-0 compute instead (delay the arm and ACK for the post-last-layer case until after `x_entry_out` of the next layer-0 frame; the frame cannot arrive earlier, so latency is unchanged). |
| 6 | Low | `.../host/group_routing.py:3-4` | Docstring says strip x=1 and A1/A3 x=2..width+1. With feedback the launcher places the strip at x=2, A1/A3 at x=3, A2 at x=3+width, collector at x=1 (`launch_tall.py:136-142, 289`, `group_routing.py:47, 73`). A checker author working from the docstring will build the wrong claim table. | Fix the docstring to the actual origins. |

## What I verified and how

**Queue and task ownership.** A1: IQ0 U16 dense, IQ2 R-in, OQ2 C10, the non-sending QKV OQ becomes R-out; `h0` in `group_routing.py:52` equals the kernel predicate at `tall_stage.csl:204-205`, so no queue is initialised twice. A3: IQ0 Z14, IQ2 START15, OQ0 R, OQ1 U16 dense, OQ2 D17. Strip: IQ0 C19, IQ1 vertical, OQ0 vertical, OQ1 START on the root only. Collectives stay on IQ/OQ3..7; `comm_pe.csl:1702-1724` skips IQ0..2/OQ0..2 under `external_io`, and its reductions are synchronous (`comm_pe.csl:1641`), so the one A1 input microthread held across a compute has no contention. Task IDs per image: A1 local 8, 9, control 42, 43, data 2; A3 local 8, 12, data 2; strip local 8, data 0, 1. `decode.csl:2603` binds nothing under `external_schedule`. C18 never enters the strip from EAST because A1 column 0 is even and emits C19; C19 never arrives from SOUTH. U16 terminates at the A1 last column with no EAST output, so A2's C16 stays isolated.

**Marker order and switch program.** Northbound travel is bottom-up, so the first source is A3 row `a3-1` (odd, GRANT only), the final source is A3 row 0 (ROW_DONE then STREAM_END, no ADV, no GRANT), and the top A1 row is the final target left at position 0. Encodings at `group_link.csl:27-30` are byte-identical to the verified prototype. The final source is the top A3 row and carries `ALWAYS_POP` (`group_strip.csl:56`), so the guard NOP is stripped exactly where the prototype strips it. Row pairing `(2r+1, 2r)` lands on A1 row `r` with offsets `half` then 0, which matches the contract's left-local ordering.

**Readiness, latch, release, reset.** Per A1 PE: block IQ0, two async halves, unblock, ROW_DONE via control task, latch `ready`, compute, then `release_input` re-arms and the ACK chain runs east to west with matched epochs. Row 0 columns additionally require STREAM_END before acking. The scan for epoch k cannot start before row 0's ACK because the root's `pending` is only set by row 0's even notification (`group_strip.csl:38, 43`). Row 0's ACK implies STREAM_END passed every source and target junction on the single ordered path, so restoring switches during the scan touches only quiescent routers. START(k) is emitted only after the odd return, after every active row restored and acked. Epoch arithmetic (`2k` even, `2k+1` odd, START value `k`) is consistent across A1, A3, strip, and root for k from 0 upward.

**X and Z lifetimes.** `ptr_X` and `ptr_Z` are never reassigned in `decode.csl`; `ffn_residual_add` writes `Z_tile` in place (`decode.csl:1758-1763`), so `link.send(ptr_Z)` sends the layer output. A3 column 0 does not advance `tick` until `sent`, so Z is not overwritten under an active send. X is released only after `x_entry_out`.

**Banks and position.** Host concatenation along the per-PE axis matches the device strides in `set_attn_layer`/`set_ffn_layer`. RoPE advances once per token at layer 0 only. Per-layer `step`/`iter_num` banks make the KV owner row `t % a2` identical in every bank, matching the bake positions and the reference. Frame index maps to `(token, layer)` identically in A1, A2, A3.

**Multi-layer and consecutive tokens.** ACK count equals feedback-frame count plus the bootstrap; START(k) credits frame k+1; the dangling final arm and credit are harmless. For L of 3 or more, the un-acked layer-0 frame sits between feedback frames without disturbing the epoch sequence. The harness lets A1 start token t+1 layer 0 while A2/A3 finish token t's last layer; that overlap is the same early-X case the baseline A2 edge already handles and uses distinct banks, so it is safe here, but it is a fixture property. It says nothing about the full model, where a token's layer 0 waits for Tail.

**Operation-order baseline.** `reference_group_order` threads bf16 outputs layer to layer, uses each layer's own prefill K/V, applies the same prefill rotation count as `prefill_len_per_pe_rt`, and caches post-RoPE K. Exact equality is the right direction: it fails closed. I did not audit its arithmetic against the kernel beyond structure.

## Not verifiable from source, and contract notes

- The small 4-source test harness is not in the tree or cache; no file other than the launcher references `group_link`/`group_strip`. `tall_stage.csl:263` rejects width 4 with `a1` of 2 or 4, so that test did not run the kernel schedule. The integrated A1/A2/A3 path with feedback has no recorded execution.
- Handling of ce-ignored control wavelets at the head of a blocked dense IQ0 while the second half's DSD attaches rests on that small test. The prototype's terminal PE evidence (`pe.csl:71` never set state 3) shows the dispatcher drops them; the microthread path is only covered by the dense test.
- `group_pass.csl` is an empty program; it is only instantiated when `a3_origin > a1`, which the small geometry may not have exercised.
- The contract's per-image task/queue manifest and checker (§4, §8.1) exist only as comments in these files.
- Deviation, benign: contract §5 lets only the designated last-column PE do terminal bookkeeping; the implementation makes every row-0 column gate its ACK on STREAM_END. That is stricter and correct given the row multicast reaches every column.

## Targeted follow-up, verbatim

**No remaining blocking findings.** The six items are closed or accepted with the limitations below. I read the two protocol modules, the stage schedule and comptime block, `tall_layout.py`, `run_tall_bounded.py`, `group_allocation.py`, the full five-layer two-token result, and the timeout control. I did not read the cache-probe JSONs or the docstring change; those dispositions rest on the reported evidence.

## Disposition

| # | Status | Basis and residual |
|---|---|---|
| 1 | Closed | Guards present at `src/tall_stage.csl:266` (feedback-conditional, all three relations), `src/group_link.csl:119` (`source_rows` even), `src/group_strip.csl:64` (`height` even, `a3 == 2*a1`), and `host/tall_layout.py:25-29`, invoked at `launch_tall.py:99`. Consistent with each other. |
| 2 | Accepted as a bounded-execution alternative; diagnostic limitation remains | The wrapper kills the child's own process group and records exit 124; the 1 ms control shows the host timeout path works. The new fail-closed paths are sound: `try_ready`, `try_ack` and strip `try_forward` all return on `error`, so any protocol fault withholds ACK/START and surfaces as a timeout rather than a wrong output. Error 6 cannot fire spuriously: the only window where IQ0 is unblocked with no receive armed is between the second half and the next arm, and no data can arrive there before the ACK. What the wrapper does not give you: after a timeout the faulting PE and error code are unrecoverable from maintained images, and on CS-3 the job teardown depends on the caller's `SdkLauncher` context, which the wrapper cannot enforce. Both are the trade you chose. |
| 3 | Accepted on reported evidence | Independent probe with a corruption control is the right shape. Residual: it is not part of the maintained launcher, so it must be re-run after any change to bank layout or `set_attn_layer` strides. The launcher's "not read back" status is honest. |
| 4 | Accepted; not blocking | `group_allocation.py` records the calls as made, not as honoured, but the exact full-geometry pass is itself the proof: an H0 sender with default `h0_sender_flag` would bind OQ0 to C19 and push QKV into the R chain, which cannot produce an exact output. Preserving the compiled per-image params in the report settles it directly. |
| 5 | Closed | Invariant documented at `src/tall_stage.csl:209-213`, at the release site. |
| 6 | Closed as reported | Not re-read. |

## Two non-blocking notes on the new code and evidence

- **`on_control` on the receive DSD** (`group_link.csl:68-69, 98-99`) is only safe if ce-ignored control wavelets never reach the microthread. The between-halves GRANT remainder arrives on IQ0 before every second half. If the hardware delivered it to the DSD, every first-target row would raise error 7 and hang, so an exact pass with this source is strong evidence it does not. But the evidence record I read carries no source hash for `group_link.csl`; the launcher prints only the `tall_stage.csl` digest. Add the digests of all staged sources to the printed summary so each result is tied to the protocol module version. This is a launcher output change, not a probe.
- **Local task 13** in the A1 image has no collision: `decode.csl` binds nothing under `external_schedule`, and the manifest at `group_allocation.py:223-231` lists it.
