# Layout C — state of play

Consolidated status of session `4b-mini-ppl-debug`, 2026-09-07 → 09-09.
Companion to the round-by-round record in
`docs/reports/2026-09-08-4b-layoutC-session-report.md`.

> **Latest direction, 2026-09-10:** Le switched implementation to the target
> full-height A2 geometry. A separate single-layer miniature now uses
> A1=8x8, A2=8x16, A3=8x8 and validates rebuilt QKV/X/Z paths in the simulator.
> Read the [tall-A2 report](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-tall-a2.md:1)
> for the current cursor, evidence, and remaining gates. The old `sim_cut3`
> scaffold and its column-collapse failure are historical context; they are
> not the geometry of the new entry. The full A1/A2/A3 group gate remains open.

> **Correction, 2026-09-10:** the historical "K prefill never lands" diagnosis
> below is superseded by
> [boundary validation](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-kv-boundary-validation.md:1).
> In local simulator cut3/cut2 runs, ingress is correct; A2's unconditional RoPE
> reset corrupts K, and cut2's final A2 row also lacks KV-cursor initialization.
> `local_px` is correct on every observed PE. Initial trial fixes/probes were
> removed; the subsequent authorized
> [permanent repair](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-kv-fix.md:1)
> is now installed and passes miniature KV regression and negative controls.
> QKV column collapse and constant sampled output still fail correctness gates.
> No CS-3 result is claimed.

**Nothing has been compiled at real size and no device job has been run.** Every
cycle figure is derived or measured compile-only; each is labelled.

---

## 1. What this session set out to do

It began as a handoff from `4b-wide-layer` about a stall in cut (ii)'s A1 stage.
It became something larger: **design and validate "layout C"** — a Qwen3-4B
decoder layer split into **three thinner stages** rather than two, tiling the
512 × 1024 WSE-3 allocation.

| stage | role |
|---|---|
| **A1** | project — RMSNorm, Q/K/V matvecs, the QKV column all-reduce, QK-norm, RoPE |
| **A2** | attend — KV write, score, softmax, P·V, O-proj, residual. **Sole KV owner** |
| **A3** | FFN — up/gate, SiLU, down, residual |

**The premise:** three stages instead of two drops the pacing stage from ATTN's
11,886 cyc/layer to A2's 8,434 — **1.41×**, derived from a measured per-slot
profile, never measured end to end. That number is an input, not a result, and
its denominator was measured at the shipped 256-wide geometry, so it is an
**upper bound** on the relative cost of anything compared against it.

---

## 2. The roadmap

Three tracks. The refactor is the spine; the prerequisites gate its last stages;
the checkers gate everything, because two of this project's gates turned out to be
incapable of failing.

### The refactor — C0 … C9

`analyses/2026-09-09-layoutC-refactor-plan.md` (revision 2, after Codex review
refuted revision 1 at the framework level).

`P_BLOCK_SIZE` currently means **four things at once**, all equal to 256 in every
production config, which is why a misclassification is invisible:

| name | meaning | today | target |
|---|---|--:|--:|
| **LANE** | head/tail band width, strip lanes, vocab Y-shard | 256 | **256** |
| **BW** | decode block width; attention/FFN X-shard denominator | 256 | **128** |
| **BH** | block-row pitch = the region's *allocated* height | 256 | **256** |
| **H_ROWS** | *active* rows in a block | = BH | **80 / 256 / 160**, per region |

| | stage | gate |
|---|---|---|
| C0 | freeze hashes; enumerate fixtures **and their expected outcome** | rejected geometries are expected-rejections, not baselines |
| C1 | define the geometry/config contract | legacy configs load; invalid ones are **rejected** |
| C2 | **build the checkers** (K1–K6 below) | each demonstrated *failing* on a seeded defect |
| C3 | **P1 + P2** designed and validated at miniature | two-layer miniature correct; transports frozen |
| C4 | **P3** D-cache fix, validated alone | A3 compiles at 128 wide; SRAM re-measured |
| C5 | equal-value rename, all aliases = `P_BLOCK_SIZE` | byte-identity via the *fixed* gate |
| C6 | separations **a** BW≠BH, **b** BW≠LANE, **c** LANE≠BH | every pair separated once, each with an observed failure |
| C7 | per-region `H_ROWS` | three stage heights, `H_ROWS > BW` on one |
| C8 | target geometry, **one layer** per group | oracle-correct; column-collapse negative control |
| C9 | 36 layers, five per group | end to end; bounded device run; compile-only SRAM |

**Why the coverage matrix (C6) exists:** the target has `LANE = BH = 256`, and
revision 1 only ever forced `LANE ≠ BW` and `BH ≠ BW`. A LANE-scoped consumer
misfiled as BH was invisible from first stage to last. Four quantities give six
pairs; **a pair never separated cannot detect a swap between its members.**

### The prerequisites — P1 … P4

| | item | state |
|---|---|---|
| **P1** | **fractional lane resharding** | **not designed.** `funnel_pe.csl` does *whole-lane* concatenation, `G = P/H`; at LANE = 256, 256/80 = 3.2 and 256/160 = 1.6. **A new transport, not an assert change.** |
| **P2** | **multi-layer feedback** | designed, reviewed, **§5 retracted** — see §4 |
| **P3** | **A3's D-cache** | probe applied, real fix undecided |
| **P4** | A2 shift + QKV diagonal | A2 shift designed and cross-reviewed; diagonal is a sketch |

### The checkers — K1 … K6

`analyses/2026-09-09-layoutC-checker-plan.md`. Rule for every one:
***a checker that has never been observed failing is not evidence.***

---

## 3. Where we are

### Settled and measured

**Per-PE SRAM** — compile-only, `scripts/sram_report.py`, 48 KB = 49,152 B/PE:

| stage | height | `dim_per_pe` | 5 layers | grows after deploy? |
|---|--:|--:|--:|---|
| A1 | 80 | 32 | **63.1 %** | no |
| **A2** | 256 | 10 | **85.4 %** | **yes — KV** |
| A3 | 160 | 16 | **97.9 %** | no |
| idle | 16 | — | — | 3.1 % of the wafer |

**The heights are forced, not chosen.** `assert dim % H_ROWS == 0` plus
2560 = 2⁹·5 leaves only `{…,64,80,128,160,256}`; A3 at 128 caps a group at 4
layers and 8 × 4 = 32 < 36; the next divisor above 160 is 256, which leaves A1
nothing. 8 groups × 5 layers = 40 ≥ 36 ✓ — but layout C's "zero waste" property
does not survive holding the model.

**The communication design**, end to end, after measured constants replaced
assumed ones (CE costs **19×–62×** the wire per word):

| path | mechanism | colours | cost |
|---|---|--:|--:|
| A2 in-square shift | senders: 2 switch positions on one colour; **receivers: no switch**, static 2-tx + counter filter, `max_counter = P−1`, `init_counter = ((N−j) mod N)·P` | 2 switch-capable from `{9,12,13,16}` | 704/shift, ~1,432/layer (17 %) |
| QKV southward | Y-replicated → router multicast | 1 **ordinary** | 24 beats |
| QKV eastward | **diagonal source, k = 1** — one sender per row | 1 ordinary | 24 beats/row-link |
| fallback | K-pipe fold, L = 2 | 4 ordinary | 8,320–27,904/layer |

### Hard constraints found

- **A3 has two independent overflows.** A 512-byte `.csl_dcache` window fails at
  `ffn_dim_per_pe = 76` (624 > 512), *independently of layers and height*, purely
  because the block is 128 wide. Removing that pin revealed a **second**,
  bank-SRAM overflow underneath.
- **`bsz = 2` does not fit.** The `bsz`-linear terms total ≈ 24,400 B against
  A2's 3,888 B of headroom. **Any throughput plan assuming batching needs this
  resolved first, and it is not a refactor question.**
- **Only 16 of 24 colours can switch** (`memcpy/sys_params.csl:42-44`), and id 0
  is spent. Four candidates: `{9, 12, 13, 16}`.
- **`max_counter` is inclusive** and `builtins.md` says "(exclusive)" — silent
  corruption, not a compile error.

### Checkers

| | state | evidence |
|---|---|---|
| **K1** record completeness | **closed** | 7 assertions, **26 fixtures**, + 12 adversarial cases from review |
| **K2** verdict sink | **closed** | 4 checks now fail the run; `INCONCLUSIVE` = FAIL; skips visible and never counted as passing; 5 real runs + **11 unit cases** |
| **K3** column checker | **closed** | **15/15**; the old checker demonstrably *passed* 2/128-distinct, layer-3-only and row-200-only defects |
| **K4** KV-seed in cut mode | **closed for bring-up; unavailable at target** | 7/7 unit + **two real cut-mode runs**: healthy → `KV-SEED PASS ... mode=cut, rows=[0,1]`; one tile corrupted → `FAIL (1 tiles)`, strict mode raises, `rc=1`. **But see the guard gap below.** |
| K5 head/tail isolation | not started | — |
| K6 oracle as a gate | not started | — |

#### K4's guard gap — the instrument does not reach the target

`_kv_seed_check` is `O(P²)` `read_symbol`, so it carries a size guard,
`P·P·P_Y_BLOCK_NUM > 4096 → SKIP`. That guard is correct and was kept. Its
consequence was not noticed until K4 computed it:

| config | P | `P_Y_BLOCK_NUM` | product | runs? |
|---|--:|--:|--:|---|
| `sim_cut2.json` | 8 | 4 | 256 | ✅ verified by real run |
| `sim_cut3.json` | 8 | 2 | 128 | ✅ verified by real run |
| **layout C target, 2-row chain** | **128** | 2 | **32,768** | ❌ **8× over — SKIPS** |
| **layout C target, 4-row chain** | **128** | 4 | **65,536** | ❌ **16× over — SKIPS** |

**So the bit-exact KV check runs at every bring-up size in this tree and does not
run at the geometry layout C exists to build.** It is not "always skips" — it
genuinely exercises today's configs — and it is not solved. It is an instrument
whose coverage stops just short of the thing being measured, which is the ninth
instance of this session's recurring pattern and the first one found *by* a
checker rather than in spite of one.

A target-size KV check needs a mechanism that is not `O(P²)` host `read_symbol`
— that is an open design item, not a parameter change, and device has no
`read_symbol` at all.

#### What was latent and what was live

K4 corrected the weighting I had given these, and the correction matters:

- **The row-parity owner shortcut was latent, not firing.** Every CHAIN that
  exists today (`stage_cut` 2, 3, 5, 6, 7) pairs `owns_kv` with role 1
  exclusively, so the shortcut produces no wrong read in any config that can
  currently be built. It is now derived from CHAIN anyway, with an assert that
  fires loudly if a future CHAIN moves `owns_kv` to role 0.
- **The compacted index was live and would have broken cut mode immediately.**
  `inj_xk`/`inj_xv` are compacted to `kv_rows`, not indexed by raw row number.

#### Historical diagnosis, superseded 2026-09-10: A2's K prefill "never lands"

**Status: reproduced independently from a clean tree, on three configs. This is
the first genuine device defect this effort has found, and it blocks layout C.**
The kernel has not been touched.

Running the now-working KV check on `sim_cut3.json` — a real A1/A2/FFN cut chain,
not the vanilla-KV diagnostic:

```
[decode] KV-SEED FAIL (64 tiles) (prefill_len_per_pe=1, mode=cut, rows=[1])
```

64 = H_ROWS(8) × P_BLOCK_SIZE(8) × layers(1) — **every K comparison fails and
zero V comparisons fail.** V's prefill lands correctly; K's does not.

```
repro:  SINGULARITYENV__DEBUG_KV_SEED=1 ./run_sim.sh \
          model_config/sim_cut3.json request_config/sim_tiny_forced.json --name out_repro
```

**It is not an off-by-one, though it first looked like one.** The debug print
sliced the cache to `[:plen]`, which at `plen = 1` cannot distinguish *written one
position late* from *never written*. Widening the dump to the full sequence extent
settles it:

```
[K MISMATCH DEBUG] by=1 ly=0 lx=0 l=0 ek=[15673, 15552, 15533, 15437] gk_l=[0, 0, 0, 0]
  [K WHERE] full seq (b=0,c=0) = [0, 15658, 0, 0]
  [K WHERE] nonzero anywhere in slab = 4/16; expected head value 15673 found at []
            (NOWHERE -> not an off-by-one)
```

Three independent facts rule out a shifted write:

1. **The expected value is nowhere in the slab** — not at position 1, not
   anywhere. A shifted write would have deposited it intact one slot over.
2. **The on-chip content is byte-identical across all 8 PE columns**
   (`[0, 15658, 0, 0]` for every `lx`) while the host reference differs per
   column, as it must — each column holds a different shard. Whatever sits at
   position 1 is not per-column sharded prefill K.
3. Only **4 of 16** slots are nonzero.

The nonzero at position 1 is the *decode* step's own K write: at `plen = 1`,
position 0 is the prefill slot and position 1 is exactly where the first decode
step writes. **A `plen = 2` run settles it** — there decode's write lands at
position 2, outside the checked prefix, and both checked positions read zero:

```
plen=2:  gk_l = [0, 0, 0, 0, 0, 0, 0, 0]      (kc=4 × plen=2, all zero, all 8 columns)
```

Nothing was written. Not shifted.

#### Isolated to the A2 stage, not to cut-mode plumbing

`sim_cut6.json` is the decisive config: **one chain containing both an A2 KV row
and two vanilla `stage_kind=0` KV rows.**

| config | chain | result |
|---|---|---|
| `sim_cut3` | single cut layer, A2 on row 1 | 64 bad = **all K**, row 1 |
| **`sim_cut6`** | **cut L0 (A2 row 1) + vanilla L1–2 (rows 2, 3)** | **64 bad of 192 possible — every mismatch is `by=1`. Rows 2 and 3 pass clean in the same run.** |
| `sim_cut2` | **two chained cut layers**, A2 on rows 1 and 3 | 144 bad. **Row 1 K empty; row 3 K and V present but column-invariant and wrong.** `LOCAL-TOPK` also **fails** — see below |
| `sim_cut7` | vanilla L0–1 + cut L2 | no result — unrelated simulator stall (`received length (0 bytes)… could be a kernel stall`), **a separate unexplained issue** |

**cut6 is as clean an isolation as this instrument can produce**: identical
launcher, identical run, identical host reference path, vanilla and A2 KV owners
side by side — and only A2 fails. The defect belongs to the A2 stage kind, not to
cut-mode plumbing.

#### cut2 shows a *second, different* signature — and it sharpens the diagnosis

cut2's extra damage was invisible until an instrument bug was fixed: K and V
mismatches shared one `bad <= 8` print budget, so row 1's K failures exhausted it
before any V detail printed. **The only symptom distinguishing cut2 from the
others was being hidden by the diagnostic's own budget.** Budgets are now per
`(kind, row)`, and V got the same full-extent dump as K. Rerun:

| cut2 row | K | V |
|---|---|---|
| **row 1** (first cut layer) | `gk_l = [0,0,0,0]`, full seq `[0, 15658, 0, 0]` — **empty; never written** | **clean** |
| **row 3** (second cut layer) | `gk_l = [15684, 15206, 15491, 15592]`, full seq `[15684, 0, 0, 0]` — **written, at the correct position 0, with wrong data** | **wrong data**, same shape |

**The row-3 signature is the informative one.** Its on-chip content is
byte-identical across every sampled column — one unique `gk_l` and one unique
`gv_l` across four columns — while the host reference has four distinct expected
values, one per column, as it must, since each column holds a different shard.

**So row 3 received *a* tile, just the same one everywhere; row 1 received
nothing.** Both are what a broken tile distribution looks like in a
recv-then-forward chain — one end starved, the other fed duplicates. That is a far
more specific hypothesis than "the K phase may not run", and it points at
`kv_ingress`'s `const num_tiles = local_px + 1` (`decode.csl:2118`), whose comment
warns that "`local_px` is always relative to that role region". **If A2's
`local_px` is relative to the wrong region, the per-column tile counts are wrong
in exactly this way.** Untested — but it is the first hypothesis to try, and it is
cheap to test.

`LOCAL-TOPK` also fails on cut2 (`1/1 batches`), confirmed in my own run, so this
has a demonstrated downstream numerical consequence and is not a KV-SEED-only
artefact.

**Ruled out as the cause:** `kv_cols` and `kv_len_per_pe` are set with
`set_param_all` uniformly across every region (`launch.py:1739,1743`), so a
differing stride between A2 and vanilla is not the explanation.

**So triage points at whether A2's K ingress phase ran for that row at all — not
at index arithmetic.** `kv_ingress_layer_phase` writes K through a per-channel
`while (f < kv_cols)` loop of `@set_dsd_base_addr` + `@fmovh`, where V does one
contiguous transfer per batch (`decode.csl:2060-2106`). The asymmetry is real and
matches the K-only failure, but the code is unconditional — no `stage_kind`
branch — and the same path lands correctly for vanilla's ATTN role and for
`sim_cut5.json`'s vanilla-`stage_kind=0` KV row. **Something distinguishes A2's
compiled image from vanilla's and it has not been isolated.**

The control is sound: `sim_cut5.json` runs identical launcher CHAIN plumbing with
the vanilla KV path and passes clean, and the checker's read formula is shared
between both branches — so the read side has a passing positive control against
the identical host reference.

It was invisible until now for a structural reason: **the check never ran in cut
mode at all.**

**K4's most valuable case is the one that throws nothing.** Two seeded defects
show a raw `by` index into `inj_xk` reading the wrong row once `kv_rows ≠
range(P_Y_BLOCK_NUM)`. The first raises `IndexError` — survivable, because it is
loud. The second does not:

```
kv_rows=[0, 2, 3, 5]:  fixed row 3 -> inj_xk[2] = 3.0 (correct)
                       naive row 3 -> inj_xk[3] = 5.0 (WRONG row's data, silently, no exception)
```

Layout C is exactly the geometry where `kv_rows` stops being `range(...)`. The
row-parity shortcut that today's code relies on happens to agree with CHAIN for
**every config shipped so far**, which is why nothing has caught it — the same
shape as the four-way `P_BLOCK_SIZE` conflation.

K4 also fixed the interpreter trap that cost time on K2: its suite now refuses to
run under plain `python3` with a named reason and a `VERDICT: ERROR (wrong
interpreter -- no case was run)`, instead of reporting a false `0/10`.

**Two gates were found incapable of failing**, and both had been reporting PASS:
`compare_records.py` passed on two empty archives; `run_sim_gates.sh` always
exited 0 because its last statement was an `echo`. Both fixed, with self-tests
that check the checkers.

### Not started

C0–C9 (no code), P1, P3's real fix, K5, K6, and the receive schedule P2 needs.

**Four of six checkers are closed, and every one of them found a defect in the
plan that specified it** — a wrong record key that would have matched zero rounds,
a fourth print-and-continue check the spec listed three of, a geometry claim about
idle rows that cut mode currently forbids, and a row-parity assumption that is
true today and false under layout C.

---

## 4. Approaches tried and abandoned

Kept because the record is more useful than the tidy version.

| approach | outcome |
|---|---|
| **Cut (ii) as-is** | **refuted by measurement** — KV identical across all 8 columns vs vanilla's 8/8 distinct, same geometry |
| **Floating-point re-association** as the cause of cut (ii)'s drift | **killed twice** — the mirror is byte-neutral (0/200 differing, with a negative control at 199/200), and the index is not mirrored anyway |
| **H2's "margin" premise** | **refuted** — vanilla's own tail has the same ~10-cycle margin |
| **Colour pairs / K-pipe fold for the shift** | **superseded.** The one-`rx`-per-colour rule is per switch *position* on WSE-3, not per colour. Fold is now 6×–20× worse, not a near-equal fallback |
| **8–16 colours for the shift** | wrong by an order of magnitude — the minimum is 1 per direction |
| **repaint-as-advance** | declined — 128 serialized CE round trips |
| **L = 2 → L = 4**, **k = 1 → k = 8** | declined by the same test: ~1.3–1.5 % of a layer is not worth a scarce id plus mechanism |
| **One colour time-multiplexed across both shifts** | declined — after shift 1 every sender is at its last switch position and immune; `SWITCH_RST` behaviour under immunity is **uncharacterised** |
| **256-wide geometry** | superseded by 128-wide (I had to be told to count again) |
| **Layout C's "zero waste"** | does not survive holding 36 layers — 16 idle rows per group |
| **"Relax the funnel's divisibility assert"** | **wrong shape** — the funnel concatenates whole lanes; the target ratios are fractional. New transport required |
| **"A loop is not a pipeline" (my P2 §5)** | **retracted.** Vanilla already runs ATTN→FFN→ATTN across layers (`decode.csl:1895-1911`); unrolled by layer the dependency graph is a DAG; and C1 requires synchronous collectives, not acyclicity |
| **Byte-identity as a sufficient Stage-1 gate** | refuted — while all four quantities are equal, a wrong bucket produces identical output |

---

## 5. The pattern worth carrying forward

**Eleven instances in two days of a property of the instrument read as a property
of the thing measured.** The last two are the most instructive, because both came
out of the machinery built to prevent exactly this:

- **The size guard.** A checker recorded as "closed" while it silently declines to
  run at the only geometry that matters. Caught *by* the process rather than in
  spite of it — the first time this session that happened.
- **The `[:plen]` slice.** The debug print's *display width* read as the
  instrument's *reach*. The data that distinguishes "written late" from "never
  written" was on the machine the whole time; the print discarded it before anyone
  saw it, and a confident off-by-one diagnosis nearly sent triage at index
  arithmetic for a bug that is a dead ingress. **A one-line widening of the dump
  refuted the headline.**

The earlier nine: — a probe window read as A1's content; a testbed's
one-layer pin read as a design choice; a `grep` scoped one directory too narrow
read as "those files do not exist"; the artefact size of two *failed* compiles
read as compile-only's footprint (7.9 GB left on a disk this project has already
filled once); an interpreter error read as a suite failing 0/10; a sandbox
supervisor's "low on memory" read as a kernel OOM. Three of the nine were mine.

**The question that catches all of them:** *does this instrument have the coverage
I am assuming it has?*

**And a corollary that appeared three times while building the checkers:**
widening an instrument's coverage moves it into territory where "unusual" and
"wrong" are no longer the same thing. K1's `HOST_STOP_TOK` terminator, K3's
zero-filled padding columns, K3's not-yet-reached rows — each needed its own model
of *correct-but-unusual there*, not just "sample the region". **A checker that can
produce a false failure is worse than one that is incomplete: it teaches people to
ignore it, including when it is right.**

Recorded in project memory as `instrument-property-read-as-world-property`.

**A related discipline that paid.** Every agent task carried the instruction
*read the source, do not trust this brief*. Three for three, the brief was wrong
and the source was right — including a record key name (`round{r}_topk_vals_u16`)
that would have made the checker match **zero rounds and pass everything**. That
failure mode, sitting in the document written to eliminate it.

---

## 6. What to do next

0. **Repair the remaining A1-to-A2 QKV column collapse.** A2's RoPE reset and
   cut-local layer-count defects are permanently repaired and miniature KV
   controls pass; the strict column gate still sees 8/8 distinct columns
   become 1/8. Constant sampled output also fails the record gate. Source
   locations, limits and next boundary checks are in the
   [permanent repair report](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-kv-fix.md:1).
   Full per-stage buffer ownership/removal and linked SRAM/context audits
   remain open; representative RoPE symbol checks are not a full audit. The
   complete A1/A2/A3 group correctness gate must pass before inter-group/head/tail
   connection work or end-to-end performance tests.
1. **Design a target-size KV check.** K4's is `O(P²)` `read_symbol` and skips at
   P = 128; device has no `read_symbol` at all. Then K5 and K6. C2 gates
   everything after it.
2. **Write P2's receive schedule** — when A1 accepts external input versus
   feedback, how many tokens may occupy a group (forced mode injects without
   waiting, so "one in flight" cannot be assumed), and how the header and STOP
   traverse and leave. Without it neither a liveness argument nor a two-layer
   miniature has a target.
3. **Decide P3** — tile the SiLU, or accept losing the documented 2× on the poly
   ops. A3's real bank SRAM is unmeasurable until this lands.
4. **Design P1.** It is a new transport and it is on the critical path for C3.
5. Only then C0.

**One thing that should not wait for any of it:** `bsz = 2` does not fit. If
layout C's value case assumes batching, that assumption needs re-examining now
rather than after the refactor.
