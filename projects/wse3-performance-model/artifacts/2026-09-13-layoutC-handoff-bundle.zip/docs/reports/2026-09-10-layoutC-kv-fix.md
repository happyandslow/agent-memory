# Layout C: permanent A2 KV state fixes

2026-09-10. Scope: repair the two defects confirmed in the
[boundary experiment](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-kv-boundary-validation.md:1).
Both fixes are installed and pass their miniature simulator KV gates. Complete
A1/A2/A3 group numerical correctness remains open. No CS-3 execution,
target-size compilation, SRAM-capacity measurement, or performance claim.

## Implementation

- [decode.csl:103](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:103)
  separates actual RoPE ownership from diagnostic storage allocation.
  [round_reset:397](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:397)
  runs RoPE initialization only in A1 or vanilla attention. A2 no longer runs
  full-width RoPE DSD operations against its one-element placeholders.
- [launch.py:1827](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:1827)
  passes CHAIN-derived local bank ownership: one for a compute stage, zero for
  a relay. This includes vanilla stages embedded in a cut chain.
  [init_once:357](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:357)
  uses that count; ordinary vanilla retains its original coordinate-derived
  distribution through default `local_layer_count=-1`. Thus cut2's last A2 row
  initializes bank zero and its prefill cursor. Compile-time assertions reject
  counts outside `[-1, max_layers_per_block]`.

Only `launch.py` and `src/decode.csl` differ from the 131-file pre-fix source
manifest. Their repaired SHA-256 hashes are respectively
`ce4224518f6c78476baf188f5eaf7318110777c9e9b2b7901ae53af0727afb0f` and
`d5e79d79fb32ef165e9c7816001d95fd226082e5cab98d855b128088895d9e31`.
The evidence bundle includes the exact patch and before/after manifests because
the model tree is untracked; Git HEAD alone does not identify this source.

## Simulator results

Each configuration/intervention ran once. Spatial tile counts and repeated
rounds are not independent statistical repetitions. These are miniature
`bsz=1` runs; cut fixtures use `P=8`. Existing in-launcher checks were used
without adding validation instrumentation to model code.

| Case | Result and scope |
|---|---|
| cut3, prefill 8, decode 2 | KV-SEED and LOCAL-TOPK pass |
| cut2, prefill 8, decode 2 | Both pass, including final A2 owner row 3 |
| cut2, prefill 16, decode 2 | Both pass with two prefill slots per PE |
| cut6, prefill 8, decode 2 | Both pass across A2 and two embedded vanilla KV rows |
| cut3, two identical rounds, prefill 8/decode 2 | Both pass; all three output arrays bit-identical across rounds |
| ordinary vanilla before/after | Both pass; comparator verifies all three output arrays identical |
| remove only RoPE guard in disposable copy | Strict failure: KV-SEED reports 64 bad tiles |
| remove only host local-count assignment in disposable copy | Strict failure: KV-SEED reports 32 bad tiles; LOCAL-TOPK also fails |
| repaired cut3 with QKV_COL_CHECK=1 | KV passes; QKV-COL fails, process exits 1 |
| repaired cut2, varied head inputs [18,19], decode 3 | KV-SEED and LOCAL-TOPK pass; record gate still fails |

**The full record gate did not pass.** Existing `check_records.py` rejected all
eight checked archives on `DEGENERATE`: sampled token 18 repeats across every
step, including the varied-head-input case. Other reported record assertions
did not fail. The varied-input rearm follow-up was not run after this failure.
`FORCED_TOKENS` controls head inputs, not tail outputs
([launch.py:787](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:787));
constant output cannot be excused merely because forced mode is enabled.
Vanilla byte identity is a regression observation, not proof of correctness.

The existing QKV gate still finds A2 samples `(row=1, ly=0/1, layer=0)` changing
from 8/8 distinct pre columns to 1/8 post columns. This is direct simulator
evidence of a remaining defect. Even cut3's diagnostic top-k oracle overlap of
1.0 does not override that failure; cut2/cut6 overlap is lower. No group gate
or milestone is marked complete.

One malformed temporary rearm request failed before compilation (two forced
lane lists for `bsz=1`); the corrected request completed two rounds. An initial
container comparator could not see its sibling baseline directory; the host
comparator rerun passed. Both excluded attempts remain in the logs.

## What “one-element buffer” means

It means an allocation remains at length one in a stage that does not own the
operation, rather than being absent from that stage's linked image. Different
stage ELF files do not establish complete buffer removal.

This session inspected representative A1, A2, and A3/FFN ELF object-symbol
tables for repaired cut3, retaining their identities, coordinates and complete
object inventories in the evidence JSON. It did **not** classify the semantic
ownership of every buffer in every region/configuration.

The six exported f32 RoPE states at
[decode.csl:665](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:665)
are `cos_cur_f32`, `sin_cur_f32`, `delta_cos_f32`, `delta_sin_f32`,
`delta_p_cos_f32`, and `delta_p_sin_f32`. Each remains a 4-byte symbol in the
sampled A2 and FFN images: 24 bytes of raw payload per sampled PE image. A1
retains full-sized states. The four non-exported RoPE scratch arrays at
[decode.csl:684](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:684)
are absent from the repaired A2/FFN symbol tables after the unreachable reset
path is eliminated. Exported placeholders remain to be removed with their
host/export dependencies. These byte counts exclude alignment and metadata;
they are not a measured context-capacity saving.

## Next bounded task

Locate and repair the QKV column collapse within the A1-to-A2 computation and
handoff, using distinct per-column values at the send, receive, and consumption
boundaries. Require the existing strict column gate to pass and a negative
control to fail. Then validate numerical stage outputs against an independent
reference; investigate the constant sampled output without weakening the
record gate. Keep temporary probes disposable.

The complete per-stage buffer ownership/removal and linked SRAM audit remains
on the local TODO. Multi-layer group feedback and target geometry still need
validation. Do not start inter-group/head-tail connection work or end-to-end
performance testing before the full group-correctness gate passes.

## Evidence and reproduction

- [Evidence JSON](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-kv-fix-evidence.json):
  exact model/request fixtures, commands, source identities, verdict summaries,
  raw output arrays, negative interventions, and linked-symbol inventory.
- [Run logs](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-kv-fix-runs.log):
  named command outputs, including failed and excluded attempts.

Reproduce in disposable copies of the identified source with the recorded SDK
environment, using `SINGULARITYENV_DUMP_RECORDS=1` and the manifest's bounded
`run_sim.sh` commands. Materialize temporary request JSON from `fixtures`.
The initial cut3 uses `model_config/sim_cut3.json`,
`request_config/sim_tiny_forced.json`, and `--name out_cut3` with the same
environment and 150-second timeout. Negative copies remove exactly the RoPE
guard or host local-count assignment; never apply these reversals to production.
The final cleanup record in the JSON verifies removal of the disposable root
and byte preservation of the installed fixes. No new probes or validation
fixtures remain in model source.
