# Layout C: A2 KV boundary validation and stage-image audit

2026-09-10. **Evidence: local SDK 2.10 simulator and linked miniature ELFs.**
No CS-3 job, target-size compile, or performance measurement was performed.
Each listed configuration/intervention was run once; PE counts below are spatial
coverage, not independent experiment repetitions.

## Result and scope

The miniature's KV transport delivers the correct per-column prefill. Two
independent downstream faults corrupt it:

1. A2 executes full-width RoPE reset operations against single-element RoPE
   arrays. K is correct immediately after ingress and wrong immediately after
   reset. Gating that initialization to the stage owning RoPE removes the fault.
2. The cut2 final A2 row inherits a zero local-layer count from vanilla's edge
   allocation rule. Its KV cursor remains zero, so the first decode append
   overwrites prefill position zero. Initializing the cut stage's actual local
   layer bank moves the append to the prefill boundary and preserves the prefix.

**No repair or diagnostic code was installed in the model tree.** All probes
and trial fixes ran in a disposable source copy and were removed after evidence
collection. The production-source defects therefore remain open implementation
TODOs. This validation does not close A1/A2/A3 group correctness, target geometry,
multi-layer local feedback, inter-group/head/tail connections, or numerical
oracle/performance gates.

This supersedes the handoff's causal wording that K prefill "never lands" and
its prioritization of wrong `local_px`: a post-decode cache dump could not
distinguish failed ingress from subsequent overwrite. All observed probe PEs
had the expected column-relative `local_px`.

## Provenance and artifacts

- Source tree:
  `/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code`.
- Repository: `main`, HEAD `38ac5b7a7d999689fe472c766e233fe545502c95`, remote
  `https://github.com/happyandslow/wse3-performance-model.git`. The source tree
  is untracked, so HEAD alone does not identify these programs.
- Original `src/decode.csl` SHA-256:
  `edb208b34dd9d80c5c476a40bab85122a0097c91628814fbca447bdc73a8189b`.
- Original `launch.py` SHA-256:
  `41f21a9d9f337d776aa17c7ace1cf58760f39188689fc70eb21e3ad52334fab1`.
- SDK SIF: `sdk-cbcore-2.10.0-sdk-202604101435-4586d3f0d8.sif`.
- [Structured evidence](2026-09-10-layoutC-kv-boundary-evidence.json): source
  manifest, exact configs, per-PE expected/actual cache bits and QKV, boundary
  markers, cursor state, negative controls, ELF identity/symbol audit, and
  cleanup verification.
- [Raw run logs](2026-09-10-layoutC-kv-boundary-runs.log): successful and failed
  attempts, including the instrument sanity failures. Host/simulator times in
  these logs are not hardware performance evidence.

## Configuration and temporary method

`sim_cut3.json`: P=8, two block rows, one model layer; A2 is row 1.
`sim_cut2.json`: P=8, four block rows, two model layers; A2 rows are 1 and 3.
Both use bsz=1, dim=64, 8 query heads, 2 KV heads, head_dim=16, four KV channels
per PE, four sequence slots per PE, BF16, and one local layer bank per stage.
The standard request is `PREFILL_LENS=[8]`, `DECODE_LENS=[2]`, token 0 with
forced token 18. A second request changes prefill to 16 (two slots per PE).

Temporary host code assigns finite, unique BF16 bit patterns to each flattened
K/V element, then uses the existing packer, adaptor, injector, westward transport,
and cache-write code. The expected per-PE slab comes from the independently
identified row/column slice before transport. K and V use disjoint tag ranges.

A temporary runtime selector stops A2 at three boundaries, using its existing
`dbg_stage` as an explicit completion marker:

1. **B1:** after all K/V ingress writes, before ingress queue drain/rebind.
2. **B2:** after `round_reset`, before activation reception/decode.
3. **B3:** immediately after the first `process_kv` append, before score or
   softmax. The normal stage wrapper saves its cursor bank before stopping.

The host allows two seconds of execution, stops the simulator, and reads every
active PE in the selected A2 row(s). Time alone is never success: missing markers
fail the probe. B3 on cut2 targets row 3 only, allowing the upstream A2 to feed it.
No additional snapshot arrays are inserted into device SRAM. The temporary
selector and exports can affect layout; therefore uninstrumented full-path
controls and the original ELF's symbol addresses are also retained.

## Boundary results

Counts are mismatching K/V **tiles** among all 64 PEs per A2 row. All accepted
runs have zero missing boundary markers and zero wrong `local_px` values.

| Case | Boundary | Row | Bad K | Bad V | Cursor observation |
| --- | --- | ---: | ---: | ---: | --- |
| Original logic, cut3 | B1 | 1 | 0 | 0 | reset has not run |
| Original logic, cut3 | B2 | 1 | 64 | 0 | 1 on every PE |
| Original logic, cut3 | B3 | 1 | 64 | 0 | owner row advances 1 to 2 |
| Original logic, cut2 | B1 | 1 / 3 | 0 / 0 | 0 / 0 | row 3 already reports zero local layers |
| Original logic, cut2 | B2 | 1 / 3 | 64 / 64 | 0 / 0 | row 1 = 1; row 3 = 0 |
| Original logic, cut2 | B3 | 3 | 64 | 8 | owner row appends at 0 |
| RoPE guard only, cut3 | B2 | 1 | 0 | 0 | 1 on every PE |
| RoPE guard only, cut3 | B3 | 1 | 0 | 0 | owner row appends at 1 |
| RoPE guard only, cut2 | B3 | 3 | 8 | 8 | owner row still appends at 0 |
| RoPE guard + local-layer correction, cut2 | B3 | 3 | 0 | 0 | owner row appends at 1 |
| Both corrections, cut2, prefill=16 | B3 | 3 | 0 | 0 | owner row appends at 2 |

For the last four accepted B3 intervention cases, all 64 PE cursor banks match
the expected state; the eight owner PEs' appended K and V match their received
QKV bits exactly. This is a copy/placement check, not an independent oracle for
the numerical correctness of the received QKV.

Every healthy K comparison was also repeated with one reference bit flipped;
the same equality predicate rejected the corrupted reference. The positive
cases cover all PEs, so this negative-control set is nonempty.

### Full-path controls with all boundary probes removed

These runs use the original launcher, its original deterministic mock weights
and KV, and two decode steps. Only the named trial kernel changes differ.

| Config / trial intervention | KV-SEED | LOCAL-TOPK | Process exit |
| --- | --- | --- | ---: |
| cut3, unchanged | FAIL: 64 tiles | PASS | 1 |
| cut2, unchanged | FAIL: 144 tiles | FAIL | 1 |
| cut3, RoPE guard only | PASS | PASS | 0 |
| cut2, both trial corrections | PASS | PASS | 0 |

This confirms that the boundary probes did not invent either symptom or the
effect of the interventions. It does **not** establish model numerical
correctness: LOCAL-TOPK compares top-k against the same run's logits, while
ROUTE-CHECK and QKV-COL were explicitly skipped. The corrected cut2 full-path
run still reports step-0 top-2 overlap 0.5 against its independent chain oracle
(diagnostic, not a numerical acceptance gate). Group correctness remains open.

## Source-level causes

### RoPE ownership mismatch

- A2 makes `st_attn_head` false, so `attn_half_elems` is 1:
  [predicates and allocation](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:103).
- RoPE arrays use that allocation, while their DSD extents still use
  `_attn_per_pe / 2` (eight f32 elements in this miniature):
  [arrays and DSDs](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:656).
- KV owners call `round_reset()` after ingress, and reset unconditionally calls
  `rope_init_from_delta_p()`:
  [resume](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:2145),
  [reset](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:385).
- The initializer executes the overlong DSDs:
  [rotation/init](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:790).

In the **original**, uninstrumented cut3 A2 `decode-15.elf`, the four RoPE
scratch arrays occupy four bytes each at `0x2f80`, `0x2f84`, `0x2f88`, and
`0x2f8c`. XKCache is 32 bytes at `0x2f90`, and XVCache starts at `0x2fb0`.
The 32-byte scratch writes overlap K's checked prefix addresses and stop before
V. The B1/B2 differential plus the isolated RoPE guard establishes the causal
path in the simulator. These addresses belong to this exact ELF only.

### Cut-chain layer ownership mismatch

- Host cut mode pins one local layer per stage, but the common compiler
  parameter remains the model's total `n_layers`:
  [cut assignment](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:1045),
  [parameter](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:1768).
- `init_once()` applies the vanilla missing-layer formula to cut2's four rows
  and two layers, leaving its last row with zero local layers:
  [formula](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:355).
- Reset skips that bank, but A2 still selects bank zero and executes:
  [reset loop](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:391),
  [A2 entry](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:2461).
- [process_kv](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1367)
  then appends at the stale zero cursor. The trial intervention overrides the
  local count for non-vanilla cut stages to the allocated one-layer count.
  This is a diagnostic intervention, not a general CHAIN/multi-layer fix design.

## Stage binary and buffer audit

The miniature **already has separate compiled stage images**, despite sharing
`decode.csl`. Source region creation and `stage_kind` assignment are in
[launch.py](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:1804).
The original `plan.json` region rectangles and `sim.lst` per-coordinate ELF map
confirm the following for every PE in each 8x8 region:

| Stage | Region | ELF | Selected linked storage |
| --- | --- | --- | --- |
| A1 | `decode_attn_r0` | `decode-12.elf` | Q weight 256 B; K/V weights 64 B each; K/V cache placeholders 2 B each |
| Transport relay | `decode_ffn_r0` | `decode-14.elf` | QKV tile 48 B; unused weight/cache placeholders remain |
| A2 | `decode_attn_r1` | `decode-15.elf` | K/V caches 32 B each; O weight 256 B; Q/K/V and FFN weight placeholders 2 B each; RoPE arrays 4 B each |
| A3/FFN content | `decode_ffn_r1` | `decode-16.elf` | Up/gate/down weights 256 B each; K/V cache placeholders 2 B each; RoPE state placeholders remain |

The three compute ELF SHA-256 values are distinct and are recorded in the
structured evidence. A3 here uses the vanilla FFN role specialization; it is
not a validation of the final target-height A3 image.

Stage-specialized compilation is therefore present, but **complete removal of
non-owned storage is not**. This audit shows actual residual symbols rather
than assuming every source declaration survives linking. No context-capacity
gain is claimed from these miniature byte counts. The plan TODO requires
removing non-owned buffers and auditing every initialization/DSD/pointer
consumer, then measuring final-image SRAM and supported KV capacity.

## Instrument failures retained

1. The first `/tmp` launch failed before compilation because the SDK wrapper's
   container mounts could not resolve that working directory. The disposable
   tree was moved under `/home/lexu/.cache`; no kernel conclusion uses that run.
2. The initial cut2 tag generator rejected a valid 2048-element array with an
   overly strict `<2048` guard. It was corrected to `<=4096`, keeping finite,
   disjoint tag ranges. The rejected attempt never compiled or ran.
3. Stopping both A2 stages at B3 starved the downstream A2. The marker gate
   rejected 64 missing markers with exit 1. Targeting only row 3 preserves its
   upstream input and passes the reachability gate. This failed case is not
   counted as a completed boundary observation.

## Reproduction and rollback boundary

Start from the recorded source hashes in a disposable copy. First reproduce
the unmodified `sim_cut3.json` / `sim_tiny_forced.json` KV-SEED failure. Add only
the temporary runtime stop selector, export existing state, and the host tag,
stop/read, marker and equality checks described above. Run B1/B2/B3 in order;
target only the final A2 for cut2 B3. Test the RoPE guard separately, then add
the cut-local bank initialization intervention; repeat the final append test
with prefill 16. Use bounded processes (180 seconds per miniature), suppressed
simfab traces, and fail on absent markers rather than increasing a sleep.

Finally remove the probes before full-path controls, collect logs and small
structured evidence, compare all original source-file hashes, and remove only
the disposable tree. Preserve pre-existing backups, scaffolds, and diagnostics
in the original checkout. No Git stage/reset/clean/commit/push is part of this
procedure.

**Final verification:** 11 accepted boundary cases match their specified
corruption counts and markers; 504 healthy-K comparisons reject a one-bit
reference corruption. All 131 original source-tree files match their captured
SHA-256 values. The disposable experiment directory, temporary probes, trial
fixes, and generated binaries have been deleted. Existing model diagnostics and
SRAM scaffolds were preserved. Only the repository instructions, local planning/
handoff corrections, and this report's small evidence artifacts changed; no
Git staging or history operation was performed.
