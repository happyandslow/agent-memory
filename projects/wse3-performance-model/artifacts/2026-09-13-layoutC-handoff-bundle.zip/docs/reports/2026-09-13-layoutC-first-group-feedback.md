# LayoutC first-group feedback implementation and verification

Date: 2026-09-13. Scope: one unequal-height A1/A2/A3 group, local layer
feedback, consecutive fixture tokens, and its resource/closure checks.

The first group now executes distinct layer banks with feedback entirely on
CS-3. Full geometry is A1 128×80, A2 128×256, A3 128×160, with 16 spare rows.
The fixture uses Qwen3-4B dimensions (hidden 2560, attention 4096, KV 1024,
head 128, FFN 9728), five synthetic independent weight banks, capacity 8192,
and prefill 1280. This is **not** the trained 36-layer model or its request loop.
Token inputs and prefill are baked; no host round trip is used between layers.

## Implemented behavior

- Each A3 source row has one sender, column 0. Northbound U16 traverses the
  WEST strip through routers only. Source rows arrive descending: row `2r+1`
  fills A1 offset16, then row `2r` fills offset0. Every destination column
  receives the same complete row through RAMP plus horizontal multicast.
  Source: [group_link.csl:63](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/group_link.csl:63),
  [group_routing.py:33](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/group_routing.py:33).
- Fixed endpoint queues separate feedback from collective IQ/OQ3–7.
  A1 IQ0 receives dense BF16; its non-QKV OQ sends R acknowledgments.
  A3 OQ1 remains U16, OQ2 is D17 boundary output, IQ2 receives START15.
  R uses horizontal C18/C19 and vertical C18/C23. A2's C16 stays inside A2.
  [Endpoint bindings](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/group_link.csl:117)
  and [allocation capture/checks](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/group_allocation.py:73).
- Receive IQ0 is blocked while two asynchronous counted f16 transfers own it,
  then explicitly unblocked to dispatch ROW_DONE/STREAM_END. An early control
  marker raises a truncated-frame error; unexpected extra data raises an error.
  These errors withhold readiness/ACK rather than accepting a partial frame.
  [Receive completion and error tasks](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/group_link.csl:96).
- The final target remains turned into its row; the final sender emits
  ROW_DONE then STREAM_END, without a final advance/grant. Every row-0 PE
  waits for STREAM_END and X-consumer completion before joining the row ACK.
  [Marker tail](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/group_link.csl:111).
- **Terminal notification precedes reset.** Top-strip row0 sends an even
  completion token down the existing router-only C23 return. Only then may
  the bottom root initiate the single northbound reset scan. The odd scan
  return permits START. This prevents restoring a source switch while the
  terminal marker is still passing it; it adds no color or second CE scan.
  Bootstrap uses all-armed/source-initialized acknowledgments.
  [group_strip.csl:26](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/group_strip.csl:26).
- A1/A3 schedule one activation per layer so R/marker tasks can run between
  computations. Layer selection changes weight/KV banks; RoPE advances once
  per token. X is released after all its consumers. The next-token early-arm
  invariant is documented at the release site.
  [tall_stage.csl:185](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:185),
  [bank fixture packing](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/group_fixture.py:11).

Full-size X/Y reduction subgroups are capped at 16, matching the previously
successful full-geometry numerical baseline; the mini subgroup sizes are
unchanged. This changes grouping/order, not the arithmetic operators.
[Grouping](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/tall_layout.py:56).
`decode.csl`, `comm_lib/comm_pe.csl` and `approx_math.csl` are byte-identical
to the session-start snapshot. Their digests are in the evidence JSON.

## Verification results

All numerical comparisons below use exact equality against the existing
operators with the layout's actual reduction/rounding order, implemented in
[group_reference.py:236](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/group_reference.py:236).
They do not claim equality to the ideal mathematical NumPy oracle.

| Test | Backend | Result |
|---|---|---|
| 4 source rows → 2 target rows × 4 columns, two different f16 epochs; delayed last receiver | CS-3 | Every element exact; no protocol errors |
| Same protocol mirrored southbound | CS-3 | Two epochs exact |
| Withheld interior receiver | CS-3 | All first-frame payloads correct; second epoch stays closed |
| Dropped / duplicated fragment | CS-3 | Rejected with error7 / error6; no second epoch |
| Withheld ROW_DONE / altered data | simfab | Missing marker prevents release; corruption is detected |
| Mini, two layers × two tokens | CS-3 | 640 output elements exact |
| Mini, five layers × 33 tokens | CS-3 | 10,560 output elements exact |
| Full geometry, five layers × two tokens, final device code | CS-3 | 5,120 output elements exact |
| Mini two-layer cache probe, 33 tokens | CS-3 | All banks/cache positions/cursors pass; includes repeated owner-row append |
| Full five-layer cache probe, 33 tokens | CS-3 | All 83,886,080 K/V BF16 values and all bank cursors/steps pass |
| Flip one unused expected K bit in cache oracle | CS-3 | Deliberate failure; final flag2 instead of1, max absolute error1 |
| Inject collective IQ3 or conflicting strip C16 into captured allocation | Host | Both rejected |
| Mini/full five-bank allocation | Compiler | Compiles; actual image params include H0 `r_oq=1`, other A1 `r_oq=0` |
| Deliberate 1 ms whole-process deadline | Host | Timeout recorded, exit124 |
| Original versus changed standalone path, same input, two tokens | simfab | All 640 output elements identical; cache prefix/unused checks pass |

**Cache-probe scope:** a disposable source copy checks every A2 K/V cache
element and each bank's cursor after the last attention. It replaces the final
output frame with reduced mismatch flags; its preceding 32 output frames are
normal computation and match exactly. The final flags are not a normal FFN
output. The generic raw validation JSON inherited the standard launcher's
"not read back" text; the evidence JSON separately labels the probe and its
actual coverage. This was an on-device full-cache comparison, not a bulk D2H
cache readback. No probe exports or arrays remain in maintained kernels.

The standalone mathematical checker still fails its old max-absolute threshold:
before and after this change, relative L2 is 0.633932976%, max absolute 0.125.
The two device-output arrays are identical. This preserves the existing
operator-versus-mathematical difference; no operator or tolerance was changed
to manufacture a pass. No kernel latency or throughput was measured here.

Full final-code job: `wsjob-7fc9rfiaksqi9xvxntsisf`.
Full-cache job: `wsjob-2ihkgma7mxwmshtygk8npc`.
Mini five-layer/33-token job: `wsjob-yamtj63huy4rcnbjrtestr`.
Cache-corruption control: `wsjob-dt3en5bqkjbawapydi2nzc`.
All case IDs, settings, raw comparisons and exact executed probe sources are
preserved in the accompanying artifacts. Early runs that failed in reference
dtype conversion or artifact collection are excluded from the success table.

## Review, reproduction, and remaining boundaries

[Claude Code review](/home/lexu/wse3-performance-model/docs/reports/2026-09-13-layoutC-first-group-feedback-review.md)
reported no remaining blocking findings after follow-up. The six initial
findings and dispositions are preserved verbatim, including the limits of
what the reviewer inspected.

Use [run_tall_bounded.py](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/scripts/run_tall_bounded.py)
around the launcher. The artifact's CS-3 controller also owns a bounded
SdkLauncher context and closes its own job on failure. A raw SDK blocking
receive has no deadline of its own. Timeout reports do not identify the
faulting PE; that would require re-running the disposable diagnostic probe.

[Evidence JSON](/home/lexu/wse3-performance-model/docs/reports/2026-09-13-layoutC-first-group-feedback-evidence.json)
contains settings, output comparisons, compiled image parameters, source
digests and checker controls.
[Reproduction archive](/home/lexu/wse3-performance-model/docs/reports/2026-09-13-layoutC-first-group-feedback-repro.tar.gz)
contains maintained-source snapshots, the implementation patch, raw results,
the full allocation manifest, temporary probes and bounded CS-3 runners.
Its README gives commands. Large baked reference arrays/ELFs are regenerated.

The normal launcher emits a source manifest covering imported protocol and
operator modules. This host-only logging addition followed the final full-size
run; its earlier executed launcher is also archived. Device sources did not
change. A subsequent mini five-layer/33-token run exercises the manifest path.

The next implementation gate is mirrored-group and two-group integration,
then the bottom turn. The southbound microtest is not a mirrored compute-group
test. Live KV ingress, Head/Tail, all 36 layer IDs, token sampling/return,
STOP/new-request rearm and full-model performance remain unimplemented or
unverified in this first-group fixture. Independent baked token inputs may
overlap at group boundaries; this does not prove full-model autoregressive
or multi-request credit safety. Re-run the cache probe after bank-layout changes.
The project-wide M1 tracking cursor was not changed by this bounded task.
