# LayoutC: attribution against the pinned original 4B source

Date: 2026-09-11. Scope: M1 / S3 LayoutC single-layer numerical attribution.
All device outputs below were measured on **real CS-3**, not the simulator.
CPU predictions and counterfactuals are explicitly analytical.

## Decision supported by the evidence

The discrepancy is separable into two effects in the tested cases:

1. **The pinned original implementation already differs from the repository's NumPy oracle.** At the original 256×256 ATTN + 256×256 FFN geometry, pinned upstream and current vanilla produce bitwise-identical integer and random outputs for all 33 decode steps. The source evolution into LayoutC does not account for that shared discrepancy in this control.
2. **Changing the geometry changes numerical operation order.** Keeping the full logical model dimensions and 16 PEs per reduction group, shrinking both square blocks to 128×128 changes the random output by 0.305503% L2. Changing from that square layout to tall A1/A2/A3 changes it by 0.296268%. Tall versus original differs by 0.147389%. These effects are not additive. Every completed full-size device output is exactly reproduced by its own source-derived operation-order CPU model. This accounts for the measured differences without an unexplained transport-error residual.

This does **not** establish universal transport correctness or approve the existing mathematical approximation. The unchanged NumPy gate remains failed. Full-model trained-weight inference, layer feedback, inter-block/head/tail connections, full-context capacity, and performance are outside this result.

## Baseline identity and alignment

The user-specified repository/path is `happyandslow/WaferEngine`, `models/qwen3_4b-decode`. Its remote `main` was resolved read-only during this session to:

- commit `b136ab64b3f5575c72fb722fb972ef5c77f4c9fe`;
- subtree `7120f9085805f8702bd49cbda1f67f6d7e94ccd7`;
- original `src/decode.csl` SHA-256 `c3da0e464dfefb8831dc17c32c8eee27485919e5b54a1d9374b0838af774272b`.

This pins the version at the supplied URL; it does not claim that this is the first historical commit of the model. The checkout `/home/lexu/WaferEngine` was at `fcfc8c163a4bebe0d886ae062334dfcb1b0d8406`; the pinned object was extracted without moving that checkout or fetching history.

The existing [SRAM baseline provenance](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/PROVENANCE.md:3) names the same pinned revision. All 35 upstream tracked files in that baseline match byte for byte. Full per-file hashes and paths are in the evidence JSON and archive `alignment.json`.

| Local variant | Identical upstream files | Changed upstream files |
|---|---:|---|
| `sram_baseline` | 35/35 |  |
| `sram_route_table` | 30/35 | `launch_device.py`, `launch.py`, `src/decode.csl`, `src/route_util.csl`, `src/comm_lib/comm_pe.csl` |
| `pp_demo` | 31/35 | `launch.py`, `launch_sim.py`, `src/ht_tail.csl`, `src/demux.csl` |
| `thin_step1` | 26/35 | `launch_device.py`, `launch.py`, `launch_sim.py`, `src/ht_tail.csl`, `src/decode.csl`, `src/decode_strip_pe.csl`, `src/route_util.csl`, `src/ht_head.csl`, `src/comm_lib/comm_pe.csl` |
| `layoutC` | 26/35 | `launch_device.py`, `launch.py`, `launch_sim.py`, `src/ht_tail.csl`, `src/decode.csl`, `src/decode_strip_pe.csl`, `src/route_util.csl`, `src/ht_head.csl`, `src/comm_lib/comm_pe.csl` |
| `S3_worktree` | 35/35 |  |
| `WaferEngine_staging` | 35/35 |  |

The 4B subtrees in `/home/lexu/worktrees/1.7b-pipeline-af` (HEAD `93a6d0e6986ac1cd91c8abc80fa9e0a032e13f52`) and `/home/lexu/WaferEngine-staging` (HEAD `5bb850489936cfb5f613292694b7fa45296dd693`) also match all 35 files. This compares the 4B subtree, not either entire repository.

The PP demo retains the original decode, collective, approximate-math, and oracle files; its launcher/head-tail changes do not make the whole application identical. Current LayoutC and thin-step1 are derived variants, not frozen original baselines. A normalized function-body audit finds 42 of the original 50 decode functions unchanged, with eight differences in initialization, role/round handling, or scheduling/communication paths. The pinned adapter retains all 50 original function bodies unchanged.

## Experiment contract and adapter boundaries

Each full-size case uses hidden=2560, attention=4096, KV=1024, head=128, FFN=9728, batch=1, one layer/bank, prefill=1280, capacity=1536, and 33 supplied input embeddings. Weights, inputs, and prefill are identical logical BF16 tensors across all four geometries. Storage sharding changes with geometry. Fixture hashes cover every weight, norm, embedding, K cache, and V cache.

- Integer fixture: seed 911; sparse ±1 projection weights, two selected input positions per output column; integer-valued embeddings and prefill; unit norm weights. These are integer-valued **BF16** inputs, not integer arithmetic after normalization/activation.
- Random fixture: seed 910; dense random BF16 parameters, inputs, norms, and prefill, generated by the frozen `make_fixture` function. These are synthetic weights, not the trained 4B checkpoint.
- Original/current square controls: one ATTN region and one FFN region side by side, each 256×256 or 128×128.
- Tall: A1 128×80, A2 128×256, A3 128×160; A3 begins at local row 96, leaving 16 inactive left-half rows between A1 and A3.
- `g16` means **16 PEs per group**, not 16 groups in every geometry. The original 256 configuration has 16 groups; square128 has 8; tall vertical axes have 5/16/10 groups. This preserves the original group size from [device config](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/model_config/device_2x4_8k.json:6).

The upstream harness wraps original layer bodies rather than invoking the full production launcher. It disables only the original automatic init-task activation, calls original `init_once`, supplies fixed inputs/prefill, invokes original `attn_layer_body` and `ffn_layer_body`, and adds external output pacing. Original compute and collective function bodies remain unchanged. `upstream_adapter.patch`, the complete frozen wrappers, and uploaded source hashes are included in the reproduction archive. The current vanilla wrapper uses `stage_kind=0`; the tall wrapper executes the split stages and current data paths. Temporary group-size edits and probes were confined to the disposable experiment directories.

The test's chronological KV is distributed cyclically by row. The original production mock generator uses row-contiguous capacity chunks for arbitrary random cache data; its flat storage indices are not chronological positions. The adapter supplies matched K/V pairs and live row counts, and does not execute that production generator. Exact AST-extracted original packers were checked against test packing for Q/K/V/O, q/k norm vectors, RoPE frequency slots, and tile inner order at widths 32, 128, and 256: all checks passed. Original packing entry points are [launch.py](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/launch.py:1430), [shard_3d](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/launch.py:1518), and [norm/RoPE tiling](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/launch.py:1593).

## Measured results

Each full case contains 33 × 2560 = 84,480 returned values. Entries below are relative L2 / maximum absolute error against the **unchanged repository NumPy oracle**. The last column compares the device with the analytical operation-order diagnostic.

| Implementation / geometry | Integer vs NumPy | Random vs NumPy | Device vs operation-order: unequal elements |
|---|---:|---:|---:|
| Pinned upstream, two 256×256 blocks | 0.372348% / 0.125 | 0.742274% / 7 | 0 / 84,480 in each fixture |
| Current vanilla, two 256×256 blocks | 0.372348% / 0.125 | 0.742274% / 7 | 0 / 84,480 in each fixture |
| Current vanilla, two 128×128 blocks | 0.372348% / 0.125 | 0.739947% / 6.8125 | 0 / 84,480 in each fixture |
| Current tall, A1/A2/A3 = 128×80 / 128×256 / 128×160 | 0.372348% / 0.125 | 0.742231% / 7 | 0 / 84,480 in each fixture |

Measured pairwise random comparisons:

| Controlled comparison | Relative L2 | Maximum absolute error | Unequal elements |
|---|---:|---:|---:|
| Current256 vs pinned upstream256 | 0% | 0 | 0 |
| Current128 vs current256 | 0.305503% | 6 | 36,235 |
| Tall128 vs current128 | 0.296268% | 6 | 33,037 |
| Tall128 vs upstream256 | 0.147389% | 4 | 10,752 |

All corresponding integer cross-implementation/layout comparisons are exact.

The mathematical acceptance rule was not changed: relative L2 < 0.02 **and** maximum absolute error < 0.05. All eight full cases fail the maximum-absolute-error part. The tall launcher consequently saves outputs and raises; a completed output capture is not a passed mathematical validation. Negative control: a one-feature cyclic permutation of a valid device output fails the gate (recorded L2 1.415477, maxabs 18.875). The offline reproduction independently repeats a feature-permutation failure check on the full upstream integer output.

The original production device launcher [skips its NumPy diagnostic on hardware](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/launch.py:2628). Its previous success therefore cannot serve as evidence of numerical agreement with NumPy.

## Why upstream differs from NumPy

The oracle is the repository's BF16-oriented NumPy implementation, including its fused-normalization conventions; it is not an independent strict Hugging Face / FP32 golden.

| Numerical contract | Original device source | NumPy source / difference |
|---|---|---|
| SiLU | [Degree-six polynomial](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/src/decode.csl:1589), [coefficients](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/src/decode.csl:883) | [Exact sigmoid expression](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/host/oracle_fp16.py:277) |
| Attention score | [FP32 score computation](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/src/decode.csl:1298) | [BF16 score storage and scale](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/host/oracle_fp16.py:310) |
| RoPE | [Intermediate BF16 arithmetic](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/src/decode.csl:1091), [startup recurrence](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/src/decode.csl:720) | [FP32 intermediate rotation, then BF16 cast](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/host/oracle_fp16.py:198) |
| Reduction / norm | [Distributed root receive order](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/src/comm_lib/comm_pe.csl:785), [approximate rsqrt](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/src/approx_math.csl:17) | Unsharded NumPy summation/order and scaling |

A concrete operator discrepancy is SiLU(0): the device polynomial evaluates to BF16 0.007537841796875, while mathematical SiLU(0)=0. This coefficient/function is already present in pinned upstream; it was not introduced by the pipeline.

Analytical ablations against the **measured upstream256 integer** output:

| CPU reference change | Relative L2 | Max absolute error | Unequal elements |
|---|---:|---:|---:|
| Original NumPy | 0.372348% | 0.125 | 32,760 |
| Match only device SiLU polynomial | 0.121058% | 0.0625 | 3,976 |
| Match score precision + RoPE arithmetic + SiLU | 0.003335% | 0.015625 | 3 |
| Match complete source operation order | 0% | 0 | 0 |

These interventions establish a substantial SiLU contribution in the integer fixture. They are not additive error percentages, nor a license to replace the mathematical gate with a permissive diagnostic. Full ablations are retained as machine-readable evidence.

## Why geometry changes output

Changing height/width changes the number of terms computed locally, where partial sums are rounded, the two-stage reduction tree, head-group summation, and the distribution of cached positions. Changing A1 height also changes RoPE startup recurrence. This is a numerical consequence of partitioning the same logical operations; the route transport itself is absent from the CPU prediction.

A correction to the previous CPU diagnostic was necessary: the root receives color 0 before color 1, but the side assigned to color 0 depends on root parity. See [first-phase mapping](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/src/route_calc.csl:58), [second-phase group-index parity](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/src/route_calc.csl:163), and [receive order](/home/lexu/wse3-performance-model/demo/qwen3-4b-decode-sram/code/qwen3_4b-decode-baseline/src/comm_lib/comm_pe.csl:785). The previous diagnostic always added the high-coordinate leg first. Correcting this CPU-only error makes all eight full outputs exact and also exactly reproduces both prior mini random outputs. The earlier unexplained three-Q-value remainder in the mini analysis is therefore resolved; it must not be cited as unexplained hardware error.

Source-derived, analytical intermediate comparisons further locate the geometry effect. These are CPU counterfactuals, not additional hardware stage captures:

| Compared with upstream256 order | Square128 | Tall128 |
|---|---:|---:|
| Unequal logical Q / K / V elements | 12 / 5 / 5 | 6 / 0 / 2 |
| Unequal Z elements | 3,163 | 391 |
| Attention/O output L2 with identical upstream QKV supplied | 0.015721% | 0.015721% |
| FFN output L2 with identical upstream Z supplied | 0.017184% | 0.022811% |

Holding only RoPE startup recurrence to the upstream 256-row sequence changes no square128 QKV values in this fixture, but changes three tall Q values. Thus the tall difference should not be attributed exclusively to the reduction tree. The full operation-order prediction includes both effects and exactly reproduces the measured final output. Random BF16 boundary crossings propagate through subsequent operations; final unequal-element counts do not imply that that many independent routing faults occurred.

## Incomplete liveness controls

These attempts have no accepted complete numerical output and are excluded from the numerical table:

- Original256 with four groups of 64: `wsjob-ib2clofp6qezsnjtdz2scu`, canceled after runtime stalled.
- Current128 with four groups of 32: `wsjob-ih5lfteydkre9y52ewjjst`, canceled after runtime stalled.
- Tall128 with default groups (X=32; Y=20/64/40): `wsjob-7a5e8crncp58n735ydvccy`, canceled after runtime stalled.
- A temporary current128 phase-marker diagnostic: `wsjob-thrgyxrcgybdpkqh5p5osv`; host debug read blocked while a receive was pending, so it did not localize a kernel phase. Canceled.
- The first mini adapter was canceled during setup and superseded by the corrected v2 adapter; it is not numerical evidence.

Changing the temporary full-size controls to 16 PEs per group enabled all four geometries to complete. This demonstrates group-configuration sensitivity in these harnesses, but does not pin the internal blocking mechanism. No maintained group-size setting was silently changed, and no large-group liveness fix is claimed. The diagnostic-v2 and larger stage-audit variants prepared but not executed do not count as evidence and are not part of the frozen successful runs.

## Reproduction and validation

| Hardware case | Job | UTC interval |
|---|---|---|
| `current-128-g16-integer-33` | `wsjob-2a55xjmxe8gzbjsxgq6dtk` | 2026-09-11T11:26:11Z → 2026-09-11T11:27:51Z |
| `current-128-g16-random-33` | `wsjob-fvjpyhzles5toyeabxdt9y` | 2026-09-11T11:27:52Z → 2026-09-11T11:29:43Z |
| `current-256-g16-integer-33` | `wsjob-3qvnrxarffqiwmmlajtk9s` | 2026-09-11T11:22:25Z → 2026-09-11T11:24:06Z |
| `current-256-g16-random-33` | `wsjob-xj9afcad5qrbumpnhdc3wr` | 2026-09-11T11:24:07Z → 2026-09-11T11:26:09Z |
| `tall-128-g16-integer-33` | `wsjob-uep9ce4fvpvyyjyucgxbyu` | 2026-09-11T11:54:29Z → 2026-09-11T11:56:00Z |
| `tall-128-g16-random-33` | `wsjob-gjtgaavsxpxskxpfgqyfm9` | 2026-09-11T11:59:30Z → 2026-09-11T12:01:01Z |
| `upstream-256-g16-integer-33` | `wsjob-hjkfo377j66qqjf2unu7ir` | 2026-09-11T11:14:49Z → 2026-09-11T11:17:11Z |
| `upstream-256-g16-random-33` | `wsjob-8kggjntjs2gwfdjjxnekf8` | 2026-09-11T11:20:42Z → 2026-09-11T11:22:23Z |
| `upstream-mini-v2-integer-33` | `wsjob-bk5iawhuvyyjdnv4u3q2et` | 2026-09-11T11:04:23Z → 2026-09-11T11:05:34Z |

The supplementary upstream mini integer run returned 33 × 320 values, exactly matching the previous current-vanilla mini integer output; its NumPy relative L2 is 0.377175%. The full-size results above provide the primary original-baseline evidence.

Artifacts:

- [2026-09-11-layoutC-upstream-numerical-attribution-evidence.json](/home/lexu/wse3-performance-model/docs/reports/2026-09-11-layoutC-upstream-numerical-attribution-evidence.json): source alignment, fixtures, raw-output hashes, jobs, metrics, ablations, and analytical attribution.
- [2026-09-11-layoutC-upstream-numerical-attribution-arrays.npz](/home/lexu/wse3-performance-model/docs/reports/2026-09-11-layoutC-upstream-numerical-attribution-arrays.npz): complete returned device outputs; archive includes each corresponding NumPy expected array.
- [2026-09-11-layoutC-upstream-numerical-attribution-repro.tgz](/home/lexu/wse3-performance-model/docs/reports/2026-09-11-layoutC-upstream-numerical-attribution-repro.tgz): frozen source closures, uploaded source hashes, downloaded evidence, CPU diagnostics, and `verify.py`.

Extract the archive and run `python verify.py` with NumPy and ml_dtypes. It regenerates fixture hashes, validates original packing, regenerates all full operation-order outputs, checks exact measured agreement, rechecks original mathematical failures and a negative control, and reproduces the ablations, geometry counterfactuals, and prior mini correction. It does not submit hardware work. Hardware rerun commands and adapter limitations are documented in the archive README.

## Next decision and remaining gate

The measured NumPy difference is now attributed: an upstream operator/reference mismatch plus geometry-dependent numerical ordering. A pipeline-transport fault is not needed to explain the completed test outputs. Before changing behavior, choose the intended numerical contract: preserving original BF16 operator behavior is different from approximating the mathematical/HF model more closely. If improving mathematical agreement, start with the identified SiLU discrepancy and keep both the original-source control and mathematical reference; do not pass by loosening the threshold.

Independently, localize the default large-group blocking mechanism before adopting the full tall configuration as robust. Then validate the complete A1/A2/A3 layer group with feedback, trained-weight inputs, and KV preservation. The user's group-correctness gate still precedes other PE-block connections, head/tail integration, and end-to-end performance.

This task changed no maintained kernel, launcher, configuration, or tracker. Temporary probes remain only in disposable experiment directories / the explicitly labeled reproduction archive. Existing unrelated modifications were preserved; no staging, commit, push, or history operation was performed.

Final artifact verification: offline `verify.py` passed; all 506 archive manifest entries matched after extraction; all eight full operation-order predictions regenerated exactly. Recomputed tall/original random metric and copied device arrays match the evidence. Archive SHA-256: `b1988bb4a260fc42763ed16c5ac34a620b511ad2ac2ece1a4801757feb6d4d09`.
