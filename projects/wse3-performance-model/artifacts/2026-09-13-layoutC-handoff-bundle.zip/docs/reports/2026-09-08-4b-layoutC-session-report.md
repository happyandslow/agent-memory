# Session report — `4b-layoutC`

Splitting a Qwen3-4B decoder layer into three thinner stages that tile today's
wafer allocation exactly, and designing the data paths that layout needs.

Started 2026-09-07 from the `4b-wide-layer` handoff about the cut (ii) A1 stall.
**Nothing in this session has been compiled and no device job has been run.**

> **Round numbering below is reconstructed from the artifacts on disk**, not from
> a transcript — the session was compacted. Each round cites the artifact that
> records it, and anything I could not source from an artifact is not claimed.

---

## Consolidated findings

| # | finding | status | evidence |
|--:|---|---|---|
| 1 | H2's "margin" premise is refuted — vanilla's own tail has a ~10-cycle margin too | **settled** | `analyses/2026-09-05-a1-stall-investigation/` |
| 2 | Cut (ii)'s drift is **not** floating-point re-association | **settled, twice** | `analyses/2026-09-07-reassociation-range-test/` |
| 3 | Cut (ii) collapses QKV across columns: vanilla 8/8 distinct, cut 1/8 | **measured** | `analyses/2026-09-07-qkv-column-sharding-check.md` |
| 4 | Layout C tiles 512×1024 exactly at **128-wide** blocks, zero waste | **settled** | `demo/qwen3-4b-thinner-stage/README.md` |
| 5 | The A2 shift is wire-bound at a min cut, so colour count barely moves the time | **derived** | `analyses/2026-09-08-equidistant-shift-colour-vs-performance.md` |
| 6 | 71% of the southward payload is Y-replicated QKV → a router multicast, not 128 transfers | **derived** | same, §6 |
| 7 | **The one-`rx`-per-colour rule is per switch *position* on WSE-3, not per colour** | **settled from SDK source** | this report, round 9 |
| 8 | Therefore the shift needs **1 colour, not 8–16**; the colour-budget dead end is gone | **derived** | `layoutC/design/01-a2-southward-shift.md` rev 2 |
| 9 | Three mechanisms, not two — **we already repaint `rx` at runtime every layer** | **settled from our source** | `route_util.csl:28-45`, `comm_pe.csl:1641-1655` (Le) |
| 10 | Only **16 of 24 colours can switch**; the audit's picks 14 and 15 are not among them | **settled from SDK source** | `memcpy/sys_params.csl:42-44` |
| 11 | Per-layer setup is ~2–4 %, priced by the `reconfig_allreduce_axis` precedent | **derived** | round 10 |

Open, and not claimed: the "height must divide width" launcher blocker
(`128 % 256 ≠ 0`), the multi-layer chain (`max_layers_per_block = 1`), and every
cycle number for layout C.

---

## The settled configuration

**Revised 2026-09-09 against `analyses/2026-09-08-equidistant-shift-colour-vs-performance.md`
§§13–14.** The previous version of this block (switch + filter at L = 2, 1,560
cyc, two switch-capable ids, fold at 2,072 as a near-equal fallback) was built on
an **assumed** `t_adv`. The constants have since been **measured**, and they
change the shape rather than the tuning. What follows replaces it.

**Design only — nothing compiled, no device job.**

### The measured constants that drive everything

From 51 CS-3 appliance jobs, n = 3/point, **max spread 1 cycle across every
cell** (`agent-memory/.../2026-08-23-m3-perf-model-coefficients.md`). One word =
2 f16 halves.

| path | cost |
|---|--:|
| wire, router → router | **0.7 cyc/word** |
| router hop, **CE not involved** | **2.0 cyc/hop** |
| CE receive, bulk fabin-DSD | **13.0 cyc/word** |
| CE receive, per-wavelet data task | **43.6 cyc/word** |

> **The CE costs 19× (DSD) to 62× (per-wavelet task) what the wire costs, per
> word.** So the constant that orders the designs is not `t_adv` at all — it is
> **whether the CE is in the path**.

### The configuration

| path | mechanism | colours | cost |
|---|---|--:|--:|
| **A2 in-square shift** (both movements) | **Senders** (rows 0–127): one colour, 2 switch positions, `ring_mode = false`, `POP_ON_ADVANCE`. pos0 `NORTH→SOUTH` transit, pos1 `RAMP→SOUTH` inject. **Receivers** (rows 128–255): **no switch, no control wavelets** — static `NORTH→{RAMP, SOUTH}` plus a counter filter — `max_counter = P−1`, `init_counter = ((N−j) mod N)·P`, in **wavelets** (`P` = 5, not the 10 halves of the DSD extent); 1-tx sink at row 255. | **2 switch-capable**, from `{9, 12, 13, 16}` — **one per shift, not time-multiplexed** | **704** cyc/column/layer |
| **QKV southward inside A2** | Y-replicated → router multicast, 2-tx, no switch | 0 new if time-multiplexed; else **1 ordinary — must not consume a switch-capable id** | 24 beats |
| **QKV eastward A1 → A2** | **diagonal source, k = 1** — one sender per row off A1's (*r*, *r*); five route classes on the vertical leg, c = 0 special-cased | 1 ordinary | 24 beats/row-link, ~383 hops fill |
| fallback for the shift | K-pipe fold — proven on silicon here, but CE-bound | 4 ordinary | **4,160 – 13,952** per shift, at L = 2 |

**Those figures are per SHIFT, and there are two shifts per layer** — the X-half
split on the way in, the Z-half gather on the way out. 704 = 448 wire (128
senders × 5 words × 0.7) + 256 (128 hops × 2.0).

| | per shift | **per layer** | vs A2's 8,434 cyc/layer |
|---|--:|--:|--:|
| **switch + filter** | 704 | **~1,432** (incl. the 24-cyc QKV broadcast) | **17 %** |
| fold, L = 2 | 4,160 – 13,952 | **8,320 – 27,904** | **99 % – 331 %** |

> **Corrected 2026-09-09.** I first reported 704 as the per-*layer* figure,
> taking it from a table that labelled it that way. It is per shift. The 6×–20×
> ratio is unaffected; every absolute number was half what it should have been.

The two shifts **cannot overlap** — the gather's payload is the output of the
compute the split's payload feeds — so the layer figure is a sum, not a max.

**Lanes are gone from the design.** They divided the per-PE CE load, which the
switch design does not have. `L` is a property of the fold only.

### Why the receivers cannot use a switch — a proof, not a preference

Receiver *j* would need its advance at `t = j·p`. At that moment senders
*j*+1…127 have not fired, sit at pos0, and are **advance-capable** — under
`POP_ON_ADVANCE` any token aimed at the receive band is eaten by the first of
them, and `NO_POP` is worse (it advances every unfired sender at once). A
different colour cannot help: `SWITCH_ADV` advances the switch of **the colour it
travels on**, and the data must be on `c`. **While any sender remains unfired, no
token can reach the receive band.** Hence a coordination-free receive side, which
is what a counter filter is.

### Resolved in simulator — three facts from runnable demos

`demo/communication-algorithm/`, four demos of 4–5 PEs, `./commands_wse3.sh`,
green. **Simulator, not device.** I verified the directory and read the results
rather than taking them on report.

- **The pre-arm + backpressure claim holds** (`02-sweep-k1`) — armed microthreads
  park on a closed route and drain the instant a `SWITCH_ADV` opens it. This was
  the design's largest unverified assumption and the whole basis of "8 % of a
  layer"; had it failed, every sender would cost a CE round trip.
- **`max_counter` is INCLUSIVE, and `builtins.md` says "(exclusive)"**
  (`01-filter-window`). The pass window is `max_counter + 1`, so the receiver
  filter is written `max_counter = p − 1`. The demo's first run took **p+1** words
  per receiver. **Silent corruption, not a compile error.**
- **`K` commands advance exactly `K` PEs in path order** under `POP_ON_ADVANCE`
  (`03-baton-k2`).

### Why two ids and not one

Time-multiplexing one colour across both shifts looks free — identical shape,
direction and stride — but after shift 1 every sender sits at pos1, its **last**
position under `ring_mode = false`, and is therefore **immune to advance
commands**. The reset would have to act on immune PEs.

The provenance of that immunity, precisely, because it is the load-bearing half
of the decision:

| claim | status |
|---|---|
| a PE at its last painted position neither advances nor pops; `SWITCH_ADV` passes through unchanged | **device-proven**, but via external work (`csl-switch-adv-pop-semantics`), not measured here |
| the same for **`SWITCH_RST`** — *the case a reset actually needs* | **unknown** |
| covered by any of the four demos | **no** |

I had guessed demo `02-sweep-k1` covered it. It does not, and structurally
cannot: the property that makes K = 1 sufficient there is that every token is born
downstream of every already-fired sender, so no token ever traverses one. The
situation never arises in that geometry. A fifth demo would settle it — same
harness as `03-baton-k2` — and should exist before any future design reaches for
a reset.

### Still open

The filter's registers count **half-wavelets** and `p = 5` words is an odd
wavelet count — unworked, and it now compounds with the inclusive-`max_counter`
correction. Everything above is simulator-only.

**Closed:** I had carried "the gather costs one extra CE arming event per PE per
layer". With each shift owning its own colour the two shifts are **two
independent instances of the same protocol** — own switch state, own sweep, own
arming — so the gather's arming costs exactly what the split's costs. That is
why the layer figure is 2 × 704 rather than 704 + ε. The remaining asymmetry is
scheduling, not cost.

**Two hazards that are NOT retired.** §13.4 proposed giving receivers switches
and claimed that retired both `count_control = false` and the spent-wavelet
RAMP-tap hazard. §14.3 killed that variant, so **both are live**: the counter
filter still counts, and the receivers carry `tx = {RAMP, SOUTH}` — a RAMP
output, exactly what the spent-wavelet hazard needs.

### Decisions declined

| decision | buys | costs | verdict |
|---|--:|---|---|
| k = 1 → k = 8 on the QKV hop | 112 cyc (1.3 %) | 1 ordinary id + the X-axis mechanism | declined |
| repaint-as-advance | — | it is CE-bound, the thing the measurement says to avoid | declined |
| L = 2 → L = 4 | — | **moot** — lane count is a property of the fold, no longer the design | withdrawn |

---

## Round 1–3 — the cut (ii) stall, and killing the re-association story

**Asked:** re-read the `4b-wide-layer` handoff and state the problem; then
visualize A1's on-chip allocation; then explain the "margin" in hypothesis H2.

**Found:** H2 claimed A1's RoPE tail left too little margin. Measuring vanilla's
own tail showed it has roughly the same ~10-cycle margin, so the premise does not
distinguish the two builds. H2 is refuted, not merely unsupported.

A separate story — that the cut's numerical drift came from floating-point
re-association under a reversed reduce chain — was killed **twice**:

- `analyses/2026-09-07-reassociation-range-test/reassoc_range.py` implements the
  actual two-phase chain reduce and shows the mirror is **byte-neutral**: 0/200
  differing at h = 256/128/64/32/16, with a negative control (root moved off the
  midpoint → 199/200 differ) proving the test can detect the effect it is
  looking for.
- The index in the cut build is not mirrored in the first place.

For scale: a 16× height change moves ≤ 1 bf16 ULP on 0.02% of outputs, and 1 ULP
at bf16 is 0.39–0.78% relative.

## Round 4 — what the cut actually broke

**Asked:** say in plain terms what is going wrong, step by step.

**Found, by measurement with a control:** the cut build's KV comes back
**identical across all 8 columns** of the KV-owning block, where the vanilla
build's is distinct 8/8 — at identical geometry. Q/K/V are X-sharded, and the
existing multicast sends from one boundary PE per row, so reusing it hands every
column the boundary column's Q/K/V.

Recorded in `analyses/2026-09-07-qkv-column-sharding-check.md`. This is the
defect any new A1→A2 hop must not reproduce, and it is the negative control that
belongs in that path's acceptance test.

## Round 5–6 — the layout, corrected to 128-wide

**Asked:** draw the layout so Le could confirm it; then "你再数一遍 我们说的是
同一个 layout 吗".

**Found:** I had assumed 256-wide squares. The correct unit is **128 wide**:

```
8 × A2 (128×256) = 262,144      4 block-columns × 128 = 512 wide  ✓
8 × A1 (128×128) = 131,072      4 block-rows    × 256 = 1024 tall ✓
8 × A3 (128×128) = 131,072
             total 524,288 PE = 512 × 1024, zero waste
```

Layers distributed 5, 5, 5, 5, 4, 4, 4, 4. Travel is vertical — down the left
pair of block-columns, then up the right pair — and the stage stacking mirrors
with the direction reversal so every group's input is on its leading edge.

Every X-axis shard changes: `attn_per_pe` 16→32, `kv_cols` 4→8,
`pes_per_kv_head` 32→16, `ffn_dim_per_pe` 38→76. A1's per-lane record becomes
QKV 48 + X 20 = 68 halves. Recorded in `demo/qwen3-4b-thinner-stage/README.md`.

`analyses/2026-09-08-layoutC-plan-v2.md` was written against 256-wide squares and
is **superseded on geometry** by that README.

## Round 7 — the colour and queue audit

**Asked:** settle the colours and queues before building anything, and put it
through Codex review.

**Found:** three Codex rounds took the audit to **revision 7**. Corrections it
forced, all accepted: the payload is 44 halves not 34 at B-128; the colour table
must be built from **paint sites**, not `Color(...)` constructor sites (colours 7
and 8 are painted on block cells in sub-height builds); dynamic colours are
per-region-instance; and `sim.params` can resolve dynamic ids after all.

Revision 7 **withdrew** its own colour and queue settlement. The block-cell
painted set is `{1,2,3,4,5,6,17,19,20,21,22,23}` always, plus 7 and 8 in
sub-height builds and 10 or 11 under `PROF_BLOCK_TSC=1`, leaving at most
`{0, 9, 12, 13, 14, 15, 16, 18}`.

## Round 8 — the pattern handed to `4b-comm-pattern`

**Asked:** this is a communication-pattern problem — L consecutive senders each
shipping to a receiver L away — so discuss the colour usage and performance
trade-off in a separate session.

**Returned**, and I verified the load-bearing claim myself:

- The pattern is **wire-bound at a min cut**: one N–S link per column, 1
  beat/cycle, 2 f16 halves/beat, so `T_floor = N·p/2`. Colour count barely moves
  the total — the whole span from 4 to 32 colours is 8% of an A2 layer.
- My description of the K-pipe was wrong. `decode_strip.csl:88-96` forwards
  `@fmovh(fwd_out, fwd_in)` where the templates are a `fabin_dsd` (`:41`) and a
  `fabout_dsd` (`:44`) — **fabric-in straight to fabric-out, never through
  memory**. I verified this directly before accepting it.
- **71% of the southward payload is the QKV, which is Y-replicated**, so it is a
  one-colour router multicast (`set_route_2tx(c, NORTH, RAMP, SOUTH)`) rather
  than 128 transfers. My own three-datapath plan had stated this in words and
  then designed 128 separate transfers anyway.

I corrected one thing in its reply: it had the supersession backwards, taking
`plan-v2`'s 256-wide geometry as current. It has applied the correction. At
128-wide the QKV tile is 48 halves rather than 24, which makes its finding
**larger**: the cut load per column per layer drops from 4,352 to **1,304 beats**,
a 70% cut rather than the 54% first reported.

**Its caveat, which I am carrying forward:** the 8,434 cyc/layer denominator for
A2 is measured at the shipped **256-wide** geometry (`phase_tables.txt:17`). At
128-wide, A2's per-PE X-sharded work doubles, so the true denominator is larger
and every percentage quoted against it is an **upper bound** on the shift's
relative cost.

## Round 9 — the switch: Le's question overturns the design

**Asked (Le):** 其实可以用 control wavelet 改方向吗 — e.g. PE2 receives
`north→ramp`, and the control operation carried alongside flips that colour from
`north→ramp` to `ramp→south`.

**Answer: yes, on WSE-3 — and it invalidates the core argument of design 01, the
colour dead end in the audit, and `4b-comm-pattern`'s lane/colour trade.**

I began answering "no, `rx` is fixed per colour, only `tx` switches", which is
what the AI knowledge base's routing guide documents. Checking the SDK source
before sending showed the opposite.

**The evidence**, from the SDK tree at `/tmp/guard-g2b/source-code/csl-libs`:

```csl
// tile_config/switch_config.csl:88-95
fn set_rxtx_switch_pos(pos: switch_pos, c: anytype,
                       comptime dir_rx: direction, comptime dir_tx: direction) void {
  @comptime_assert(@is_arch("wse3"));
  ...
}
```

`target/wse3.csl:94` `SWITCH_REGS_PER_COLOR = 4`, and `:114-121` gives the
encoding — per switch position, **bits 7:5 input select** (one rx direction) and
bits 4:0 output direction enable (a tx mask). `target/wse2.csl:79` has
`SWITCH_REGS_PER_COLOR = 1`. **The per-position `rx` is a WSE-3 addition**, which
is why the "one rx per colour" rule is repeated everywhere — it is the WSE-2
picture, and WSE-3 is our target.

**A shipped Cerebras kernel already runs our exact pattern on one colour.**
`kernels/fft/fft_internal/transpose.csl:155-171`, middle PE, vertical mode:

```csl
color_config.reset_routes(LR_color, .{ .rx = {NORTH}, .tx = {RAMP, SOUTH} }); // pos0: transit
set_new_filter(LR_color, TRANS_LEN-1, BRICK_WAVELETS-1, counter_LR);          // counter_LR = (DEPTH-PE_ID)*BRICK_WAVELETS
switch_config.set_rxtx_switch_pos1(LR_color, RAMP, SOUTH);                    // pos1: INJECT
switch_config.set_pop_mode(LR_color, pop_mode.POP_ON_ADVANCE);
switch_config.set_ring_mode(LR_color, ring_mode.RING_MODE);
```

A line of PEs, each alternating between forwarding others' traffic and injecting
its own, on **one colour per direction**. It is a transpose — an all-to-all along
a line — which is a strict generalisation of our equidistant stride-128 shift.
And the per-PE turn is scheduled by a **filter counter**, not by the CE, so no
control wavelet is needed per payload.

**We already ship the tx-only form of the same mechanism.**
`src/kv_ingress_injector.csl` is a vertical demux: pos0 `NORTH→RAMP` (take my
row-slice), pos1 `NORTH→SOUTH` (forward the rest), painted from the launcher as
`inj.paint_all(inj_in_color, [inj_take, inj_fwd])` (`launch.py:1822-1824`),
advanced by a `SWITCH_ADV` from `kv_ingress_adaptor` and reset per round by
`switch_config.clear_current_position`. Its header states the property we want:
the next slice "streams past PE k at the router, **never buffered here**".

**What this changes:**

| | before | after |
|---|--:|--:|
| colours for the shift | 8 – 16 | **1** |
| input queues | 1 | 1 |
| output queues | 1 | 1 |
| filters per colour | 0 | **1** |
| CE work per forwarded payload | 1 relay op | **0** |

The audit left at most eight unpainted colours on block cells. Eight candidates
for sixteen was a dead end; eight for one needs a single aliasing argument. Both
movements are southward and time-separated — the split on the way in, the gather
on the way out — so one colour may serve both.

**What it does not settle**, and these are now the design's real risks:

1. **Can SdkLayout paint a *differing* `rx` across switch positions?**
   `RoutingPosition` has `set_input` and `paint_all` takes a list, so the shape
   is there, but our one in-tree user paints the same `rx` in both positions and
   FFT sets its differing ones at **runtime** via `tile_config`. Runtime path
   proven; layout path not. **A 1-column, 16-row mini sim settles it — local, no
   device job.**
2. **The cost moved from the fabric to the CE.** FFT configures filters and
   switch positions once per transpose; we would do it per layer, per token.
   Unpriced.
3. **Filters were never audited.** There is one per colour (`@get_filter_id`),
   the mechanism needs it, and the colour audit does not cover them.
4. **The phantom-cell hazard is relocated, not removed.** A cell that configures
   when it should not still overrides host-painted transit and kills every
   wavelet crossing it.

**Artifacts updated this round:** `layoutC/design/01-a2-southward-shift.md` to
revision 2 (the withdrawn premise is marked, not silently edited), and
`docs/diagrams/2026-09-08-a2-shift-routing.png` regenerated — panel A unchanged,
panels B and C replaced.

![A2 shift routing, revision 2](../diagrams/2026-09-08-a2-shift-routing.png)

## Round 10 — the third mechanism, and what the switch actually costs

**Asked (Le):** 还有 rx 可能可以改的（但不是用 control wavelet，当然也可以用这个
trigger）参考一下 decode 里面 reconfig axis 的写法.

**Le is right, and the precedent is ours.** `src/route_util.csl:28-45` —
`set_route_1tx(c, rx, tx)` writes **both** `rx` and `tx` into the colour-config
register via `@set_config`, at runtime. `comm_pe.csl:1641-1655`
`reconfig_allreduce_axis(axis)` calls `write_Y_routes()` / `write_X_routes()` to
move the collective between axes — **every layer, on silicon, today**. Changing
`rx` at runtime is not exotic and needs no control wavelet; a control wavelet is
one possible *trigger*, not the mechanism.

So there are **three** mechanisms, separated by granularity:

| | changes `rx`? | granularity | proven | cost |
|---|:-:|---|---|---|
| colour pair + relay (K-pipe) | no | per PE, static | our edge strips | 2 colours/lane, 1 CE op per payload |
| **route repaint** (`route_util` + `reconfig_allreduce_axis`) | **yes** | per **phase** | **our block PEs, every layer** | 1 `@set_config`/colour, needs quiescence |
| switch positions (WSE-3) | **yes** | per **wavelet** | FFT; our injector (tx-only) | switch-capable colour + filter |

The transfer needs per-wavelet granularity, so the switch stays the right choice
there. **The repaint's role is the setup** — and that answers the risk I flagged
in round 9. `reconfig_allreduce_axis` is ~5 `@set_config` per axis switch, run
every layer today, and has never been large enough to appear in the phase
profile. The shift's per-layer setup is the same order, ~2–4 % against ~1,300
cycles. **The per-token setup cost is priced by in-kernel precedent, not by
estimate.** `route_util.csl:52-79` also gives the form to copy:
`compute_route_word_1tx` precomputes the word at init, `apply_route_word`
replays it.

Carried with it: `comm_pe.csl:1630-1640`'s **C1 safety invariant**. Repainting
shared colours without a barrier is race-free *only* because the collectives are
synchronous and self-fencing — call only at a collective boundary, keep
`all_reduce_*` synchronous, keep the broadcast multi-tx. Breaking any one is a
**device-only, sim-green hang**.

### A hard constraint that runs against us

`memcpy/sys_params.csl:42-44`, read directly:

```
// WARNING 4: switching-capable colors are
//   0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 13, 16, 17, 20, and 21
```

**Not all 24 colours can switch.** Against the audit's free set on block cells:

| | |
|---|---|
| free on block cells | `{0, 9, 12, 13, 14, 15, 16, 18}` |
| switch-capable | `{0..9, 12, 13, 16, 17, 20, 21}` |
| **usable** | **`{9, 12, 13, 16}`** |
| lost | 14, 15, 18 — **14 and 15 were the audit's picks**; and id 0, spent |

Four candidates for one requirement: workable, but criterion 1 must be redone.
Id 0 looks free but is out twice over — `launch.py:814` already spends it as
`ht_ready_color`, and `:808-813` documents the WSE-3 "avoid id 0 for
long-distance routes" caveat, waived there *only* because that use is single-hop.
A 128-row span is exactly the case the caveat exists for.

The constraint does not apply to the K-pipe fold or the repaint path. Colours 1–5
*are* switch-capable, which makes borrowing them between collective phases more
attractive than it looked.

### A fourth point on the curve — repaint as the *advance*

Raised by `4b-comm-pattern` off Le's pointer: a sender that has drained its
transit quota calls `set_route_1tx(c, RAMP, SOUTH)` on itself and injects. No
control wavelet, no pop semantics, none of the spent-wavelet hazards — and **no
switch-capable id required**, which reopens `{9, 12, 13, 14, 15, 16, 18}` and
revives 14 and 15.

It needs a CE completion event, so the transit stream must land in a DSD instead
of being filtered away. My analysis of that: wall clock is fine (PE *k* drains
*k*·p beats, all in parallel, worst case 127 × 5 = 635 beats, concurrent with the
transit it *is*); the CE is occupied for the whole transfer rather than free; and
**the drain needs a landing buffer** up to 635 beats — 1,270 halves per PE —
unless chunked, which puts per-chunk activations back. **Price the buffer first:**
A2 is the KV owner and SRAM there is the scarce resource. Not evaluated, not
claimed to win.

### Two corrections to round 9, both verified

- **The advance is `SWITCH_ADV`, not the filter counter.** `transpose.csl:350-357`
  — each non-last PE runs `SEND_DATA → SEND_SENTINEL` and emits a `.control =
  true` wavelet after its own data. The filter is a separate *receive-side*
  selector. I conflated two mechanisms.
- **The middle PE is on the ramp.** pos0 is `tx = {RAMP, SOUTH}` — both — so
  every wavelet is delivered to the ramp and the **filter** drops what is not
  this PE's. RAMP bandwidth is consumed at every cell; **CE work is zero**. The
  conclusion survives, the reason was wrong.

### The repricing — and the correction to it

**First version: "≈ 1,304, ≈ 0 % vs floor." Wrong** — it ignored the advance
chain. `4b-comm-pattern` found the missing term; kept visible rather than edited
away.

Only one sender injects at a time. Sender *k*+1 cannot begin until sender *k*'s
last beat has passed it, so each pair of consecutive injections is separated by
whatever delivers the advance, and those gaps are **strictly serial**:

```
T(one direction) ≈ N·p/2  +  N·t_adv / L
```

| advance carried by | `t_adv` | why |
|---|--:|---|
| `SWITCH_ADV` | ~1–3 cyc | the **router** advances; pipelined into the stream |
| route repaint | ~20–40 cyc | a **CE round trip**: completion → task → `@set_config` → arm |
| K-pipe fold | ~0 | relay DSDs are **armed before the stream starts** |

Both values are guesses, and they set the ordering. **`t_adv` has replaced α as
the constant the mini sim must measure first.**

| scheme | colours per lane | L = 1 | L = 2 | L = 4 | L = 8 |
|---|--:|--:|--:|--:|--:|
| switch + filter | 1 **switch-capable** | 1,816 | 1,560 | 1,432 | 1,368 |
| repaint-as-advance | 1 ordinary | 8,984 | 5,144 | 3,224 | 2,264 |
| K-pipe fold | 2 ordinary | 2,816 | 2,072 | 1,664 | 1,496 |

**The colour budget caps L, and neither table says so.** Mine. Free ids on A2's
block cells with 0 removed: `{9, 12, 13, 14, 15, 16, 18}` — seven. Switch-capable
among them: `{9, 12, 13, 16}` — four. A lane needs its own colour, so:

**And L must divide N** — `launch.py:836` `assert P_BLOCK_SIZE % KPIPE_K == 0`,
because the fold `k = local_y mod L` / `i_own = local_y / L` is uniform only with
equal slot counts per lane. **L ∈ {1, 2, 4, 8, 16}**; my first pass interpolated
L = 3 and L = 7, which are not lane counts.

| scheme | colours/lane | pool | affordable L | best **reachable** |
|---|--:|--:|---|--:|
| **switch + filter** | 1 switch-capable | 4 | 1, 2, **4** | **1,432** |
| K-pipe fold | 2 ordinary | 7 | 1, **2** | **2,072** |
| repaint-as-advance | 1 ordinary | 7 | 1, 2, **4** | **3,224** |

**1,432 / 2,072 / 3,224** — the switch design's margin over the fold is **45 %**,
not the 23 % my interpolation suggested.

**The pick is L = 2, not L = 4.** L = 2 → L = 4 buys 128 cycles (~1.5 % of an A2
layer) for two switch-capable ids that layout C still needs; L = 4 spends all
four and leaves zero for the QKV column-identity hop, which has no design and no
id.

**Though there may be no conflict at all.** The QKV hop is *the same primitive
rotated*: A1 column *c* and A2 column *c* are 128 fabric columns apart, so
preserving column identity is an equidistant stride-128 shift **along X**, with
the Y-replication handled by the free multicast. Our kernel already repaints one
colour between an X-axis and a Y-axis role — `write_X_routes()` /
`write_Y_routes()`. If the two are strictly sequential with quiescence between,
**they may cost one switch-capable id in total**, restoring L = 4. Unverified.

The ceiling is also soft: colours 1–5 are all switch-capable, and borrowing them
between collective phases lifts the pool from 4 to 9 at no id cost — for the
price of the C1 invariant.

**My 1,270-halves buffer objection may dissolve.** It assumed the drain must
*land*; it need only produce a completion event at the right beat. A 1-element
fabin DSD triggered by a counter filter would take the buffer to **one** — but
FFT's filter is a *periodic* pass/drop cycle with a per-PE start, not an
arbitrary one-shot window, so this is a mini-sim question, not a claim. It does
not fix the latency either.

**Joint recommendation: target switch + filter at L = 4, keep the fold as the
fallback.** The switch design is unproven in this codebase, needs switch-capable
ids the audit has not cleared, and has a silent-hang failure class; the fold is
proven on silicon here. The gap is real but not decisive — **a risk decision, not
a performance one.**

## Round 11 — the QKV hop is not a multi-sender problem at all

**Asked:** nothing — this came out of my own observation that the QKV
column-identity hop looked like the A2 shift rotated 90°, and
`4b-comm-pattern`'s correction of the conclusion I drew from it.

**My observation was right and my conclusion was wrong.** A1 column *c* and A2
column *c* are 128 fabric columns apart, so preserving column identity is an
equidistant stride-128 shift along X. I proposed sharing one switch-capable id
between the two axes. Priced as a multi-sender shift it would be terrible: the
cut between the block-columns has one E–W link **per row**, and if every A1
column sourced on every row, each row-link would carry 128 × 48 / 2 = **3,072
beats — 2.4× the entire southward split-and-gather floor, and 36 % of an A2
layer** sitting next to the 1,560-cycle path we had spent five rounds tuning.

**It is not that primitive, because of the Y-replication.** A1's PE at (*c*, *r*)
holds column *c*'s QKV for **every** *r*. So the **diagonal** PE (*r*, *r*)
already holds exactly what row *r* needs to carry — no pre-movement inside A1, no
transpose, no funnel.

- **Row *r* has exactly one sender.** A1 PE (*r*, *r*) sends 48 halves east; A1
  columns *r*+1…127 and A2 columns 0…*r*−1 are pure transit; A2 PE (*r*, *r*)
  takes it. Every route is a static function of `(lx, ly)`.
- Then A2 column *r* distributes it over its 256 rows.

| | per row-link | vs an A2 layer |
|---|--:|--:|
| every column sources on every row | 3,072 | 36 % |
| **diagonal source** | **24** | **0.28 %** |

**One sender per row means there is no multi-sender problem on this axis.** No
fold, no lanes, no switch, no store-and-forward, **and no switch-capable id.**
Credit to `4b-comm-pattern` (§12.10); the geometry was mine, the fix is theirs.

### Two corrections to the sketch, mine

**The vertical distribution is not "the identical shape §5 carved out".** §5's is
a southward broadcast from the top of the column. Here the source sits at row *r*,
**interior**, so rows above it need `rx = SOUTH` and rows below need `rx = NORTH`.
Still one colour and still static, but three route classes keyed on the sign of
`ly − c`, not one:

```
column c, row y:   y = 0        rx = SOUTH, tx = {RAMP}           // sink
                   0 < y < c    rx = SOUTH, tx = {RAMP, NORTH}
                   y = c        rx = RAMP,  tx = {NORTH, SOUTH}
                   c < y < 255  rx = NORTH, tx = {RAMP, SOUTH}
                   y = 255      rx = NORTH, tx = {RAMP}           // sink
```

The two sinks are `4b-comm-pattern`'s addition — without a 1-tx terminator at
each end the wavelet leaks past the region, which is a leak rather than an error.

**And there is a degenerate case at c = 0**, mine, sharpened by
`4b-comm-pattern`: the `y = 0` sink class and the `y = c` source class land on the
**same cell**, so the table is broken either way you resolve it — paint the sink
and nothing is ever injected; paint the source and its `tx = NORTH` leaks off the
north edge. Column 0 needs **three** classes (I first said two, which was wrong):

```
c = 0:   y = 0        rx = RAMP,   tx = {SOUTH}
         0 < y < 255  rx = NORTH,  tx = {RAMP, SOUTH}
         y = 255      rx = NORTH,  tx = {RAMP}
```

There is no mirror case: *c* ≤ 127 < 255, so the south region is never empty.

Calling this "the identical shape" understates the work and invites a wrong route
table.

**It is a latency item, not a bandwidth item.** The diagonal wavelet crosses 128
columns and the vertical distribution up to 255 rows — ~383 hops of pure routing
per layer. That is fill, not throughput, and it is only free if it overlaps
something; nothing has been said about what A2 is doing while it happens.

**383 is a floor, and the obvious way to trade it down does not pay.** Any source
map is a bijection from 128 columns onto A1's 128 rows, so *some* column must
source from row 0, forcing a 255-row vertical spread — 128 + 255 = 383 is optimal
for the one-sender-per-row family (`4b-comm-pattern`). Dropping the bijection so
*k* columns share a row concentrates the sources near A1's bottom edge, close to
A2's midpoint, and shortens the vertical leg:

| *k* | A1 rows used | fill (hops) | beats/row-link | **also costs** |
|--:|---|--:|--:|---|
| **1** | [0, 128) | **383** | **24** | **nothing** |
| 2 | [64, 128) | 319 | 48 | a colour + the mechanism |
| 8 | [112, 128) | 271 | 192 | a colour + the mechanism |
| 128 | [127, 128) | 256 | 3,072 | a colour + the mechanism |

**The last column is mine, and it is why k = 1 wins.** At k = 1 row *r* has
exactly one sender — A1 col *r* injects `rx = RAMP, tx = EAST`, everything
downstream is `rx = WEST, tx = EAST` transit, A2 col *r* takes. One rx per cell,
one ordinary colour, no switch, no fold. **That is the whole reason the diagonal
is free.** At k = 2, row *r* has sources at c₁ < c₂ and c₁'s wavelet must transit
c₂, which is itself a source — so c₂ needs `rx = WEST` to forward and
`rx = RAMP` to inject. That is exactly the conflict this whole thread was about,
back on the X axis.

And the magnitudes settle it against our own precedent. The fill is ~383 hops
against A2's ~8,434 cyc/layer, ~4.5 %; k = 8 saves 112 cycles, **1.3 % of a
layer, for a colour plus the mechanism**. Two rounds earlier we declined
L = 2 → L = 4 because 128 cycles was not worth two switch-capable ids. This fails
the same test more clearly. **Record the k table as a bound, not a
recommendation.**

`4b-comm-pattern`'s framing of the inversion is worth keeping even so: here
bandwidth is the slack and latency the binding side, the opposite of every other
path in this analysis. It just does not pay at these magnitudes.

### It should also fix the 2026-09-07 column collapse

`4b-comm-pattern` asked, having not read the defect. **Yes, and structurally.**
The measured failure was that the existing multicast sources from one boundary PE
per row, so every A2 column received the boundary column's Q/K/V — 1 of 8 distinct
against vanilla's 8 of 8. Under the diagonal, the source column is a function of
the row and the take column equals it, so **column identity is preserved by
construction, not by care.** The acceptance test already exists:
`analyses/2026-09-07-qkv-column-sharding-check.md`, with its control.

### What it does to the lane pick

`4b-comm-pattern`'s L = 2 argument rested on reserving switch-capable ids for
this hop. That premise is gone, so **L = 4 is defensible again** — but the
difference is 128 cycles, 1.5 % of an A2 layer, and layout C still has the
multi-layer chain and the height-divides-width blocker unresolved, either of
which may want ids. **L = 2 stands as the conservative pick, now marked as
conservative rather than forced.**

**This is a sketch, not a design.** Unchecked against A2's actual QKV consumption
pattern, against whether row *r*'s link is free during that phase, and against
sequencing the vertical distribution alongside the southward shift on the same
columns. The intra-layer ordering still has never been written down.

---

## 2026-09-09 — from "is this layout buildable" to "can any gate here be trusted"

Eleven rounds of communication design settled how data moves. The next day
answered whether the layout can hold the model at all, and then turned up
something worse than a layout problem.

### The SRAM audit — measured, compile-only

| stage | height | `dim_per_pe` | 5 layers | grows after deploy? |
|---|--:|--:|--:|---|
| A1 | 80 | 32 | **63.1 %** | no |
| **A2** | 256 | 10 | **85.4 %** | **yes — KV** |
| A3 | 160 | 16 | **97.9 %** | no |

Heights are **forced, not chosen**: `assert dim % H_ROWS == 0` plus 2560 = 2⁹·5
leaves only `{…,64,80,128,160,256}`; A3 at 128 caps a group at 4 layers and
8 × 4 = 32 < 36; the next divisor above 160 is 256, which leaves A1 nothing. So
16 rows idle per group — layout C's "zero waste" does not survive holding the
model. 8 × 5 = 40 ≥ 36 ✓.

**A3 has two independent overflows.** A 512-byte `.csl_dcache` window fails at
`ffn_dim_per_pe = 76` (`624 > 512`), *independently of layer count and height* —
purely because the block is 128 wide. Removing that pin revealed a second,
bank-SRAM overflow underneath. **`bsz = 2` does not fit at all**: the
`bsz`-linear terms total ≈ 24,400 B against A2's 3,888 B of headroom.

### Then the floor gave way

Two of this project's gates were audited and **both were incapable of failing**:

- `compare_records.py` **passed on two empty archives** — equal empty key sets,
  empty comparison loop, `ok` never touched. Two runs that produced nothing
  compared "byte-identical".
- `run_sim_gates.sh` **always exited 0** — its last statement was an `echo`, it
  had no `set -e`, and it asserted neither gate's outcome.

`4b-wide-layer` then narrowed my overbroad claim (device drivers *do* consume the
exit status via `&&` chains) and I narrowed its narrowing back: **two runs that
both truncate to 3 rounds of 8 still pass**, with per-key lines present and a
normal-looking verdict. Neither of us had named that class. It is why
`check_records.py` exists rather than just a hardened comparator —
*two archives agreeing is a value claim about a pair; whether either is a complete
record of what was asked for is a shape claim about one, and nothing was making
it.*

### The pattern underneath, nine instances in two days

**A property of the instrument read as a property of the thing measured.** A probe
window read as A1's content; a stall read as blocking a cut it never touches; a
back-pressure window read as the FFN's own cost; a testbed's one-layer pin read as
a design choice; a gate re-defined to fit the testbed read as evidence; a `grep`
scoped one directory too narrow read as "those files do not exist"; the artefact
size of two *failed* compiles read as compile-only's footprint in general (mine —
it left 7.9 GB on a disk this project has already filled once); an interpreter
error read as a test suite failing 0/10 (also mine); and a sandbox supervisor's
"low on memory" message read as a kernel OOM kill.

**The question that catches all nine:** *does this instrument have the coverage I
am assuming it has?* Recorded in project memory.

### Checkers built, K1 and K2

Both delivered by Codex agents against a written spec, each reviewed by
re-running its evidence rather than reading its report.

| | delivered | the part that mattered |
|---|---|---|
| **K1** | `check_records.py`, 7 assertions, 26 fixtures, wired in with a self-test gate | **It found three errors in my spec by reading source** — including a record key name (`round{r}_topk_vals_u16`, not `..._vals`) that would have made the checker match **zero rounds and pass everything**. That failure mode, in the document written to eliminate that failure mode. |
| **K2** | verdict sink; four checks now fail the run; `INCONCLUSIVE` counts as failure; skips visible and never counted as passing | It found a **fourth** print-and-continue check I had missed (`LOCAL-TOPK`), and recorded all four as SKIPPED on the device path — without which `finalize_checks` would pass vacuously on an empty set. |

### The refactor plan, revision 2

Codex review refuted revision 1 at the framework level, not in detail:

- **A misclassification class escaped every gate.** The target has `LANE = BH = 256`,
  and revision 1 only ever forced `LANE ≠ BW` and `BH ≠ BW`. Replaced with a
  **coverage matrix**: four quantities give six pairs, and a pair never separated
  cannot detect a swap between its members.
- **The funnel cannot be relaxed, only replaced.** `funnel_pe.csl` does *whole-lane*
  concatenation with `G = P/H`; at LANE = 256, 256/80 = 3.2 and 256/160 = 1.6.
  Relaxing the assert does not implement the mapping — **a new transport, not an
  assert change.**
- Sequence reordered to C0–C9: checkers precede what they gate; the multi-layer
  feedback design moves early because it **changes routes a later stage would
  already have validated**; correctness (one layer) splits from capacity (five).

---

## Corrections I made to my own earlier claims

Kept deliberately, because the record is more useful than the tidy version.

| claim | why it was wrong |
|---|---|
| FFT's advance comes from the filter counter | it is a `SWITCH_ADV` control wavelet; the filter is receive-side selection |
| FFT's middle PEs are not in the data path | pos0 is `tx = {RAMP, SOUTH}`; the ramp gets every wavelet, the filter drops them |
| the switch is the only way to change `rx` | `route_util` + `reconfig_allreduce_axis` repaint routes every layer (Le) |
| ATTN always on the west in the layout figure | roles alternate by row parity (`launch.py:1400-1401`) |
| payload 34 halves | `dim_per_pe = 2560/128 = 20`, so 24 + 20 = 44 (Codex) |
| OQ1 would be freed | the A colour also carries the per-round header |
| colour table from `Color(...)` sites | colours 7 and 8 are painted on block cells in sub-height builds |
| "≈2× context" | wrong reference frame — 2× vs the uniform-128 variant, same as today |
| 256-wide squares | the unit is 128 wide; I had to be told to count again |
| "the primitive wants 8–16 colours" | anchored on the K-pipe's L = 8; the minimum was 2 |
| "the minimum is 2 colours" | **also wrong** — with per-position `rx` it is 1 |
| K-pipe is store-and-forward through memory | `@fmovh(fabout, fabin)` never touches memory |

---

## Standing constraints

No `git commit` / `git push` without Le's explicit instruction for that exact
operation. No local compiles of real-size configs — CS-3 only; local runs are
mini geometries and `sim.elf` is deleted after each. New source files must go
into `FILES_TO_STAGE`. Cycles are canonical, converted at 0.85 GHz. No
uncompiled numbers in results tables. Per-PE SRAM comes from the compile-only
memory report, never hand-derived.
