# A3 to A1 two-row merge: proposed paths and color budget

> Historical CE-relay proposal. As of 2026-09-12, the preferred candidate uses
> router-only strip transit and source switches; see the
> [ordering comparison and new time-slice diagrams](/home/lexu/wse3-performance-model/docs/design/2026-09-12-layoutC-router-sweep-ordering.md).
> The 3/5-color counts below apply only to this older CE-relay design, not a
> lower bound for the connection. The replacement's full control protocol is
> still unvalidated.

2026-09-11. Design and host index/count checks only. No maintained communication
implementation changed; no compiler, simulator, CS-3, or performance pass is claimed.

## Proposed path and what is merged

Hidden dimension stays 2560. A3 has 160 rows with 16 hidden elements per row;
A1 has 80 rows with 32. A1 logical row r needs the concatenation of A3 logical
rows 2r and 2r+1, in that order. No addition, reduction, or conversion is needed.
There are 160 A3 source PEs (column 0, one per row) and 80 destination row
shards, subsequently multicast across all 128 A1 columns. The image shows r=0.
Blue/orange arrows identify source payloads, NOT fabric color IDs or separate
physical strip columns. Each payload traverses the same parity-alternating
color pair on successive vertical hops.

Use a one-PE-wide bridge strip immediately west of A1/A3. This replaces the
single-group output collector for these paths; it is not an additional stream
into the existing collector. The source's A3 column-0 output is already
[emitted here](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:222)
on [C15 westward](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:258).
The FFN output comes from its [X-axis reduction and cast](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1751).

For a southbound group, use coordinates relative to its A1 origin, omitting
external SDK offsets:

- Local feedback: source (x=0,y=96+2r) and (0,97+2r) send west into strip x=-1;
  relay north to strip row r; concatenate and send east into A1 row r.
- Straight inter-group transfer: same sources; relay south to strip row 256+r;
  concatenate and send east into the next group's A1 row r.
- The exact two source rows for r=79 are y=254 and255. Local target is y=79;
  the next-group target is y=335. Other rows share the ordered strip stream.
- Northbound groups mirror Y ownership. The same two physical direction pairs
  can exchange roles; this note does not validate the mirrored schedule,
  bottom turnaround, final-Z return, or head/tail/ingress composition.

The full placement already reserves west/center strips, but those strips also
have other proposed users; see [the allocation](/home/lexu/wse3-performance-model/docs/design/2026-09-10-layoutC-full-allocation.md:57).
Their coexistence is an open resource/scheduling check.

## Static color proposal

| Symbol | Candidate ID | Painted/used where |
|---|---:|---|
| H | 15, existing A3 exit ID | A3: RAMP→WEST; strip at A3 rows: EAST→RAMP. Strip at A1 rows: RAMP→EAST; A1 row: WEST→RAMP+EAST, terminate at last column. |
| U0/U1 | 17/18 | Northward software relay on the bridge strip, alternating by physical row parity. |
| D0/D1 | 19/20 | Southward software relay on the bridge strip, alternating by physical row parity. |

**One vertical direction uses 3 data-color IDs; both fixed directions use 5
IDs total (C15 plus four proposed new IDs).** These are sufficient design
allocations for this topology, not a proof of the minimum possible count.
Neither the two sources nor the two 16-element halves require separate colors.
No route repaint is assumed. Sharing a single vertical pair between directions
would require a different route/phase/drain design and is not counted as proved.

H can serve both horizontal legs because A3 source rows and A1 destination
rows are disjoint, including adjacent groups. Its router configuration therefore
never needs opposite meanings at the same strip PE. Merely saying two phases
are separated would not establish this reuse; the row-set check is explicit.

The appended **fabric view** uses gray for C15, purple for C17 and cyan for
C18; unlike the original overview, these arrow colors identify fabric IDs,
not payload provenance. At source row y=96, A3 column 0 and strip column -1
are adjacent: C15 travels RAMP→WEST at the source and EAST→RAMP at the strip.
There is no intermediate westbound PE in this placement. A longer horizontal
span could use EAST→WEST at intermediate routers without involving their CE.

At destination row y=0, the strip emits the concatenated 32 values using
C15 RAMP→EAST. A1 routers use WEST→{RAMP,EAST}, with WEST→RAMP at the final
column. The router taps each copy locally and forwards the transit copy;
the A1 CE does not receive and then re-emit that transit copy. This is the
same router-multicast shape as the current [C16 row distribution](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:237),
but assigning C15 to the new A1 input remains a proposal.

For strip physical row y:

| Direction | y even: input / output | y odd: input / output |
|---|---|---|
| North | C18 from SOUTH / C17 to NORTH | C17 from SOUTH / C18 to NORTH |
| South | C20 from NORTH / C19 to SOUTH | C19 from NORTH / C20 to SOUTH |

Every hop is a software consume/forward operation. Separate parity IDs allow
one color to terminate at RAMP and the other to originate at RAMP on that PE.
For example, y=98 emits a chunk north on C17; y=97 receives it on C17 and
emits it on C18; y=96 receives it on C18 and emits it on C17. The same chunk
uses both colors. This follows the static receive/emit pattern illustrated by
[communication demo 04](/home/lexu/wse3-performance-model/demo/communication-algorithm/04-fold-store-forward/layout.csl:35).
The pair is needed by this concurrently available static CE-relay design,
not by vertical motion itself: a router-only SOUTH→NORTH transit can retain
one color. Reusing one color for a CE receive/emit relay would require a
different switching/drain schedule, which is not designed or validated here.
CE-driven fabric-to-fabric streaming does not imply storing every transit
chunk in SRAM; the destination explicitly retains its two halves for merging.
Different payloads are serialized in known logical order, not routed using a
wavelet destination field. All source/receiver counts derive from the frame's
fixed geometry and consistently selected feedback/next-group phase.

## Queue and buffer proposal

- Bridge strip: IQ0/OQ0 for H; IQ1/OQ1 for the U pair; IQ2/OQ2 for the D pair.
  Binding depends only on row parity and remains fixed. H receive versus send
  usage depends on whether that row overlaps A3 or A1.
- A3 keeps existing OQ2/C15. A1 adds IQ0/C15 for row input; router multicast
  needs no A1 output queue. In the current external schedule, A1 only binds
  OQ0/1/2 for QKV and X in [its wrapper](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:238),
  while the imported module suppresses ordinary external queues through
  [external_io](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:286)
  and [its guarded initialization](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/comm_lib/comm_pe.csl:1700).
  This is a manual source observation, not a compiled new binding.
- A destination strip PE stages 32 BF16 values = 64 bytes of payload, then
  emits one 32-element row vector. Source strips handle 16-element chunks;
  relay-only chunks need not be stored as a full hidden vector. Control,
  DSD/task, code, and other users' storage are additional and need compilation.
- Compute queues 3..7 remain outside this proposed bridge's queue allocation.
  Frame selection, backpressure cycles, early next-layer/token arrivals,
  STOP/rearm and output drain still require explicit implementation/testing.

The current standalone launcher paints [C0..C16](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:148).
C17..C20 are proposed candidates; that observation does not certify them free
in the full composed layout. This budget excludes control, KV ingress, existing
A1/A2/A3 internal traffic, head/tail and turnaround paths. It is not a global
wafer color count.

## Ordered stream and host validation

Use 160 chunks, chunk k containing features [16k:16k+16]. For northward
feedback, each A3 strip row emits its own chunk before forwarding higher-index
chunks received from the south. For southward group transfer, it forwards
lower-index chunks from the north before emitting its own. Each A1 strip row
keeps chunks 2r and 2r+1 and forwards the remaining chunks in order. Thus every
destination receives the exact 32 features it expects without an all-reduce.

The generator enumerates all source chunks and strip rows for each direction,
checks order/coverage of all 2560 feature IDs, matches adjacent send/receive
color bindings, and rejects swapped half-vectors and a bad parity binding.
Calculated vertical 16-element chunk-hops: 21,760 north, 19,200 south. These
are topology counts, not measured time or bandwidth. The checker materializes
lists on the host; the device proposal uses a stream, not those host lists as
SRAM buffers. It does not model finite FIFO timing or prove deadlock freedom.

`csl-color-audit --worktree` was attempted with explicit /tmp outputs. It
refused at comm_pe.csl:790 (unsupported multiline encode_output_queue), so no
automatically verified occupancy map is claimed. No extractor bypass or
shared-memory generated view was edited. Source hashes and analytical results
are in the diagram JSON.

## Artifacts

- [Editable source](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-11-layoutC-a3-a1-merge.excalidraw)
- [PNG preview](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-11-layoutC-a3-a1-merge.png)
- [Focused fabric-color preview (derived from the same source)](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-11-layoutC-a3-a1-merge-color-detail.png)
- [SVG export](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-11-layoutC-a3-a1-merge.svg)
- [Generator and checks](/home/lexu/wse3-performance-model/docs/diagrams/gen_2026-09-11-layoutC-a3-a1-merge.py)
- [Analytical results and source hashes](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-11-layoutC-a3-a1-merge.json)
