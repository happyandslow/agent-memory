# A3-to-A1 router sweep: sender ordering and burst continuity

2026-09-12. Proposed design, based on source inspection and analytical checks.
No maintained CSL change, compile, simulator result, hardware run, or performance
claim. This replaces the per-hop CE-relay preference in the September 11 diagram;
the earlier artifacts remain historical, not the active routing recommendation.

## Geometry and port convention

Use coordinates relative to the south-oriented group's A1 origin. A3 source
column 0 occupies y=96..255; its west strip is x=-1. A1 logical row r occupies
y=r for local feedback, or y=256+r in the next group. Two A3 rows 2r and 2r+1
hold the 16-element halves of A1's 32-element row shard. No arithmetic reduction
is involved. Source output is replicated along A3 X; only column 0 sends.

`INPUT -> OUTPUT` is relative to the router being configured. At a source strip
PE, the A3 PE is east of it. Thus southbound injection is EAST->SOUTH. At a
destination strip PE, the stream arrives from the north and A1 lies east, so
the route is NORTH->EAST. Both are required at different locations. Northbound
equivalents are EAST->NORTH and SOUTH->EAST. Neither corner uses strip RAMP.
Source A3 uses RAMP->WEST; A1 uses WEST->{RAMP,EAST}, with only RAMP at the last
column. Intermediate strip payload uses only cardinal router ports.

## Side-by-side ordering tradeoff

"Upstream" means the side from which transit traffic arrives, not necessarily
the north. At each source-strip junction, a single color selects either the
upstream stream or this row's A3 input from EAST.

| Property | Upstream first, then own payload (recommended candidate) | Own payload first, then upstream |
|---|---|---|
| Northbound source order | 255 down to 96, farthest to nearest | 96 up to 255, nearest to farthest |
| Southbound source order | 96 up to 255, farthest to nearest | 255 down to 96, nearest to farthest |
| North junction transition | SOUTH->NORTH to EAST->NORTH | EAST->NORTH to SOUTH->NORTH |
| South junction transition | NORTH->SOUTH to EAST->SOUTH | EAST->SOUTH to NORTH->SOUTH |
| Source grant direction | A completed source's control follows the data direction to open the next source | In a simple explicit grant design, grant travels against the data direction to the next source |
| Junction after own payload | Can stay in injection state and go quiet: later sources are downstream and do not cross it | Must become transit-transparent: later upstream payload must cross it |
| Simple completion protocol | Send the complete burst, then an ordered in-band SWITCH_ADV consumed at the next source switch | Finish the local burst, establish transit mode safely, then release the upstream source; alternative backpressure/local-control designs require separate proof |
| Readiness dependency | A not-ready upstream source delays all later sources in the sweep | Nearby ready sources may produce early output without waiting for the farthest source |
| North pair arrival / A1 writes | Odd half then even half; write offsets 16 then 0 | Even half then odd half; write offsets 0 then 16 |
| South pair arrival / A1 writes | Even half then odd half; write offsets 0 then 16 | Odd half then even half; write offsets 16 then 0 |
| Payload link traffic | Same source-to-destination paths and element counts, for a fixed geometry | Same; ordering alone does not remove payload hops |
| Performance implication | Avoids a reverse source-grant path in this candidate, but still incurs source completion/control dependencies | May favor early nearby arrivals, but adds safe return-to-transit coordination in the explicit-grant candidate |
| Between layers/tokens | Switches, counters and final control must be drained/rearmed | Also needs drain/rearm; not automatically reusable |

This is not a latency ranking. Readiness, backpressure, target selection, control
cost and reset can dominate either scheme. "Own first" does not intrinsically
require an extra color: reverse grants are one concrete coordination option,
not a lower-bound proof. The recommended upstream-first source handoff follows
the structure of [demo 02's switch configuration](/home/lexu/wse3-performance-model/demo/communication-algorithm/02-sweep-k1/layout.csl:32).
The source-side [completion task](/home/lexu/wse3-performance-model/demo/communication-algorithm/02-sweep-k1/sender.csl:27)
appends an in-band control operation after the payload; this is CE work at the
sender, not a CE payload relay on the strip. In our adaptation the controlled
strip input is EAST instead of that demo's local RAMP.

## Does each source remain contiguous on a shared link?

Both orders can preserve complete, non-interleaved source bursts. The necessary
contract is that the junction exclusively selects one source for the entire
burst, changes selection only at the verified payload boundary, and preserves
FIFO order onto the shared downstream path. Merely choosing one or two colors
does not establish this contract.

For the upstream-first two-source case:

1. The nearer source's strip is initially transit-only; its horizontal input
   is not selected. The upstream source emits all 16 elements.
2. Only after payload completion does that source append SWITCH_ADV on the same
   ordered color/output stream. Source completion alone is not a whole-path
   drain: safety depends on the control following the payload at the junction.
3. The nearer junction consumes the control and changes to its EAST input.
   Its own data follows the earlier burst on the common downstream FIFO path.
4. Earlier data may still be farther downstream when the next source starts;
   this is safe spatial overlap, not interleaving on one shared link.

For own-first, local payload must finish through the junction before it opens
the upstream route. An upstream source may wait for an explicit grant or be
held by backpressure; a complete implementation must demonstrate that the
change cannot truncate the local tail or admit the upstream burst early.

Allowed: `S1[all 16] | optional idle/control gap | S2[all 16]`.
Forbidden: `S1[prefix] | S2[prefix] | S1[suffix]`.
Stalls inside one burst are also allowed. Contiguous means no other source's
payload interleaves; it does not mean one payload element every cycle.
Two independent colors without a burst scheduler can interleave at a shared
physical link even if each color's own FIFO remains ordered.

## Two-source time slices shown in the figures

North: y=97 injects Z[16:32] while y=96 passes SOUTH->NORTH. A trailing control
advances y=96 to EAST->NORTH, enabling Z[0:16]. Both reach target strip y=0,
which turns SOUTH->EAST. A1 columns 0 and 1 are drawn; the row multicast
continues through column 127. The receiver writes offsets 16, then 0.

South: y=96 injects Z[0:16] while y=97 passes NORTH->SOUTH. Its trailing control
advances y=97 to EAST->SOUTH, enabling Z[16:32]. Both reach target strip y=256,
which turns NORTH->EAST. The receiver writes offsets 0, then 16.

The source strip shows exactly two adjacent vertical PEs, y=96 and y=97.
Each source row shows the adjacent horizontal pair strip x=-1 / A3 x=0.
Two adjacent horizontal receiving PEs, A1 x=0 and x=1, are also shown. Long
vertical distances are compressed. Solid and dashed arrows use the same
color for payload and control; source labels distinguish the two payloads.
T0/T1 are causal phases, not a global clock or measured duration. Target
turns are preselected for this isolated pair; the figure does not claim a
completed 80-destination selection protocol.

## Resource and validation boundary

Candidate data paths remain one switch-capable color per direction. Source
handoff control may share that color as above. Full target selection, the final
control wavelet's termination, mirrored/turnaround routes, repeated-frame reset,
queue conflicts and actual ID assignment remain unvalidated. No claim of a
complete two-color full-model protocol is made. In particular, existing C15
exit usage is not a validated switch-capable allocation for this replacement.

The host checker accepts two ordered 16-element bursts with idle gaps, rejects
an interleaved payload and an early control marker, and verifies that both
global arrival orders reconstruct all 80 x 32 = 2560 features at fixed buffer
offsets. It checks an abstract trace contract, not a simulated scheduler,
finite FIFO behavior or actual SWITCH_ADV implementation. The diagrams were
visually inspected. Required future device cases include varied source
readiness, receiver stalls, withheld/early control and second-frame reset.

## Artifacts

- [North editable source](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-12-layoutC-north-switch-timeslices.excalidraw)
- [North PNG](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-12-layoutC-north-switch-timeslices.png)
- [North SVG](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-12-layoutC-north-switch-timeslices.svg)
- [South editable source](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-12-layoutC-south-switch-timeslices.excalidraw)
- [South PNG](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-12-layoutC-south-switch-timeslices.png)
- [South SVG](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-12-layoutC-south-switch-timeslices.svg)
- [Generator and host checks](/home/lexu/wse3-performance-model/docs/diagrams/gen_2026-09-12-layoutC-switch-timeslices.py)
