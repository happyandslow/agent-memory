# Full-model LayoutC regional color audit

Date: 2026-09-13. Evidence: manual source audit and analytical geometry/resource
checks. No new CSL compilation, simulator execution, device run, SRAM claim or
performance result. The full-model composition does not yet exist as a compiled
route map. This report must not be represented as one.

## Transport interpretation

The target is the complete 36-layer 4B decode model on the changed layout.
The already-discussed single-color-per-direction source/target-switch protocol
provides local feedback and straight inter-group activation transport. Do not
add the legacy eight-pipe CE relay as a second transport for those same links.
This supersedes the assumption in the preceding C16 discussion that retaining
K-pipe meant retaining its old implementation and fixed 16-color allocation.

Physical strip PEs remain necessary for the proposed placement: they provide
router transit and turns between nonaligned source/destination rows. Payload
need not enter those strip CEs. Compute endpoints still inject/receive payload;
reset/control endpoints may use CE tasks. A physical strip is not synonymous
with the old `decode_strip.csl` software relay.

For example, in proposed fabric coordinates, G0 A3 row 0 is at y=98 and its
leftmost PE is x=132. A local feedback fragment enters x=131 at y=98, travels
north on the strip, and turns east toward G0 A1 row 0 at y=2. A straight
inter-group fragment can instead travel south toward G1 A1 row 0 at y=258.
These are path examples, not a claim that either is already integrated.

The old K-pipe implementation explicitly moves upstream payload through a CE
before injecting the local shard, and receiver CEs forward downstream payload
before broadcasting. See [sender relay](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode_strip.csl:80)
and [receiver relay](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode_strip.csl:122).
Its C16/C17 pipe-7 routes are a real conflict **if that old implementation is
retained on the same strip**, but they are not an inherent requirement of
inter-group communication. The standalone `tall_output.csl` collector is also
replaced by full-pipeline activation transport, not added to it.

## Figure and geometry

![Full-model regions and color ledger](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-13-layoutC-color-regions.png)

- [Editable Excalidraw source](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-13-layoutC-color-regions.excalidraw)
- [SVG export](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-13-layoutC-color-regions.svg)
- [Exact rectangles, color sets, source hashes and check results](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-13-layoutC-color-regions.json)

The figure preserves the previous 650x1028 proposed reservation and its
nonoverlapping regions. It includes all 36 layers once, distributed
[5,5,5,5,4,4,4,4] across G0..G7. Each group has A1 128x80, A2 128x256 and
A3 128x160 plus 16 spare rows. G4..G7 are geometrically mirrored proposals;
their actual mirrored schedule remains to be validated. These coordinates
are not a verified physical allocation on a live CS-3.

| Physical band / reservation | Intended target role | Numeric color status |
|---|---|---|
| x=0..2, y=2..1025 | Host I/O and demux | Legacy C0 ready / C18 pre-embed plus unresolved auto IDs |
| x=3..130, y=2..257 | Head | Known internal/ABI baseline below |
| x=3..130, y=258..513 | Tail | Known baseline plus two unresolved local IDs |
| x=3..130, y=514 | Record mux | Input/output auto IDs unresolved |
| x=3..130, y=515..1025 | Service reserve | Exact KV/control component placement unresolved |
| x=131, y=2..1025 | Left-column router bridge, head/tail reshard | North/south handoff, head/tail and reset IDs to allocate |
| x=132..387, y=2..1025 | G0..G3 | Per-stage baseline below |
| x=388, y=2..1025 | Right-column router bridge and left A2 KV crossing | Shared physical strip: handoff and KV must be allocated together |
| x=389..644, y=2..1025 | G7..G4 from top to bottom | Per-stage baseline; direction adaptation pending |
| x=645, y=2..1025 | Right A2 KV feeders / return reservation | Numeric IDs unresolved |
| x=646..649, y=2..1025 | Control / host-adapter reserve | Exact placement and IDs unresolved |
| y=0..1 and y=1026..1027, x=0..649 | North return/ingress and bottom G3/G4 turn | Exact route/ID assignment unresolved |

## Known regional claims and available candidates

Numbers below are physical color IDs. Each row is a conservative union over
the corresponding region: it does not claim every listed color is used by
every PE. Repeated groups can reuse IDs on disjoint rectangles. A2 edge colors,
for example, are not charged as active at every interior A2 PE.

**Candidate** means the complement of known component claims, before adding
new ingress, feedback, reset and crossing routes. It is not a globally free
allocation and is not evidence of an available IQ/OQ or task slot. Question
marks in the figure mean additional numeric claims remain unresolved, not
that all 24 colors are occupied.

| Region baseline | Known claimed IDs | IDs unclaimed by that baseline | Switch-capable subset of candidates |
|---|---|---|---|
| A1 | 0-4,8-10 | 5-7,11-23 | 5-7,12-13,16-17,20-21 |
| A2 | 0-4,8-14,16 | 5-7,15,17-23 | 5-7,17,20-21 |
| A3 | 0-4,14-15 | 5-13,16-23 | 5-9,12-13,16-17,20-21 |
| Head | 0,7-13,18,21-23 | 1-6,14-17,19-20 | 1-6,16-17,20 |
| Tail, before two auto allocations | 1-5,7,22 | 0,6,8-21,23 **minus unresolved auto IDs** | 0,6,8-9,12-13,16-17,20-21 **minus unresolved auto IDs** |

A3 C15 is its current standalone result binding, not a mandatory fixed
full-model ABI. It can be replaced/rebound consistently with the selected
handoff protocol; its nonswitchable status means it cannot directly serve as
the switching color of that protocol. C5/C6/C7 in tall are legacy parameters
with inactive startup routes, not active legacy collectives. Startup inert
paints and queue initialization must still be changed consistently when an
ID is allocated to a new use. This audit conservatively retains the current
C15 binding in the baseline column.

The SDK lists switch-capable IDs as 0-9,12,13,16,17,20,21; see
[SDK switch specification](/home/lexu/CSL-Demo-Code/versions/v2.10/Cerebras_Docs/csl/language/builtins.md:3581).

## What each color does

| Region | Usage and evidence |
|---|---|
| A1 | C0-4 collective; C8/C9 folded QKV east; C10 residual X east. [Binding](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:238), [sender/route choice](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:164). |
| A2 | C8/C9 horizontal QKV arrival/transit; C11 QKV column multicast; C10 edge X receive; C12/C13 edge vertical X/Z redistribution; C16 X row multicast; C14 Z west. C0-4 collective. [Routes](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:174), [queue phase transitions](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:96). |
| A3 | C14 Z receive/multicast; C0-4 FFN collective; C15 standalone output. [Routes](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:249). |
| Head | C21/C22 north and C8/C9 south embedding gather; C7 token input; C18 pre-embedding and C23 post-embedding; C0 ready; C10-13 forced-token relay. The forced-token routes are painted even when forced mode is off, so this audit does not reclaim them. [Forced-token paint](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:1456), [other bindings](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:1499). |
| Tail | C1-5 Y/X collectives; C7 token return; C22 legacy final-Z ingress. `logits_south_color` and `tail_xready_color` are auto-allocated, not source-pinned numeric IDs. [Bindings and auto allocations](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:2831). |
| Demux / mux / KV feeders | Some ports and chains use auto `region.color(...)` allocation. Do not infer their IDs or free complements from names. [Demux](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:1362), [injector/adaptor](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:2221), [mux](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:3008). |

## C16 and the remaining assignment

C16 is a candidate for A1/A3 plus the replacement router bridges. A2 retains
C16 for its internal horizontal X multicast; the final A2 column receives
without forwarding east, so that route does not itself spill into the next
strip. See [row multicast termination](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:237).
The two uses can be spatially separate; the old K-pipe C16/C17 reservation
does not automatically survive replacement of that transport.

This does not yet assign C16. The center strip also carries left A2 KV ingress,
and the head/tail and reset crossings are not fixed. The next allocation must
place these claims on the same physical map:

- U/D: north/south activation stream, including source/target markers and
  sentinels on the same ordered color/queue as payload.
- H/T: 10-to-32 and 16-to-10 hidden resharding at head/tail boundaries.
- K: runtime layer-specific KV ingress, metadata, and per-request rearm.
- R: reset/START routing and task/queue ownership.

Use the candidate intersection for each entire path, including transit PEs,
not just its endpoint regions. For A1/A3, the shared switch-capable candidate
set is **5-7,12-13,16-17,20-21** before bridge/K/H/T/R claims. A static color on
a strip requires no payload IQ/OQ there; endpoints still need queue/task
allocation and lifecycle checks. Do not reuse collective C0-4 merely because
one endpoint has completed its local receive.

## Reproduction and verification

The generator creates a new dated view and refuses to overwrite an existing
source/export. The previous human-editable allocation drawing is preserved.

```bash
python3 /home/lexu/wse3-performance-model/docs/diagrams/gen_2026-09-13-layoutC-color-regions.py --check
```

Positive checks: exact footprint partition, nonoverlapping rectangles, all
36 layers once, color complements and switch capability, source hashes and
line bounds, unique Excalidraw IDs, and exported image presence. The PNG was
visually inspected for legibility and clipping.

Five negative controls were rejected: overlapping regions, duplicate layer,
listing used A2 C16 as free, claiming a globally free ID while allocations are
unknown, and adding the legacy K-pipe allocation back into this target.
These are analytical consistency tests, not an independent CSL routing
legality proof. Inventory extraction was manual; the existing general audit
parser does not support this kernel's dynamic queue configuration syntax.

Only this report, its generator and dated diagram artifacts are changed in
the work repository. No tracking documents or device/host kernel files were
edited. The next integration gate remains complete-group correctness before
inter-group/head/tail execution and end-to-end performance testing.
