# Layout C datapath discussion: QKV colors and hidden-axis ownership

> Subsequent implementation: Le authorized this plan; see the
> [unequal-height datapath report](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-unequal-datapath.md).
> The discussion below preserves the rationale. H0/H1 are now 8/9, the middle
> spare placement is implemented, and single-group compile / miniature exact
> transport gates pass. Complete numerical and multi-layer gates remain open.

2026-09-10. Discussion proposal only; no kernel edit, vendor compile, simulator
execution, hardware measurement, or new acceptance-gate completion.

## QKV

Keep column c's complete Q/K/V shard in column c. Select A1 source row c mod
80 and A2 reception row c mod 80. Columns 0..79 use symbolic fixed horizontal
fabric color H0; columns 80..127 use a different fixed color H1. Numeric IDs
and queue bindings are not allocated. This proposes no runtime route repaint.
Rows 0..47 carry two payloads from two different source PEs; rows 48..79 carry
one. Shared physical east links still serialize traffic. No doubled link
bandwidth or globally synchronized two-round schedule is claimed.

Only the matching A2 column receives each horizontal payload; intermediate
routers forward without storing a full shard. Each receiving PE broadcasts
within its own A2 column, both north and south where needed. The column routes
may reuse one vertical color V because they are disjoint; vertical arrow hues
in the figure indicate data provenance, not distinct vertical color IDs.

The source eligibility comes from the current
[Y all-reduce and QK/RoPE completion](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1849).
The current miniature instead selects a single diagonal sender, at
[tall_stage.csl:112](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:112),
with routing at
[launch_tall.py:79](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:79).
Those sites do not implement the proposal.

## Hidden features X/Z

The configured hidden dimension is
[2560](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/model_config/device_2x4_8k.json:8).
Dividing by A1/A2/A3 heights 80/256/160 yields 32/10/16 hidden elements per PE.
Each row's hidden shard is replicated across columns at the relevant stage
boundary, rather than divided by 128 again.

Propose contiguous half-open feature ownership [32r,32r+32), [10s,10s+10),
and [16t,16t+16). A source can split across destination rows, and a destination
can join adjacent source pieces. All intersections have even extent. Sixteen
independent feature groups of 160 each correspond to 5 A1, 16 A2, and 10 A3
rows; this is a logical decomposition, not 16 allocated fabric channels.

For a first transport implementation, use an A2 edge column for vertical
redistribution, followed by row multicast. X crosses east from A1, moves south
inside A2, then broadcasts across its target A2 row. Z is already row-replicated
after O projection; take its west-edge copy, redistribute vertically in A2,
then send west into the target A3 row. Relay scheduling must preserve exact
counts and forward without a vector-sized intermediate stash. The actual
task/queue schedule and deadlock validation remain open.

This physical-direction proposal assumes spare rows between A1 and A3:
A1 physical rows 0..79; spare 80..95; A3 96..255. Then feature i follows
floor(i/32) -> floor(i/10) -> 96+floor(i/16), a nondecreasing sequence for all
2560 features. The existing full-wafer drawing has spare rows below A3; that
file is not modified here. Middle spare placement is still under discussion.

## Weight axes

Keep the horizontal Q/K/V/O attention shards and FFN intermediate shards,
including head/RoPE ordering. Change hidden-axis ownership along physical PE-Y.
This is not a matrix transpose. Physical PE-Y need not be a matrix's first
logical index: O and DOWN have hidden on their output axis.

| Stage | Local weight tile under proposed heights | Hidden-axis change |
|---|---|---|
| A1 | Q 32x32; K,V 32x8 | Q/K/V input and attention RMSNorm |
| A2 | O 32x10 | O output and residual X/Z |
| A3 | UP,GATE 16x76; DOWN 76x16 | UP/GATE input, DOWN output, FFN RMSNorm |

The unchanged horizontal element counts are attention 4096/128=32,
KV 1024/128=8, and FFN 9728/128=76. The current fixture explicitly uses
one hidden `rows` index for these weights at
[tall_fixture.py:46](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/tall_fixture.py:46).
Its miniature A2 mapping is permuted, so the proposed contiguous mapping
requires coordinated weight and residual packing changes.

Q/K head-norm and RoPE mapping remain attached to the attention columns.
KV sequence-position ownership is a separate row/cursor mapping and is not
changed by choosing contiguous hidden-feature ownership.

## Artifacts and checks

Editable sources, each with derived SVG/PNG exports:

- `docs/diagrams/2026-09-10-layoutC-qkv-two-colors.excalidraw`
- `docs/diagrams/2026-09-10-layoutC-hidden-reshard.excalidraw`
- `docs/diagrams/2026-09-10-layoutC-weight-axes.excalidraw`

The generator checks all 128 QKV columns, the per-row payload counts, all 2560
X/Z feature identities, corrupted-destination rejection, south-only direction
under the proposed middle gap, and local weight dimensions. These arithmetic
checks do not validate fabric resource allocation, liveness, SRAM, or numerics.
