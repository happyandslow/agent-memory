# Full-model Layout C allocation and remaining construction plan

2026-09-10. **Full-wafer placement remains a design.** The subsequent
[single-group implementation report](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-unequal-datapath.md)
records a full-size southbound group compile and exact miniature transport
tests. It does not validate the full-wafer composition or hardware execution.

## Scope and evidence

The recovered prior planning baseline is A1=128x80, A2=128x256, A3=128x160 per group.
Le chose the shorter-A1/taller-A3 direction; the original author derived these
exact heights, and Le agreed to record the analysis and continue planning.
A1 and A3 share 256 rows with 16 spare rows. The equal-half allocation
initially shown in this note was a regression to an earlier design.
All dimensions in this note are width x height. Eight groups own all 36 layers,
with zero-based layer IDs. Each group stores the weights/state for its own
layers in its A1/A2/A3 regions; there are not 36 spatially separate copies of
those three regions.

The [model configuration](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/model_config/device_2x4_8k.json:2)
provides hidden=2560, FFN=9728, Q heads=32, KV heads=8, head dimension=128,
layers=36, real vocabulary=151936, and tail width=128. Batch 1 and capacity
8192 are proposed first full-model settings, not established limits. Padded
vocabulary and exported shapes must be recomputed for the final head/tail ABI.

The approximately 762x1172 outline is a planning envelope taken from the
[legacy launcher's budget comment](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:646),
not a verified live CS-3 grant or an exact physical wafer specification.

## Proposed allocation

The editable [Excalidraw diagram](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-10-layoutC-full-allocation.excalidraw)
and its [coordinate manifest](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-10-layoutC-full-allocation.json)
are the source of the geometry below. Coordinates are inclusive fabric x/y.
This is a new placement proposal, not a dump of the current launcher.

| Group | Layers | x | y | Flow |
|---|---|---|---|---|
| G0 | 0,1,2,3,4 | 132..387 | 2..257 | south |
| G1 | 5,6,7,8,9 | 132..387 | 258..513 | south |
| G2 | 10,11,12,13,14 | 132..387 | 514..769 | south |
| G3 | 15,16,17,18,19 | 132..387 | 770..1025 | south |
| G4 | 20,21,22,23 | 389..644 | 770..1025 | north |
| G5 | 24,25,26,27 | 389..644 | 514..769 | north |
| G6 | 28,29,30,31 | 389..644 | 258..513 | north |
| G7 | 32,33,34,35 | 389..644 | 2..257 | north |

Within each group A2 is the right 128-wide half at full height. Southbound
left halves have A1 (80 rows), 16 spare rows, then A3 (160 rows): local rows
0..79, 80..95, and 96..255. Le authorized implementing this discussed plan.
This supersedes the bottom-spare placement assumed by the old feedback note;
continuous hidden ownership now permits south-only X/Z remapping. Northbound
left halves provisionally mirror this to A3, spare rows, then A1. The
right-hand groups need a genuinely mirrored schedule and local-coordinate
mapping; reversing an arrow in the picture does not implement it.

| Other component/reservation | x | y | Responsibility |
|---|---|---|---|
| Host I/O reservation | 0..2 | 2..1025 | stream adapters, input demux, host results; exact SDK placement pending |
| Head | 3..130 | 2..257 | embedding table and token-to-hidden lookup |
| Tail | 3..130 | 258..513 | final RMSNorm, lm_head matrix/GEMV, top-k and sampling |
| Token/record mux | 3..130 | 514 | collect tail records for host output |
| Support spare | 3..130 | 515..1025 | unused reservation; no layer capacity credited |
| West bridge strip | 131 | 2..1025 | head-to-G0 hidden resharding and G7-to-tail bridge |
| Center strip | 388 | 2..1025 | left A2 KV injection and proposed bridge channels |
| East strip | 645 | 2..1025 | right A2 KV injection and final-result return |
| Control/I/O spare | 646..649 | 2..1025 | headers, STOP/rearm, telemetry/adapters as required |
| North corridor | 0..649 | 0..1 | ingress fanout and final-Z return reservation |
| South corridor | 0..649 | 1026..1027 | G3-to-G4 turn reservation |

The full reservation is **650x1028**, including support. The decoder tiles
alone sum to 512x1024; there is an additional center strip between the two
256-wide group columns. Spare cells and routing reservations are not all
active code PEs. No physical path/color/queue schedule is implied by the
logical arrows. Exact external stream routing can change the footprint.

Keep head/tail height 256 independently of the 128-wide decoder stages.
The [existing embedding ABI](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch.py:1125)
uses 128 embedding columns paired with 256 hidden rows. Shrinking that
geometry with the decoder width would also change embedding ownership and
per-PE storage. Full vocabulary head/tail SRAM must be compiled separately;
the older reduced-vocabulary stage audit provides no such evidence.

Prefill computation is upstream of this decode allocation. The host/preparer
supplies layer-specific prefetched KV, request metadata, and initial input.
The plan includes on-chip KV ingress, but no on-chip prefill transformer
kernel. Weight loading initializes the owning stage's layer banks; it is not
an extra on-chip weight-storage region. The tail returns a sampled token to
the head on-chip and sends records to the host separately.

## Recovered decision and capacity evidence

Le had already asked to shorten A1 to give A3 more rows in the shared
128x256 half. The original `4b-mini-ppl-debug` session contains the correction
at [line 4364](/home/lexu/.claude/projects/-home-lexu-wse3-performance-model/824688b0-1bbe-4637-99c5-03ed21f26380.jsonl:4364),
the resulting 80/256/160 analysis at
[line 4368](/home/lexu/.claude/projects/-home-lexu-wse3-performance-model/824688b0-1bbe-4637-99c5-03ed21f26380.jsonl:4368),
and Le's agreement to record it, plus the question about padding, at
[line 4372](/home/lexu/.claude/projects/-home-lexu-wse3-performance-model/824688b0-1bbe-4637-99c5-03ed21f26380.jsonl:4372).
The current request explicitly returns to that prior height discussion.
The original author was consulted read-only on September 10 by forking the
same Claude session; it distinguished Le's direction from its derived numbers.
Its claim that Le later demoted those heights relied on a Codex-written scope
note, not a new user instruction. That note described the earlier miniature's
coverage and should not have been treated as a new full-model height decision.

The previous version of this drawing incorrectly presented 80/160 as an
unselected alternative and made 128/128 the primary plan. The primary drawing
now restores 80/256/160. There is no need to ask Le to choose that direction
again. The numbers are the next trial baseline, not a claim of validated final
geometry or an assertion that Le separately approved each derived dimension.

The [prior compile-only audit](/home/lexu/wse3-performance-model/analyses/2026-09-09-layoutC-sram-audit.md:270)
reports five-layer stage footprints of A1 63.1%, A2 85.4%, A3 97.9%, using
matching per-PE dimensions in an SRAM scaffold, batch 1. These are historical
compiler observations, not new full-geometry execution results. A2 has 120
cache slots per PE, corresponding to capacity 30720 across 256 rows. The
scaffold used reduced vocabulary; its head/tail footprint is not full-model
evidence. Specifically, the scaffold retained 128 physical rows and changed
hidden dimension to 4096/1280/2048 to obtain 32/10/16 elements per PE; see
[A1 scaffold configuration](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/model_config/sram_dpp32.json:8),
[A2 scaffold configuration](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/model_config/sram_dpp10.json:8),
and [A3 scaffold configuration](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/model_config/sram_dpp16.json:8).
The new integrated images still need complete linked-memory checks at real
hidden dimension 2560 and actual heights 80/256/160.

Why these heights were chosen under that implementation's constraints:

- A3 at 128 rows overflows with five layers; 160 rows reduces its hidden shard
  from 20 to 16 elements per PE and fits the old compile-only test.
- A3 leaves 96 rows in the shared half, but 96 does not divide hidden=2560.
  A1 takes the largest available exact divisor, 80 rows, with 32 hidden elements
  per PE. The remaining 16 rows are unused capacity, not padded tensor entries.
- A2 keeps all 256 rows, a 10-element hidden shard, and the KV storage role.
  This follows Le's stated preference to preserve room for A2 context growth;
  A1/A3 allocation is fixed at deployment.

The old 128/128 split is retained only as a historical inset/profile. Removing
its few placeholder scalars is not evidence of enough capacity for a fifth
layer. The old note's 2880-padding suggestion is not a valid common hidden
size for this whole group: 2880 is not divisible by A2 height 256.

The changed geometry now has a single-group transport implementation: X/Z
ownership is 32/10/16 elements per row, and QKV selects row c mod 80 with
two fixed horizontal colors. See the
[current selector](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:180)
and the linked implementation report for exact test scope. The
historical claim that relaxing a divisibility assertion is sufficient was
already corrected by the later refactor plan. Full-model capacity and
executable-routing gates remain open.

## What the 0.575% result does and does not establish

The [earlier evidence](/home/lexu/wse3-performance-model/docs/reports/2026-09-10-layoutC-tall-a2-evidence.json:1)
records simfab, synthetic weights/inputs, one layer, and 17 forced input steps.
Relative L2 was computed over the complete 17x64 output, with max absolute
error 0.015625. It is neither a hardware measurement nor a perplexity result.
The fixture generation is at
[tall_fixture.py:13](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/tall_fixture.py:13).

The reference uses full unsharded tensors and explicit BF16 rounding;
see [oracle layer computation](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/host/oracle_fp16.py:286).
Different reduction/rounding/approximation paths are possible explanations,
not an established attribution. The 2% threshold was a miniature bring-up
criterion. It is not sufficient grounds to accept all 36 layers.

Before widening the claim, compare matched A1 Q/K/V, A2 attention/O/residual,
and A3 FFN/residual boundaries. Use a matched-operation-order reference to
separate arithmetic-model differences from routing/packing defects, followed
by a full-precision model reference. Transport-only identity checks should
be exact. Any temporary device probes must be removed after retaining the
evidence. Do not simply relax the threshold or dismiss the discrepancy.

## Construction sequence and failing gates

1. **Finish one group.** First attribute the miniature numerical difference
   and revalidate full-dimensional four/five-layer SRAM at the selected
   80/256/160 heights. Implement
   actual full-height KV ingress with explicit layer/column/position packing;
   require exact prefix/unused storage, correct append cursors, STOP and
   reset/rearm coverage. Add local A3-to-A1 feedback and bank selection;
   test two distinct layers before four/five layers. RoPE position advances
   once per token, while KV cursors remain per layer. Validate northbound
   mirrored execution as well. No inter-group/head/tail integration yet.
2. **After the complete group gate**, connect G0..G7. Intermediate layers
   feed back locally; only each group's last layer sends the full 2560-value
   hidden vector to the next group. Use predetermined feature ownership
   and exact counts, not packet destination keys. Test two groups, then the
   bottom turn, then the entire snake against per-layer references. Add head
   output resharding (256 rows to 80) and final-Z resharding (160 to 256).
   Define the new global-feature mapping explicitly; the old miniature's
   1:2 split and 2:1 merge are not the mapping for these heights. Validate embedding, final norm, lm_head,
   sampling, token return, EOS, host records, and request rearm separately.
   Freeze route/color/queue lifetimes only with the actual final transport.
3. **Only after complete model correctness**, run full 4B on-chip and measure
   end-to-end performance. Establish a deterministic model/logit reference
   before stochastic sampling comparisons. Report device timing boundaries
   separately from host loading/I/O, and tie every number to the final
   compiled layout, batch, context, and weight artifact.

No next step is authorized merely by a spatial fit. The full-group correctness
requirement remains ahead of inter-group/head/tail integration and performance.

## Validation of this design artifact

The generator checks the restored profile and historical equal-half profile: all layers 0..35 appear exactly
once in group ownership; rectangles do not overlap; every cell in the 650x1028
reservation is assigned a role or explicitly reserved; and the reservation
fits the stated provisional envelope. Deliberately overlapping regions and
repeating a layer both fail the checker. These are allocation checks only,
not SRAM, compiler-routing, simulator, or hardware validation. The rendered
preview was inspected for legibility and consistency with the editable source.
