# LayoutC full-model communication implementation plan

Date: 2026-09-13. Revision: 3, incorporating the source review, bounded review and follow-up findings; see §9 for scope.

Scope: a resource and implementation plan, with a read-only Claude Code review.
No kernel, launcher, test, configuration, tracking document, or device change is
authorized in this session. All numeric assignments below are **proposals**, not
a compiled allocation. Existing isolated hardware evidence is explicitly scoped.

## 1. Contract and placement

Restore the complete 36-layer Qwen3-4B decoder with the new layout while retaining
the original operators and numerical contract. Validate a complete A1/A2/A3 group
before connecting groups and head/tail; measure end-to-end performance last.
Resource design nevertheless includes all components now.

Preserve the agreed decisions:

- A1 128 columns x 80 rows, A2 128 x 256, A3 128 x 160; 16 spare rows.
- Hidden width 2560: A1 owns 32, A2 10, A3 16 hidden elements per row.
  Horizontal weight/QKV column ownership does not change.
- QKV has one sender per A1 column, at logical `(c,c mod 80)`. C8/C9 are
  two fixed colors, not two copies of the same payload.
- A3 output is replicated across columns: choose column 0 of each source row.
  Two distinct 16-element source rows assemble one A1 32-element row; multicast
  that row's fragments to all destination columns. This is concatenation, not sum.
- Source switches forward upstream traffic before accepting their own source.
  Payload transit and turns in strips stay in routers. CE involvement at strip
  nodes is allowed for reset/control words, not mandatory payload relaying.
- Data and source/target markers use the same ordered output queue and color.
  A separate marker IQ/OQ is not required. No collective may be needed to send
  a grant that enables that collective's missing inputs.
- Preserve contiguous source fragments, direct writes to destination offsets,
  and exact counts. Overlap source CE-to-router injection where possible, while
  switches determine arbitration. Do not serialize all source RAMP operations
  behind a CE-issued grant merely because the strip payload stream is ordered.
- Small-message RAMP cost and large-message bandwidth saturation are later
  performance questions. Do not claim either from a color count.

### K-pipe on the existing figure

The purple **WEST bridge (x=131)** and **CENTER bridge (x=388)** carry the new
inter-group transport role previously called K-pipe. There is no separate old
eight-pipe module to add beside them. They also carry local feedback and other
explicitly budgeted routes. The bottom corridor connects these two bridges.

[Full-wafer figure](/home/lexu/wse3-performance-model/docs/diagrams/2026-09-13-layoutC-color-regions.png)
and [regional baseline audit](/home/lexu/wse3-performance-model/docs/design/2026-09-13-layoutC-regional-color-audit.md).
The figure's unknown entries remain unknown until assigned here and subsequently
validated; this document does not modify the existing diagram source.

| Group | Layers | x range | y range | Proposed orientation |
|---|---|---|---|---|
| G0 | 0–4 | 132–387 | 2–257 | south |
| G1 | 5–9 | 132–387 | 258–513 | south |
| G2 | 10–14 | 132–387 | 514–769 | south |
| G3 | 15–19 | 132–387 | 770–1025 | south |
| G4 | 20–23 | 389–644 | 770–1025 | north, mirrored |
| G5 | 24–27 | 389–644 | 514–769 | north, mirrored |
| G6 | 28–31 | 389–644 | 258–513 | north, mirrored |
| G7 | 32–35 | 389–644 | 2–257 | north, mirrored |

Head is x3–130/y2–257, Tail x3–130/y258–513, record mux y514 in the same
x span. Host/demux x0–2; service reserve x3–130/y515–1025; EAST KV strip
x645; auxiliary reserve x646–649. North corridor y0–1, bottom y1026–1027.
The proposed 650x1028 footprint is analytical, not a confirmed live allocation.

For mirrored groups define logical row explicitly: A1 row r is physical
`base_y+255-r`; A3 row t is `base_y+159-t`; A2 row s is
`base_y+255-s`. Kernels, weights, KV ownership, source selection and routes must
use the same mapping. Mirroring rectangles alone is insufficient.

## 2. Existing resources that the implementation must preserve

| Component | Existing queues and colors | Consequence |
|---|---|---|
| All tall compute | IQ/OQ3–7: collective C0–4 | Never borrow for new activation/control traffic. A2's already-existing IQ/OQ3 vertical phase is the explicit exception below. |
| A1 | OQ0 C8, OQ1 C9, OQ2 C10; IQ0–2 unused by the external schedule | Allocate new input queues here. One of OQ0/OQ1 is unused **per PE**, according to its actual QKV sender predicate. The corresponding fabric color can still carry transit traffic. |
| A2 | IQ0 C8/9, IQ1/OQ1 C11; IQ2 C10 at edge or C16 elsewhere; OQ0 C14, OQ2 C16 | Do not add a fourth noncollective IQ. Bootstrap KV may time-share an IQ before decoding starts, with an explicit ingress closure. |
| A2 edge | IQ/OQ3 alternate collective C0 and vertical C12/13 | Preserve the current output-empty callback and counted input drain; never infer IQ emptiness solely from an OQ flush. |
| A3 | IQ0 C14, OQ2 C15 result; IQ1/2 and OQ0/1 unused | Replace the standalone result ABI consistently. Use these spare resources for control, not collective queues. |
| Head | IQ0/1 forced relay; IQ2 token C7; IQ3 preembed C18; IQ4/5 C21/22; IQ6/7 C8/9. OQ0/1 forced relay; OQ2 postembed C23; OQ3/4 C21/22; OQ5 ready C0; OQ6/7 C8/9 | All eight queues in each namespace have claims. Set the post_embed_x_color compile parameter and matching OQ2 binding; preserve token/ready and forced-mode support. Do not assume spare control queues. |
| Tail | IQ0 Z; IQ1/OQ1 xready; IQ/OQ2–6 collective C1–5; OQ0 logits, OQ7 token C7; IQ7 unclaimed | Reserve IQ7 for new control if required. OQ0 can be borrowed only after the complete record and its tail drain; there is no globally spare OQ. |
| Adaptor / injector | adaptor IQ2/OQ2; injector IQ2 input, OQ3 scatter, IQ3/OQ4 reset | These belong to their own service/strip PEs, not the A2 compute queue namespace. |
| Demux / mux | demux IQ2/3 and OQ2/3; mux IQ2/OQ2 | Preserve their record/header protocols. Pin actual stream IDs; names of auto-allocated colors are not numeric reservations. |

Source sites:
[tall bindings](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:238),
[collective queues](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/comm_lib/comm_pe.csl:97),
[external-I/O guard](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/comm_lib/comm_pe.csl:1685),
[Head](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/ht_head.csl:92),
[Tail](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/ht_tail.csl:158),
[adaptor](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/kv_ingress_adaptor.csl:31),
[injector](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/kv_ingress_injector.csl:50),
[demux](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/demux.csl:56),
[mux](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/mux.csl:27).

## 3. Proposed color choices: full-path reservations

Switch-capable IDs are 0–9,12,13,16,17,20,21, per the
[SDK specification](/home/lexu/CSL-Demo-Code/versions/v2.10/Cerebras_Docs/csl/language/builtins.md:3581).
Different uses of one ID require disjoint physical route claims, including
turns/transit, or an explicitly fenced lifetime. A free endpoint ID alone is
not enough. The table supplies choices, not a claim that all alternatives can
be selected simultaneously.

| Path / role | Preferred proposal | Alternative and tradeoff | Physical claim and remaining gate |
|---|---|---|---|
| U: northbound local/straight activation | C16 | C5/6/7/12/13/17/20/21 from the A1/A3 intersection; must displace another proposed role | A1/A3 plus WEST/CENTER bridge. A2 C16 remains isolated, terminating at its last column. |
| D: southbound local/straight activation | C17 | Same intersection excluding chosen U and other active claims | Same strips, separate direction. No runtime reversal of U is needed for straight links. |
| B: G3→G4 bottom turn | C5 | Time-share/repaint U or D only with whole-edge drain; saves an ID but complicates direction and reset | G3 A3→WEST→bottom corridor→CENTER→G4 A1. One color through all turns, no router color conversion. Distinct C5 avoids forcing G4 local southbound feedback and bottom-arriving northbound input into one static route. |
| H: Head→G0 A1, 10→32 | C6 | Reuse D17 with a fenced source/route lifetime; shares G0 incoming queue but entangles Head and the generic bridge | Head post_embed_x_color compile parameter becomes C6; WEST and G0 A1. Source and target y zones overlap: cannot copy the disjoint-zone two-row marker program unchanged. See §6. |
| T: G7 A3→Tail, 16→10 | C12 | C13, or fenced U/D reuse; C22 is not switch-capable | G7 A3→CENTER north→north corridor west→WEST south→Tail, avoiding compute interiors. Tail IQ0 ABI becomes C12. Explicit index/order and fragment schedule required. |
| K-feed: adaptor→injector rows | C20 | C17 only if moved off activation strips or fully fenced; avoid as default | Service + north ingress corridor + CENTER/EAST feeder strips. Shares CENTER spatially with U/D/B, but uses a different ID. |
| K-scatter: injector→A2 columns | C21 | A2 candidates C5/6/7/17/20 with complete strip crossing re-audit | Injector EAST/CENTER strips, then west through its A2 row. Column switch selects each distinct KV shard; no copy of one column into all columns. C21 terminates in A2, before A1/A3. |
| K-reset: injector C20 switch rearm | C22 | A service-local control network with explicit return | CENTER/EAST northbound, north corridor and WEST return to the left adaptor; right EAST return to the right adaptor. Never cross Head/Tail compute interiors. See §7 for exact turns. |
| R: row completion and strip aggregation | C18/C19 on parallel row chains; C18/C23 on strip aggregation | Two colors with a serialized, explicitly fenced junction receive/send phase; do not assume a static two-input merge costs only two colors | Row completion enters strip on C19; vertical receive/send use C18/C23, so all three routes have distinct input ownership. A1/A3 and bridge/control PEs only. See §5. |
| S: source START/credit | C15, freed by removing standalone result transport | C23 if R aggregation moves elsewhere | Static multicast to A3 IQ2. A1 destinations need no START IQ: their local input-ready/ownership state drives computation. |
| K-ACK: A2 row completion | C5/C7 inside A2; final hop C7 to injector IQ5 | A separately proved row-ack collective in the closed bootstrap phase | Bootstrap IQ1/OQ0 only, restored to C11/C14 before local computation. C5 never enters the strip, so it does not collide with B5. |
| K-READY: completed injector reset acknowledgment | C13 | Another switch-capable strip ID after full-path audit | Per-group injector roots emit after their complete R round-trip. C13 gathers the four group acknowledgments, upstream first, on CENTER/EAST then returns to adaptor IQ6. Source positions are armed before K begins, never reset while acknowledgments are in flight. |
| CONFIG bus for A1/A3 | C19 | Host initialization only at request boundary, with explicit readback/READY | Roots (259,0) and (516,0): IQ2 host-input ID from SDK manifest, OQ0 C19 south. Rightmost-column bus then C18/C19 westward row chains. Mutually exclusive with row-ACK traffic; includes upstream-group transit. |
| Tail CONFIG / Head-credit requests | C19 | Separate service-local color if the mux corridor cannot reserve C19 | Controller/adaptor (130,515), OQ1 north through mux cell (130,514); Tail right-column spine fans west to IQ7. Only Tail's existing token-source PEs emit the resulting C7 messages. |
| H_ROUTE request to G0 root | C14 | Another unclaimed WEST-only ID | Service (130,515) OQ3 → EAST to WEST strip → NORTH to root (131,257) IQ6. Root uses existing R IQ1/OQ0 to carry strip-only H_ROUTE/H_WAIT records. |
| H_ROUTE/H_FRAGMENT response | C11 | Another unclaimed WEST-only ID | Root (131,257) OQ2 → SOUTH on WEST → WEST at y515 to service (130,515) IQ7. C11 is outside A2's QKV-column routes and outside Head's forced-token routes. |
| Tail→Head token / end control | Retain C7 | New port only if full old interface is deliberately replaced | x3–130 Tail/Head. Per column, the existing Tail token-source PE is the sole injector on OQ7→Head IQ2. Controller requests enter Tail IQ7/C19; they never inject a second producer directly onto C7. Tall collective colors are C0–4 on IQ/OQ3–7; color C7 and queue 7 are different namespaces. |
| Tail logits→mux | Pin C18 locally | C23 if SDK boundary routes conflict | Tail→y514 mux only; Head C18 does not overlap. Tail CONFIG already claims C19; any future R extension must account for that and C18 record traffic rather than treating either as free. |
| Tail xready | Pin C6 locally | C0 or C8/9 after local audit | Only Tail's root row, disjoint from Head/G0 H=C6. Preserve Tail phase fences. |
| Host/demux, mux host-out, KV host-in | Keep ports; explicitly capture SDK-assigned IDs in generated manifest | Pin IDs where SDK allows it, with full I/O route audit | Cannot promise numeric IDs without creating the complete SdkLayout. Reserve these as a mandatory allocation step, not “free colors.” |

C16 is **not globally free**: its new bridge use and the existing A2 X multicast
coexist by geometry. C20/C21 similarly coexist with any retained Head roles only
when their routes remain outside Head. C5/C6/C12 chosen for external bridges
must not cross Tail collectives, Head forced routes, or A2 vertical routes.
All turns are assigned to reserved corridors, not drawn through those rectangles.

## 4. Endpoint IQ/OQ selection

Recommended activation input assignment, fixed throughout decoding:

| A1 group | IQ0 | IQ1 | IQ2 | IQ3–7 |
|---|---|---|---|---|
| G0 | local U16 | Head H6 | R receive | collective |
| G1–G3 | local U16 | predecessor D17 | R receive | collective |
| G4 | predecessor B5 | local D17 | R receive | collective |
| G5–G7 | predecessor U16 | local D17 | R receive | collective |

One logical input frame is admitted at a time to the A1 X buffer. Fixed IQs
do not permit overwriting it from both input paths. Frame identity is
`(request, token_position, global_layer, input_kind)`; the deterministic schedule
selects one queue. Every unexpected frame/count is an error, not silently skipped.

| PE | Preferred output/control assignment | Alternative |
|---|---|---|
| A1 | Existing OQ0/1 QKV and OQ2 X. Use the **non-sending** QKV OQ for R: if the PE is an H0 sender use OQ1, otherwise OQ0 (H1 senders therefore use OQ0). Bind that OQ to its R link at startup. | No R output on a collective queue. A1 does not receive START; adding a fourth input queue is neither necessary nor available. |
| A3 | IQ0 Z14; IQ1 R; IQ2 START15. OQ0 R; OQ1 fixed local-feedback color; OQ2 fixed exit color. Markers use the selected payload OQ. | One rebound payload OQ is possible with the §5 flush predicate but is not preferred: every group has exactly two output colors. |
| Router strip | No activation payload IQ/OQ. R uses IQ0 for row C19, IQ1 for vertical C18/23, and OQ0 for vertical output. START root uses OQ1; a selected control root may receive START on IQ4. KV uses IQ2/3, OQ3/4; K-ACK uses IQ5. K-READY roots use OQ2/C13. The WEST G0 control root instead uses IQ6/C14 and OQ2/C11 for H service traffic. These are different PEs/roles. The merged image must own all bindings and task IDs. | Router-only reset instructions may later replace some CE control hops if fully ordered and acknowledged. |
| Head | Set post_embed_x_color=6 at compile time, updating route paint and OQ2 together. IQ2 C7 carries typed CONFIG/CREDIT control as well as existing data tokens; credit gating applies also to forced mode and the first host-preembedded frame. No added R queue. | Do not borrow preembed IQ3 while a later request may already be queued. |
| Tail | Set z_drain_color=12 at compile time on IQ0; retain collective IQ/OQ2–6 and xready1. Reserve IQ7 for CONFIG/completion control C19. OQ0 remains record output until complete record drain; only then may a control relay borrow it. OQ7 keeps token/control C7. | Keep Tail out of the activation ring initially; integrate its completion acknowledgment through the existing token/controller interface before full-model admission. |
| A2 KV bootstrap | Before admitting QKV: IQ0 K21, IQ1 row-ACK C5/7, OQ0 row-ACK C5/7. IQ2/OQ2 retain the existing X route, used first for one C16 reset word. Restore IQ0 C8/9 and IQ1 C11 before forwarding ACK; flush and restore OQ0 C14 before enabling this PE’s computation. Details in §7. | A per-PE unused IQ0/IQ1 specialization may avoid rebind, but complicates root roles and does not itself solve lifecycle. Do not borrow collective IQ3. |

Service/control endpoint reservations (new functionality, not existing bindings):

| PE / role | IQ claims | OQ claims |
|---|---|---|
| Left adaptor/controller (130,515) | IQ2 SDK host input; IQ3 C22; IQ6 K_READY13; IQ7 H_RESP11 | OQ0 host READY port (SDK ID gate); OQ1 Tail control19; OQ2 K-feed20; OQ3 H_REQ14 |
| Right adaptor (646,1) | IQ2 host input; IQ3 C22; IQ6 K_READY13 | OQ2 K-feed20; OQ0 host READY (SDK ID gate) |
| CONFIG roots (259,0), (516,0) | IQ2 host/config input (SDK ID gate) | OQ0 C19 south |
| G0 WEST root (131,257) | IQ0 row19; IQ1 return23; IQ6 H_REQ14 | OQ0 vertical18; OQ1 START15; OQ2 H_RESP11 |
| CENTER/EAST group-bottom K_READY roots | R/injector IQs from table above, including IQ5 ACK7 | OQ2 K_READY13, distinct from scatter OQ3 and reset OQ4 |

Reserve C19 router transit through mux cell (130,514); the mux auto host-output
color must not collide with it. No service/controller code exists yet with this
combined table. Its task slots, host ports and request-join completion remain
manifest gates.

Fixed A3 payload outputs (compile parameters, not runtime queue changes):

| Groups | OQ1 local | OQ2 exit |
|---|---|---|
| G0–G2 | U16 | D17 |
| G3 | U16 | B5 |
| G4–G6 | D17 | U16 |
| G7 | D17 | T12 |

New tasks must have a per-image table. Tall local task 8 is already main; the
isolated experiment's control entry 40 aliases local task 8 and cannot be copied.
Allocate ROW_DONE, STREAM_END, reset-data dispatch and output-empty callbacks
only after enumerating imported tasks and SDK entrypoint aliases. This is a
compile gate, not an unverified promise that IDs 40+ are spare.

## 5. Straight activation protocol and safe boundaries

Reuse the **semantics**, not the conflicting queue/task IDs, of the
[verified marker protocol](/home/lexu/wse3-performance-model/docs/reports/2026-09-12-layoutc-marker-reset-verification.md).
Its CS-3 evidence covers 3x7 PEs, u32, four 16-word sources, two rows/two columns,
two epochs in both directions, plus withheld-ROW_DONE rejection. It does not
establish packed f16, 128-column fanout or collective coexistence.

Normal source switches use pop_on_advance. The final source strips one guard
NOP with always_pop. Intermediate target junctions turn into their receiving
row, then ADV to strip transit. Pin all pop modes in the manifest; reject
pop_on_advance_nop on pass nodes because it would strip the guard prematurely.

The final target is different: **keep it pointing into its receiving row**.
After the last row's payload, send ROW_DONE then STREAM_END on the same payload
OQ, with no final TARGET_ADV or GRANT. All PEs in that row receive the sentinel;
the last-column PE starts the row ACK chain, and every other column joins only
after its own terminal and consumer conditions hold. This avoids
an out-of-group terminal colliding with a neighbor's source switch. For example,
G1 U16 ends inside its A1 last receiving row y258, never at G0 source y257.
Apply the same endpoint rule to U/D/B/T and to a fenced H fragment epoch.
This change from the measured prototype must be tested, not called measured.

Non-final source tails are unambiguous: if its fragment does not complete a
receiver row, send GRANT only; if it completes a non-final row, send ROW_DONE,
TARGET_ADV, then GRANT. Target boundaries within a source (H/T) require a
TARGET_ADV without granting a different source. Preserve the verified guard
encodings for disjoint zones. Derive half order from logical ownership, not direction alone: left local U and
right local D write offsets16/0; left inter-group D, right inter-group U, and B
write offsets0/16. Mirroring changes the relation between physical direction
and feature order.

Recommended R/S structure retains a **single completion/reset pass plus a
source-only START tree**, rather than inventing a second release pass:

1. A1 uses per-frame activations, not the current monolithic while loop. Once
   count and ROW_DONE are satisfied it latches `frame_ready` and may compute.
   All source grants are already generated on the payload stream and do not
   depend on this computation. After its old X consumers finish, it arms the
   next selected receive and becomes eligible to forward a completion word.
   Clearing transport counters must never clear a still-live frame_ready latch
   or overwrite the corresponding X buffer.
2. In parallel, each A1 row aggregates acknowledgments east-to-west across
   **every receiver PE**, on alternating C18/C19. The last-column PE starts
   only after its local conditions; each other PE waits for both the incoming
   word and its own conditions, then forwards on its non-QKV OQ. The strip
   receives the row result on C19. An A3 column-0 source reports its completed
   payload/marker sequence on C19 using OQ0. Other A3 columns do not send data
   completion acknowledgments but can relay request CONFIG records.
3. Strip nodes merge their local row/source acknowledgment with a vertical
   completion token using C18/C23. IQ0=C19 is the row input; IQ1 is the vertical
   input; OQ0 is the other vertical color. This explicitly spends **three R
   colors**: a static CE node receiving from EAST and a vertical direction and
   injecting onward cannot assume the same two colors cover all three routes.
   Only active-edge participants gate progress; never wait for output from an
   inactive future layer/group. Restore each source/target switch only after
   that node’s relevant row/source acknowledgment and terminal condition.
4. A concrete first-group topology is 80 parallel A1 row chains plus 160 A3 source acknowledgments into WEST, a
   northbound WEST control chain, then router-only return down the group's
   column-0 compute band on C23. On an even 256-row strip, arrange alternating
   C18/C23 so the top node emits C23 and the bottom root receives C23. C23
   return does not enter compute CEs or overlap their row C18/C19 routes.
   Before a non-bootstrap reset scan, the top row ACK sends an even terminal
   notification down that existing router-only C23 return to the bottom root.
   Only this notification starts the reset scan; its odd return permits START.
   This prevents resetting source switches before STREAM_END has passed them,
   and needs no additional color or CE scan.
   Source and target acknowledgments remain separate per-epoch bits. A3 output sends are asynchronous, so a blocked fabric output cannot monopolize the CE needed by control callbacks. This
   needs roughly 128 row-chain steps plus 256 strip steps, not a 30,720-compute-
   PE serial snake; plus roughly 256 router-only return hops and the START tree. These are analytical dependency lengths, not latency data.
5. After all required rows/sources and the final in-row sentinel are accounted
   for and switches restored, the root broadcasts START15 to **A3 IQ2 only**.
   A3 may calculate its next result earlier but sends only when both result_ready
   and the matching source credit hold. START does not gate A1's collective or
   A3's FFN computation. An initialization credit follows a separate all-armed
   bootstrap condition, since no previous frame exists to acknowledge yet.

The first-group U/R/START return and source-only tree are now compiled and
verified on CS-3; see the
[first-group implementation report](/home/lexu/wse3-performance-model/docs/reports/2026-09-13-layoutC-first-group-feedback.md). Full-model control composition still needs explicit root
placement, active-edge masks, and joins between columns for B/T; §8 requires
that manifest before connecting them. The initial correctness target admits
**one model token/request context at a time**. Do not substitute an unproved
“number of tokens less than number of groups” rule or claim multi-request
pipeline credit safety from this plan.

Keep R tasks nonblocking when a local predicate is missing. Replace both tall
while loops with per-frame scheduling; a function called once per frame may
still perform its synchronous arithmetic/collectives. A pending R callback may
be delayed by that computation, but no input grant or prerequisite for that
same computation may wait for the callback. A3 computes before waiting for
source credit. The linked report establishes synthetic first-group verification
(two/five layers, multiple tokens); it does not establish full-model closure.

Safe-boundary requirements (implementation predicates, not measured results):

| Operation | Required closure |
|---|---|
| Alternative only: one A3 payload OQ changes color | Old send and all marker instructions issued; output-empty callback after queue flush; no active DSD; change binding, exit flush, then admit next send. Destination completion is separately required before route/buffer reuse. |
| A2 IQ0 K→QKV | All per-layer KV and metadata committed, exact expected count and terminal marker consumed, K producer closed and unable to enqueue again, no active receive; restore all IQ0 bindings before any A1 is released. OQ flush alone cannot establish this. |
| A2 existing IQ/OQ3 switch | Preserve counted input drain and `next_stage` output-empty callback. Keep vertical binding between Z[t] and X[t+1], because early next X may already be queued. |
| A1 computation starts | Selected input has all 32 f16 elements at correct offsets and ROW_DONE; frame_ready latched and buffer acquired. Its source grants are independent. R completion waits for that frame’s local consumers, and gates only future source transmission, not the current collective. |
| Same physical color route changes | Every producer disabled, receiver/marker counts complete, terminal observed and required fanout acknowledgments complete; then repaint/restore and explicitly reopen. Prefer fixed U/D to avoid this. |
| Tail OQ0 temporarily becomes control | Full header/record/timestamps/padding emitted and flushed; no next record admitted; restore record binding before reopening. Never use “sampling finished” as the drain predicate. |
| New request / STOP | Finish old token/record accounting, close future producers, drain all live transports, rearm KV and switches, initialize new banks/positions, and acknowledge READY before next request data. No legacy STOP functionality may silently disappear. |

[Existing queue transition](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:96),
[early-X restriction](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:213),
[SDK control-table selection](/home/lexu/CSL-Demo-Code/versions/v2.10/Cerebras_Docs/csl/language/builtins.md:2573),
[SDK async on-control](/home/lexu/CSL-Demo-Code/versions/v2.10/Cerebras_Docs/csl/language/dsds.md:1489).
The SDK data/control distinction is in the wavelet/DSD; `ctrl_table_id` does not
allocate a second input queue for the same color.

## 6. Nonuniform boundaries: implementation choices, not omitted links

For source interval `[a,b)` and destination `[c,d)`, transmit the intersection
`[max(a,c),min(b,d))` if nonempty, into destination offset `max(a,c)-c`.
Generate this table from global hidden indices; all lengths below are even f16
counts. Keep one selected source PE per source row and multicast at destination.

| Boundary | Example fragments for one destination | Exact full-vector fragmentation |
|---|---|---|
| A3→A1 16→32 | X[0:16] then X[16:32], or reversed with offsets16/0 | 160 fragments; each destination has two |
| Head→A1 10→32 | row0 receives [0:10], [10:20], [20:30], [30:32]; row1 starts with source-row3's [32:40] | 320 nonempty intersections; target row has 4 contributions |
| A3→Tail 16→10 | Tail row1 [10:20] receives [10:16] and [16:20] | 384 nonempty intersections; target row has 1 or 2 contributions |

Do not equate these fragments with that many mandatory separate CE instructions:
coalesce adjacent sends/receives where marker and destination boundaries permit.
Target count is derived from the interval table, not a hard-coded assumption of
two sources at every boundary.

H has overlapping source and target y zones on WEST. T has a reversed corridor
and unequal fragment lengths. The disjoint-source-zone guard proof in §5 does
not cover either. The resource alternatives to implement are:

1. **T12: router switch schedule from the interval table**, destination
   fragments placed directly in Tail input buffers. Its zones are disjoint.
   **H6 continuous overlapping-zone streaming is not selected**: the existing
   guard/pop protocol has no demonstrated way to distinguish target advances
   from future source grants in the shared junctions. Merely generating a
   table does not fix that constraint.
   Generate the complete per-junction state/command trace. A T source may span
   three Tail rows: validate mid-source TARGET_ADV without GRANT, the guard
   consumption sites, and all Tail fragment offsets. This is an extension of
   the measured two-half test, not an already-tested T implementation.
2. **Selected initial H implementation: separately fenced fragment routing
   epochs on H6**. Reconfigure only source/target router endpoints via a
   control network, forward payload entirely in routers, and acknowledge the
   fragment before changing its path. For each interval: close Head credit;
   use H_REQ14 to ask the root for a strip-only H_ROUTE pass on R (never the
   compute CONFIG bus while a row may be in a collective); configure all transited C6 nodes (WEST input at the Head source row, SOUTH
   transit northward, EAST output at the A1 target, or WEST→EAST for a same-row
   transfer); root returns ROUTE_READY on H_RESP11. The service sends a credit
   request on Tail C19; Tail's sole C7 producers issue the source credit.
   Head sends a single-NOP FRAG_DESCRIPTOR control wavelet containing destination
   offset/length (within the SDK's 16-bit argument) before f16 data and FRAG_DONE,
   all on H6/OQ2. The descriptor handler arms the fragment DSD; handlers/buffer
   ownership are prepared before credit. Data may queue behind the descriptor.
   All static C6 routes use no_pop in this mode. Receive n elements, consume
   FRAG_DONE and collect every target PE's FRAGMENT_RECEIVED acknowledgment,
   then change the next path. No GRANT/TARGET_ADV source-switch protocol is
   used inside this single-source fenced fragment epoch. Pure transit PEs
   never receive payload in their CE. The Head diagonal sender is preserved:
   local column = row/2 + x_offset, not the boundary column.
   H keeps separate fragment and frame state: acknowledge FRAGMENT_RECEIVED
   **before** entering the row's collective; preserve accumulated X and frame
   counts across fragments; start arithmetic only after all 32 elements exist.
   Receipt ACK does not make X reusable for a future frame; FRAME_REUSABLE
   additionally requires its consumers to finish. Otherwise the next H fragment
   could wait for an ACK held behind a collective that needs that fragment.
   H_WAIT on R selects only the current target row; other computing rows cannot
   hold that token. Withhold first-feedback START15 until H closes and the next
   receives/ownership are ready, keeping H control and activation R phases apart.
   The endpoint-control task/credit trace remains the H microtest gate. No full-vector CE collector
   is added. Independent source preparation remains parallel; this fallback
   serializes fragment admission and must be priced before performance acceptance.
   This is a correctness fallback with potentially substantial control/RAMP
   serialization; it is not the desired final performance implementation.
3. An optimization candidate is an additional 10→32 redistribution inside Head
   after its existing embedding gather, using the already-owned UP/DOWN queues
   in a proven nonoverlapping phase. H then consists of aligned eastward rows.
   This preserves embedding arithmetic but adds movement, selected-PE buffer
   capacity and phase fences; it is not the selected initial implementation.
4. A second strip lane or a north-corridor CE payload staging converter changes
   geometry/SRAM or the agreed router-only strip behavior. Neither is silently
   included. The first review’s suggested 800-feature corridor relay is rejected
   for the present scope.

The first executable work remains U/D f16 group feedback. H/T have reserved
resources and concrete algorithm alternatives, but the H endpoint-control trace and T marker trace
are implementation gates before their own integration, not a
blocker to the first group-only patch.

B uses a single C5 path, south on WEST, east below G3, north on CENTER to G4.
G3's increasing logical source rows arrive at G4's increasing logical A1 rows
under the mirrored mapping. For example logical features0:32 from G3 A3 rows0/1
end at G4 A1 physical y1025. Verify every index, not merely this example, and
place its final-source guard before destination junctions along path order.

## 7. KV, external components and request control

K is a bootstrap/rearm phase for the initial target; it is not concurrent KV
refill during decode. Preserve separate K/V values per column, position and
layer. Feed group metadata for 5 or 4 local banks, convert to A2's 128x256
ownership, initialize prefill cursors, then release QKV ingress. Capacity and
SRAM feasibility must be checked from linked images; no 8192-context guarantee
is made by this routing plan.

Preferred physical placement: injector columns on CENTER (left A2) and EAST
(right A2). Reserve a left adaptor at service PE (130,515): C20 goes EAST to
(131,515), NORTH along WEST to y0, EAST along y0 to x388, then SOUTH on CENTER.
Reserve a right adaptor at auxiliary/north-corridor PE (646,1), emitting WEST
then SOUTH on EAST x645. These are proposed concrete endpoints; SDK host-port
assignment and service SRAM remain gates. WEST therefore also claims K-feed
C20, not only activation colors. K21 traverses A2 westward, never A1/A3.

A2 C21 column switches need a reset distinct from injector C20 reset:

- Pack all supported local banks/positions for a column before advancing to the
  next column; append a final marker to the last column (A2 column0). No new K
  frame can be admitted until reset/READY completes.
- After column0 observes the ordered row tail, it clears its own C21 switch and
  sends exactly one u32 RESET_K word on its existing C16 OQ2. Every other column
  consumes exactly one word on IQ2, clears C21 and latches reset_k_seen.
  This handler does not independently restore IQ0.
  This word precedes all ordinary f16 X-row frames and has a distinct DSD/count.
- Each PE forwards ACK only when **own K stores complete AND RESET_K consumed
  (or locally performed at column0) AND C21 cleared AND upstream ACK consumed
  (vacuously true at column0)**. Under this single predicate it restores
  IQ0=C8/9 and IQ1=C11 before forwarding ACK. A row ACK traverses column0→127 on bootstrap C5/C7 using IQ1
  and OQ0; the final hop is C7 to injector IQ5. Each forwarding PE subsequently
  flushes OQ0, restores C14 and only then enables its local compute task. QKV
  can queue on the already-restored IQ0 but cannot bypass this local gate.
- The injector/controller waits for all row ACKs before declaring K ingress
  complete. Feeder C20 reset uses C22 as a separate step. Its left return goes from
  CENTER north to (388,1), west to (131,1), south to (131,515), then west to
  adaptor (130,515) IQ3. Its right return goes north on EAST to (645,1), then
  east to adaptor (646,1) IQ3. All intervening turns/transit are C22 claims.
- In the closed K_REARM phase, reuse each injector group's R vertical C18/C23
  chain for acknowledgment, gated on its local C22 reset handler having cleared
  C20 and its A2 row ACK having completed. Reserve that pair on EAST as well as
  CENTER; EAST's router-only return is in auxiliary column646. Wait for the
  full control round-trip before the group-bottom root emits K_READY on OQ2/C13.
  Four group-root C13 source switches gather upstream-first on each feeder
  column. C13 returns via the same left/right geometric corridors as C22 but
  into adaptor IQ6; source roots use pop_on_advance and the final source sends
  no trailing GRANT. Initial C13 positions are prepared before any K_READY can
  be emitted. This phase is disjoint from activation R traffic.
- Request READY requires the adaptor closed, C22 return received, and all four
  matching K_READY records on each side. The request controller joins both
  sides before decoder admission; per-request host orchestration is allowed,
  but no host round-trip is inserted per layer/token. An injector send-completion
  callback alone is not a global KV-write acknowledgment.

This bootstrap ACK/reset design is new and needs its own counted microtest;
A2 is still excluded from steady-state R. It uses no collective queue and no
additional payload buffer on strip PEs. Next-request rearm repeats the closed
bootstrap phase after all old decode/record traffic is drained.

Request metadata has an explicit logical transport choice: **typed CONFIG
records on the control plane**, never an unaccounted extra word in the f16
activation stream. Carry request epoch, prefill length, decode budget and flags
as a fixed multi-word u32 record. Do not assume all fields fit in one word.
A1/A3 CONFIG enters the rightmost-column C19 control bus, then propagates west
on the C18/C19 row chains to each compute PE and the strip. The same row paths
are ACK-only after configuration; phase and record length distinguish the two.
No bootstrap CONFIG is allowed during live ACK traffic. A2 gets matching fields
through K metadata and validates them against the request descriptor. Tail
reserves IQ7=C19 for CONFIG and controller credit requests. **Only existing
Tail token-emission PEs inject C7**, using their OQ7 for both ordinary token
wavelets and control-wavelet CONFIG/CREDIT messages. Head therefore has one
ordered producer per column, including forced mode and the first frame.
On C7, encode CONFIG fields as a fixed sequence of single-NOP control wavelets
with 16-bit arguments; split wider fields across messages. Do not copy an
unrestricted u32 R record into a control-wavelet payload or count it as a token.
C7 routes retain no_pop. The SDK encoder supports this argument width:
[control encoder](/home/lexu/CSL-Demo-Code/versions/v2.10/source-code/csl_libraries/control.csl:52).
Tail's credit service must remain runnable while waiting for Z: post an async
Z receive and return to dispatch, rather than blocking a main task on data whose
production requires that credit. Head's bootstrap handlers run before any
blocking preembed wait; forced-token generation also obeys source credit.
Preserve RoPE prefill position initialization in A1. Replace Tail’s old IQ0
step-budget header receive with the CONFIG state, including its forwarding to
mux; do not leave it waiting for a header G7 never emits.

The complete controller and front-end route manifest must instantiate the CONFIG
bus roots and Tail multicast reserved in §3, their acknowledgment predicates, and C7 source-credit injection
(including forced mode and first-token admission), and mux length-header source.
Their endpoint queues/colors are reserved here; their complete readiness trace
is **not closed**. This is an explicit external-integration dependency, not an
implied existing feature. Head operator output remains its existing diagonal
sender and gather implementation:
[Head ownership/paint](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/ht_head.csl:281).

Pin Tail's currently automatic logits/xready IDs to the proposed local C18/C6
only after checking the corresponding generated routes. Maintain embedding,
final norm, lm_head, top-K/sampling, token return, forced-token debug mode,
host records, length header, STOP, and next-request readiness. These are all
external integration tasks; none is covered by a single-layer tall test.

Scheduling invariant: a token retains its position while traversing every local
and global layer. Update the layer bank on each layer transition; advance token
position only after Tail completes that model token. Different layers must use
distinct weights and KV banks. Current tall sets layer0 in both A1/A3 and reads
host-preloaded per-tick input; it is not yet this scheduler:
[A1 loop](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:175),
[A3 loop](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:222).

## 8. Implementation sequence and falsifiable acceptance

1. Produce a complete parameter/route/task manifest for the first group (including SDK loader reservations; the old memcpy harness owns IQ0/1 and cannot host this allocation unchanged): every
   `(PE,color,phase)` route, IQ/OQ binding, switch positions, control entrypoints,
   local task aliases, and producer closure. Fail on double claims, unsupported
   switch colors, queue aliases, or routes spilling into A2 C16. Negative controls:
   deliberately claim R on collective IQ3 and insert a conflicting CENTER K16;
   checker must reject both. No successful source grep counts as a compile pass.
2. Adapt the isolated protocol to packed f16, proposed noncollective queues,
   in-row termination, single-pass R and source-only START15. Distinct source-row/feature/epoch signatures; every destination column must match its row reference. Test both directions, 2→1 rows and
   repeated epochs. Withhold ROW_DONE, delay an interior receiver, and delay the last receiver:
   release must remain closed. Duplicate/drop/alter a fragment must fail.
3. Integrate real A1/A2/A3 computation for two different layers, then a complete
   five-layer group. Preserve upstream operators. Compare stage outputs with
   the agreed operation-order-aware baseline, test KV prefill unchanged and
   append positions, multiple tokens, and rearm. Remove temporary probes.
4. Only after the complete-group gate: mirror the group; connect two groups,
   then B bottom turn, all eight groups. Validate all 36 layer IDs exactly once.
5. Complete H/T command traces and microtests, KV packing/rearm and all external
   port manifests. Integrate Head/Tail/mux/token loop and multiple requests.
   Include STOP/empty-or-minimum supported prefill/maximum supported decode
   boundaries, shuffled columns, withheld last receiver and corrupted records.
6. After full-model correctness, measure end-to-end latency/throughput and
   optimize reset and fragment scheduling. Count reset CE hops and route-control
   stalls separately. No performance threshold is invented for this plan.

## 9. Review and evidence status

Claude Code read-only review is requested against this document and cited source.
Required review questions: detect actual resource collisions; distinguish usable
first-group choices from unresolved full-model edges; inspect R release ordering,
H overlap, T/B direction, A2 KV bootstrap and Head/Tail queue pressure; identify
anything incompatible with the user's decisions. Do not change code.

The accompanying review report preserves both reviews and the disposition.
In particular, do not adopt the bounded review’s claim that the last-column
receiver alone proves every CE consumed its input, its omission of straight
exit colors from G0–G2/G4–G6, or its unproved token-credit bound. No claim of whole-wafer compiler approval, hardware validation, or complete
protocol closure is made by this plan.

Source workspace HEAD at audit: `38ac5b7a7d999689fe472c766e233fe545502c95`.
Much of the relevant demo is untracked, so source hashes in the preceding regional
audit and a live no-code-change comparison are needed in addition to HEAD.
SDK evidence checkout: `/home/lexu/CSL-Demo-Code`,
`aecfdd0942bb5003b7ab4f583fdd0db60771dfcc`, SDK v2.10 documentation.

## 10. First-group implementation checkpoint — 2026-09-13

Sections 8.1–8.3 now have first-group implementation and measured evidence in
[the report](/home/lexu/wse3-performance-model/docs/reports/2026-09-13-layoutC-first-group-feedback.md):
full 128/80/256/160 geometry, five independent synthetic banks, exact normal
outputs, full-cache/cursor checks using a disposable probe, negative controls,
and a Claude Code follow-up with no remaining blocking findings. The report
separates normal outputs from the cache probe's final flag frame.

Implementation uses all-column row0 STREAM_END acknowledgment and a terminal
notification on the existing C23 router return before the single reset scan.
Full-size compute subgroups are capped16, following the prior successful
operation-order baseline; operators remain unchanged. Maintained kernels have
no diagnostic/cache probe exports. Bounded runners surface protocol faults as
timeouts without per-PE fault identification.

Section 8.4 (mirrored compute group/two groups/bottom turn) is next. The prior
whole-wafer allocation options and unresolved Head/Tail/KV/control boundaries
remain proposals. No all-model, multi-request, or performance gate is closed.
