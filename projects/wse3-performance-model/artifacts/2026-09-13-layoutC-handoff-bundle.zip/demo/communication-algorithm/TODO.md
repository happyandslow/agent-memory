# Communication methodology — TODO

Updated: 2026-09-13. This is the shared queue for pending work, deferred work,
and decisions still requiring evidence or discussion. [PLAN.md](PLAN.md)
owns step definitions/dependencies; step trackers own execution evidence.
The existing LayoutC backlog and source references are preserved below.
Listing an item here does not authorize implementation or hardware runs.

## Active pending work

- [ ] CP-03: review the concrete [matching design](steps/step-03/MATCHING-DESIGN.md)
  and close the design gate in [its tracker](steps/step-03/TRACKING.md).
  API, bindings, budget accounting, rejection examples and emission gates are
  written; matching and emission remain unimplemented.
- [ ] CP-04: extract one gather implementation into a configurable CSL template,
  connect matching/configuration/emission, then develop a performance model
  for that concrete template. Add the second template/model to compare tradeoffs.
- [ ] CP-05: validate exposed constraints and generated behavior independently,
  including exact counts, handoffs, and completion of one invocation. Repeated
  invocation/reload design is deferred below, not a current acceptance gate.
- [ ] CP-06: package generation with consistent build/host configuration and
  source/configuration manifests in isolated derived-output directories.
- [ ] CP-07: enumerate registered templates and return all applicable candidates
  with bindings, rejection reasons, validation state and generation entry points.
- [ ] CP-08: add comparable costs and broaden algorithm coverage, including the
  application cases below. Do not claim global optimality from a finite catalog.

Use the corresponding [plan steps](PLAN.md#minimal-plan) for detailed gates.
CP-01/CP-02 are complete for the bounded draft; no full IR dependency is added.

## Pending decisions and evidence

- [x] CP-03: write the concrete API/configuration proposal in the matching
  design: `match(scenario, budget)` returns a candidate or rejection;
  `emit(candidate, target, output_dir)` returns a generated-file manifest.
  Uniform per-PE color/IQ/OQ caps filter candidates; target IDs and SDK
  reservations are separately checked before emission. Design review is pending.
- [ ] CP-03/CP-05: pin SDK/compiler identity and verify required switch/filter/
  queue capabilities and reservations before claiming executable support.
- [ ] CP-04/CP-05: establish completion and final control termination for
  sweep; test the proposed suppression of the final sender's handoff token,
  and make excess payload observable beyond output-array equality. Include
  every added resource in its configuration/claim. Repeated
  invocation/reset work is deferred separately below.
- [ ] CP-05: determine which template conditions can be checked statically and
  which require bounded simulator/device evidence. Generic progress analysis
  is not a prerequisite; document the limits of empirical coverage.
- [ ] CP-08A: establish comparable CE relay, completion-task, control-injection,
  receipt, setup and reset costs. Timing constants are not available yet.
- [ ] CP-08B: after the selected shift example, choose the next many-to-many or
  2-D case using concrete abstraction/coverage gaps, including LayoutC below.

## CP-03 design discussion

- [x] T1 — Le chose a standalone demo first (2026-09-11): layout, PE programs,
  host oracle, and build instructions. See the CP-03 tracker for the decision.

T2 (model-provision mechanism) was moved out of the current discussion after
Le clarified the sequence: matching first, concrete template second, its
performance model third. No decision between authored formulas and automatic
analysis has been made; model questions must not block matching design.

- [x] T3 — Le confirmed optional resource budgets (2026-09-12). With a budget,
  apply resource filters. Without one, assume sufficient resources and return
  all matches. Mapping/order and template-domain checks still apply; assumed
  availability is not measured target feasibility.
- [x] T4 — Le deferred the generic solver (2026-09-12): start with reusable
  scenario-family matching functions, with shared gather matching followed by
  sweep/relay-specific checks. Keep the first implementation simple.
- [x] Le chose demo 02 sweep first, then demo 04 relay (2026-09-12).
- [x] Le limited initial optional budgets to colors and queues (2026-09-12).
  Task and memory budgets are deferred. Proposed accounting distinguishes
  input and output queues per PE; other implementation legality checks remain.
- [x] Le asked to defer reload/repeated-invocation discussion (2026-09-12).
  A router-only turn toward a diagonal destination does not itself split a
  transfer into two communications. This clarification does not add diagonal
  routing to the first template's supported geometry.
- [x] Le defined one communication end to end (2026-09-12): source RAMP
  transmission through receipt of all required data at all designated target
  PE RAMPs. Router turns and intermediate CE forwarding do not split it into
  multiple communications. Payload arrival is distinct from SRAM writes,
  subsequent computation, and control/reset completion; no reload discussion
  is required to define this boundary. See the CP-03 tracker for SDK/source
  clarification of streaming relay and its resource use.

Only ask subsequent interface questions when needed by a concrete choice/example.
Confirmed answers and validation evidence belong in the
[CP-03 tracker](steps/step-03/TRACKING.md); open questions stay here.

### Deferred: first-template domain extensions

The [initial matching design](steps/step-03/MATCHING-DESIGN.md) explicitly rejects
valid descriptors outside its small gather subset. Add support when a concrete
use case requires it; these are not CP-03 blockers:

- [ ] Offset/strided buffers, replicas, equivalent split copy/output records,
  and one-sender cases; avoid automatic coalescing or source selection for now.
- [ ] Nonadjacent collectors (distance L), reverse direction, and 2-D placement.
- [ ] Generalize relay collector color binding to odd N and verify it; the
  first source-preserving domain retains the current even-N restriction.
- [ ] Per-PE budget overrides or consumer-delivery callbacks if an application
  needs them. Initial budgets are uniform caps; arrival/visibility order suffice
  for the standalone gather demos.

## Deferred: revisit model CE relays and K-pipe router bypass

Requested by Le on 2026-09-13. Evidence is the
[WaferEngine CE relay audit](steps/step-03/WAFERENGINE-CE-RELAY-AUDIT.md),
pinned to WaferAGI/WaferEngine main at
`6708757641492c6e887e2889e5a51e7f249f79d4`. Recheck the revision when resuming.
This work does not block the current sweep-first template path and does not
authorize model changes or hardware runs now.

- [ ] Investigate replacing K-pipe's opaque prefix/suffix CE forwarding with
  router transit and control-wavelet handoffs. Preserve the required data map,
  ordering, local-share handling, STOP propagation, readiness dependencies,
  and completion behavior. Audit the whole protocol rather than deleting a
  move instruction. Compare color/queue requirements and latency only after
  a concrete replacement passes independent correctness checks; no improvement
  is established by the existing source audit.
- [ ] Revisit the other audited model families: HT_head/X-chain forwarding,
  KV ingress adaptor/egress colmux, numerical reductions, and buffered role
  shuttles. Separate CE work required for arithmetic, local data, or header
  interpretation from unchanged payload transit. Header parsing may determine
  how much data follows and when a switch can advance: retain that dependency,
  or explicitly replace the framing/control mechanism before bypassing CE.
  Do not infer that all payload must pass through CE merely because its header
  does. Use the audit's pinned implementation sites as the starting evidence.

## Deferred: repeated invocation and reload

- [ ] Revisit rearming routes/counters and validating two different-data
  invocations without reloading. Le requested leaving this discussion aside
  on 2026-09-12. It is separate from counting route turns or CE transfer
  boundaries, and is not a prerequisite for the initial template path.
  Preserve the original one-shot demo identities and do not claim repeatability
  from single-invocation evidence. Completion and final control termination
  for the invocation being generated remain required.

## After the first template: performance modeling

- [ ] Once a demo-derived template exists, identify its performance elements
  and dependencies, then build its model for comparing the same communication
  requirement across algorithms. Do not choose formulas from hypothetical code.
- [ ] Revisit T2's model-provision mechanism against that concrete template;
  the earlier manual-formula versus automatic-analysis question was premature.
- [ ] Define comparison metrics, timing boundaries, unknown parameters, and
  validation/calibration evidence. Keep analytical counts, predictions, and
  measurements distinct. First-template modeling need not wait for the entire
  registry or calibrated ranking infrastructure.

## Deferred: generic parameterized-mapping solver

- [ ] Revisit templates declaring parameterized mappings and a generic solver
  discovering matching bindings automatically. Le requested deferral on
  2026-09-12. This is not a prerequisite for matching, template extraction, or
  performance modeling. First use explicit reusable match functions; revisit
  only when concrete supported cases expose costly duplication or limitations.

## Deferred: IR to cost

- [ ] Generalize from IR to cost only after concrete templates/models establish
  the relevant performance elements and their dependencies. Dependencies are
  both that understanding and an IR representation capable of expressing it.
  Determine composition/overlap rules and validation against concrete models
  before claiming generic cost generation. This is not a prerequisite of
  descriptor matching, demo-derived templates, or their first performance models.

## Deferred: full Protocol IR

- [ ] Revisit a complete Protocol IR only when a concrete task needs structural
  protocol synthesis, route/task transformations, protocol composition, or
  analysis shared across algorithms. **Deferred; not on the critical path**
  of descriptor → template matching → configuration → direct CSL generation.

Decision (2026-09-11): Le requested moving IR out of the active path if it is
not required by template selection. Future templates can retain their own
routes, per-PE setup, task activation and control/reset code. Parameter bindings
and applicability checks suffice for selection and emission. Neither the
Python template configuration nor the existing scenario representation implies
building a new full protocol language.

Scope retained from the old CP-03 plan, for a future separately scoped task:

- Represent logical channels and paths, per-phase routes, switches/filters,
  queues/DSDs, CE local/data/control tasks, router control effects, and internal
  setup/completion/drain/reset/release events. Keep caller entry conditions
  separate from generated protocol actions.
- Separate symbolic channels/tasks from physical resource allocation.
- If pursued, use source-faithful sweep/relay reference encodings and require
  traceability for every route/operation/activation. Preserve the distinctions
  `payload_complete → send_token` and `relay_complete → inject`. Do not invent
  absent completion/reset behavior or claim repeatability from an encoding.
- Possible artifacts are `compiler/ir.py`, `PROTOCOL-IR.md`, and
  `protocols/reference/`; these are deferred proposals, not current deliverables.

Trigger to reconsider: show a concrete operation needed by a supported case
that cannot reasonably remain within template matching/configuration/source.
No decision to build IR, universal optimizer, or generic proof engine is pending
as a blocker for CP-03 through CP-08.

## LayoutC communication scenarios awaiting generalization

Date: 2026-09-10. Status: captured application cases; descriptor integration,
generic protocol extraction, and comparative evaluation are pending.

These are three composed application cases, not three new semantic primitives.
Keep the required values/placement separate from the current route algorithm,
following [CONTRACTS.md](scenarios/CONTRACTS.md). Do not infer an optimal
algorithm or measured hardware cost from these source-derived examples.

### Common setting

One southbound block, block-local coordinates (no launcher origin offset):
A1 `(x=0..127, y=0..79)`; A2 `(x=128..255, y=0..255)`;
A3 `(x=0..127, y=96..255)`; left-side rows 80..95 are spare.
Hidden size D=2560, with 32/10/16 hidden elements per A1/A2/A3 row.
Ranges are half-open. Arrow hues in the figures identify data provenance;
fabric IDs are explicitly labeled C8, C9, etc.

### 1. QKV: select a column replica, translate, then multicast

**Precondition:** QKV computation is complete. Before that boundary, each A1
row contributes a partial dot-product from its hidden slice. The Y all-reduce
sums these contributions and broadcasts the result within the A1 column;
QK normalization and RoPE then prepare the handoff value. Do not concatenate
80 partial vectors or treat their replicas as independent inputs.

**Value contract:** for each column c, one logical S[c] contains 32 Q, 8 K and
8 V elements. A1 has ready row replicas; every A2 PE `(128+c, y)` needs S[c]
for all y in 0..255. Different columns retain distinct logical identities.

**Current algorithm:** select A1 `(c, c mod 80)`; route east to A2
`(128+c, c mod 80)` using C8 for c<80 or C9 otherwise. The receiver stores
S[c] and injects C11 north/south multicast within its column. A y=0 receiver
only sends south. There are 128 inter-region QKV injectors: one per column.
Rows 0..47 carry two distinct sources; rows 48..79 carry one.

**Candidate semantic decomposition:** replica selection + location-preserving
copy + replication. The preceding arithmetic reduction is a separate stage.

Sources: [A1 reduction and transforms](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1843),
[reduction and result broadcast](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/comm_lib/comm_pe.csl:1365),
[sender and receiver schedule](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:179).
Figure: [editable source](../../docs/diagrams/2026-09-10-layoutC-travel-qkv.excalidraw),
[preview](../../docs/diagrams/2026-09-10-layoutC-travel-qkv.png).

### 2. X: redistribute row slices, then multicast east

**Value contract:** source A1 `(127,r)` provides X[32r:32r+32).
For every feature i and every A2 local column c, destination
`(128+c, floor(i/10))` stores X[i] at local offset i mod 10.
Other A1 replicas of the same X row are alternative residences, not extra
contributions. The transferred X is the residual input, not normalized X.

**Current algorithm:** C10 sends the 32-element source slice east into A2
`(128,r)`. A2's west edge forwards two-element atoms south on alternating
C12/C13, retaining each destination row's ten elements. It then sends one
assembled ten-element C16 multicast east across that A2 row.

**Split/join example:** X[0:32) splits across A2 rows 0..3. Row 3 assembles
X[30:32) from source row 0 and X[32:40) from source row 1: 2+8 elements.
This is placement/concatenation, not numerical addition.

**Candidate semantic decomposition:** element copy/resharding + replication;
ordered streaming and alternating colors belong to the protocol candidate.

Sources: [X redistribution](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:118),
[edge and row routes](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:212).
Figure: [editable source](../../docs/diagrams/2026-09-10-layoutC-travel-x.excalidraw),
[preview](../../docs/diagrams/2026-09-10-layoutC-travel-x.png).

### 3. Z: redistribute to displaced rows, then multicast west

**Precondition:** A2 has completed attention/output projection and residual
addition; its west-edge row s provides Z[10s:10s+10).

**Value contract:** for every feature i and every A3 column c, destination
`(c, 96+floor(i/16))` stores Z[i] at local offset i mod 16.

**Current algorithm:** stream south along A2 local column 0 using C12/C13.
At physical row 96+t, assemble Z[16t:16t+16) and send one C14 multicast west
across A3 row t. The vertical path stays in A2 beside the left-side gap.

**Split/join example:** source row 1's Z[10:20) splits: Z[10:16) exits west
at y=96 after joining Z[0:10); Z[16:20) continues to y=97 and joins
Z[20:30) plus Z[30:32). Again, concatenate by offset; no arithmetic reduction.

**Candidate semantic decomposition:** element copy/resharding + replication
with a displaced destination origin. X and Z may share an abstraction;
their physical direction and endpoint geometry remain explicit parameters.

Sources: [Z redistribution](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:137),
[westbound routes](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/launch_tall.py:234).
Figure: [editable source](../../docs/diagrams/2026-09-10-layoutC-travel-z.excalidraw),
[preview](../../docs/diagrams/2026-09-10-layoutC-travel-z.png).

### 4. A3 -> A1: ordered source sweep, router transit, row assembly

Date: 2026-09-12. Le requested retaining this application pattern for later
performance/resource comparison. The current discussion uses upstream-first
source handoff; this is not an optimality or completed-protocol claim.

**Value contract:** A3 column-0 sources at y=96+2r and y=97+2r provide the two
16-element halves of a 32-element A1 row. Target y=r is same-group feedback;
target y=256+r is the straight next-group connection. All 128 destination
columns receive the row shard. Northward source order is 255..96 (write odd
half then even half at offsets 16 then 0); southward order is 96..255 (offsets
0 then 16). Preserve feature placement and operator behavior.

**Separate responsibilities:**

- Source compute PE: prepare and issue its horizontal payload, then append an
  ordered end-of-burst control marker after payload completion.
- Source-side strip junction: first pass upstream traffic, then select this
  row's EAST input when the handoff marker advances its switch. North routes
  SOUTH->NORTH then EAST->NORTH; south routes NORTH->SOUTH then EAST->SOUTH.
- Transit strip PE: router-only cardinal-port forwarding; no CE payload relay.
- Destination-side strip junction: select which stream segment turns toward
  A1. This is a receiver-selection role, not local payload injection. Exact
  target-marker delivery and reset now have an isolated executable protocol
  (see the verification note below); integration into tall is still pending.
- Destination compute PE: receive both halves into fixed offsets, recognize
  local input completion for the same token/layer, then perform local work.

**Le's performance comparison criteria (hypotheses to measure, not calibrated
constants):** small messages may be dominated by CE<->router/RAMP initiation
and receipt costs; larger messages may be dominated by link bandwidth. Prefer
overlapping independent PEs' CE-to-router injection and router-to-CE receipt,
avoiding unnecessary sequential endpoint transfers, while keeping shared
links occupied. Pre-arming asynchronous DSDs alone is not proof that the RAMP
transfers overlap: a closed route can leave the payload waiting on backpressure.
No sender-order ranking or universal payload crossover is established yet.

- [ ] CP-08: compare upstream-first and own-first on this same value contract,
  including source readiness, CE launch/completion/control costs, receive-side
  overlap, shared-link idle gaps, bytes per link, switch/queue/color budget and
  repeated-frame reset. Measure small-to-large payload sweeps and skew/stalls;
  separate endpoint overlap from wire utilization and total handoff latency.
- [ ] CP-04/CP-05: preserve complete non-interleaved source bursts with the
  ordered sender tail marker. Idle gaps and simultaneous traffic on different
  physical links are allowed. Verify final control termination and target-side
  selection separately; a source marker must not accidentally advance the
  wrong switch. Do not infer full-protocol resource count from the source sweep.
- [ ] CP-05: pre-arm independent source and destination operations where legal;
  measure actual injection/receipt overlap rather than counting armed tasks.
  Preserve buffer ownership and exact receive counts under backpressure.

**Source audit: first communication after A1 input.** The current tall harness
still copies preloaded `group_input` into X and calls layer bank 0; it has no
new A3->A1 ingress yet ([entry](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:175)).
The subsequent sequence is local sum-of-squares/norm-weight application and
local QKV partial products, then Y-axis fused QKV+sumsq all-reduce, then global
RMS scale application ([local and reduce calls](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1844)).
Local norm work is explicit [here](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1094);
the all-reduce uses synchronous receive/reduce operations and ends with a
broadcast ([implementation](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/comm_lib/comm_pe.csl:1365)).

- [ ] Validate per-PE local-ready launch instead of imposing a global input
  barrier by default. Both halves must be written for the same token/layer;
  banks, buffers, routes and collective call order must match. Local precompute
  needs no neighbor data. An early participant can wait in the collective only
  if delayed peers can continue receiving and reaching that same collective.
- [ ] Negative/control case: if a ready row blocks in Y all-reduce before
  releasing the destination strip to deliver later rows, the ready row waits
  for peers whose ingress it has prevented. Keep handoff/control progress
  independent of the blocking collective, or release the required route first.
  This is a design dependency to exclude, not an observed current bug.
- [ ] Validate ingress/collective resource separation and route lifetimes under
  row/column arrival skew. The next A1 phase repaints collective colors for
  X-band QK norm ([call](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/decode.csl:1865));
  the reconfiguration function has no explicit barrier and documents reliance
  on synchronous collective/broadcast behavior ([source contract](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/comm_lib/comm_pe.csl:1633)).
  Do not treat that comment as a new skewed-ingress hardware validation, or a
  local receive completion as proof that every router/output queue is drained.
- [ ] Keep X owned until its remaining consumers finish, including the residual
  handoff ([current sender](/home/lexu/wse3-performance-model/demo/qwen3-4b-thinner-stage/layoutC/code/src/tall_stage.csl:187)).
  Test delayed second halves, a stalled receiver, distinct consecutive frames,
  and mismatched layer/token state before enabling repeated feedback.

References: [ordering comparison and time-slice diagrams](/home/lexu/wse3-performance-model/docs/design/2026-09-12-layoutC-router-sweep-ordering.md),
[existing sender completion/marker mechanism](/home/lexu/wse3-performance-model/demo/communication-algorithm/02-sweep-k1/sender.csl:27).

**2026-09-12 verification note:** the isolated source/target protocol uses
`[ADV]` for source handoff and `[NOP,ADV]` for target advance. Normal source
junctions use pop_on_advance; the final source junction uses always_pop to
remove the NOP prefix before the marker reaches the target zone. Each pair
sends ROW_DONE before TARGET_ADV, and TARGET_ADV precedes the next source grant.
The last sender appends STREAM_END after the last target advance. A control-only
reset sweep waits for both exact receive counts and per-row completion, restores
switches, and broadcasts the next START only after every reset node has finished.
Payload remains router-only in the strip. See
[protocol, resource inventory and validation evidence](/home/lexu/wse3-performance-model/docs/reports/2026-09-12-layoutc-marker-reset-verification.md).

- [ ] Integrate the verified microprotocol using queues/tasks that do not
  overlap tall collectives. The standalone memcpy harness's IQ/OQ2/3/4 and
  control entrypoint 40 are **not** a drop-in assignment for tall.
- [ ] Validate packed f16 reception, larger fanout/idle-row transit and skew,
  then actual multi-layer feedback. Preserve the original full-group gate.
- [ ] Optimize the conservative control-only reset sweep only after measuring
  it; retain the rule that a main-strip sentinel alone is not an all-receiver
  write-completion acknowledgement.

### Pending work

- [ ] Map these value contracts to the existing descriptor schema; represent
  replicas explicitly and report unsupported constructs instead of inventing syntax.
- [ ] Factor a reusable X/Z copy-slice contract with source/destination row
  widths, physical origins, local offsets, and multicast destinations.
- [ ] Specify QKV's preceding reduction separately, including arithmetic order,
  fused normalization statistic, and the boundary before QK-norm/RoPE.
- [ ] Extract protocol candidates separately from contracts: route/color tables,
  counts, CE relay vs router multicast, queue bindings, completion and reset.
- [ ] Audit shared IQ/OQ3 lifetime across X, compute, Z and next-token X;
  output flush alone does not prove the input queue is empty.
- [ ] Validate distinct source/column/step patterns, split/join boundaries,
  local zero-hop cases, repeated tokens, and deliberate wrong-offset/column controls.
- [ ] Compare feasible alternative protocols only with matched value contracts;
  measure latency, link load, CE work and SRAM before making performance claims.

No generic compiler implementation or new hardware run is included here.
