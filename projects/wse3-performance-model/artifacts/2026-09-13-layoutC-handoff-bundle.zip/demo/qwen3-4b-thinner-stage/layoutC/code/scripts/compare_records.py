#!/usr/bin/env python3
"""Byte-identity gate between two device_records.npz files.

Compares every round's arrays bitwise.

    python3 scripts/compare_records.py <a.npz> <b.npz> [--expect identical|divergent]
                                       [--require-keys k1,k2] [--min-arrays N]

Exit 0 iff the outcome matches `--expect` (default: identical).

WHY THIS IS STRICTER THAN IT LOOKS (2026-09-09). The previous version passed on
two EMPTY archives: `set(a.files) != set(b.files)` is False for two empty sets,
the intersection loop never ran, and `ok` stayed True. A gate that cannot fail is
not a gate, and this one was load-bearing for the layout-C refactor's Stage 1
byte-identity check. Found by Codex plan review, reproduced in memory:
empty/empty -> 0/PASS, matching -> 0/PASS, corrupted -> 1/FAIL.

So this version refuses, rather than passes, when there is nothing to compare:
both archives must load, carry at least one array, carry the same key set, and
every compared array must be non-empty. `--expect divergent` turns the negative
control into a positive assertion instead of "the caller should see exit 1".
"""
import argparse
import sys
from pathlib import Path

import numpy as np


def die(msg):
    print(f"GATE ERROR: {msg}")
    print("VERDICT: ERROR")
    sys.exit(2)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("a")
    p.add_argument("b")
    p.add_argument("--expect", choices=("identical", "divergent"), default="identical")
    p.add_argument("--require-keys", default="",
                   help="comma-separated keys that MUST be present in both")
    p.add_argument("--min-arrays", type=int, default=1,
                   help="fail if fewer than this many arrays are compared")
    args = p.parse_args()

    pa, pb = Path(args.a), Path(args.b)
    for q in (pa, pb):
        if not q.is_file():
            die(f"{q} does not exist — the run that should have produced it did not")
        if q.stat().st_size == 0:
            die(f"{q} is empty")
    if pa.resolve() == pb.resolve():
        die("both paths resolve to the same file; a self-comparison always passes")

    try:
        a, b = np.load(pa), np.load(pb)
    except Exception as exc:                       # noqa: BLE001 - report, do not mask
        die(f"could not load: {exc}")

    ka, kb = set(a.files), set(b.files)
    if not ka or not kb:
        die(f"empty archive: {pa.name} has {len(ka)} arrays, {pb.name} has {len(kb)}")
    if ka != kb:
        print(f"KEY MISMATCH: {sorted(ka)} vs {sorted(kb)}")
        print("VERDICT: FAIL")
        sys.exit(1)

    required = {k for k in args.require_keys.split(",") if k}
    if required - ka:
        die(f"required keys absent from both archives: {sorted(required - ka)}")

    compared = 0
    identical = True
    for k in sorted(ka):
        xa, xb = a[k], b[k]
        if xa.size == 0 or xb.size == 0:
            die(f"{k}: zero-sized array ({xa.shape} vs {xb.shape}) — nothing to compare")
        compared += 1
        if xa.shape != xb.shape or xa.dtype != xb.dtype:
            print(f"{k}: SHAPE/DTYPE MISMATCH {xa.shape}/{xa.dtype} vs {xb.shape}/{xb.dtype}")
            identical = False
            continue
        if np.array_equal(xa, xb):
            print(f"{k}: BYTE-IDENTICAL ({xa.shape})")
        else:
            d = np.nonzero(np.any(
                xa.reshape(xa.shape[0], -1) != xb.reshape(xb.shape[0], -1), axis=1))[0]
            print(f"{k}: MISMATCH at {d.size} step(s), first diff step {int(d[0])}")
            identical = False

    if compared < args.min_arrays:
        die(f"compared only {compared} array(s), expected at least {args.min_arrays}")

    outcome = "identical" if identical else "divergent"
    ok = outcome == args.expect
    print(f"compared {compared} array(s); outcome={outcome}; expected={args.expect}")
    print("VERDICT:", "PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
