#!/usr/bin/env cs_python
"""Tall three-region fixture, with optional on-wafer group feedback.

Boundary token inputs and prefill are baked fixtures. --feedback runs distinct
local layer banks; --cmaddr selects CS-3. Head/tail and inter-group links remain
outside this entry point. Run from this directory with cs_python launch_tall.py.
"""

import argparse
import json
import os
import hashlib
from dataclasses import asdict, replace
from pathlib import Path

import numpy as np
from launch import (
    Color,
    Edge,
    Route,
    RoutingPosition,
    SdkLayout,
    SdkTarget,
    SdkRuntime,
    SimfabConfig,
    get_platform,
    FP16TYPE,
    IntVector,
)
from host import route_table as rt
from host.tall_layout import Geometry, full_geometry, y_group
from host.tall_fixture import make_fixture, bake, reference, check_cache, BF16


def axis_words(pos, span, lo, hi):
    group = y_group(span)
    quotient, remainder = divmod(pos, group)
    root1, root2 = group // 2, (span // group // 2) * group + group // 2
    a = rt.chain_dirs_1st(remainder, root1, lo, hi)
    b = rt.second_phase(pos, quotient, remainder, root1, root2, lo, hi)
    c = rt.bcast_dirs(pos, root2, span, lo, hi)
    bc = rt.w1(c[0], c[1]) if c[5] else rt.w2(c[2], c[3], c[4])
    return [rt.w1(*a[:2]), rt.w1(*a[2:]), rt.w1(*b[:2]), rt.w1(*b[2:]), bc]


def coordinate_table(width, height, pes_per_head):
    """Region-local coordinates: A2's Y never wraps at width."""
    table = np.zeros((height, width, rt.PE_CFG_WORDS), np.uint16)
    for y in range(height):
        for x in range(width):
            kx = x % pes_per_head
            a = rt.chain_dirs_1st(kx, pes_per_head // 2, rt.WEST, rt.EAST)
            b = rt.bcast_dirs(kx, pes_per_head // 2, pes_per_head, rt.WEST, rt.EAST)
            kv = [
                rt.w1(*a[:2]),
                rt.w1(*a[2:]),
                rt.w1(b[0], b[1]) if b[5] else rt.w2(b[2], b[3], b[4]),
            ]
            table[y, x] = (
                [
                    x,
                    y,
                    x // y_group(width),
                    x % y_group(width),
                    y // y_group(height),
                    y % y_group(height),
                    kx,
                    0,
                    0,
                    0,
                    0,
                    1,
                ]
                + axis_words(y, height, rt.NORTH, rt.SOUTH)
                + axis_words(x, width, rt.WEST, rt.EAST)
                + kv
                + [rt.UNUSED] * 7
                + [12, 13]
            )
    return table.reshape(height, -1)


def route(region, x, y, color, source, *destinations):
    region.paint(
        IntVector(x, y),
        Color(f"c{color}", color),
        [RoutingPosition().set_input([source]).set_output(list(destinations))],
    )


def run(args):
    feedback = getattr(args, "feedback", False)
    g = (
        full_geometry(args.layers)
        if args.profile == "full"
        else replace(Geometry(), layers=args.layers if feedback else 1).validate()
    )
    if feedback:
        g.validate_feedback()
    if getattr(args, "cmaddr", None) and not feedback:
        raise ValueError("--cmaddr is supported by the feedback fixture only")
    if feedback and g.layers < 2:
        raise ValueError("feedback requires at least two distinct layer banks")
    if args.profile == "full" and not args.compile_only and not feedback:
        raise ValueError(
            "The standalone full profile is compile-only; select --feedback for the group fixture"
        )
    if not 1 <= args.steps <= g.capacity - g.prefill:
        raise ValueError("decode steps exceed the prefill/cache capacity")
    here = Path(__file__).resolve().parent
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=True)
    os.chdir(out)
    # Bind the result to every staged operator/protocol and host implementation,
    # including imported modules; a stage-only digest misses protocol changes.
    sources = {
        str(p.relative_to(here)): hashlib.sha256(p.read_bytes()).hexdigest()
        for subtree in (here, here / "src", here / "host", here / "scripts")
        for p in (subtree.glob("*.py") if subtree == here else subtree.rglob("*"))
        if p.is_file() and p.suffix in (".py", ".csl")
    }
    manifest = json.dumps(sources, indent=2, sort_keys=True) + "\n"
    Path("source_manifest.json").write_text(manifest)
    print(
        json.dumps(
            {
                "source": str(here / "src/tall_stage.csl"),
                "sha256": hashlib.sha256(
                    (here / "src/tall_stage.csl").read_bytes()
                ).hexdigest(),
                "geometry": asdict(g),
                "source_manifest_sha256": hashlib.sha256(manifest.encode()).hexdigest(),
                "protocol_sha256": {
                    name: sources["src/" + name]
                    for name in ("group_link.csl", "group_strip.csl")
                }
                if feedback
                else {},
            }
        ),
        flush=True,
    )
    width = g.width
    params = dict(
        width=width,
        a1_height=g.a1,
        a2_height=g.a2,
        a3_height=g.a3,
        model_dim=g.dim,
        attn_dim=g.attn,
        kv_dim=g.kv,
        head_dim=g.head,
        ffn_dim=g.ffn,
        capacity=g.capacity,
        num_steps=args.steps,
        prefill=g.prefill,
        layer_banks=g.layers,
        feedback_mode=int(feedback),
    )
    platform = get_platform(
        getattr(args, "cmaddr", None),
        SimfabConfig(dump_core=not feedback),
        SdkTarget.WSE3,
    )
    layout = SdkLayout(platform)
    if feedback:
        from host.group_allocation import Allocation

        layout = Allocation(layout)
    regions = {}
    for stage in (1, 2, 3):
        height = g.height(stage)
        origin = (
            (2 + width + int(feedback), 1)
            if stage == 2
            else (2 + int(feedback), 1 + (g.a3_origin if stage == 3 else 0))
        )
        rg = layout.create_code_region(
            str(here / "src/tall_stage.csl"), f"A{stage}", width, height
        )
        regions[stage] = rg
        for key, value in dict(
            params, stage=stage, group_y=y_group(height), edge=False, qkv_color=8
        ).items():
            rg.set_param_all(key, value)
        # Collectives 0..4 use IQ/OQ3..7; H0=8, H1=9, X-entry=10,
        # QKV-column=11, vertical parity=12/13, Z=14, output=15, X-row=16.
        # All transport colors stay static. Only edge IQ/OQ3 rebind after flush.
        for color in range(17):
            rg.paint_all(
                Color(f"c{color}", color),
                [RoutingPosition().set_input([Route.RAMP]).set_output([Route.RAMP])],
            )
        rg.set_symbol_all(
            "pe_cfg",
            coordinate_table(width, height, width // (g.kv // g.head)),
            width * 34,
            height,
        )
        for y in range(height):
            for x in range(width):
                if stage == 1:
                    for hcolor, source_col in [(8, y), (9, y + g.a1)]:
                        if source_col >= width:
                            continue
                        if x == source_col:
                            route(rg, x, y, hcolor, Route.RAMP, Route.EAST)
                        elif x > source_col:
                            route(rg, x, y, hcolor, Route.WEST, Route.EAST)
                    if x == width - 1:
                        route(rg, x, y, 10, Route.RAMP, Route.EAST)
                elif stage == 2:
                    rg.set_param(IntVector(x, y), "edge", x == 0)
                    rg.set_param(IntVector(x, y), "qkv_color", 8 if x < g.a1 else 9)
                    for hcolor, target_col in [(8, y), (9, y + g.a1)]:
                        if y >= g.a1 or target_col >= width:
                            continue
                        if x < target_col:
                            route(rg, x, y, hcolor, Route.WEST, Route.EAST)
                        elif x == target_col:
                            route(rg, x, y, hcolor, Route.WEST, Route.RAMP)
                    root = x % g.a1
                    if y == root:
                        route(
                            rg,
                            x,
                            y,
                            11,
                            Route.RAMP,
                            *([Route.SOUTH] if y == 0 else [Route.NORTH, Route.SOUTH]),
                        )
                    else:
                        src, dst = (
                            (Route.SOUTH, Route.NORTH)
                            if y < root
                            else (Route.NORTH, Route.SOUTH)
                        )
                        route(
                            rg,
                            x,
                            y,
                            11,
                            src,
                            *(
                                [Route.RAMP]
                                if y in (0, height - 1)
                                else [Route.RAMP, dst]
                            ),
                        )
                    if x == 0:
                        if y < g.a1:
                            route(rg, x, y, 10, Route.WEST, Route.RAMP)
                        if y > 0:
                            route(
                                rg,
                                x,
                                y,
                                13 if y % 2 == 0 else 12,
                                Route.NORTH,
                                Route.RAMP,
                            )
                        if y < height - 1:
                            route(
                                rg,
                                x,
                                y,
                                12 if y % 2 == 0 else 13,
                                Route.RAMP,
                                Route.SOUTH,
                            )
                        route(rg, x, y, 16, Route.RAMP, Route.EAST)
                        if y >= g.a3_origin:
                            route(rg, x, y, 14, Route.RAMP, Route.WEST)
                    else:
                        route(
                            rg,
                            x,
                            y,
                            16,
                            Route.WEST,
                            *(
                                [Route.RAMP, Route.EAST]
                                if x < width - 1
                                else [Route.RAMP]
                            ),
                        )
                else:
                    route(
                        rg,
                        x,
                        y,
                        14,
                        Route.EAST,
                        *([Route.RAMP, Route.WEST] if x else [Route.RAMP]),
                    )
                    if x == 0:
                        route(rg, x, y, 15, Route.RAMP, Route.WEST)
        rg.place(*origin)
    if feedback:
        from host.group_routing import configure

        configure(layout, regions, g, here / "src")
    fixture = None
    if not args.compile_only:
        if feedback:
            from host.group_fixture import make_group_fixture, bake_group

            fixture = make_group_fixture(args.steps, g)
            bake_group(regions, fixture, g)
        else:
            fixture = make_fixture(args.steps, g)
            bake(regions, fixture, g)
    collector = layout.create_code_region(
        str(here / "src/tall_output.csl"), "output", 1, g.a3
    )
    for key, value in dict(
        width=g.dim // g.a3,
        height=g.a3,
        num_steps=args.steps,
        input_color=17 if feedback else 15,
    ).items():
        collector.set_param_all(key, value)
    for y in range(g.a3):
        collector.set_param(IntVector(0, y), "row", y)
        route(collector, 0, y, 17 if feedback else 15, Route.EAST, Route.RAMP)
        route(collector, 0, y, 13 if y % 2 == 0 else 12, Route.NORTH, Route.RAMP)
        route(collector, 0, y, 12 if y % 2 == 0 else 13, Route.RAMP, Route.SOUTH)
    route(collector, 0, g.a3 - 1, 14, Route.RAMP, Route.SOUTH)
    collector.place(1, 1 + g.a3_origin)
    port = collector.create_output_port(
        Color("c14", 14),
        Edge.BOTTOM,
        [RoutingPosition().set_input([Route.RAMP])],
        args.steps * (g.dim // 2),
        prefix="group_output",
    )
    stream = layout.create_output_stream(port)
    if feedback:
        layout.write("group_allocation.json")
    if feedback and fixture is not None:
        from host.group_fixture import reference_group
        from host.group_reference import reference_group_order

        mathematical, _, _ = reference_group(fixture, g)
        expected, expected_k, expected_v, stages = reference_group_order(fixture, g)
        np.savez(
            "group_reference.npz",
            mathematical=mathematical,
            expected_k=expected_k.astype(np.float32),
            expected_v=expected_v.astype(np.float32),
            **{
                f"layer_{i}_{key}": value
                for i, stage in enumerate(stages)
                for key, value in stage.items()
            },
        )
    artifacts = layout.compile(
        out_prefix="sim",
        cslc_prefix=str(here / "scripts/cslc_bin"),
        f16_type=FP16TYPE.BF16,
        save_port_map=True,
    )
    if args.compile_only:
        Path("compile_validation.json").write_text(
            json.dumps(
                {"compiled": True, "geometry": asdict(g), "executed": False}, indent=2
            )
            + "\n"
        )
        return
    runtime = SdkRuntime(artifacts, platform, memcpy_required=False)
    try:
        runtime.load()
        runtime.run()
        result = np.zeros(args.steps * (g.dim // 2), np.uint32)
        runtime.receive(stream, result, args.steps * (g.dim // 2), nonblock=False)
        np.save("group_output.npy", result)
    finally:
        runtime.stop()
    actual = (
        result.view(np.uint16).view(BF16).astype(np.float32).reshape(args.steps, g.dim)
    )
    if feedback:
        cache = {"status": "not read back by this output-only entry point"}
    else:
        expected, expected_k, expected_v = reference(fixture, g)
        cache = check_cache(runtime, fixture, expected_k, expected_v, g)
    np.savez("comparison.npz", actual=actual, expected=expected.astype(np.float32))
    error = np.abs(actual - expected.astype(np.float32))
    relative_l2 = float(
        np.linalg.norm(error) / np.linalg.norm(expected.astype(np.float32))
    )
    passed = bool(
        np.isfinite(actual).all()
        and (
            np.array_equal(actual, expected)
            if feedback
            else relative_l2 < 0.02 and error.max() < 0.05 and cache["passed"]
        )
    )
    summary = dict(
        passed=passed,
        backend="CS-3" if getattr(args, "cmaddr", None) else "simfab",
        seed=910,
        scope="group output; distinct layer banks; on-wafer local feedback; baked token inputs and prefill"
        if feedback
        else "single layer; baked embeddings and prefill; no feedback",
        reference="existing operator and operation order, exact output equality"
        if feedback
        else "mathematical NumPy",
        relative_l2=relative_l2,
        max_abs=float(error.max()),
        steps=args.steps,
        cache=cache,
        geometry=asdict(g),
    )
    Path("validation.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary), flush=True)
    if not passed:
        raise RuntimeError("Tall group failed the selected reference/cache checks")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=["mini", "full"], default="mini")
    parser.add_argument(
        "--layers",
        type=int,
        default=5,
        help="distinct layer banks for feedback (or full compile-only allocation)",
    )
    parser.add_argument("--output", default="out_tall")
    parser.add_argument("--steps", type=int, default=2)
    parser.add_argument("--compile-only", action="store_true")
    parser.add_argument("--feedback", action="store_true")
    parser.add_argument("--cmaddr", default=None)
    run(parser.parse_args())
