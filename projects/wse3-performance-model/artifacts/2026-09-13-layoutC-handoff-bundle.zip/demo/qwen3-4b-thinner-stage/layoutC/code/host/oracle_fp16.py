"""Numpy fp16 oracle for the on-chip pipeline decode.

Mirrors `MAX_OUTPUT_LEN` decode steps × `n_layers` total transformer layers,
distributed across block rows via `distribute_layers`. Each row's ATTN/FFN
role pair runs its assigned contiguous slice before feeding the next row.
Per-(global layer, per-PE) iter_num is tracked
independently so attention masks match the on-chip per-PE state.

Weight generation must consume RandomState(2025 + global_layer_idx) in the
EXACT same call order as `launch._gen_block_tensors_single_layer` so seeds
align.
"""
import math

import numpy as np
import ml_dtypes

# Must mirror launch.py's WEIGHT_SCALE.
WEIGHT_SCALE = 0.05

# 16-bit effective -inf for softmax masking (large negative, exp → 0).
NEG_INF_F16 = ml_dtypes.bfloat16(-65504.0)

# Qwen3 RoPE constant — must mirror launch.py.
ROPE_THETA = 1000000.0


def _qwen3_inv_freq(head_dim: int) -> np.ndarray:
    """Qwen3 plain RoPE inv_freq (no NTK scaling). Must match
    launch._qwen3_inv_freq bit-for-bit. Returns np.float64 of shape (head_dim//2,)."""
    return 1.0 / (
        ROPE_THETA ** (np.arange(0, head_dim, 2, dtype=np.float64) / head_dim)
    )


# --------------------------------------------------------------------- #
# Weight generation — matches launch._gen_block_tensors call order so
# that RandomState state advances identically.
# --------------------------------------------------------------------- #

def _zpad(a, shape):
    """Zero-pad ndarray `a` up to `shape`; real data at the origin, tail zero.
    Mirrors launch.py._zpad so the oracle and device share weights exactly."""
    shape = tuple(shape)
    if a.shape == shape:
        return a
    out = np.zeros(shape, dtype=a.dtype)
    out[tuple(slice(0, s) for s in a.shape)] = a
    return out


def _gen_block_weights(global_l, *, dim, kv_dim, ffn_dim, seq_len, head_dim,
                       P_BLOCK_SIZE, bsz,
                       dim_true=None, kv_dim_true=None, ffn_true=None, seq_true=None,
                       attn_dim=None, attn_dim_true=None):
    """Return a dict of unsharded fp16 weights for the global layer index
    `global_l` (in [0, n_layers_total)).

    RNG call order MUST match launch._gen_block_tensors_single_layer exactly
    so seeds align. Seed = 2025 + global_l (block index dropped on purpose —
    each global layer's weights are now block-independent so the oracle can
    iterate purely by layer).

    XKCache / XVCache are per-batch (shape (bsz, ...)). RNG order: bsz
    consecutive rb(kv_dim, seq_len) draws then bsz consecutive
    rb(seq_len, kv_dim) draws — must match launch.py.
    """
    rng = np.random.RandomState(2025 + global_l)
    # Draw at true dimensions, then apply the same zero padding as launch.py so
    # both sides consume the RNG stream in the same order.
    dim_true = dim if dim_true is None else dim_true
    kv_dim_true = kv_dim if kv_dim_true is None else kv_dim_true
    ffn_true = ffn_dim if ffn_true is None else ffn_true
    seq_true = seq_len if seq_true is None else seq_true
    # Attention width is independent of the hidden width.
    attn_dim = dim if attn_dim is None else attn_dim
    attn_dim_true = dim_true if attn_dim_true is None else attn_dim_true

    def rb(*shape):
        return (rng.rand(*shape) * WEIGHT_SCALE).astype(ml_dtypes.bfloat16)

    # Order matches launch._gen_block_tensors_single_layer:
    # W_attn_norm, W_ffn_norm, Q, O, K, V, q_norm, k_norm, then per-batch XK×bsz,
    # per-batch XV×bsz, UP, GATE, DOWN.
    w_attn_norm = _zpad(rb(1, dim_true), (1, dim)).reshape(dim)
    w_ffn_norm  = _zpad(rb(1, dim_true), (1, dim)).reshape(dim)
    Q = _zpad(rb(dim_true, attn_dim_true), (dim, attn_dim))
    O = _zpad(rb(attn_dim_true, dim_true), (attn_dim, dim))
    K = _zpad(rb(dim_true, kv_dim_true), (dim, kv_dim))
    V = _zpad(rb(dim_true, kv_dim_true), (dim, kv_dim))
    # Qwen3 QK-Norm: per-head RMSNorm weights (head_dim vectors, never padded).
    # Drawn right after V to match launch's RNG stream.
    q_norm = rb(head_dim)
    k_norm = rb(head_dim)
    XK = np.stack([_zpad(rb(kv_dim_true, seq_true), (kv_dim, seq_len)) for _ in range(bsz)], axis=0)
    XV = np.stack([_zpad(rb(seq_true, kv_dim_true), (seq_len, kv_dim)) for _ in range(bsz)], axis=0)
    UP = _zpad(rb(dim_true, ffn_true), (dim, ffn_dim))
    GATE = _zpad(rb(dim_true, ffn_true), (dim, ffn_dim))
    DOWN = _zpad(rb(ffn_true, dim_true), (ffn_dim, dim))

    return {
        "W_attn_norm": w_attn_norm,
        "W_ffn_norm":  w_ffn_norm,
        "Q": Q, "O": O, "K": K, "V": V,
        "q_norm": q_norm, "k_norm": k_norm,
        "XKCache": XK, "XVCache": XV,
        "UP": UP, "GATE": GATE, "DOWN": DOWN,
    }


# --------------------------------------------------------------------- #
# Layer distribution — must match launch.distribute_layers bit-for-bit.
# --------------------------------------------------------------------- #

def _distribute_layers(n_layers: int, N: int):
    """Mirror of launch.distribute_layers."""
    if N == 1:
        return [n_layers], [0]
    x = math.ceil(n_layers / N)
    y = N * x - n_layers
    counts = [x] * N
    counts[0]  = x - (y + 1) // 2
    counts[-1] = x - y // 2
    assert counts[0] >= 1, (
        f"_distribute_layers: n_layers={n_layers} too small for N={N} blocks"
    )
    offsets = [0]
    for c in counts[:-1]:
        offsets.append(offsets[-1] + c)
    return counts, offsets


# --------------------------------------------------------------------- #
# X-shard attention validity mask
# --------------------------------------------------------------------- #

def _build_valid_mask(iter_num_per_pe, kv_len_per_pe, P_BLOCK_SIZE, seq_len):
    """Returns float16 mask[s] = 1.0 if global col s is in some PE's valid
    range [p*kv_len_per_pe, p*kv_len_per_pe + iter_num_per_pe[p]); else 0.0.
    """
    mask = np.zeros(seq_len, dtype=ml_dtypes.bfloat16)
    for p in range(P_BLOCK_SIZE):
        for col in range(iter_num_per_pe[p]):
            mask[p * kv_len_per_pe + col] = 1.0
    return mask


# --------------------------------------------------------------------- #
# Kernels — all fp16, reference-correct
# --------------------------------------------------------------------- #

def _rmsnorm(x, W, dim, eps=1e-6):
    """Qwen3 RMSNorm equivalent: full fp32 sumsq /
    variance / rsqrt / normalize, cast back to fp16 ONLY at the final * W
    step. Matches the kernel-side fp32 allreduce path in decode.csl and
    ht_tail.csl so sim/oracle agree byte-for-byte on the precision regime.
    """
    x_f32 = x.astype(np.float32)
    # Divide by the TRUE (unpadded) hidden dim, not x.shape[-1] (the padded
    # width). Padded hidden positions are exactly zero so the sumsq is unchanged;
    # only the divisor must stay true (e.g. 4096, not 4608). `dim` is the true dim.
    variance = (x_f32 * x_f32).sum(axis=-1, keepdims=True) / np.float32(dim)
    inv = (1.0 / np.sqrt(variance + np.float32(eps))).astype(np.float32)
    normalized_f16 = (x_f32 * inv).astype(ml_dtypes.bfloat16)
    return (normalized_f16 * W.astype(ml_dtypes.bfloat16)).astype(ml_dtypes.bfloat16)


def _rmsnorm_local(x, W, dim, eps=1e-6):
    """L1 split of _rmsnorm: returns ((x (*) W) in bf16, per-row 1/rms in f32).

    The device no longer scales x before the projection. Its sumsq all-reduce was
    folded into the projection's own all-reduce, so the scalar is applied to the f32
    projection OUTPUT instead (decode.csl rmsnorm_local / rmsnorm_apply_*). A scalar
    commutes with the linear projection, so the value is the same in exact
    arithmetic — but the ROUNDING is not: the old order rounded x*s to bf16 and then
    multiplied by W, this one rounds x (*) W once and applies s in f32 after an f32
    accumulation. That is one fewer bf16 rounding, so an oracle left on the old order
    would disagree with the device in the last bf16 ulp for a reason that is not a
    bug — and the [sampled] ids gate is sensitive enough to notice.

    `dim` is the TRUE (unpadded) hidden dim, same rule as _rmsnorm above.

    _rmsnorm itself is KEPT: ht_tail's final norm feeds lm_head directly, has no
    projection reduce to fold into, and is unchanged on the device.
    """
    x_f32 = x.astype(np.float32)
    variance = (x_f32 * x_f32).sum(axis=-1, keepdims=True) / np.float32(dim)
    inv = (1.0 / np.sqrt(variance + np.float32(eps))).astype(np.float32)
    xw = (x.astype(ml_dtypes.bfloat16) * W.astype(ml_dtypes.bfloat16)).astype(ml_dtypes.bfloat16)
    return xw, inv


def _apply_rms_scale(proj, inv):
    """Scale an f32 projection output by the deferred per-row 1/rms, then round."""
    return (proj.astype(np.float32) * inv).astype(ml_dtypes.bfloat16)


def _rope(x, sin, cos, n_pairs):
    """Qwen3 rotate-half RoPE: pair (x[k], x[k+H/2]) rotates with cos[k]/sin[k].
    cos / sin shape (head_dim/2,); broadcasts against x[..., :H/2] and x[..., H/2:].
    """
    assert x.shape[-1] == n_pairs * 2
    half = x.shape[-1] // 2
    x1 = x[..., :half]
    x2 = x[..., half:]
    new_x1 = (x1 * cos - x2 * sin).astype(ml_dtypes.bfloat16)
    new_x2 = (x2 * cos + x1 * sin).astype(ml_dtypes.bfloat16)
    out = np.empty_like(x)
    out[..., :half] = new_x1
    out[..., half:] = new_x2
    return out


def _q_rope_per_head(Q_h, base_sin, base_cos):
    return _rope(Q_h, base_sin, base_cos, n_pairs=Q_h.shape[-1] // 2)


def _k_rope_per_head(K_kh, base_sin, base_cos):
    return _rope(K_kh, base_sin, base_cos, n_pairs=K_kh.shape[-1] // 2)


def _rmsnorm_head(x, W, head_dim, eps=1e-6):
    """Qwen3 q_norm / k_norm: RMSNorm over the head_dim axis (last), per head, in
    fp32. x shape (..., head_dim); W shape (head_dim,). Mirrors the device
    qk_norm_kernel (fp32 sumsq/head_dim, rsqrt, normalize, cast bf16, * W)."""
    x_f32 = x.astype(np.float32)
    variance = (x_f32 * x_f32).sum(axis=-1, keepdims=True) / np.float32(head_dim)
    inv = (1.0 / np.sqrt(variance + np.float32(eps))).astype(np.float32)
    normalized_f16 = (x_f32 * inv).astype(ml_dtypes.bfloat16)
    return (normalized_f16 * W.astype(ml_dtypes.bfloat16)).astype(ml_dtypes.bfloat16)


_APPROX_EXP_CUTOFF_F32 = np.float32(-32.0)
_APPROX_EXP_LOG2E_F32 = np.float32(1.4426950408889634)
_APPROX_EXP_LN2_F32 = np.float32(0.6931471805599453)
_APPROX_EXP_C_F32 = np.array([
    0.999924556951, 0.999984928632, 0.505022284214, 0.167670118752,
], dtype=np.float32)


def _approx_exp_neg_f32(x):
    """Vector mirror of approx_math.exp_neg_f32 for max-shifted x <= 0."""
    x = np.asarray(x, dtype=np.float32)
    x_work = np.maximum(x, _APPROX_EXP_CUTOFF_F32)
    n = np.trunc(x_work * _APPROX_EXP_LOG2E_F32 - np.float32(0.5)).astype(np.int32)
    r = (x_work - n.astype(np.float32) * _APPROX_EXP_LN2_F32).astype(np.float32)
    p = np.full_like(r, _APPROX_EXP_C_F32[3])
    p = (_APPROX_EXP_C_F32[2] + r * p).astype(np.float32)
    p = (_APPROX_EXP_C_F32[1] + r * p).astype(np.float32)
    p = (_APPROX_EXP_C_F32[0] + r * p).astype(np.float32)
    two_n = ((n + 127).astype(np.uint32) << np.uint32(23)).view(np.float32)
    out = (two_n * p).astype(np.float32)
    return out


def _approx_recip_f32(x):
    """Vector mirror of approx_math.recip_f32."""
    x = np.asarray(x, dtype=np.float32)
    y_bits = np.uint32(0x7EF127EA) - x.view(np.uint32)
    y = y_bits.view(np.float32)
    for _ in range(4):
        y = (y * (np.float32(2.0) - x * y)).astype(np.float32)
    return y


def _softmax_exp_fp16(x, axis):
    # Device keeps max/exp/local denominator in fp32, but casts the
    # unnormalized exp values to bf16 before the local Score@V numerator.
    x_f32 = x.astype(np.float32)
    m = x_f32.max(axis=axis, keepdims=True)
    shifted = (x_f32 - m).astype(np.float32)
    e = _approx_exp_neg_f32(shifted)
    s = e.sum(axis=axis, keepdims=True)
    return e.astype(ml_dtypes.bfloat16), s


def _silu_fp16(x):
    s = 1.0 / (1.0 + np.exp(-x.astype(np.float32)))
    return (x.astype(ml_dtypes.bfloat16) * s.astype(ml_dtypes.bfloat16)).astype(ml_dtypes.bfloat16)


# --------------------------------------------------------------------- #
# Block decode pass with cache state + valid_mask
# --------------------------------------------------------------------- #

def _layer_body(X, w, XK_full, XV_full, valid_mask, *,
                dim, kv_dim, head_dim, n_heads, n_kv_heads, ffn_dim, seq_len,
                cos_step, sin_step, true_dim=None, attn_dim=None):
    """One layer-body pass over input X with provided cache state and per-PE
    validity mask. `cos_step / sin_step` are the position-specific RoPE
    angles (shape (head_dim//2,) each) for the new Q being projected in this
    step. Returns Z.
    """
    gqa_group_size = n_heads // n_kv_heads
    bsz = X.shape[0]
    true_dim = dim if true_dim is None else true_dim
    attn_dim = dim if attn_dim is None else attn_dim   # decoupled attn width (4B)

    x_w, inv_x = _rmsnorm_local(X, w["W_attn_norm"], true_dim)
    Q = _apply_rms_scale(x_w @ w["Q"], inv_x)
    Q_h = Q.reshape(bsz, n_heads, head_dim)
    Q_h = _rmsnorm_head(Q_h, w["q_norm"], head_dim)   # Qwen3 q_norm (before RoPE)
    Q_h = _q_rope_per_head(Q_h, sin_step, cos_step)

    # Per-batch independent KV cache. Each batch attends only against its own
    # K/V history slab.
    XK = XK_full.reshape(bsz, n_kv_heads, head_dim, seq_len)
    XV = XV_full.reshape(bsz, seq_len, n_kv_heads, head_dim)

    score = np.empty((bsz, n_heads, seq_len), dtype=ml_dtypes.bfloat16)
    for h in range(n_heads):
        kh = h // gqa_group_size
        for i_b in range(bsz):
            score[i_b, h, :] = (Q_h[i_b, h, :].astype(ml_dtypes.bfloat16) @
                                XK[i_b, kh].astype(ml_dtypes.bfloat16)).astype(ml_dtypes.bfloat16)
    score = (score * ml_dtypes.bfloat16(1.0 / np.sqrt(head_dim))).astype(ml_dtypes.bfloat16)

    # Mask out positions outside each PE's [0, iter_num) range.
    invalid = (valid_mask < 0.5)
    score = np.where(invalid[np.newaxis, np.newaxis, :], NEG_INF_F16, score)

    score, score_sum = _softmax_exp_fp16(score, axis=-1)

    out_h = np.empty((bsz, n_heads, head_dim), dtype=ml_dtypes.bfloat16)
    for h in range(n_heads):
        kh = h // gqa_group_size
        for i_b in range(bsz):
            numerator = (score[i_b, h, :].astype(ml_dtypes.bfloat16) @
                         XV[i_b, :, kh, :].astype(ml_dtypes.bfloat16)).astype(np.float32)
            inv_sum = _approx_recip_f32(score_sum[i_b, h, 0])
            out_h[i_b, h, :] = (
                numerator * inv_sum).astype(ml_dtypes.bfloat16)
    out = out_h.reshape(bsz, attn_dim)

    h1 = (out @ w["O"]).astype(ml_dtypes.bfloat16)
    Z = (X + h1).astype(ml_dtypes.bfloat16)

    z_w, inv_z = _rmsnorm_local(Z, w["W_ffn_norm"], true_dim)
    up = _apply_rms_scale(z_w @ w["UP"], inv_z)
    gate = _apply_rms_scale(z_w @ w["GATE"], inv_z)
    z3 = (_silu_fp16(gate) * up).astype(ml_dtypes.bfloat16)
    h2 = (z3 @ w["DOWN"]).astype(ml_dtypes.bfloat16)
    Z = (Z + h2).astype(ml_dtypes.bfloat16)

    return Z


def _compute_kv_step(X, w, *, n_kv_heads, head_dim, dim, kv_dim,
                     cos_step, sin_step, true_dim=None):
    """Compute K_step (RoPE'd at the current decode position) and V_step from
    current X. `cos_step / sin_step` are the position-specific angles for this
    step. Returns full bsz slices — each batch's new K/V appends into its own
    cache slab."""
    true_dim = dim if true_dim is None else true_dim
    x_w, inv_x = _rmsnorm_local(X, w["W_attn_norm"], true_dim)
    K = _apply_rms_scale(x_w @ w["K"], inv_x)                # (bsz, kv_dim)
    V = _apply_rms_scale(x_w @ w["V"], inv_x)                # (bsz, kv_dim)
    K_kh = K.reshape(X.shape[0], n_kv_heads, head_dim)
    K_kh = _rmsnorm_head(K_kh, w["k_norm"], head_dim)   # Qwen3 k_norm (before RoPE)
    K_kh = _k_rope_per_head(K_kh, sin_step, cos_step)
    K = K_kh.reshape(X.shape[0], kv_dim)
    return K, V                                       # (bsz, kv_dim), (bsz, kv_dim)


def _gen_W_E(vocab_size, dim, vocab_true=None, dim_true=None):
    """Mirror launch._gen_W_E_tile_array's raw HF row-major nn.Embedding
    layout. Seed 2024 is disjoint from per-layer weight seeds (2025 + gl).
    Draw true (vocab, dim); zero-pad to padded (dummy vocab rows / dim cols zero).
    """
    vocab_true = vocab_size if vocab_true is None else vocab_true
    dim_true = dim if dim_true is None else dim_true
    rng = np.random.RandomState(2024)
    return _zpad((rng.rand(vocab_true, dim_true) * WEIGHT_SCALE).astype(ml_dtypes.bfloat16),
                 (vocab_size, dim))


def _gen_W_final_norm(dim, dim_true=None):
    """Mirror launch._gen_W_final_norm_tile_array's full weight vector.
    Qwen3 final RMSNorm weight; it has no bias. Seed 2028 disjoint
    from W_E (2024), per-layer (2025+l); lm_head is tied to W_E (2024).
    """
    dim_true = dim if dim_true is None else dim_true
    rng = np.random.RandomState(2028)
    return _zpad((rng.rand(dim_true) * WEIGHT_SCALE).astype(ml_dtypes.bfloat16), (dim,))


def _gen_W_lm_head(vocab_size, dim, vocab_true=None, dim_true=None):
    """Mirror launch._gen_lm_head_tile_array's full lm_head matrix. Shape
    (vocab_size, dim) f16. Qwen3-4B ties lm_head to embed_tokens
    (tie_word_embeddings=true), so this draws the SAME matrix as W_E (seed 2024).
    """
    vocab_true = vocab_size if vocab_true is None else vocab_true
    dim_true = dim if dim_true is None else dim_true
    rng = np.random.RandomState(2024)   # tied to W_E (Qwen3 tie_word_embeddings)
    # Draw true (vocab, dim); zero-pad. Dummy vocab rows [vocab_true:] are zero
    # -> logit 0, masked below (logits[:, vocab_true:] = -inf) so a padded
    # zero-logit cannot outrank a real token (mirrors device vocab_pad_count).
    return _zpad((rng.rand(vocab_true, dim_true) * WEIGHT_SCALE).astype(ml_dtypes.bfloat16),
                 (vocab_size, dim))


def numpy_decode_oracle(cfg, forced_tokens=None):
    """Multi-step decode oracle. Simulates MAX_OUTPUT_LEN calls of
    the role-split device loop. `n_layers` is the TOTAL transformer layer count;
    it is distributed across P_Y block rows via _distribute_layers (must match
    launch.distribute_layers). Each row pair runs its assigned layer slice and
    feeds its output to the next row. Returns
    logits_stack: post-lm_head logits per step (max_output_len, bsz, vocab),
    or None when cfg has no vocab_size. Caller reshapes to the device mux
    PE-outer layout for comparison.

    X[0] = W_E[cfg['token_ids']] (host pre-embed seed, via demux → head C1).
    X[s>=1] = W_E[next_token_{s-1}] — autoregressive close: after norm(Z), the
    oracle computes logits = norm(Z) @ W_lm_head.T. The device samples its next
    token on-chip from the top-K (and emits it north on tok_bcast_color into
    HT_head), so when those sampled tokens are supplied (forced_tokens) the
    oracle replays them; otherwise it falls back to argmax(logits) for the feed.
    """
    Pw = cfg["Pw"]
    P_X_BLOCK_NUM = cfg["P_X_BLOCK_NUM"]
    P_Y_BLOCK_NUM = cfg["P_Y_BLOCK_NUM"]
    P_BLOCK_SIZE = Pw // P_X_BLOCK_NUM
    bsz = cfg["bsz"]; dim = cfg["dim"]; head_dim = cfg["head_dim"]
    seq_len = cfg["MAX_SEQ_LEN"]; ffn_dim = cfg["ffn_dim"]
    n_heads = cfg["n_heads"]; n_kv_heads = cfg.get("n_kv_heads", n_heads)
    n_layers = cfg.get("n_layers", 1)
    prefill_len = int(cfg["PREFILL_LENS"][0])
    max_output_len = int(cfg["DECODE_LENS"][0])
    kv_dim = n_kv_heads * head_dim
    # ---- P_BLOCK_SIZE padding resolution (mirror launch.py) ---------------- #
    from math import gcd as _gcd
    def _pad_to(x, m):
        return ((x + m - 1) // m) * m
    def _lcm(a, b):
        return a * b // _gcd(a, b)
    HT_WIDTH_tail = cfg.get("HT_WIDTH_tail", P_BLOCK_SIZE // 2)
    _head_mult = _lcm(P_BLOCK_SIZE, head_dim)
    _vocab_mult = _lcm(P_BLOCK_SIZE, HT_WIDTH_tail)
    dim_true, kv_dim_true, ffn_true, seq_true = dim, kv_dim, ffn_dim, seq_len
    vocab_true = cfg.get("vocab_size")
    attn_dim_true = n_heads * head_dim
    dim = _pad_to(dim_true, _head_mult)
    kv_dim = _pad_to(kv_dim_true, _head_mult)
    ffn_dim = _pad_to(ffn_true, P_BLOCK_SIZE)
    seq_len = _pad_to(seq_true, P_BLOCK_SIZE)
    attn_dim = _pad_to(attn_dim_true, _head_mult)
    # Head counts derive from attention dimensions, matching launch.py.
    n_heads = attn_dim // head_dim
    n_kv_heads = kv_dim // head_dim
    vocab_pad = _pad_to(vocab_true, _vocab_mult) if vocab_true is not None else None
    # ----------------------------------------------------------------------- #
    kv_len_per_pe = seq_len // P_BLOCK_SIZE
    prefill_len_per_pe = prefill_len // P_BLOCK_SIZE
    # One logical layer slice per block row; the two physical X blocks are
    # its ATTN/FFN roles rather than independent pipeline blocks.
    N_blocks = P_Y_BLOCK_NUM

    # Layer distribution across blocks — must match launch.distribute_layers.
    layer_counts, layer_offsets = _distribute_layers(n_layers, N_blocks)

    # Per-global-layer weights + per-batch cache state. XKCache shape
    # (bsz, kv_dim, seq_len); XVCache shape (bsz, seq_len, kv_dim). Keyed by
    # global layer index since each global layer lives in exactly one block.
    weights_by_l = {}
    XK_by_l = {}
    XV_by_l = {}
    for gl in range(n_layers):
        w = _gen_block_weights(gl, dim=dim, kv_dim=kv_dim,
                               ffn_dim=ffn_dim, seq_len=seq_len,
                               head_dim=head_dim, P_BLOCK_SIZE=P_BLOCK_SIZE,
                               bsz=bsz, dim_true=dim_true, kv_dim_true=kv_dim_true,
                               ffn_true=ffn_true, seq_true=seq_true,
                               attn_dim=attn_dim, attn_dim_true=attn_dim_true)
        weights_by_l[gl] = w
        XK_by_l[gl] = w["XKCache"].copy()
        XV_by_l[gl] = w["XVCache"].copy()

    # Per-(global layer, PE) iter_num state.
    iter_num_state = {
        gl: [prefill_len_per_pe] * P_BLOCK_SIZE for gl in range(n_layers)
    }

    # Qwen3 RoPE per-step cos/sin: position `prefill_len + s` for step s,
    # shared across all layers since inv_freq is layer-invariant.
    inv_freq = _qwen3_inv_freq(head_dim)              # fp64
    positions = prefill_len + np.arange(max_output_len, dtype=np.float64)
    angles = positions[:, None] * inv_freq[None, :]    # (max_output_len, head_dim/2)
    # Cast to fp16 to match the kernel's path: f32 state → f16 working buffer.
    cos_table = np.cos(angles).astype(ml_dtypes.bfloat16)
    sin_table = np.sin(angles).astype(ml_dtypes.bfloat16)

    logits_per_step = []  # post-lm_head logits (bsz, vocab) per step, EVERY step
    # X[0] = W_E[cfg['token_ids']] (host pre-embed via demux→head C1 path).
    # X[s>=1] = W_E[next_token_{s-1}] — autoregressive close. next_token is the
    # device's on-chip sampled token (forced_tokens) when supplied, else
    # argmax(logits) at the end of step s-1, with logits = norm(Z) @ W_lm_head.T.
    # Final Qwen3 RMSNorm weight — applied at the end of every step before
    # the host sees Z. Must match launch._gen_W_final_norm_tile_array (seed 2028).
    W_final_norm = _gen_W_final_norm(dim, dim_true=dim_true)

    vocab_size = vocab_pad
    W_lm_head = None
    if vocab_size is not None:
        W_E = _gen_W_E(vocab_size, dim, vocab_true=vocab_true, dim_true=dim_true)
        W_lm_head = _gen_W_lm_head(vocab_size, dim, vocab_true=vocab_true, dim_true=dim_true)
        token_ids = cfg.get("token_ids", [0] * bsz)
        assert len(token_ids) == bsz, (
            f"token_ids length {len(token_ids)} != bsz {bsz}"
        )
        X_block = np.stack([W_E[t] for t in token_ids], axis=0).astype(ml_dtypes.bfloat16)
    else:
        # Configs without vocab_size: skip W_E lookup, seed X[0] to zeros and
        # use Z-feedback for s>=1.
        X_block = np.zeros((bsz, dim), dtype=ml_dtypes.bfloat16)
    pred_token = None  # set at end of each step from argmax(logits); fed into next step
    for s in range(max_output_len):
        if s >= 1:
            # Autoregressive feed. With on-chip sampling the device sequence
            # diverges from greedy, so replay the device's sampled token when
            # provided (forced_tokens[s-1]); else fall back to the oracle argmax.
            step_in_tok = forced_tokens[s - 1] if forced_tokens is not None else pred_token
            if step_in_tok is not None:
                X_block = np.stack(
                    [W_E[int(step_in_tok[b])] for b in range(bsz)],
                    axis=0,
                ).astype(ml_dtypes.bfloat16)
        # else: s==0 uses pre-built X_block (W_E[token_ids]); s>=1 without
        # vocab_size falls through to Z-feedback below.
        owning_px = s % P_BLOCK_SIZE
        cos_step = cos_table[s]
        sin_step = sin_table[s]
        for b in range(N_blocks):
            X = X_block.copy()
            for local_l in range(layer_counts[b]):
                gl = layer_offsets[b] + local_l
                w = weights_by_l[gl]

                # process_kv: compute K_step / V_step for all batches, write
                # each batch's slice into its own cache slab at owning PE's
                # current iter_num col, then bump iter_num (shared).
                col_in_pe = iter_num_state[gl][owning_px]
                if col_in_pe < kv_len_per_pe:
                    K_step, V_step = _compute_kv_step(
                        X, w, n_kv_heads=n_kv_heads, head_dim=head_dim,
                        dim=dim, kv_dim=kv_dim,
                        cos_step=cos_step, sin_step=sin_step, true_dim=dim_true)
                    decoded_col = owning_px * kv_len_per_pe + col_in_pe
                    XK_by_l[gl][:, :, decoded_col] = K_step
                    XV_by_l[gl][:, decoded_col, :] = V_step
                    iter_num_state[gl][owning_px] += 1

                # Build mask from the (post-bump) iter_num state.
                valid_mask = _build_valid_mask(
                    iter_num_state[gl], kv_len_per_pe, P_BLOCK_SIZE, seq_len)

                X = _layer_body(X, w, XK_by_l[gl], XV_by_l[gl],
                                valid_mask, dim=dim, kv_dim=kv_dim,
                                head_dim=head_dim, n_heads=n_heads,
                                n_kv_heads=n_kv_heads, ffn_dim=ffn_dim,
                                seq_len=seq_len, attn_dim=attn_dim,
                                cos_step=cos_step, sin_step=sin_step, true_dim=dim_true)
            X_block = X
        # Final Qwen3 RMSNorm on the last hidden state, mirroring HT_tail's
        # tail_final_rmsnorm. norm(Z) is the lm_head input, not host-visible.
        X_block = _rmsnorm(X_block, W_final_norm, dim_true)
        # Autoregressive close: lm_head matvec on norm(Z), then argmax for the
        # next-step feed. Both paths use fp32 accumulation, but their operation
        # order and approximations can still differ on close logits.
        # Device emits logits every step (mux stream); collect logits[bsz, vocab]
        # per step. The argmax feed is only needed for s < max_output_len-1.
        if W_lm_head is not None:
            logits = (X_block.astype(ml_dtypes.bfloat16) @ W_lm_head.T.astype(ml_dtypes.bfloat16)).astype(ml_dtypes.bfloat16)
            # Mask padded (dummy) vocab ids >= vocab_true so they can never win
            # argmax/top-K (mirrors the device's vocab_pad_count masking). No-op
            # when vocab is not padded.
            if vocab_pad is not None and vocab_true is not None and vocab_pad > vocab_true:
                logits[:, vocab_true:] = NEG_INF_F16
            logits_per_step.append(logits.copy())
            if s < max_output_len - 1:
                pred_token = np.argmax(logits, axis=1).astype(np.int32)
    logits_stack = (np.stack(logits_per_step, axis=0)  # (max_output_len, bsz, vocab)
                    if W_lm_head is not None else None)
    return logits_stack
