#!/usr/bin/env python3
"""Build a forced-prefill request config from a free run's records.

Reads the free run's device_records.npz (round0_sampled, shape (N, bsz)) and
the free request config, and writes a new request config with FORCED_TOKENS =
the sampled sequence (first N-1 tokens per lane; the head consumes tokens at
steps 1..N-1, which are the tail's emissions at free steps 0..N-2).

Usage:
  python3 scripts/make_forced_request.py <free_records.npz> <free_request.json> <out_request.json>
"""
import json
import sys

import numpy as np


def main():
    rec_path, req_path, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
    rec = np.load(rec_path)
    req = json.load(open(req_path))
    sampled = rec["round0_sampled"]           # (N, bsz) int32
    n, bsz = sampled.shape
    assert len(req["token_ids"]) == bsz, (req["token_ids"], bsz)
    budget = int(req["DECODE_LENS"][0])
    assert n == budget, (
        f"free run generated {n} != budget {budget} — early EOS stop? "
        f"forced mode assumes a full-budget reference")
    # STOP_TOK (-2) or negatives must never appear in a full-budget reference.
    assert int(sampled.min()) >= 0, "negative token id in reference records"
    forced = [[int(t) for t in sampled[: n - 1, b]] for b in range(bsz)]
    out = dict(req)
    out["FORCED_TOKENS"] = forced
    json.dump(out, open(out_path, "w"))
    print(f"wrote {out_path}: {len(forced)} lane(s) x {len(forced[0])} tokens")


if __name__ == "__main__":
    main()
