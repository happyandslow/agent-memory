#!/usr/bin/env bash
# Usage: ./run_sim.sh [model.json] [request.json] [launch_sim.py options]
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODEL="${1:-${HERE}/model_config/sim_2x2_bsz2.json}"
REQUEST="${2:-${HERE}/request_config/sim_varlen.json}"

case "$(basename "$MODEL")" in
    sim_*) ;;
    *)
        echo "ERROR: run_sim.sh requires a sim_*.json model" >&2
        echo "       Got: $(basename "$MODEL")" >&2
        exit 1
        ;;
esac

# Set SIMFAB_TRACE=1 only when GUI traces are required.
: "${SIMFAB_TRACE:=0}"
[ "$SIMFAB_TRACE" = "1" ] || export SINGULARITYENV_CSL_SUPPRESS_SIMFAB_TRACE=1

cd "$HERE"
exec cs_python launch_sim.py \
    --model "$MODEL" \
    --request "$REQUEST" \
    "${@:3}"
