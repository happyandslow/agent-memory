# `sram_p128_l5.json` — measurement scaffold, NOT a deployable config

Compile-only, to read the per-PE SRAM report for layout C's shard parameters.

`P_BLOCK_SIZE = Pw / P_X_BLOCK_NUM = 128` with the default square height, so every
existing assert passes and **no launcher code is changed**.

It over-estimates layout C deliberately, in three independent ways:

| | this config | layout C | direction |
|---|--:|--:|---|
| `dim_per_pe` | 20 | 10 (A2) / 20 (A1, A3) | A2 over by 2x |
| `kv_len_per_pe` | MAX_SEQ/128 | MAX_SEQ/256 | over by 2x |
| role image | vanilla ATTN carries `st_attn_head` **and** `st_attn_tail` | A1 is head-only, A2 is tail-only | over by the sum |

`attn_per_pe = 32`, `kv_cols = 8`, `ffn_dim_per_pe = 76` and
`max_layers_per_block = 5` are **exact** matches for layout C.

**So: if it fits here, it fits in layout C.**

`vocab_size` is shrunk to 2048 because HT_head's embedding table is
`2*vocab*dim/P^2` per PE and blows up at P=128 (`launch.py:254-256`).
`decode.csl` never reads `vocab`, so this does not affect the number being
measured — but it does mean **the HT_head/HT_tail rows of the report are
meaningless in this build** and must be ignored.
