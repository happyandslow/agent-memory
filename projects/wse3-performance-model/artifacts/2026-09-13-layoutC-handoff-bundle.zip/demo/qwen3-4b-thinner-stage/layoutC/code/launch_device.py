#!/usr/bin/env python3
"""Stage one model/request pair and launch it on WSE-3."""
import argparse
import os
import shutil
from pathlib import Path

from cerebras.sdk.client import SdkLauncher


HERE = Path(__file__).parent.resolve()

# Complete worker-side source closure.
FILES_TO_STAGE = [
    "launch.py",
    "host/oracle_fp16.py",
    "host/route_table.py",
    "src/approx_math.csl",
    "src/decode.csl",
    "src/prof_tsc.csl",
    "src/decode_strip.csl",
    "src/decode_strip_pe.csl",
    "src/funnel_pe.csl",
    "src/route_calc.csl",
    "src/route_util.csl",
    "src/comm_lib/comm_pe.csl",
    "src/mux.csl",
    "src/demux.csl",
    "src/kv_ingress_adaptor.csl",
    "src/kv_ingress_injector.csl",
    "src/kv_fwd.csl",
    "src/ht_head.csl",
    "src/ht_tail.csl",
    "scripts/cslc_bin/bin/cslc-driver",
]


def parse_args():
    p = argparse.ArgumentParser(
        description="Control-node entry: SdkLauncher -> cs_python launch.py on worker.")
    p.add_argument("--model", required=True,
                   help="Path to model_config/*.json (relative or absolute).")
    p.add_argument("--request", required=True,
                   help="Path to request_config/*.json (relative or absolute).")
    p.add_argument("--name", default=None,
                   help="Worker artifact directory. Default: out_<model>__<request>.")
    p.add_argument("--cslc-prefix", type=str, default="")
    p.add_argument("--compile-only", action="store_true",
                   help="Forward --compile-only to the worker launch.py (build/placement smoke; skip run).")
    p.add_argument("--route-table", action="store_true", help="Forward --route-table to the worker launch.py.")
    p.add_argument("--route-check", action="store_true", help="Forward --route-check to the worker launch.py.")
    p.add_argument("--legacy-init", action="store_true", help="Forward --legacy-init (original on-device route derivation).")
    p.add_argument("--shared-reduce-len", action="store_true", help="Forward --shared-reduce-len.")
    p.add_argument("--dump-records", action="store_true", help="Forward --dump-records (device_records.npz).")
    p.add_argument("--forced-variant", action="store_true", help="Forward --forced-variant (step-1b serial-handshake diagnostic).")
    p.add_argument("--msize", action="store_true", help="Forward --msize (worker-side cs-readelf -m -> msize.txt).")
    p.add_argument("--prof-block-tsc", action="store_true", help="Forward --prof-block-tsc (block_prof.npz).")
    p.add_argument("--prof-broken", action="store_true", help="Forward --prof-broken (negative control).")
    p.add_argument("--diag-a1-stub", type=int, default=0, help="Forward --diag-a1-stub N.")
    p.add_argument("--prof-ring", type=int, default=None, help="Forward --prof-ring N.")
    p.add_argument("--prof-row", type=int, default=None, help="Forward --prof-row N.")
    p.add_argument("--prof-shift", type=int, default=None, help="Forward --prof-shift N.")
    p.add_argument("--pull", action="store_true",
                   help="After the run, download run_summary.json, device_records.npz, msize.txt, sim.map, "
                        "colors.json and executables/*.elf into ./<name>/.")
    p.add_argument("--staging", default=None,
                   help="Local staging directory. Default: device_staging_<model>__<request>.")
    args = p.parse_args()
    pair = f"{Path(args.model).stem}__{Path(args.request).stem}"
    if args.name is None:
        args.name = f"out_{pair}"
    if args.staging is None:
        args.staging = f"device_staging_{pair}"
    return args


def main():
    args = parse_args()
    os.chdir(HERE)  # so relative FILES_TO_STAGE paths resolve

    model_path = Path(args.model).resolve()
    request_path = Path(args.request).resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"Model config not found: {args.model}")
    if not request_path.is_file():
        raise FileNotFoundError(f"Request config not found: {args.request}")
    for f in FILES_TO_STAGE:
        if not (HERE / f).is_file():
            raise FileNotFoundError(f"Missing source: {f}")

    staging_dir = HERE / args.staging
    if staging_dir.exists():
        shutil.rmtree(staging_dir)
    staging_dir.mkdir(parents=True)
    for f in FILES_TO_STAGE:
        dst = staging_dir / f
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(HERE / f, dst)

    staged_model_rel = f"model_config/{model_path.name}"
    staged_request_rel = f"request_config/{request_path.name}"
    (staging_dir / "model_config").mkdir(parents=True, exist_ok=True)
    (staging_dir / "request_config").mkdir(parents=True, exist_ok=True)
    shutil.copy2(model_path, staging_dir / staged_model_rel)
    shutil.copy2(request_path, staging_dir / staged_request_rel)

    extra = f"--cslc-prefix {args.cslc_prefix} " if args.cslc_prefix else ""
    if args.compile_only:
        extra += "--compile-only "
    for flag in ("route_table", "route_check", "legacy_init", "shared_reduce_len", "dump_records",
                 "msize", "forced_variant", "prof_block_tsc", "prof_broken"):
        if getattr(args, flag):
            extra += "--" + flag.replace("_", "-") + " "
    for flag in ("diag_a1_stub",):
        if getattr(args, flag, 0):
            extra += f"--{flag.replace('_', '-')} {getattr(args, flag)} "
    for flag in ("prof_ring", "prof_row", "prof_shift"):
        if getattr(args, flag) is not None:
            extra += f"--{flag.replace('_', '-')} {getattr(args, flag)} "
    run_cmd = (
        f"cs_python launch.py "
        f"--model {staged_model_rel} "
        f"--request {staged_request_rel} "
        f"--name {args.name} "
        f"{extra}"
        f"--cmaddr %CMADDR%"
    )

    print("=== qwen3_4b on-chip pipeline: Appliance Launcher ===")
    print(f"Model        : {model_path}")
    print(f"Request      : {request_path}")
    print(f"Staging dir  : {staging_dir}")
    print(f"Run command  : {run_cmd}")
    print()

    with SdkLauncher(str(staging_dir), disable_version_check=True) as launcher:
        response = launcher.run(run_cmd)
        if args.pull:
            result_dir = HERE / args.name
            if result_dir.exists():
                shutil.rmtree(result_dir)
            (result_dir / "executables").mkdir(parents=True)
            wanted = ["run_summary.json", "device_records.npz", "block_prof.npz", "msize.txt",
                      "sim.map", "colors.json", "plan.json", "executables.tgz"]
            for name in wanted:
                remote = f"{args.name}/{name}"
                local = str(result_dir / name)
                try:
                    launcher.download_artifact(remote, local)
                    print(f"Downloaded  : {remote}")
                except Exception as e:  # keep pulling the rest
                    print(f"Download FAILED: {remote}: {e}")

    print("Appliance response:")
    print(response)


if __name__ == "__main__":
    main()
