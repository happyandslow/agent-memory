#!/usr/bin/env python3
"""Dependency-free numerical gates for src/approx_math.csl.

Two routes evaluate the same exp polynomial and must be gated together:

  * the scalar route, ``approx_math.exp_neg_f32``, used by the HT tail and by
    the unaligned prologue/tail of ``decode.csl:softmax_exp_slot``;
  * the SIMD route, the DSD chain inside ``softmax_exp_slot`` itself.

They differ in how the range-reduction integer ``n`` is formed: the scalar
route truncates with ``@as(i16, .)`` and pre-biases by -0.5, the SIMD route
uses ``@fs2xp16``, which already rounds to nearest and therefore carries no
bias. Gating only one route hides a mismatch between them, and the mismatch is
what a slot-crossing softmax actually experiences.
"""

import math
import random
import struct


EXP_RELERR_BUDGET = 1.1e-4
SEAM_RELERR_BUDGET = 2.2e-4
SOFTMAX_TV_BUDGET = 2.0e-4
SAMPLING_TV_BUDGET = 2.0e-4
SWEEP_POINTS = 1_000_001
REGRESSION_SWEEP_POINTS = 20_001
SOFTMAX_LEN = 16_384


def f32(value):
    return struct.unpack(">f", struct.pack(">f", float(value)))[0]


def f32_bits(value):
    return struct.unpack(">I", struct.pack(">f", f32(value)))[0]


def bits_f32(value):
    return struct.unpack(">f", struct.pack(">I", value & 0xFFFFFFFF))[0]


def bf16_scale_f32(n):
    """Mirror SIMD path: bf16 bits (n+127)<<7, then bf16-to-f32 widen."""
    bf16_bits = (n + 127) << 7
    return bits_f32(bf16_bits << 16)


def f32_scale(n):
    """Mirror scalar path: f32 bits (n+127)<<23."""
    return bits_f32((n + 127) << 23)


EXP_MIN = f32(-32.0)
LOG2E = f32(1.4426950408889634)
LN2 = f32(0.6931471805599453)
C = tuple(map(f32, (
    0.999924556951,
    0.999984928632,
    0.505022284214,
    0.167670118752,
)))


def rint_ties_even(value):
    """Round to nearest, ties to even."""
    return int(round(f32(value)))


def rint_ties_away(value):
    """Round to nearest, ties away from zero."""
    x = f32(value)
    return int(math.floor(x + 0.5)) if x >= 0.0 else int(math.ceil(x - 0.5))


def n_scalar(x):
    """approx_math.exp_neg_f32: @as(i16, .) truncates toward zero, so the
    -0.5 bias is what turns it into round-to-nearest over x <= 0."""
    return int(f32(f32(x * LOG2E) - f32(0.5)))


def n_simd(x, rint=rint_ties_even):
    """decode.csl softmax_exp_slot: @fs2xp16 rounds to nearest, no bias."""
    return rint(f32(x * LOG2E))


def n_simd_double_rounded(x, rint=rint_ties_even):
    """The SIMD route as it shipped before 2026-07-31: the scalar route's -0.5
    bias fed into a builtin that already rounds, i.e. rounded twice. Retained
    only so the gates below can demonstrate that they discriminate against it."""
    return rint(f32(f32(x * LOG2E) - f32(0.5)))


def exp_remainder_and_poly(x, n):
    r = f32(x - f32(f32(n) * LN2))
    p = C[3]
    p = f32(C[2] + f32(r * p))
    p = f32(C[1] + f32(r * p))
    p = f32(C[0] + f32(r * p))
    return r, p


def exp_neg_f32(value):
    """Scalar route: n by biased truncation, exponent rebuilt in f32."""
    x = max(f32(value), EXP_MIN)
    n = n_scalar(x)
    _, p = exp_remainder_and_poly(x, n)
    return f32(f32_scale(n) * p)


def exp_neg_f32_simd(value, n_fn=n_simd):
    """SIMD route: n by @fs2xp16, exponent rebuilt in bf16 then widened."""
    x = max(f32(value), EXP_MIN)
    n = n_fn(x)
    _, p = exp_remainder_and_poly(x, n)
    return f32(bf16_scale_f32(n) * p)


def rsqrt_f32(value):
    x = f32(value)
    y = bits_f32(0x5F3759DF - (f32_bits(x) >> 1))
    for _ in range(3):
        yy = f32(y * y)
        half_xyy = f32(f32(0.5 * x) * yy)
        y = f32(y * f32(1.5 - half_xyy))
    return y


def recip_f32(value):
    x = f32(value)
    y = bits_f32(0x7EF127EA - f32_bits(x))
    for _ in range(4):
        y = f32(y * f32(2.0 - f32(x * y)))
    return y


def ulp_distance(lhs, rhs):
    return abs(f32_bits(lhs) - f32_bits(rhs))


def softmax(values, approximate):
    exps = [
        exp_neg_f32(x) if approximate else f32(math.exp(f32(x)))
        for x in values
    ]
    total = f32(0.0)
    for value in exps:
        total = f32(total + value)
    inv = recip_f32(total) if approximate else f32(1.0 / total)
    return [f32(value * inv) for value in exps]


def nucleus_distribution(logits, temperature, top_p, approximate):
    zmax = logits[0] / temperature
    shifted = [f32(value / temperature - zmax) for value in logits]
    probs = softmax(shifted, approximate)
    cumulative = f32(0.0)
    n = 1
    for i, prob in enumerate(probs):
        cumulative = f32(cumulative + prob)
        n = i + 1
        if cumulative >= top_p:
            break
    inv_c = recip_f32(cumulative) if approximate else f32(1.0 / cumulative)
    return [f32(probs[i] * inv_c) if i < n else 0.0 for i in range(len(probs))]


def total_variation(lhs, rhs):
    return 0.5 * sum(abs(a - b) for a, b in zip(lhs, rhs))


def sweep_x(points):
    for i in range(points):
        yield f32(EXP_MIN + (0.0 - EXP_MIN) * i / (points - 1))


def main():
    # (a) The bf16 and f32 exponent reconstructions must agree bit-for-bit over
    # every n either route can produce on the clamped domain [-32, 0].
    for n in range(-47, 1):
        assert f32_bits(bf16_scale_f32(n)) == f32_bits(f32_scale(n)), n

    half_ln2 = math.log(2.0) / 2.0
    exact_cache = {}

    max_relerr_scalar = 0.0
    worst_x_scalar = 0.0
    max_relerr_simd = 0.0
    worst_x_simd = 0.0
    max_seam_relerr = 0.0
    worst_x_seam = 0.0
    r_min_scalar = math.inf
    r_max_scalar = -math.inf
    r_min_simd = math.inf
    r_max_simd = -math.inf

    for x in sweep_x(SWEEP_POINTS):
        exact = math.exp(x)
        exact_cache[x] = exact

        ns = n_scalar(x)
        r_s, _ = exp_remainder_and_poly(x, ns)
        r_min_scalar = min(r_min_scalar, r_s)
        r_max_scalar = max(r_max_scalar, r_s)

        # Both tie conventions are checked: upstream does not document
        # @fs2xp16's tie rule and the probe did not pin it down, so the range
        # bound must hold under either.
        for rint in (rint_ties_even, rint_ties_away):
            nv = n_simd(x, rint)
            r_v, _ = exp_remainder_and_poly(x, nv)
            r_min_simd = min(r_min_simd, r_v)
            r_max_simd = max(r_max_simd, r_v)

        scalar = exp_neg_f32(x)
        simd = exp_neg_f32_simd(x)

        relerr_scalar = abs(scalar / exact - 1.0)
        if relerr_scalar > max_relerr_scalar:
            max_relerr_scalar = relerr_scalar
            worst_x_scalar = x

        relerr_simd = abs(simd / exact - 1.0)
        if relerr_simd > max_relerr_simd:
            max_relerr_simd = relerr_simd
            worst_x_simd = x

        # The seam gate. softmax_exp_slot mixes a scalar prologue, a SIMD body
        # and a scalar tail inside one slot, so the two routes must agree
        # element-for-element; whole-route accuracy alone does not imply it.
        seam = abs(simd - scalar) / exact
        if seam > max_seam_relerr:
            max_seam_relerr = seam
            worst_x_seam = x

    assert r_min_scalar >= -half_ln2 - 3.0e-6, (r_min_scalar, -half_ln2)
    assert r_max_scalar <= half_ln2 + 3.0e-6, (r_max_scalar, half_ln2)
    assert r_min_simd >= -half_ln2 - 3.0e-6, (r_min_simd, -half_ln2)
    assert r_max_simd <= half_ln2 + 3.0e-6, (r_max_simd, half_ln2)
    assert max_relerr_scalar <= EXP_RELERR_BUDGET, (max_relerr_scalar, worst_x_scalar)
    assert max_relerr_simd <= EXP_RELERR_BUDGET, (max_relerr_simd, worst_x_simd)
    assert max_seam_relerr <= SEAM_RELERR_BUDGET, (max_seam_relerr, worst_x_seam)

    # (b) Prove the gates discriminate. The double-rounded SIMD variant is the
    # code that shipped to device before 2026-07-31; measured on Gala2 at
    # 4.047e-03 max relative error against a 1.1e-4 budget. If this assertion
    # ever stops firing, the gates above have lost their teeth.
    max_relerr_regression = 0.0
    for x in sweep_x(REGRESSION_SWEEP_POINTS):
        value = exp_neg_f32_simd(x, n_simd_double_rounded)
        max_relerr_regression = max(
            max_relerr_regression, abs(value / math.exp(x) - 1.0))
    assert max_relerr_regression > EXP_RELERR_BUDGET, max_relerr_regression

    rng = random.Random(20260728)
    softmax_cases = {
        "floor": [0.0] + [-40.0] * (SOFTMAX_LEN - 1),
        "range_edges": [0.0] + [
            -(half_ln2 + (i % 46) * math.log(2.0))
            for i in range(SOFTMAX_LEN - 1)
        ],
        "uniform": [0.0] + [rng.uniform(-40.0, 0.0) for _ in range(SOFTMAX_LEN - 1)],
        "gaussian": [0.0] + [-abs(rng.gauss(0.0, 6.0)) for _ in range(SOFTMAX_LEN - 1)],
    }
    softmax_tv = {}
    for name, values in softmax_cases.items():
        tv = total_variation(softmax(values, False), softmax(values, True))
        assert tv <= SOFTMAX_TV_BUDGET, (name, tv)
        softmax_tv[name] = tv

    max_rsqrt_ulp = 0
    max_recip_ulp = 0
    for i in range(200_001):
        exponent = -6.0 + 12.0 * i / 200_000
        x = f32(10.0 ** exponent)
        max_rsqrt_ulp = max(max_rsqrt_ulp, ulp_distance(rsqrt_f32(x), f32(1.0 / math.sqrt(x))))
        max_recip_ulp = max(max_recip_ulp, ulp_distance(recip_f32(x), f32(1.0 / x)))
    assert max_rsqrt_ulp <= 2, max_rsqrt_ulp
    assert max_recip_ulp <= 1, max_recip_ulp

    max_sampling_tv = 0.0
    for _ in range(2000):
        logits = sorted((rng.uniform(-12.0, 12.0) for _ in range(20)), reverse=True)
        exact = nucleus_distribution(logits, 0.6, 0.95, False)
        approx = nucleus_distribution(logits, 0.6, 0.95, True)
        max_sampling_tv = max(max_sampling_tv, total_variation(exact, approx))
    assert max_sampling_tv <= SAMPLING_TV_BUDGET, max_sampling_tv

    print(
        "PASS approx_math:",
        "bf16_scale_bitexact=True",
        f"exp_scalar_max_relerr={max_relerr_scalar:.9g}@x={worst_x_scalar:.9g}",
        f"exp_simd_max_relerr={max_relerr_simd:.9g}@x={worst_x_simd:.9g}",
        f"seam_max_relerr={max_seam_relerr:.9g}@x={worst_x_seam:.9g}",
        f"double_rounded_regression_relerr={max_relerr_regression:.9g}",
        f"remainder_scalar=[{r_min_scalar:.9g},{r_max_scalar:.9g}]",
        f"remainder_simd=[{r_min_simd:.9g},{r_max_simd:.9g}]",
        f"rsqrt_max_ulp={max_rsqrt_ulp}",
        f"recip_max_ulp={max_recip_ulp}",
        f"sampling_max_tv={max_sampling_tv:.9g}",
        "softmax_tv=" + ",".join(f"{k}:{v:.9g}" for k, v in softmax_tv.items()),
    )


if __name__ == "__main__":
    main()
