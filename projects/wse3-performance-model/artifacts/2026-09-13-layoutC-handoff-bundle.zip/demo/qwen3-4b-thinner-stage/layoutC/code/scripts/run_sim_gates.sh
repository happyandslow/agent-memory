#!/usr/bin/env bash
# Step-1 sim gates (run from the tree root, after out_sim_free exists):
#   GATE 1  forced sim records byte-identical to the free sim's
#   GATE 2  negative control: one corrupted forced token -> records MUST diverge
#
# 2026-09-09 — this script previously ALWAYS EXITED 0. Its last statement was an
# `echo`, so the script's status was the echo's, never a gate's; `set -e` was
# absent so a failing `cs_python` did not stop it; and neither gate's outcome was
# asserted, only printed. Combined with a comparator that passed on two empty
# archives, the whole gate could report success having compared nothing. Found by
# Codex plan review while auditing the layout-C refactor plan, which depends on
# this script for its Stage 1 byte-identity gate.
#
# Now: every step is asserted, the script exits non-zero on any failure, and the
# negative control is a POSITIVE assertion (`--expect divergent`) rather than an
# exit code the caller is trusted to interpret.
#
# K1 (2026-09-09): compare_records.py refusing an empty archive is not the same
# as an archive holding the round content a run was supposed to produce — a run
# that emitted 3 rounds instead of 8 still "compares identical" against another
# run that failed the same way. `check_records.py` closes that gap and runs on
# every archive before it is compared.
set -euo pipefail

# cs_python runs inside Singularity: env must use the SINGULARITYENV_ prefix.
export SINGULARITYENV_CSL_SUPPRESS_SIMFAB_TRACE=1 SINGULARITYENV_DUMP_RECORDS=1 DUMP_RECORDS=1

FAILED=0
step() { printf '\n=== %s ===\n' "$1"; }
check() {                      # check <name> <expected-rc> <cmd...>
    local name=$1 want=$2; shift 2
    local rc=0
    "$@" || rc=$?
    if [ "$rc" -eq "$want" ]; then
        printf '%s: PASS (rc=%d)\n' "$name" "$rc"
    else
        printf '%s: FAIL (rc=%d, expected %d)\n' "$name" "$rc" "$want"
        FAILED=1
    fi
}
need_records() {               # the run must actually have produced records
    [ -s "$1" ] || { printf 'MISSING/EMPTY: %s\n' "$1"; FAILED=1; return 1; }
}

MODEL=model_config/sim_2x2_bsz1.json
BASE=out_sim_free/device_records.npz
step "precondition"
need_records "$BASE" || { echo "OVERALL: FAIL (no baseline)"; exit 1; }
check "CHECK(baseline-records)" 0 \
    python3 scripts/check_records.py "$BASE" \
    --request request_config/sim_rearm.json --model "$MODEL"

step "build the forced request from the free run"
python3 scripts/make_forced_request.py "$BASE" \
    request_config/sim_rearm.json request_config/sim_rearm_forced.json

step "GATE 1 — forced run must reproduce the free run byte-for-byte"
cs_python launch_sim.py --model "$MODEL" \
    --request request_config/sim_rearm_forced.json --name out_sim_forced
if need_records out_sim_forced/device_records.npz; then
    check "CHECK(forced-records)" 0 \
        python3 scripts/check_records.py out_sim_forced/device_records.npz \
        --request request_config/sim_rearm_forced.json --model "$MODEL"
    check "GATE1(identity)" 0 \
        python3 scripts/compare_records.py "$BASE" out_sim_forced/device_records.npz \
        --expect identical
fi

step "GATE 2 — corrupt one forced token; records MUST diverge"
python3 - <<'EOF'
import json
req = json.load(open("request_config/sim_rearm_forced.json"))
seq = req["FORCED_TOKENS"][0]
seq[10] = (seq[10] + 1) % 24   # corrupt one token (vocab 24)
json.dump(req, open("request_config/sim_rearm_negctl.json", "w"))
print("negctl: corrupted forced token at step index 10")
EOF

cs_python launch_sim.py --model "$MODEL" \
    --request request_config/sim_rearm_negctl.json --name out_sim_negctl
if need_records out_sim_negctl/device_records.npz; then
    check "CHECK(negctl-records)" 0 \
        python3 scripts/check_records.py out_sim_negctl/device_records.npz \
        --request request_config/sim_rearm_negctl.json --model "$MODEL"
    check "GATE2(negative-control)" 0 \
        python3 scripts/compare_records.py "$BASE" out_sim_negctl/device_records.npz \
        --expect divergent
fi

step "GATE 3 — the comparator itself must reject an empty archive"
readarray -t EMPTY < <(python3 - <<'EOF'
import numpy as np, tempfile, pathlib
d = pathlib.Path(tempfile.mkdtemp())
np.savez(d / "e1.npz"); np.savez(d / "e2.npz")
print(d / "e1.npz"); print(d / "e2.npz")
EOF
)
check "GATE3(comparator-self-test)" 2 \
    python3 scripts/compare_records.py "${EMPTY[0]}" "${EMPTY[1]}"

step "GATE 4 — the record checker itself must reject an incomplete archive"
readarray -t SHORT < <(python3 - <<'EOF'
import numpy as np, tempfile, pathlib
d = pathlib.Path(tempfile.mkdtemp())
# request_config/sim_rearm.json asks for 2 rounds; this archive has only 1.
np.savez(d / "short.npz",
         round0_sampled=np.zeros((3, 1), dtype=np.int32),
         round0_topk_args=np.zeros((3, 1, 2), dtype=np.int32),
         round0_topk_vals_u16=np.zeros((3, 1, 2), dtype=np.uint16))
print(d / "short.npz")
EOF
)
check "GATE4(checker-self-test)" 1 \
    python3 scripts/check_records.py "${SHORT[0]}" \
    --request request_config/sim_rearm.json --model "$MODEL"

printf '\n=== OVERALL: %s ===\n' "$([ "$FAILED" -eq 0 ] && echo PASS || echo FAIL)"
exit "$FAILED"
