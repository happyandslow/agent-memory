"""One-group geometry and static feature ownership for the unequal-height layout."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Geometry:
    width: int = 16
    a1: int = 10
    a2: int = 32
    a3: int = 20
    dim: int = 320
    attn: int = 512
    kv: int = 128
    head: int = 16
    ffn: int = 1216
    capacity: int = 224
    prefill: int = 160
    layers: int = 1

    @property
    def a3_origin(self):
        return self.a2 - self.a3

    def validate_feedback(self):
        self.validate()
        assert self.a3 == 2 * self.a1 and self.a2 % 2 == 0
        assert self.dim // self.a1 == 2 * (self.dim // self.a3)
        return self

    def height(self, stage):
        return (self.a1, self.a2, self.a3)[stage - 1]

    def validate(self):
        assert self.a1 <= self.width <= 2 * self.a1
        assert self.a1 + self.a3 <= self.a2
        assert self.layers > 0
        for h in (self.a1, self.a2, self.a3):
            assert self.dim % h == 0 and (self.dim // h) % 2 == 0
            assert self.prefill % h == 0
            assert h % y_group(h) == 0
        assert self.capacity % self.a2 == 0 and self.capacity > self.prefill
        assert self.attn % self.kv == 0 and self.kv % self.head == 0
        assert self.width % (self.kv // self.head) == 0
        assert self.ffn % self.width == 0
        assert all(
            i // (self.dim // self.a1)
            <= i // (self.dim // self.a2)
            <= self.a3_origin + i // (self.dim // self.a3)
            for i in range(self.dim)
        )
        return self


def y_group(height):
    # A group needs a left neighbor at its root; avoid the unsupported size-1 case.
    # Cap full-size X/Y groups at the 16-PE grouping used by the CS-3 attribution
    # baseline. Miniature geometry keeps its existing grouping.
    return min(16, height // 4) if height % 4 == 0 else 2


def full_geometry(layers=5):
    return Geometry(
        128, 80, 256, 160, 2560, 4096, 1024, 128, 9728, 8192, 1280, layers
    ).validate()
