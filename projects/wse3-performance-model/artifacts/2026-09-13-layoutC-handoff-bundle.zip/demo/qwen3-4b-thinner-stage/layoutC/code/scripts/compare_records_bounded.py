#!/usr/bin/env python3
"""Bounded-divergence gate between two device_records.npz files.

For geometries where byte-identity is impossible by construction (the cut
chain places layers on the opposite serpentine row parity, re-associating
the X-axis reduces), the gate is:
  - top-k IDS identical at every step of every round (hard gate), and
  - top-k VALUES within a bounded relative difference (reported; the run
    FAILS if max rel > --tol, default 5e-2).
Reports max abs / max rel value difference and the first step where the
raw records differ at all (informational).

Usage: compare_records_bounded.py <ref.npz> <test.npz> [--tol 5e-2]
Exit 0 iff ids identical everywhere and max rel <= tol.
"""
import sys

import numpy as np
import ml_dtypes


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    tol = 5e-2
    for a in sys.argv[1:]:
        if a.startswith("--tol"):
            tol = float(a.split("=", 1)[1]) if "=" in a else float(sys.argv[sys.argv.index(a) + 1])
    ref = np.load(args[0])
    test = np.load(args[1])
    rounds = sorted({k.split("_")[0] for k in ref.files})
    ok = True
    overall_rel = 0.0
    for r in rounds:
        ka, kv, ks = f"{r}_topk_args", f"{r}_topk_vals_u16", f"{r}_sampled"
        if ka not in test.files:
            print(f"{r}: not present in test run (informational; only common rounds gate)")
            continue
        n = min(ref[ka].shape[0], test[ka].shape[0])
        ids_same = np.array_equal(ref[ka][:n], test[ka][:n])
        fa = ref[kv][:n].view(ml_dtypes.bfloat16).astype(np.float32)
        fb = test[kv][:n].view(ml_dtypes.bfloat16).astype(np.float32)
        absd = np.abs(fa - fb)
        reld = absd / np.maximum(np.abs(fa), 1e-6)
        first_diff = None
        raw_diff = np.any(ref[kv][:n] != test[kv][:n], axis=(1, 2))
        if raw_diff.any():
            first_diff = int(np.argmax(raw_diff))
        samp_same = np.array_equal(ref[ks][:n], test[ks][:n])
        print(f"{r}: steps={n} ids {'IDENTICAL' if ids_same else 'DIFFER'} "
              f"sampled {'identical' if samp_same else 'differ'} "
              f"maxAbs={absd.max():.6f} maxRel={reld.max():.6f} "
              f"firstValDiffStep={first_diff}")
        if not ids_same:
            d = np.nonzero(ref[ka][:n] != test[ka][:n])
            print(f"   first id diff at step {d[0][0]}: ref {ref[ka][d[0][0],0]} vs test {test[ka][d[0][0],0]}")
            ok = False
        overall_rel = max(overall_rel, float(reld.max()))
    print(f"BOUNDED GATE: ids {'PASS' if ok else 'FAIL'}, maxRel={overall_rel:.6f} "
          f"(tol {tol}) -> {'PASS' if ok and overall_rel <= tol else 'FAIL'}")
    sys.exit(0 if ok and overall_rel <= tol else 1)


if __name__ == "__main__":
    main()
