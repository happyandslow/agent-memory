# qwen3_4b-decode

Qwen3-4B autoregressive decode for WSE-3 and SDK 2.10.0. SdkLayout wires
embedding, role-split transformer rows, final RMSNorm, lm_head, top-K, sampling,
and KV ingress into one on-wafer pipeline.

The checked-in host uses deterministic mock weights and an fp16 oracle. It
validates the execution protocol; it is not a checkpoint loader. A production
port must replace weight generation and request ingestion without changing the
KV metadata, re-arm, EOS/STOP, or output-record contracts.

## Configuration

`model_config` contains compile-time geometry, tensor sizes, capacity, sampling
policy, and EOS settings. `request_config` contains runtime prefill rounds and
seed token IDs. Launchers require both files explicitly.

Retained profiles:

- `device_2x4_8k.json` + `device_prefill4k.json`: sole device profile,
  8K capacity with 4K prefill and 4K decode.
- `sim_2x2_bsz2.json` + `sim_varlen.json`: default multi-batch, variable-prefill,
  multi-round, and forced KV-segmentation gate.
- `sim_2x2_bsz1.json` + `sim_rearm.json`: re-arm regression geometry
  (`bsz=1`, prefill-per-PE=1).
- `sim_2x4_bsz2.json` + `sim_varlen.json`: cross-row strip/K-pipe gate.
- `sim_2x2_longkv.json` + `sim_longkv.json`: long-cache and repeated re-arm gate.

All model files use the same field order. Request files contain parallel
`PREFILL_LENS` and `DECODE_LENS` arrays plus a `token_ids` list matching the
model batch size. Round `i` uses `PREFILL_LENS[i]` cache tokens and generates at
most `DECODE_LENS[i]` tokens; EOS may stop it earlier.

## Run

From this directory:

```bash
bash run_sim.sh
bash run_sim.sh model_config/sim_2x2_bsz1.json request_config/sim_rearm.json
bash run_sim.sh model_config/sim_2x4_bsz2.json request_config/sim_varlen.json
bash run_sim.sh model_config/sim_2x2_longkv.json request_config/sim_longkv.json
```

`run_sim.sh` compiles and runs simfab, then checks re-arm identity, streamed KV,
local top-K, and the numpy oracle. Useful options are forwarded after the two
config paths:

```bash
bash run_sim.sh model_config/sim_2x2_bsz2.json request_config/sim_varlen.json --compile-only
bash run_sim.sh model_config/sim_2x2_bsz2.json request_config/sim_varlen.json --prefill-len 8
SIMFAB_TRACE=1 bash run_sim.sh
```

Device operations should use the repository CS-3 runner workflow. The direct
EIDF control-node fallback is:

```bash
bash run_device.sh
```

Simulator and device artifacts are target-specific. Artifact and staging names
include both model and request basenames, so concurrent profiles do not collide.

Offline checks:

```bash
cs_python host/check_approx_math.py
python3 scripts/sram_report.py out_<model>__<request>
```

## Protocol invariants

- `P_X_BLOCK_NUM == 2`; block size and block-row count are even.
- Block size is at least 8 and divisible by the eight K-pipes.
- ATTN owns KV ingress/cache; FFN does not allocate those banks or tasks.
- Every fabric send/receive pair transfers the same number of wavelets.
- Finite KV fabric DSDs are at most 32766 wavelets and are segmented when needed.
- Output queues are flushed before runtime rebinding.
- Every round resets KV-derived state, RoPE, sampling state, EOS state, strips,
  demux, and mux before accepting the next request.
- EOS pads completed lanes; all-lane completion emits the STOP protocol that
  terminates every pipeline stage consistently.
- SdkLayout D2H records retain even-wavelet padding and end with one 8-u32 TSC
  burst.
- `run_summary.json` records per-round budgets, generated counts, re-arm checks,
  host timing, TSC, and simulator oracle diagnostics.

Performance history and per-step A/B gains are retained in
[`OPTIMIZATION_HISTORY.md`](OPTIMIZATION_HISTORY.md). Simulator results establish
functional behavior, not device liveness or performance.
