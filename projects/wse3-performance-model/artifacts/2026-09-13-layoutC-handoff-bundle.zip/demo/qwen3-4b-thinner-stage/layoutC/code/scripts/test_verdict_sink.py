#!/usr/bin/env cs_python
"""Seeded-defect suite for launch.py's K2 verdict sink (make_verdict_sink,
qkv_col_verdict_word, qkv_col_aggregate).

Per the checker plan: "a checker that has never been observed failing is not
evidence." The sink is a closure factory living inside launch.py, which
itself imports the Cerebras SDK bindings and so can only be *run* through a
simulator or device job -- driving all four real checks (KV-SEED,
ROUTE-CHECK, QKV-COL, LOCAL-TOPK) to a forced failure that way needs a full
compile + decode round each. The three checks only run once, after ALL
decode rounds finish, so a long decode budget buys nothing for this purpose
-- keep the request short (a handful of decode steps is enough to reach
them) regardless of how the box is behaving that day.

This suite is the labelled-synthetic supplement to real runs, not a
replacement for them: it imports launch.py (which DOES need `cs_python`,
hence the shebang and the guard below) and calls the exact functions run()
calls -- make_verdict_sink()'s record_verdict/finalize_checks, and the
QKV-COL classification helpers qkv_col_verdict_word/qkv_col_aggregate --
directly, in a fresh subprocess per case (so CHECK_ADVISORY and the raise
are observed as real process exit codes, the same signal `main()` and
run_sim.sh rely on). It does NOT exercise the read_symbol device-readback
that produces bad/_bad/npre/npost in the first place -- a real sim run
(via run_sim.sh, optionally with the matching `_TEST_FORCE_*_FAIL` /
`_TEST_FORCE_QKV_COL_INCONCLUSIVE` env var -- note run_sim.sh execs
cs_python inside Singularity, so a plain `VAR=1 ./run_sim.sh ...` will NOT
reach the check; it needs the `SINGULARITYENV_` prefix, e.g.
`SINGULARITYENV__TEST_FORCE_KV_SEED_FAIL=1 ./run_sim.sh ...`) is still
required to show those wired to real device state.

Run directly. This MUST be `cs_python`, not a bare `python3` -- launch.py's
module-level imports pull in the Cerebras SDK bindings, which only resolve
inside the SDK container. Run under the wrong interpreter and every one of
this suite's subprocesses would fail to import launch.py and traceback,
turning "wrong interpreter" into a false "0/N VERDICT: FAIL" that looks
exactly like a real defect -- exactly the kind of misleading verdict this
plan exists to prevent, now in the test suite itself. The guard below
catches that case up front and exits distinctly instead:

    cs_python scripts/test_verdict_sink.py

Exit codes:
  0  every case passed
  1  at least one case failed (a real result -- see the per-case output)
  3  wrong interpreter: launch.py could not be imported here at all, so no
     case was run and the suite is not reporting on the sink

Prints one PASS/FAIL line per case and a final VERDICT line -- same
convention as test_check_records.py.
"""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).parent.resolve()
CODE_DIR = HERE.parent
PY = sys.executable   # cs_python's interpreter; launch.py needs the SDK bindings


def _require_cs_python():
    """Fail fast and distinctly if this is not running under cs_python.

    Without this, running `python3 scripts/test_verdict_sink.py` by mistake
    makes every case's subprocess traceback on `from launch import ...` (no
    Cerebras SDK bindings outside the container), and the suite reports
    "0/10 VERDICT: FAIL" -- a false failure indistinguishable from a real
    one unless you already know to check the interpreter. That is exactly
    the failure mode K2 exists to eliminate in launch.py itself; the suite
    should not reproduce it on itself.
    """
    try:
        import cerebras.sdk.runtime.sdkruntimepybind  # noqa: F401  pylint: disable=unused-import,import-outside-toplevel
    except Exception as exc:                          # noqa: BLE001
        print(f"ERROR: this suite must be run under cs_python, not {sys.executable}.")
        print("       launch.py imports the Cerebras SDK bindings at module scope; "
              "those bindings only resolve inside the SDK container.")
        print(f"       Import failed here with: {type(exc).__name__}: {exc}")
        print(f"       Run instead:  cs_python {Path(__file__).resolve()}")
        print("VERDICT: ERROR (wrong interpreter -- no case was run)")
        sys.exit(3)


def run_snippet(code, env_extra=None):
    import os
    env = dict(os.environ)
    if env_extra:
        env.update(env_extra)
    p = subprocess.run([PY, "-c", code], capture_output=True, text=True,
                        cwd=str(CODE_DIR), env=env)
    return p.returncode, p.stdout, p.stderr


CASES = []


def case(name):
    def deco(fn):
        CASES.append((name, fn))
        return fn
    return deco


def find_verdict_line(text):
    for line in text.splitlines():
        if line.strip().startswith("VERDICT:"):
            return line.strip()
    return None


# --------------------------------------------------------------------- #
# Positive controls
# --------------------------------------------------------------------- #

@case("golden: empty sink -> no raise, exit 0")
def _(_state):
    code = (
        "from launch import make_verdict_sink\n"
        "rv, fin, recs = make_verdict_sink()\n"
        "failed = fin()\n"
        "assert failed == [], failed\n"
        "print('CASE-OK')\n"
    )
    rc, out, err = run_snippet(code)
    ok = (rc == 0 and "CASE-OK" in out
          and "VERDICT: all checks PASSED or SKIPPED" in out)
    return ok, rc, out + err


@case("golden: PASS + SKIPPED -> no raise; SKIPPED never counted as pass or fail")
def _(_state):
    code = (
        "from launch import make_verdict_sink\n"
        "rv, fin, recs = make_verdict_sink()\n"
        "rv('KV-SEED', True, 'prefill_len_per_pe=4, 0 bad tile(s)')\n"
        "rv('ROUTE-CHECK', None, 'not enabled (ROUTE_TABLE=1, ROUTE_CHECK=0)')\n"
        "failed = fin()\n"
        "assert failed == [], failed\n"
        "print('CASE-OK')\n"
    )
    rc, out, err = run_snippet(code)
    ok = (rc == 0 and "CASE-OK" in out
          and "[PASS   ] KV-SEED" in out
          and "[SKIPPED] ROUTE-CHECK" in out
          and "VERDICT: all checks PASSED or SKIPPED" in out)
    return ok, rc, out + err


# --------------------------------------------------------------------- #
# Demonstration 1 (plan K2): each of the three checks forced to FAIL ->
# non-zero exit, strict mode (CHECK_ADVISORY unset).
# --------------------------------------------------------------------- #

@case("FAIL: KV-SEED forced -> strict mode raises, non-zero exit")
def _kv_seed_fail(state):
    code = (
        "from launch import make_verdict_sink\n"
        "rv, fin, recs = make_verdict_sink()\n"
        "rv('KV-SEED', False, 'prefill_len_per_pe=4, 3 bad tile(s)')\n"
        "fin()\n"
        "print('SHOULD-NOT-REACH-HERE')\n"
    )
    rc, out, err = run_snippet(code)
    verdict_line = find_verdict_line(out)
    state["kv_seed_fail_verdict_line"] = verdict_line
    ok = (rc != 0 and "[FAIL   ] KV-SEED" in out
          and verdict_line == "VERDICT: 1 check(s) FAILED: ['KV-SEED']"
          and "SHOULD-NOT-REACH-HERE" not in out
          and "RuntimeError: in-launcher check(s) failed (strict mode" in err)
    return ok, rc, out + err


@case("FAIL: ROUTE-CHECK forced -> strict mode raises, non-zero exit")
def _(_state):
    code = (
        "from launch import make_verdict_sink\n"
        "rv, fin, recs = make_verdict_sink()\n"
        "rv('ROUTE-CHECK', False, '5 PE(s) disagree with host table; first=(0, 0, 1, 2, -3, 9)')\n"
        "fin()\n"
        "print('SHOULD-NOT-REACH-HERE')\n"
    )
    rc, out, err = run_snippet(code)
    ok = (rc != 0 and "[FAIL   ] ROUTE-CHECK" in out
          and "VERDICT: 1 check(s) FAILED: ['ROUTE-CHECK']" in out
          and "SHOULD-NOT-REACH-HERE" not in out
          and "RuntimeError: in-launcher check(s) failed (strict mode" in err)
    return ok, rc, out + err


@case("FAIL: LOCAL-TOPK forced -> strict mode raises, non-zero exit")
def _(_state):
    code = (
        "from launch import make_verdict_sink\n"
        "rv, fin, recs = make_verdict_sink()\n"
        "rv('LOCAL-TOPK', False, '1/2 batch(es) mismatched (device top-2 vs numpy top-2)')\n"
        "fin()\n"
        "print('SHOULD-NOT-REACH-HERE')\n"
    )
    rc, out, err = run_snippet(code)
    ok = (rc != 0 and "[FAIL   ] LOCAL-TOPK" in out
          and "VERDICT: 1 check(s) FAILED: ['LOCAL-TOPK']" in out
          and "SHOULD-NOT-REACH-HERE" not in out
          and "RuntimeError: in-launcher check(s) failed (strict mode" in err)
    return ok, rc, out + err


@case("FAIL: QKV-COL forced via a real INCONCLUSIVE sample -> strict mode raises")
def _qkv_col_fail(state):
    # Exercises the REAL classification/aggregation code (qkv_col_verdict_word,
    # qkv_col_aggregate), not a hand-written ok=False -- this is what run()'s
    # QKV-COL block itself calls once npre/npost are read off the device.
    # npre=1 (prefix identical) is exactly the INCONCLUSIVE case from the
    # plan: "an INCONCLUSIVE QKV-COL -> non-zero exit in strict mode."
    code = (
        "from launch import make_verdict_sink, qkv_col_aggregate, qkv_col_verdict_word\n"
        "assert qkv_col_verdict_word(1, 1, 8).startswith('INCONCLUSIVE')\n"
        "samples = [(0, 0, 0, 8, 8, False, True), (1, 0, 0, 1, 1, False, True)]   # row 1: npre=1 -> INCONCLUSIVE\n"
        "ok, detail = qkv_col_aggregate(samples, P=8)\n"
        "assert ok is False, (ok, detail)\n"
        "assert 'INCONCLUSIVE' in detail, detail\n"
        "rv, fin, recs = make_verdict_sink()\n"
        "rv('QKV-COL', ok, detail)\n"
        "fin()\n"
        "print('SHOULD-NOT-REACH-HERE')\n"
    )
    rc, out, err = run_snippet(code)
    verdict_line = find_verdict_line(out)
    state["qkv_col_fail_verdict_line"] = verdict_line
    ok = (rc != 0 and "[FAIL   ] QKV-COL" in out and "INCONCLUSIVE" in out
          and verdict_line == "VERDICT: 1 check(s) FAILED: ['QKV-COL']"
          and "SHOULD-NOT-REACH-HERE" not in out
          and "RuntimeError: in-launcher check(s) failed (strict mode" in err)
    return ok, rc, out + err


@case("control: QKV-COL all-healthy samples -> aggregate ok=True, no raise")
def _(_state):
    code = (
        "from launch import make_verdict_sink, qkv_col_aggregate\n"
        "samples = [(0, 0, 0, 8, 8, False, True), (0, 1, 0, 8, 8, False, True), (1, 0, 0, 8, 8, False, True)]\n"
        "ok, detail = qkv_col_aggregate(samples, P=8)\n"
        "assert ok is True, (ok, detail)\n"
        "rv, fin, recs = make_verdict_sink()\n"
        "rv('QKV-COL', ok, detail)\n"
        "failed = fin()\n"
        "assert failed == [], failed\n"
        "print('CASE-OK')\n"
    )
    rc, out, err = run_snippet(code)
    ok = rc == 0 and "CASE-OK" in out and "[PASS   ] QKV-COL" in out
    return ok, rc, out + err


@case("control: QKV-COL DEFECT sample (npost=1, npre!=1) -> aggregate ok=False")
def _(_state):
    code = (
        "from launch import qkv_col_aggregate, qkv_col_verdict_word\n"
        "assert qkv_col_verdict_word(8, 1, 8).startswith('DEFECT')\n"
        "ok, detail = qkv_col_aggregate([(0, 0, 0, 8, 1, False, True)], P=8)\n"
        "assert ok is False and 'DEFECT' in detail, (ok, detail)\n"
        "print('CASE-OK')\n"
    )
    rc, out, err = run_snippet(code)
    ok = rc == 0 and "CASE-OK" in out
    return ok, rc, out + err


# --------------------------------------------------------------------- #
# Demonstration 2 (plan K2): same failing set, CHECK_ADVISORY=1 -> exit 0,
# SAME message.
# --------------------------------------------------------------------- #

@case("CHECK_ADVISORY=1: same KV-SEED failure -> exit 0, run continues, SAME VERDICT line")
def _kv_seed_advisory(state):
    code = (
        "from launch import make_verdict_sink\n"
        "rv, fin, recs = make_verdict_sink()\n"
        "rv('KV-SEED', False, 'prefill_len_per_pe=4, 3 bad tile(s)')\n"
        "failed = fin()\n"
        "assert failed == ['KV-SEED'], failed\n"
        "print('REACHED-AFTER-FINALIZE')\n"
    )
    rc, out, err = run_snippet(code, env_extra={"CHECK_ADVISORY": "1"})
    verdict_line = find_verdict_line(out)
    strict_line = state.get("kv_seed_fail_verdict_line")
    ok = (rc == 0 and "REACHED-AFTER-FINALIZE" in out
          and "[FAIL   ] KV-SEED" in out
          and verdict_line is not None and verdict_line == strict_line
          and "[CHECK_ADVISORY=1] continuing despite 1 failed check(s) above" in out)
    detail = (out + err
              + f"\n  -- strict VERDICT line was: {strict_line!r}"
              + f"\n  -- advisory VERDICT line was: {verdict_line!r}")
    return ok, rc, detail


@case("CHECK_ADVISORY=1: same INCONCLUSIVE QKV-COL failure -> exit 0, SAME VERDICT line")
def _qkv_col_advisory(state):
    code = (
        "from launch import make_verdict_sink, qkv_col_aggregate\n"
        "samples = [(0, 0, 0, 8, 8, False, True), (1, 0, 0, 1, 1, False, True)]\n"
        "ok, detail = qkv_col_aggregate(samples, P=8)\n"
        "rv, fin, recs = make_verdict_sink()\n"
        "rv('QKV-COL', ok, detail)\n"
        "failed = fin()\n"
        "assert failed == ['QKV-COL'], failed\n"
        "print('REACHED-AFTER-FINALIZE')\n"
    )
    rc, out, err = run_snippet(code, env_extra={"CHECK_ADVISORY": "1"})
    verdict_line = find_verdict_line(out)
    strict_line = state.get("qkv_col_fail_verdict_line")
    ok = (rc == 0 and "REACHED-AFTER-FINALIZE" in out
          and verdict_line is not None and verdict_line == strict_line)
    detail = (out + err
              + f"\n  -- strict VERDICT line was: {strict_line!r}"
              + f"\n  -- advisory VERDICT line was: {verdict_line!r}")
    return ok, rc, detail


# --------------------------------------------------------------------- #
# Demonstration 3 (plan K2): a SKIPPED check appears in the summary and
# does not make the run pass silently -- i.e. it must be visible even
# alongside a real failure, not absorbed into "all passed".
# --------------------------------------------------------------------- #

@case("mixed: PASS + SKIPPED + FAIL -> only FAIL raises; all three outcomes visible")
def _(_state):
    code = (
        "from launch import make_verdict_sink\n"
        "rv, fin, recs = make_verdict_sink()\n"
        "rv('KV-SEED', True, 'prefill_len_per_pe=4, 0 bad tile(s)')\n"
        "rv('ROUTE-CHECK', None, 'not enabled (ROUTE_TABLE=1, ROUTE_CHECK=0)')\n"
        "rv('QKV-COL', False, '1 (row,ly) sample(s) checked, 1 not healthy')\n"
        "fin()\n"
        "print('SHOULD-NOT-REACH-HERE')\n"
    )
    rc, out, err = run_snippet(code)
    ok = (rc != 0
          and "[PASS   ] KV-SEED" in out
          and "[SKIPPED] ROUTE-CHECK" in out
          and "[FAIL   ] QKV-COL" in out
          and "VERDICT: 1 check(s) FAILED: ['QKV-COL']" in out
          and "SHOULD-NOT-REACH-HERE" not in out)
    return ok, rc, out + err


def main():
    _require_cs_python()
    n_pass = 0
    state = {}
    for i, (name, fn) in enumerate(CASES):
        try:
            ok, rc, out = fn(state)
        except Exception as exc:                    # noqa: BLE001
            ok, rc, out = False, None, f"<test harness raised: {exc}>"
        status = "PASS" if ok else "FAIL"
        if ok:
            n_pass += 1
        print(f"[{status}] {name}  (subprocess rc={rc})")
        if not ok:
            print("  ----- subprocess output -----")
            for line in out.splitlines():
                print(f"  {line}")
            print("  ------------------------------")
    total = len(CASES)
    print(f"\n{n_pass}/{total} case(s) passed")
    print("VERDICT:", "PASS" if n_pass == total else "FAIL")
    sys.exit(0 if n_pass == total else 1)


if __name__ == "__main__":
    main()
