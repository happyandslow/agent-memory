"""Synthetic unequal-height fixture; unsharded oracle never consumes PE packing."""

import numpy as np
import ml_dtypes
from .oracle_fp16 import _compute_kv_step, _layer_body, _qwen3_inv_freq
from .tall_layout import Geometry

BF16 = ml_dtypes.bfloat16


def make_fixture(steps, g=Geometry(), seed=910):
    rng = np.random.RandomState(seed)

    def random(shape, scale=0.1):
        return (rng.standard_normal(shape) * scale).astype(BF16)

    weights = {
        name: random(shape)
        for name, shape in {
            "Q": (g.dim, g.attn),
            "K": (g.dim, g.kv),
            "V": (g.dim, g.kv),
            "O": (g.attn, g.dim),
            "UP": (g.dim, g.ffn),
            "GATE": (g.dim, g.ffn),
            "DOWN": (g.ffn, g.dim),
        }.items()
    }
    for name, size in [
        ("W_attn_norm", g.dim),
        ("W_ffn_norm", g.dim),
        ("q_norm", g.head),
        ("k_norm", g.head),
    ]:
        weights[name] = (1 + random(size, 0.1).astype(np.float32)).astype(BF16)
    inputs = random((steps, g.dim), 0.5)
    k = np.zeros((1, g.kv, g.capacity), BF16)
    v = np.zeros((1, g.capacity, g.kv), BF16)
    k[:, :, : g.prefill] = random((1, g.kv, g.prefill), 0.5)
    v[:, : g.prefill] = random((1, g.prefill, g.kv), 0.5)
    return weights, inputs, k, v


def column_indices(x, g):
    pph = g.width // (g.kv // g.head)
    head, band = divmod(x, pph)
    kw = g.kv // g.width
    low = np.arange(band * (kw // 2), (band + 1) * (kw // 2))
    pair = np.stack([low, low + g.head // 2], axis=1).reshape(-1)
    contiguous = np.arange(band * kw, (band + 1) * kw)
    ratio = g.attn // g.kv
    q = np.concatenate([(head * ratio + j) * g.head + pair for j in range(ratio)])
    o = np.concatenate([(head * ratio + j) * g.head + contiguous for j in range(ratio)])
    return q, head * g.head + pair, head * g.head + contiguous, o, pair, low


def bake(regions, fixture, g):
    w, inputs, k, v = fixture
    for stage, rg in regions.items():
        height = g.height(stage)
        shard = g.dim // height
        tiles = {}
        for y in range(height):
            rows = np.arange(y * shard, (y + 1) * shard)
            for x in range(g.width):
                q, ki, vi, oi, pair, low = column_indices(x, g)
                if stage == 1:
                    values = {
                        "group_input": inputs[:, rows],
                        "W_attn_norm_tile": w["W_attn_norm"][rows],
                        "Q_weight_tile": w["Q"][np.ix_(rows, q)],
                        "K_weight_tile": w["K"][np.ix_(rows, ki)],
                        "V_weight_tile": w["V"][np.ix_(rows, vi)],
                        "q_norm_tile": np.tile(w["q_norm"][pair], g.attn // g.kv),
                        "k_norm_tile": w["k_norm"][pair],
                    }
                    freq = np.tile(_qwen3_inv_freq(g.head)[low], g.attn // g.kv)
                    for name, angle, fn in [
                        ("delta_cos_f32", freq, np.cos),
                        ("delta_sin_f32", freq, np.sin),
                        ("delta_p_cos_f32", height * freq, np.cos),
                        ("delta_p_sin_f32", height * freq, np.sin),
                    ]:
                        values[name] = fn(angle).astype(np.float32)
                elif stage == 2:
                    positions = np.arange(y, g.capacity, g.a2)
                    values = {
                        "XKCache_tile": k[0][np.ix_(ki, positions)],
                        "XVCache_tile": v[0][np.ix_(positions, vi)],
                        "O_weight_tile": w["O"][np.ix_(oi, rows)],
                    }
                else:
                    ff = np.arange(x * (g.ffn // g.width), (x + 1) * (g.ffn // g.width))
                    values = {
                        "W_ffn_norm_tile": w["W_ffn_norm"][rows],
                        "UP_weight_tile": w["UP"][np.ix_(rows, ff)],
                        "GATE_weight_tile": w["GATE"][np.ix_(rows, ff)],
                        "DOWN_weight_tile": w["DOWN"][np.ix_(ff, rows)],
                    }
                for name, value in values.items():
                    if name not in tiles:
                        tiles[name] = np.empty(
                            (height, g.width, value.size), value.dtype
                        )
                    tiles[name][y, x] = value.reshape(-1)
        for name, value in tiles.items():
            flat = value.reshape(height, -1)
            rg.set_symbol_all(
                name,
                flat.view(np.uint16) if value.dtype == BF16 else flat,
                flat.shape[1],
                height,
            )


def reference(fixture, g):
    w, inputs, k0, v0 = fixture
    k, v = k0.copy(), v0.copy()
    outputs = []
    for t, x in enumerate(inputs):
        pos = g.prefill + t
        angle = pos * _qwen3_inv_freq(g.head)
        cos, sin = np.cos(angle).astype(np.float32), np.sin(angle).astype(np.float32)
        x = x[None, :]
        ks, vs = _compute_kv_step(
            x,
            w,
            n_kv_heads=g.kv // g.head,
            head_dim=g.head,
            dim=g.dim,
            kv_dim=g.kv,
            cos_step=cos,
            sin_step=sin,
        )
        k[:, :, pos], v[:, pos] = ks, vs
        mask = (np.arange(g.capacity) <= pos).astype(np.float32)
        outputs.append(
            _layer_body(
                x,
                w,
                k,
                v,
                mask,
                dim=g.dim,
                kv_dim=g.kv,
                head_dim=g.head,
                n_heads=g.attn // g.head,
                n_kv_heads=g.kv // g.head,
                ffn_dim=g.ffn,
                seq_len=g.capacity,
                cos_step=cos,
                sin_step=sin,
                attn_dim=g.attn,
            )[0]
        )
    return np.array(outputs), k, v


def check_cache(runtime, fixture, expected_k, expected_v, g):
    actual_k = np.empty((1, g.kv, g.capacity), BF16)
    actual_v = np.empty((1, g.capacity, g.kv), BF16)
    for y in range(g.a2):
        positions = np.arange(y, g.capacity, g.a2)
        for x in range(g.width):
            _, ki, vi, _, _, _ = column_indices(x, g)
            k = (
                np.asarray(
                    runtime.read_symbol(
                        2 + g.width + x, 1 + y, "XKCache_tile", dtype="uint16"
                    ),
                    np.uint16,
                )
                .view(BF16)
                .reshape(g.kv // g.width, -1)
            )
            v = (
                np.asarray(
                    runtime.read_symbol(
                        2 + g.width + x, 1 + y, "XVCache_tile", dtype="uint16"
                    ),
                    np.uint16,
                )
                .view(BF16)
                .reshape(-1, g.kv // g.width)
            )
            actual_k[0][np.ix_(ki, positions)] = k
            actual_v[0][np.ix_(positions, vi)] = v
    end = g.prefill + len(fixture[1])
    exact_prefix = np.array_equal(
        actual_k[:, :, : g.prefill], fixture[2][:, :, : g.prefill]
    ) and np.array_equal(actual_v[:, : g.prefill], fixture[3][:, : g.prefill])
    exact_unused = np.array_equal(
        actual_k[:, :, end:], fixture[2][:, :, end:]
    ) and np.array_equal(actual_v[:, end:], fixture[3][:, end:])
    metrics = {}
    for name, actual, expected in [
        ("K", actual_k[:, :, g.prefill : end], expected_k[:, :, g.prefill : end]),
        ("V", actual_v[:, g.prefill : end], expected_v[:, g.prefill : end]),
    ]:
        delta = actual.astype(np.float32) - expected.astype(np.float32)
        metrics[name] = dict(
            relative_l2=float(
                np.linalg.norm(delta) / np.linalg.norm(expected.astype(np.float32))
            ),
            max_abs=float(np.abs(delta).max()),
        )
    passed = bool(
        exact_prefix
        and exact_unused
        and all(
            m["relative_l2"] < 0.02 and m["max_abs"] < 0.05 for m in metrics.values()
        )
    )
    np.savez(
        "cache_comparison.npz",
        actual_k=actual_k.astype(np.float32),
        actual_v=actual_v.astype(np.float32),
        expected_k=expected_k.astype(np.float32),
        expected_v=expected_v.astype(np.float32),
    )
    return dict(
        passed=passed,
        exact_prefix=bool(exact_prefix),
        exact_unused=bool(exact_unused),
        per_tensor=metrics,
        checked_pes=g.width * g.a2,
    )
