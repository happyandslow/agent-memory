#!/usr/bin/env python3
"""Report per-PE SRAM occupancy from compiled CSL artifact directories.

Usage:
    python3 sram_report.py out_<cfg> [out_<cfg2> ...] [--json sram.json] [--top 12]

For each `executables/*.elf`, invoke the SDK's `cs_readelf` helper and compute
the bank-memory high-water mark.

WSE-3 per-PE bank SRAM = 48 KB = 49152 B, address range 0x0000-0xBFFF. The D-cache at
0xFE00+ is a SEPARATE SRAM and is reported separately (excluded from the 48 KB %).

ELF filenames are `<region>-<coord>.elf` (coord is a single linear index, e.g.
`ht_tail-10.elf`, `demux-17.elf`). `.elf.zst` (compressed twins) are ignored by the
`*.elf` glob.

Parsing is defensive because `cs_readelf -m` output varies by SDK build:
  * Primary   : `cs_readelf -m`   (repo bench convention: "per-PE main memory").
  * Fallback  : `cs_readelf --sym` -> max(addr+size) over symbols with addr < 0xC000
                (doc-backed: Cerebras_Docs/csl/language/appendix.md).
The first ELF's raw output is printed so the parsed columns can be checked.
"""
import argparse
import glob
import json
import os
import re
import subprocess
import sys

BANK_BYTES = 49152        # 48 KB bank memory, 0x0000-0xBFFF
BANK_TOP = 0xC000
DCACHE_LO = 0xFE00

_HEX = re.compile(r"0x[0-9a-fA-F]+")
NAME_RE = re.compile(r"(?P<region>.+?)-(?P<coord>\d[\d-]*)\.elf$")


def _run(args):
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=180).stdout
    except FileNotFoundError:
        sys.exit(
            "ERROR: cs_readelf not on PATH. Run this on the Gala2 sim host inside the "
            "SDK SIF env (cs_readelf is a Cerebras SIF helper, not GNU readelf); e.g. "
            "under `zsh -ic` so ~/.zshrc puts it on PATH."
        )
    except subprocess.TimeoutExpired:
        return ""


def parse_sym(elf):
    """Return bank/DCACHE high-water marks and raw symbol output."""
    out = _run(["cs_readelf", "--sym", elf])
    bank_hwm = 0
    dcache_hwm = 0
    for line in out.splitlines():
        hexes = _HEX.findall(line)
        if len(hexes) < 2:
            continue
        addr = int(hexes[0], 16)
        size = int(hexes[1], 16)
        end = addr + size
        if addr < BANK_TOP:
            bank_hwm = max(bank_hwm, min(end, BANK_TOP))
        elif addr >= DCACHE_LO:
            dcache_hwm = max(dcache_hwm, end - DCACHE_LO)
    return bank_hwm, dcache_hwm, out


def parse_m(elf):
    """Return the largest '<N> bytes' value and raw `cs_readelf -m` output."""
    out = _run(["cs_readelf", "-m", elf])
    best = 0
    for line in out.splitlines():
        m = re.search(r"(\d+)\s*bytes", line, re.I)
        if m:
            best = max(best, int(m.group(1)))
    return best, out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dirs", nargs="+", help="one or more out_<cfg> artifact dirs")
    ap.add_argument("--json", default=None)
    ap.add_argument("--top", type=int, default=12)
    args = ap.parse_args()

    rows = []
    first = True
    for d in args.dirs:
        elfs = sorted(glob.glob(os.path.join(d, "executables", "*.elf")))
        if not elfs:
            print(f"WARN: no ELFs under {d}/executables/ (compile first, e.g. run_sim.sh <cfg> --compile-only)")
        for elf in elfs:
            bank, dcache, sym_raw = parse_sym(elf)
            m_bytes, m_raw = parse_m(elf)
            if first:
                print("=" * 72)
                print(f"RAW `cs_readelf -m` (first ELF — confirm the byte-total column):\n  {elf}")
                print(m_raw[:2000])
                print("-" * 72)
                print("RAW `cs_readelf --sym` (first 40 lines — confirm (addr,size) columns):")
                print("\n".join(sym_raw.splitlines()[:40]))
                print("=" * 72)
                first = False
            base = os.path.basename(elf)
            mm = NAME_RE.search(base)
            region = mm.group("region") if mm else base
            coord = mm.group("coord") if mm else "?"
            peak = bank if bank else m_bytes    # prefer sym HWM; fall back to -m figure
            rows.append(dict(
                dir=d, elf=base, region=region, coord=coord,
                bank_bytes=peak, bank_pct=round(100.0 * peak / BANK_BYTES, 1),
                dcache_bytes=dcache, m_bytes=m_bytes,
            ))

    if not rows:
        sys.exit("No ELFs parsed.")

    rows.sort(key=lambda r: r["bank_bytes"], reverse=True)
    peak = rows[0]
    print(f"\nPEAK per-PE bank SRAM: {peak['bank_bytes']} B = {peak['bank_pct']}% of 48KB  "
          f"@ {peak['region']}[{peak['coord']}]  [{peak['dir']}]")

    reg = {}
    for r in rows:
        if r["region"] not in reg or r["bank_bytes"] > reg[r["region"]]["bank_bytes"]:
            reg[r["region"]] = r

    print(f"\nTop {args.top} PEs by bank SRAM:")
    print(f"{'bytes':>7} {'%48KB':>6} {'dcacheB':>8}  region[coord]")
    for r in rows[:args.top]:
        print(f"{r['bank_bytes']:>7} {r['bank_pct']:>6} {r['dcache_bytes']:>8}  {r['region']}[{r['coord']}]")

    print("\nPer-region peak:")
    for name, r in sorted(reg.items(), key=lambda kv: kv[1]["bank_bytes"], reverse=True):
        print(f"  {r['bank_pct']:>5}%  {r['bank_bytes']:>7} B  {name}")

    if args.json:
        with open(args.json, "w") as f:
            json.dump(dict(peak=peak, per_region=reg, all=rows), f, indent=2)
        print(f"\nwrote {args.json}")


if __name__ == "__main__":
    main()
