"""Materialize the reviewed first-group U/R/START allocation.

All coordinates below are local to the group fixture placement: WEST strip x=2,
A1/A3 x=3..width+2, A2 x=width+3..2*width+2. The x=1 output adapter is a test
boundary, not an inter-group K-pipe implementation.
"""

from pathlib import Path
from launch import Color, Route, RoutingPosition, IntVector


def paint(region, x, y, color, source, *dest):
    region.paint(
        IntVector(x, y),
        Color(f"c{color}", color),
        [RoutingPosition().set_input([source]).set_output(list(dest))],
    )


def switches(region, y, color, positions):
    region.paint(
        IntVector(0, y),
        Color(f"c{color}", color),
        [
            RoutingPosition().set_input([src]).set_output([dst])
            for src, dst in positions
        ],
    )


def configure(layout, regions, g, source_root):
    strip = layout.create_code_region(
        str(Path(source_root) / "group_strip.csl"), "feedback_strip", 1, g.a2
    )
    for key, value in dict(height=g.a2, a1_height=g.a1, a3_height=g.a3).items():
        strip.set_param_all(key, value)
    for y in range(g.a2):
        strip.set_param(IntVector(0, y), "row", y)
        if y < g.a1:
            switches(
                strip, y, 16, [(Route.SOUTH, Route.EAST), (Route.SOUTH, Route.NORTH)]
            )
        elif y >= g.a3_origin:
            switches(
                strip, y, 16, [(Route.SOUTH, Route.NORTH), (Route.EAST, Route.NORTH)]
            )
        else:
            paint(strip, 0, y, 16, Route.SOUTH, Route.NORTH)
        if y < g.a1 or y >= g.a3_origin:
            paint(strip, 0, y, 19, Route.EAST, Route.RAMP)
        if y == g.a2 - 1:
            paint(strip, 0, y, 23, Route.EAST, Route.RAMP)
        else:
            paint(strip, 0, y, 18 if y % 2 == 0 else 23, Route.SOUTH, Route.RAMP)
        paint(
            strip,
            0,
            y,
            23 if y % 2 == 0 else 18,
            Route.RAMP,
            Route.EAST if y == 0 else Route.NORTH,
        )
        # D17 is only a boundary output in this first-group harness.
        if y >= g.a3_origin:
            paint(strip, 0, y, 17, Route.EAST, Route.WEST)
            paint(
                strip,
                0,
                y,
                15,
                Route.RAMP if y == g.a2 - 1 else Route.SOUTH,
                *([Route.EAST] if y == g.a3_origin else [Route.EAST, Route.NORTH]),
            )
    strip.place(2, 1)
    for stage in (1, 3):
        region = regions[stage]
        for y in range(g.height(stage)):
            for x in range(g.width):
                h0 = stage == 1 and x < g.a1 and y == x
                rout = 19 if x % 2 == 0 else 18
                rin = 18 if x % 2 == 0 else 19
                for key, value in dict(
                    r_in=rin, r_out=rout, r_oq=1 if h0 else 0, h0_sender_flag=int(h0)
                ).items():
                    region.set_param(IntVector(x, y), key, value)
                if stage == 1:
                    paint(
                        region,
                        x,
                        y,
                        16,
                        Route.WEST,
                        *(
                            [Route.RAMP, Route.EAST]
                            if x < g.width - 1
                            else [Route.RAMP]
                        ),
                    )
                    if x < g.width - 1:
                        paint(region, x, y, rin, Route.EAST, Route.RAMP)
                    paint(region, x, y, rout, Route.RAMP, Route.WEST)
                elif x == 0:
                    paint(region, x, y, 16, Route.RAMP, Route.WEST)
                    paint(region, x, y, 17, Route.RAMP, Route.WEST)
                    paint(region, x, y, 19, Route.RAMP, Route.WEST)
                    paint(region, x, y, 15, Route.WEST, Route.RAMP)
                if x == 0:
                    global_y = y if stage == 1 else y + g.a3_origin
                    paint(
                        region,
                        x,
                        y,
                        23,
                        Route.WEST if global_y == 0 else Route.NORTH,
                        Route.WEST if global_y == g.a2 - 1 else Route.SOUTH,
                    )
    if g.a3_origin > g.a1:
        spare = layout.create_code_region(
            str(Path(source_root) / "group_pass.csl"),
            "feedback_return",
            1,
            g.a3_origin - g.a1,
        )
        for y in range(g.a3_origin - g.a1):
            paint(spare, 0, y, 23, Route.NORTH, Route.SOUTH)
        spare.place(3, 1 + g.a1)
    return strip
