"""Operation-order diagnostic reused from the 2026-09-11 CS-3 attribution.

This models the existing operators/rounding; it is separate from the mathematical
NumPy oracle and never consumes baked PE weight tiles. It is not an accuracy
specification for a different operator implementation.
"""

import numpy as np
from . import oracle_fp16 as sr
from .tall_fixture import BF16 as bf, column_indices
from .tall_layout import y_group


def rope_bf16(X, sin, cos, *, n_pairs):
    a = X[..., :n_pairs].astype(bf)
    b = X[..., n_pairs : 2 * n_pairs].astype(bf)
    c = cos.astype(bf)
    s = sin.astype(bf)
    y = X.copy()
    y[..., :n_pairs] = ((a * c).astype(bf) - (b * s).astype(bf)).astype(bf)
    y[..., n_pairs : 2 * n_pairs] = ((a * s).astype(bf) + (b * c).astype(bf)).astype(bf)
    return y


def fma(a, b, c):
    return (a.astype(np.float64) * np.float64(b) + c.astype(np.float64)).astype(
        np.float32
    )


def poly_fma(x):
    x = x.astype(np.float32)
    a = abs(x)
    tail = np.maximum(a - 8, 0)
    s = (a - tail) * np.float32(0.25) - 1
    c = np.array(
        [
            3.92888761,
            4.21356344,
            -0.290447652,
            0.123400837,
            0.237175241,
            -0.342465132,
            0.126434281,
        ],
        np.float32,
    )
    sk = s * s
    p = c[0] + c[1] * s
    p = fma(sk, c[2], p)
    for k in range(3, 7):
        sk = (sk * s).astype(np.float32)
        p = fma(sk, c[k], p)
    p = p + tail
    p = fma(x - a, np.float32(0.5), p)
    return p.astype(bf)


def chain(a, root):
    # The CSL root receives color 0 then color 1. route_calc maps color 0
    # to the low-coordinate leg for an even root, high-coordinate for odd.
    v = a[root].copy()
    legs = {}
    if root > 0:
        x = a[0].copy()
        for i in range(1, root):
            x = (x + a[i]).astype(np.float32)
        legs["low"] = x
    if root + 1 < len(a):
        x = a[-1].copy()
        for i in range(len(a) - 2, root, -1):
            x = (x + a[i]).astype(np.float32)
        legs["high"] = x
    for name in ["low", "high"] if root % 2 == 0 else ["high", "low"]:
        if name in legs:
            v = (v + legs[name]).astype(np.float32)
    return v


def tree(a, group):
    return chain(
        [chain(a[i : i + group], group // 2) for i in range(0, len(a), group)],
        (len(a) // group) // 2,
    )


def gemv(x, w, n):
    k = w.shape[0] // n
    p = []
    for t in range(n):
        a = np.zeros((len(x), w.shape[1]), np.float32)
        for i in range(t * k, (t + 1) * k):
            a = (
                a + x[:, i : i + 1].astype(np.float32) * w[i].astype(np.float32)
            ).astype(np.float32)
        p.append(a)
    return p


def rsqrt(x):
    y = np.asarray(
        np.int32(0x5F3759DF) - (x.view(np.int32) >> np.int32(1)), dtype=np.int32
    ).view(np.float32)
    for _ in range(3):
        y = y * (np.float32(1.5) - np.float32(0.5) * x * y * y)
    return y


def ff(z, w, width, height):
    shard = z.shape[1] // height
    v = z.astype(np.float32) ** 2
    p = []
    for r in range(height):
        a = np.zeros((len(z), 1), np.float32)
        for i in range(r * shard, (r + 1) * shard):
            a = (a + v[:, i : i + 1]).astype(np.float32)
        p.append(a)
    s = tree(p, y_group(height))
    inv = rsqrt(s * np.float32(1 / z.shape[1]) + np.float32(1e-6))
    x = (z.astype(bf) * w["W_ffn_norm"]).astype(bf)
    up = (tree(gemv(x, w["UP"], height), y_group(height)) * inv).astype(bf)
    gate = (tree(gemv(x, w["GATE"], height), y_group(height)) * inv).astype(bf)
    hidden = (poly_fma(gate) * up).astype(bf)
    h = tree(gemv(hidden, w["DOWN"], width), y_group(width)).astype(bf)
    return (z.astype(bf) + h).astype(bf).astype(np.float32), dict(
        up=up, gate=gate, hidden=hidden, sum=s, inv=inv
    )


def qkv_order(fixture, g):
    w, z, _, _ = fixture
    shard = g.dim // g.a1
    v = z.astype(np.float32) ** 2
    p = []
    for row in range(g.a1):
        a = np.zeros((len(z), 1), np.float32)
        for i in range(row * shard, (row + 1) * shard):
            a = a + v[:, i : i + 1]
        p.append(a)
    inv = rsqrt(tree(p, y_group(g.a1)) * np.float32(1 / g.dim) + np.float32(1e-6))
    x = (z * w["W_attn_norm"]).astype(bf)
    q, k, v = [
        (tree(gemv(x, w[name], g.a1), y_group(g.a1)) * inv).astype(bf)
        for name in ["Q", "K", "V"]
    ]
    pph = g.width // (g.kv // g.head)
    pairs = [column_indices(c, g)[4] for c in range(pph)]
    for values, name in [(q, "q_norm"), (k, "k_norm")]:
        for h in range(values.shape[1] // g.head):
            vh = values[:, h * g.head : (h + 1) * g.head]
            sums = []
            for pair in pairs:
                a = np.zeros((len(z), 1), np.float32)
                for i in pair:
                    a = a + vh[:, i : i + 1].astype(np.float32) ** 2
                sums.append(a)
            inv = rsqrt(
                chain(sums, pph // 2) * np.float32(1 / g.head) + np.float32(1e-6)
            )
            vh[:] = ((vh.astype(np.float32) * inv).astype(bf) * w[name]).astype(bf)
    freq = sr._qwen3_inv_freq(g.head)
    c = np.ones(g.head // 2, np.float32)
    s = np.zeros(g.head // 2, np.float32)
    dc = np.cos(g.a1 * freq).astype(np.float32)
    ds = np.sin(g.a1 * freq).astype(np.float32)
    for _ in range(g.prefill // g.a1):
        c, s = c * dc - s * ds, s * dc + c * ds
    dc = np.cos(freq).astype(np.float32)
    ds = np.sin(freq).astype(np.float32)
    for tick in range(len(z)):
        for values in [q, k]:
            vh = values[tick].reshape(-1, g.head)
            vh[:] = rope_bf16(vh, s, c, n_pairs=g.head // 2)
        c, s = c * dc - s * ds, s * dc + c * ds
    packed = []
    for col in range(g.width):
        qi, ki, vi, _, _, _ = column_indices(col, g)
        packed.append(np.concatenate([q[:, qi], k[:, ki], v[:, vi]], axis=1))
    return np.concatenate(packed, axis=1).astype(np.float32), (q, k, v)


def attention(fixture, g, parts):
    w, x, k0, v0 = fixture
    k = k0.copy()
    v = v0.copy()
    q, kk, vv = parts
    outputs = []
    for t in range(len(x)):
        pos = g.prefill + t
        k[0, :, pos] = kk[t]
        v[0, pos] = vv[t]
        out = np.empty((g.attn // g.head, g.head), bf)
        for h in range(g.attn // g.head):
            kh = h // (g.attn // g.kv)
            qh = q[t].reshape(-1, g.head)[h].astype(np.float32)
            khist = k[0, kh * g.head : (kh + 1) * g.head, : pos + 1].astype(np.float32)
            pph = g.width // (g.kv // g.head)
            ps = []
            for col in range(pph):
                pair = column_indices(col, g)[4]
                acc = np.zeros(pos + 1, np.float32)
                for idx in pair:
                    acc = acc + qh[idx] * khist[idx]
                ps.append(acc)
            score = chain(ps, pph // 2)
            score = (score - score.max()) * rsqrt(np.array(g.head, np.float32))
            ef = sr._approx_exp_neg_f32(score)
            ev = ef.astype(bf).astype(np.float32)
            vvh = v[0, : pos + 1, kh * g.head : (kh + 1) * g.head].astype(np.float32)
            ns = []
            ds = []
            for row in range(g.a2):
                nn = np.zeros(g.head, np.float32)
                dd = np.zeros(1, np.float32)
                for idx in range(row, pos + 1, g.a2):
                    nn = nn + ev[idx] * vvh[idx]
                    dd = dd + ef[idx]
                ns.append(nn)
                ds.append(dd)
            num = tree(ns, y_group(g.a2))
            den = tree(ds, y_group(g.a2))
            out[h] = (num * sr._approx_recip_f32(den)).astype(bf)
        oo = out.reshape(-1).astype(np.float32)
        parts = []
        for col in range(g.width):
            oi = column_indices(col, g)[3]
            acc = np.zeros(g.dim, np.float32)
            for idx in oi:
                acc = acc + oo[idx] * w["O"][idx].astype(np.float32)
            parts.append(acc)
        h1 = tree(parts, y_group(g.width)).astype(bf)
        outputs.append((x[t] + h1).astype(bf).astype(np.float32))
    return np.asarray(outputs)


def reference_group_order(fixtures, g):
    inputs = fixtures[0][1]
    keys = []
    values = []
    stages = []
    for weights, _, k0, v0 in fixtures:
        fixture = (weights, inputs, k0, v0)
        packed, parts = qkv_order(fixture, g)
        z = attention(fixture, g, parts)
        outputs, _ = ff(z, weights, g.width, g.a3)
        k, v = k0.copy(), v0.copy()
        for tick in range(len(inputs)):
            k[0, :, g.prefill + tick] = parts[1][tick]
            v[0, g.prefill + tick] = parts[2][tick]
        keys.append(k)
        values.append(v)
        stages.append(dict(qkv=packed, z=z, output=outputs))
        inputs = outputs.astype(bf)
    return inputs.astype(np.float32), np.array(keys), np.array(values), stages
