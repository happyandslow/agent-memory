#!/usr/bin/env bash
# Direct EIDF control-node fallback. CS-3 operations normally use cs3-runner.
# Usage: ./run_device.sh [model.json] [request.json] [launch_device.py options]
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODEL="${1:-${HERE}/model_config/device_2x4_8k.json}"
REQUEST="${2:-${HERE}/request_config/device_prefill4k.json}"

cd "$HERE"
exec python ./launch_device.py \
    --model "$MODEL" \
    --request "$REQUEST" \
    "${@:3}"
