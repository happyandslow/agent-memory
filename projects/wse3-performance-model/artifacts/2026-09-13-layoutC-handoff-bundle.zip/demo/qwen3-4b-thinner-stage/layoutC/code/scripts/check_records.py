#!/usr/bin/env python3
"""Completeness gate for a device_records.npz produced by DUMP_RECORDS=1.

    python3 scripts/check_records.py <records.npz> --request <request.json> \
                                      [--model <model.json>]

`compare_records.py` (see its docstring) refuses to pass on two EMPTY
archives, but it never checks that an archive holds the content a run was
SUPPOSED to produce — a run that emitted 3 rounds instead of 8, or a
right-shaped `topk_args` full of zeros, still "compares identical" against
another run that failed the same way. This script is the missing check: it
inspects ONE archive against the request/model that were supposed to produce
it and asserts the archive is actually complete.

WHAT THE LAUNCHER ACTUALLY WRITES (`launch.py`, `DUMP_RECORDS` block, read at
the 2026-09-09 revision — do not trust old summaries of this, re-read the
source if launch.py changes):

    round{r}_sampled        int32,  shape (steps, bsz)
    round{r}_topk_args      int32,  shape (steps, bsz, TOP_K)
    round{r}_topk_vals_u16  uint16, shape (steps, bsz, TOP_K)   <- NOT
                                    "round{r}_topk_vals"; the value array is a
                                    bf16 array bit-cast to uint16 before saving
                                    (`.view(np.uint16)`), and the key carries
                                    the `_u16` suffix. A checker that looks for
                                    `round{r}_topk_vals` will silently check
                                    zero rounds.

    TOP_K lives on the LAST axis (shape[-1]) of topk_args/topk_vals_u16, not
    "the second dimension" shape[1] (shape[1] is bsz: `.reshape(top_k,
    bsz).T` is the write-side shape). Checked against shape[-1] here.

    `steps` (round r's leading dim) equals `DECODE_LENS[r]` in the ordinary
    (non-FORCED_PRODUCTION) path: `n_recv = n_rnd` and the per-round arrays
    are `r_sampled[:r_ngen]` where `r_ngen` starts at `n_rnd` and is only
    lowered by an early HOST_STOP_TOK (sentinel -2 in every batch lane,
    `launch.py:2861,3033-3035`) — see HOST_STOP_TOK CARVE-OUT below. Under
    `FORCED_PRODUCTION` (`launch.py:2985,3036`) exactly ONE record is
    received per round regardless of DECODE_LENS (`n_recv = 1`, `r_ngen`
    force-set to 1), so `steps == 1` is the correct expectation there, not
    `DECODE_LENS[r]`. This script reads `FORCED_PRODUCTION` from the request
    to pick the right expectation instead of assuming DECODE_LENS
    unconditionally, which is what the plan's assertion 3 literally says and
    which would misfire on every production-tail archive.

HOST_STOP_TOK CARVE-OUT (assertions 3 and 7). A round can legitimately end
before its decode budget: `launch.py:3033-3035` breaks the receive loop the
FIRST time a step's `sampled` row is `HOST_STOP_TOK` (-2) across every batch
lane, and that terminator row IS included in the saved slice (`r_ngen = s +
1`). Real token ids are never negative, so "trailing row of `sampled` is
entirely -2" is an unambiguous, architecturally-guaranteed signal of a
legitimate early stop — it can only ever be the LAST row of the saved array,
never a middle one, because the loop cannot keep iterating past the step
where it first sees an all-(-2) row. So:
  * assertion 3 accepts `steps < DECODE_LENS[r]` iff the trailing row of
    `sampled` is entirely HOST_STOP_TOK; a short round WITHOUT that trailing
    terminator is still a failure (nothing else legitimately produces a
    short round outside FORCED_PRODUCTION).
  * assertion 7 excludes exactly that trailing row from the `sampled`
    range check when it is the terminator (every earlier row must still be
    a valid vocab id); `topk_args` is never exempted — nothing in
    `_parse_token` gives it a sentinel value, only `r_sampled` carries
    HOST_STOP_TOK.
This does NOT special-case "steps == DECODE_LENS[r]" — an exact-length round
is accepted by assertion 3 regardless of what its trailing row contains, and
only assertion 7's per-row check (via the same trailing-terminator test)
decides whether that row needs to be a real id or is allowed to be -2.

Assertion 6 (degenerate array) carries the same carve-out, narrowed further:
a round that stops on its very first step (`got == 1`) with `bsz > 1` has
`sampled` shaped `(1, bsz)`, size > 1, and — because it IS the terminator —
entirely HOST_STOP_TOK; that is a real one-step-generation round, not a
stuck run, and is exempted. The exemption applies ONLY to `sampled`, and
ONLY when the round is exactly that one-row terminator: a `sampled` array
with `got > 1` where every row (not just the trailing one) is the sentinel
still trips DEGENERATE (not producible by the launcher's break-on-first-match
loop, but not excused here either), and `topk_args`/`topk_vals_u16` are never
exempted since nothing in `_parse_token` ever puts a sentinel there.

LIMITATIONS: none currently known in the assertions above. (Earlier
revisions of this file deferred the assertion-6 carve-out because no config
in this tree reaches step-0 termination naturally — no EOS in the toy vocab,
decode budgets are all >= 2 — and there was no fixture to build it against.
`test_check_records.py`'s carve-out fixtures synthesize the archive directly,
so a real run reaching that state was never actually required.)

Exit codes (same convention as `compare_records.py`):
  0  VERDICT: PASS      every assertion that could be evaluated held
  1  VERDICT: FAIL      the archive is malformed relative to the request/model
  2  VERDICT: ERROR     the inputs themselves are unusable (refused, not
                         judged) -- missing/empty/corrupt files, request with
                         no DECODE_LENS, model missing TOP_K/vocab_size, etc.
"""
import argparse
import json
import re
import sys
from pathlib import Path

import numpy as np

SUFFIXES = ("sampled", "topk_args", "topk_vals_u16")
ROUND_KEY_RE = re.compile(r"^round(\d+)_(sampled|topk_args|topk_vals_u16)$")
HOST_STOP_TOK = -2   # launch.py:2861 -- HT_tail emits this for every lane once finished.


def die(msg):
    print(f"CHECK ERROR: {msg}")
    print("VERDICT: ERROR")
    sys.exit(2)


def load_json_object(path, kind):
    p = Path(path)
    if not p.is_file():
        die(f"{kind} config does not exist: {p}")
    if p.stat().st_size == 0:
        die(f"{kind} config is empty: {p}")
    try:
        with p.open() as f:
            value = json.load(f)
    except Exception as exc:                      # noqa: BLE001 - report, do not mask
        die(f"{kind} config {p} is not valid JSON: {exc}")
    if not isinstance(value, dict):
        die(f"{kind} config must be a JSON object: {p}")
    return value


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("records")
    ap.add_argument("--request", required=True)
    ap.add_argument("--model", default=None,
                     help="if omitted, TOPK-WIDTH and TOKEN-RANGE are skipped")
    args = ap.parse_args()

    # ------------------------------------------------------------------ #
    # ERROR class: inputs that make the check itself impossible to run.
    # ------------------------------------------------------------------ #
    rp = Path(args.records)
    if not rp.is_file():
        die(f"{rp} does not exist — the run that should have produced it did not")
    if rp.stat().st_size == 0:
        die(f"{rp} is empty")
    try:
        arc = np.load(rp)
    except Exception as exc:                       # noqa: BLE001
        die(f"could not load {rp}: {exc}")
    if not arc.files:
        die(f"{rp} carries no arrays")

    request = load_json_object(args.request, "request")
    if "DECODE_LENS" not in request:
        die(f"{args.request} has no DECODE_LENS key")
    decode_lens = request["DECODE_LENS"]
    if (not isinstance(decode_lens, list) or not decode_lens
            or any(not isinstance(x, int) or isinstance(x, bool) for x in decode_lens)):
        die(f"{args.request} DECODE_LENS must be a non-empty list of integers, "
            f"got {decode_lens!r}")
    forced_production = bool(request.get("FORCED_PRODUCTION", False))

    top_k = vocab_size = None
    if args.model is not None:
        model = load_json_object(args.model, "model")
        if "TOP_K" not in model:
            die(f"{args.model} has no TOP_K key")
        if "vocab_size" not in model:
            die(f"{args.model} has no vocab_size key")
        top_k = model["TOP_K"]
        vocab_size = model["vocab_size"]
    else:
        print("NOTE: no --model given; skipping TOPK-WIDTH and TOKEN-RANGE assertions")

    def get(key):
        try:
            return arc[key]
        except Exception as exc:                   # noqa: BLE001
            die(f"could not read array {key!r} from {rp}: {exc}")

    # ------------------------------------------------------------------ #
    # Parse round indices actually present, per suffix.
    # ------------------------------------------------------------------ #
    by_suffix = {s: set() for s in SUFFIXES}
    unrecognized = []
    for k in arc.files:
        m = ROUND_KEY_RE.match(k)
        if not m:
            unrecognized.append(k)
            continue
        by_suffix[m.group(2)].add(int(m.group(1)))
    if unrecognized:
        print(f"NOTE: ignoring {len(unrecognized)} key(s) not matching "
              f"round{{r}}_<sampled|topk_args|topk_vals_u16>: {sorted(unrecognized)}")

    all_rounds = set().union(*by_suffix.values())
    expected_rounds = len(decode_lens)
    expected_index_set = set(range(expected_rounds))

    failures = []

    def fail(tag, msg):
        failures.append(tag)
        print(f"FAIL[{tag}]: {msg}")

    # ---- Assertion 1: round count == len(DECODE_LENS) ----
    if len(all_rounds) != expected_rounds:
        fail("ROUND-COUNT",
             f"archive carries {len(all_rounds)} round(s) {sorted(all_rounds)}; "
             f"request DECODE_LENS has {expected_rounds} entries")

    # ---- Assertion 2: every round carries all three keys; no index gaps ----
    for r in sorted(all_rounds | expected_index_set):
        missing = [s for s in SUFFIXES if r not in by_suffix[s]]
        if missing:
            fail("ROUND-KEYS",
                 f"round {r} is missing key(s): {[f'round{r}_{s}' for s in missing]}")
    gaps = sorted(expected_index_set - all_rounds)
    extra = sorted(all_rounds - expected_index_set)
    if gaps:
        fail("ROUND-GAP", f"round index gap: DECODE_LENS expects rounds "
             f"{sorted(expected_index_set)} but {gaps} are absent from the archive")
    if extra:
        fail("ROUND-EXTRA",
             f"archive has round index(es) beyond DECODE_LENS' range: {extra}")

    # Only evaluate content assertions for rounds that actually loaded all
    # three keys — a round already flagged by ROUND-KEYS gets one clear
    # reason, not a cascade of KeyErrors or bogus shape complaints on top.
    usable_rounds = sorted(r for r in all_rounds if all(r in by_suffix[s] for s in SUFFIXES))

    for r in usable_rounds:
        sampled = get(f"round{r}_sampled")
        topk_args = get(f"round{r}_topk_args")
        topk_vals = get(f"round{r}_topk_vals_u16")

        # Trailing-row terminator test shared by assertions 3 and 7: real
        # token ids are never negative, so an all-HOST_STOP_TOK last row is
        # an unambiguous legitimate-early-stop signal (see HOST_STOP_TOK
        # CARVE-OUT in the module docstring). Only meaningful for `sampled`.
        got = sampled.shape[0] if sampled.ndim >= 1 else None
        terminated = bool(got) and bool(np.all(sampled[-1] == HOST_STOP_TOK))

        # ---- Assertion 3: sampled length matches the round's expected step count ----
        if forced_production:
            expected_len, why = 1, "FORCED_PRODUCTION: exactly one record expected per round"
        elif r < len(decode_lens):
            expected_len, why = decode_lens[r], f"DECODE_LENS[{r}]={decode_lens[r]}"
        else:
            expected_len, why = None, None          # already flagged as ROUND-EXTRA
        if expected_len is not None:
            if got == expected_len:
                pass
            elif got is not None and got < expected_len and terminated:
                pass   # legitimate early stop: trailing row is the HOST_STOP_TOK terminator
            else:
                fail("SAMPLED-LEN",
                     f"round {r}: sampled has {got} step(s) (shape {sampled.shape}), "
                     f"expected {expected_len} ({why})"
                     + ("; trailing row is not a HOST_STOP_TOK terminator"
                        if got is not None and got < expected_len else ""))

        # ---- Assertion 4: topk_args/topk_vals_u16 last axis == TOP_K ----
        if top_k is not None:
            for name, arr in (("topk_args", topk_args), ("topk_vals_u16", topk_vals)):
                if arr.ndim < 1 or arr.shape[-1] != top_k:
                    fail("TOPK-WIDTH",
                         f"round {r}: {name} shape {arr.shape}, last axis != TOP_K ({top_k})")

        # ---- Assertion 5: dtypes as the launcher actually writes them ----
        if sampled.dtype != np.dtype(np.int32):
            fail("DTYPE", f"round {r}: sampled dtype {sampled.dtype}, expected int32")
        if topk_args.dtype != np.dtype(np.int32):
            fail("DTYPE", f"round {r}: topk_args dtype {topk_args.dtype}, expected int32")
        if topk_vals.dtype != np.dtype(np.uint16):
            fail("DTYPE", f"round {r}: topk_vals_u16 dtype {topk_vals.dtype}, expected uint16")

        # ---- Assertion 6: no array is all-zero / entirely one repeated value ----
        # HOST_STOP_TOK carve-out: a round that stops on its very first step
        # (`got == 1`) with bsz > 1 has `sampled` shaped (1, bsz), size > 1,
        # and — because it IS the legitimate terminator (`terminated`, the
        # same trailing-row test as assertions 3/7) — entirely HOST_STOP_TOK.
        # That is a real, single-step-generation round, not a stuck run;
        # without this exemption it would be misreported as DEGENERATE. The
        # exemption is narrow on purpose: it fires only for `sampled`, only
        # when the round IS exactly the one-row terminator (`got == 1`), so
        # a multi-row array that happens to be entirely -2 (a `sampled`
        # array with `got > 1` where every row, not just the trailing one,
        # is the sentinel — not producible by the launcher's break-on-first
        # match loop, but not excused here either) still trips DEGENERATE.
        # topk_args/topk_vals_u16 get no exemption: nothing in the launcher
        # ever puts a sentinel there, constant content in either is always
        # a defect signal regardless of what `sampled` is doing.
        exempt_degenerate = terminated and got == 1
        for name, arr in (("sampled", sampled), ("topk_args", topk_args),
                          ("topk_vals_u16", topk_vals)):
            if arr.size <= 1:
                continue   # a lone sample is trivially "constant"; not a signal
            if name == "sampled" and exempt_degenerate:
                continue   # single-step round whose only row is the legitimate terminator
            first = arr.reshape(-1)[0]
            if np.all(arr == first):
                kind = "all-zero" if first == 0 else f"constant value {first!r}"
                fail("DEGENERATE",
                     f"round {r}: {name} is {kind} across all {arr.size} element(s)")

        # ---- Assertion 7: token ids in [0, vocab_size) ----
        if vocab_size is not None:
            # `sampled`'s trailing row is exempted when it is the legitimate
            # HOST_STOP_TOK terminator (see assertion 3) -- every row before
            # it must still be a real id. `topk_args` gets no such exemption:
            # nothing in the launcher's parse path ever puts a sentinel there.
            sampled_check = sampled[:-1] if terminated else sampled
            for name, arr in (("sampled", sampled_check), ("topk_args", topk_args)):
                if arr.size == 0:
                    continue
                lo, hi = int(arr.min()), int(arr.max())
                if lo < 0 or hi >= vocab_size:
                    fail("TOKEN-RANGE",
                         f"round {r}: {name} has id(s) outside [0, {vocab_size}): "
                         f"min={lo}, max={hi}"
                         + (" (trailing HOST_STOP_TOK row excluded)" if name == "sampled" and terminated else ""))

    if failures:
        print(f"checked {len(usable_rounds)}/{expected_rounds} round(s); "
              f"{len(failures)} failure(s): {failures}")
        print("VERDICT: FAIL")
        sys.exit(1)

    print(f"checked {len(usable_rounds)} round(s); all assertions held")
    print("VERDICT: PASS")
    sys.exit(0)


if __name__ == "__main__":
    main()
