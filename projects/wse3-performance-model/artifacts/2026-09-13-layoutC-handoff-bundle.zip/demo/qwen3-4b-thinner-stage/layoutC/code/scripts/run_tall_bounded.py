#!/usr/bin/env python3
"""Bound a fixture's compile/run process, including blocking SDK receives.

Run with cs_python (or the worker's Python). Forward all arguments after the
wrapper options to launch_tall.py. A CS-3 caller must retain its SdkLauncher
context so its finally/context-exit tears down the owned job on failure.
"""

import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def run():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--deadline-seconds", type=float, default=900)
    parser.add_argument("--status-file", default="bounded_status.json")
    args, forwarded = parser.parse_known_args()
    if args.deadline_seconds <= 0:
        parser.error("--deadline-seconds must be positive")
    entry = Path(__file__).resolve().parents[1] / "launch_tall.py"
    start = time.monotonic()
    proc = subprocess.Popen(
        [sys.executable, str(entry), *forwarded], start_new_session=True
    )
    timed_out = False
    try:
        code = proc.wait(timeout=args.deadline_seconds)
    except subprocess.TimeoutExpired:
        timed_out = True
        # Kill only this child's process group, including its simulator children.
        os.killpg(proc.pid, signal.SIGTERM)
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait()
        code = 124
    Path(args.status_file).write_text(
        json.dumps(
            dict(
                exit_code=code,
                timed_out=timed_out,
                elapsed_host_seconds=time.monotonic() - start,
                deadline_seconds=args.deadline_seconds,
                scope="whole fixture process; not a kernel performance measurement",
            ),
            indent=2,
        )
        + "\n"
    )
    return code


if __name__ == "__main__":
    raise SystemExit(run())
