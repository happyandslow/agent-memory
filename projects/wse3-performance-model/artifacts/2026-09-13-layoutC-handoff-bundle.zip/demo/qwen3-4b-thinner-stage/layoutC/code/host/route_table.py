"""Host-side model of comm_pe.csl init(): per-PE route words and runtime scalars.

Transliteration of src/route_calc.csl get_params() and the static-route case
analysis in src/comm_lib/comm_pe.csl init(). Produces one u16 row per PE:

  [0..11]  local_px, local_py, quotient_x, remainder_x, quotient_y, remainder_y,
           px_in_kv_head, is_inter_row_recv_block, is_result_sender, is_x_receiver,
           row_y, row_dir_east
  [12..24] low byte (rx|tx bits) of the 13 axis route words, in the order
           Y_r1_0 Y_r1_1 Y_r2_0 Y_r2_1 Y_bc  X_r1_0 X_r1_1 X_r2_0 X_r2_1 X_bc  KV_r1_0 KV_r1_1 KV_bc
  [25..31] low byte of the static routes for the color slots
           intra_row_bcast, inter_block_a, inter_block_b, kv_ingress_0, kv_ingress_1,
           kv_ingress_entry, result   (0xFFFF = leave the color untouched)
  [32..33] ing_iq_color_i16, ing_oq_color_i16

The device only ORs the low byte under the preserved high byte of the color
register, exactly like route_util.compute_route_word_* / set_route_*.
"""
import numpy as np

RAMP, WEST, EAST, SOUTH, NORTH = "RAMP", "WEST", "EAST", "SOUTH", "NORTH"
RX = {WEST: 0x00, EAST: 0x20, SOUTH: 0x40, NORTH: 0x60, RAMP: 0x80}
TX = {WEST: 0x01, EAST: 0x02, SOUTH: 0x04, NORTH: 0x08, RAMP: 0x10}
UNUSED = 0xFFFF
PE_CFG_WORDS = 34


def w1(rx, tx):
    return RX[rx] | TX[tx]


def w2(rx, tx0, tx1):
    return RX[rx] | TX[tx0] | TX[tx1]


def chain_dirs_1st(pos, root, lo, hi):
    r0_rx = r0_tx = r1_rx = r1_tx = RAMP
    par = pos % 2
    if pos == root:
        if par == 0:
            r0_rx, r0_tx, r1_rx, r1_tx = lo, RAMP, hi, RAMP
        else:
            r1_rx, r1_tx, r0_rx, r0_tx = lo, RAMP, hi, RAMP
    elif pos < root:
        if par == 0:
            r0_rx, r0_tx, r1_rx, r1_tx = lo, RAMP, RAMP, hi
        else:
            r1_rx, r1_tx, r0_rx, r0_tx = lo, RAMP, RAMP, hi
    else:
        if par == 0:
            r1_rx, r1_tx, r0_rx, r0_tx = hi, RAMP, RAMP, lo
        else:
            r0_rx, r0_tx, r1_rx, r1_tx = hi, RAMP, RAMP, lo
    return r0_rx, r0_tx, r1_rx, r1_tx


def bcast_dirs(pos, root, span, lo, hi):
    ep_rx = ep_tx = rl_rx = rl_tx0 = rl_tx1 = RAMP
    if pos == root:
        if pos == 0:
            ep_rx, ep_tx = RAMP, hi
        elif pos == span - 1:
            ep_rx, ep_tx = RAMP, lo
        else:
            rl_rx, rl_tx0, rl_tx1 = RAMP, lo, hi
    elif pos < root:
        if pos == 0:
            ep_rx, ep_tx = hi, RAMP
        else:
            rl_rx, rl_tx0, rl_tx1 = hi, lo, RAMP
    else:
        if pos == span - 1:
            ep_rx, ep_tx = lo, RAMP
        else:
            rl_rx, rl_tx0, rl_tx1 = lo, RAMP, hi
    is_ep = 1 if (pos == 0 or pos == span - 1) else 0
    return ep_rx, ep_tx, rl_rx, rl_tx0, rl_tx1, is_ep


def second_phase(local, quotient, remainder, root_1st, root_2nd, lo, hi):
    r0_rx = r0_tx = r1_rx = r1_tx = RAMP
    par = quotient % 2
    if local == root_2nd:
        if par == 0:
            r0_rx, r0_tx, r1_rx, r1_tx = lo, RAMP, hi, RAMP
        else:
            r1_rx, r1_tx, r0_rx, r0_tx = lo, RAMP, hi, RAMP
    elif local < root_2nd:
        if remainder == root_1st:
            if par == 0:
                r0_rx, r0_tx, r1_rx, r1_tx = lo, RAMP, RAMP, hi
            else:
                r1_rx, r1_tx, r0_rx, r0_tx = lo, RAMP, RAMP, hi
        else:
            r0_rx, r0_tx, r1_rx, r1_tx = lo, hi, lo, hi
    else:
        if remainder == root_1st:
            if par == 0:
                r1_rx, r1_tx, r0_rx, r0_tx = hi, RAMP, RAMP, lo
            else:
                r0_rx, r0_tx, r1_rx, r1_tx = hi, RAMP, RAMP, lo
        else:
            r0_rx, r0_tx, r1_rx, r1_tx = hi, lo, hi, lo
    return r0_rx, r0_tx, r1_rx, r1_tx


def pe_cfg_row(wafer_x, wafer_y, role_attn, *, P, P_X_BLOCK_NUM, P_Y_BLOCK_NUM,
               pe_num_per_group, root_1st_phase, root_2nd_phase, pes_per_kv_head,
               kv_head_root, region_origin_x, region_origin_y, kv_ingress_color_0,
               kv_ingress_color_1,
               # Sub-block heights (budget B'): Y-axis tree geometry when a
               # stage's active height differs from the block width. Defaults
               # reproduce today's square blocks bit-for-bit.
               P_y=None, group_y=None, root_1st_y=None, root_2nd_y=None):
    P_y = P if P_y is None else P_y
    group_y = pe_num_per_group if group_y is None else group_y
    root_1st_y = root_1st_phase if root_1st_y is None else root_1st_y
    root_2nd_y = root_2nd_phase if root_2nd_y is None else root_2nd_y
    decode_py = wafer_y - region_origin_y
    row_y = decode_py // P
    row_dir_east = 1 if row_y % 2 == 0 else 0
    region_py = decode_py - row_y * P
    region_px = wafer_x - region_origin_x

    block_x = region_px // P
    local_px = region_px - block_x * P
    local_py = region_py
    quotient_x, remainder_x = divmod(local_px, pe_num_per_group)
    quotient_y, remainder_y = divmod(local_py, group_y)
    pipeline_idx = block_x if row_dir_east else P_X_BLOCK_NUM - 1 - block_x
    is_first_in_row = 1 if pipeline_idx == 0 else 0
    is_first_in_pipeline = 1 if (row_y == 0 and is_first_in_row) else 0
    is_inter_row_recv_block = (1 - is_first_in_pipeline) * is_first_in_row
    DIR_OUT, DIR_IN = (EAST, WEST) if row_dir_east else (WEST, EAST)

    X1 = chain_dirs_1st(remainder_x, root_1st_phase, WEST, EAST)
    Y1 = chain_dirs_1st(remainder_y, root_1st_y, NORTH, SOUTH)
    X2 = second_phase(local_px, quotient_x, remainder_x, root_1st_phase, root_2nd_phase, WEST, EAST)
    Y2 = second_phase(local_py, quotient_y, remainder_y, root_1st_y, root_2nd_y, NORTH, SOUTH)
    px_in_kv_head = local_px % pes_per_kv_head
    KV1 = chain_dirs_1st(px_in_kv_head, kv_head_root, WEST, EAST)
    KVb = bcast_dirs(px_in_kv_head, kv_head_root, pes_per_kv_head, WEST, EAST)
    Xb = bcast_dirs(local_px, root_2nd_phase, P, WEST, EAST)
    Yb = bcast_dirs(local_py, root_2nd_y, P_y, NORTH, SOUTH)
    X_is_endpoint = 1 if (local_px == 0 or local_px == P - 1) else 0
    Y_is_endpoint = 1 if (local_py == 0 or local_py == P_y - 1) else 0
    far_edge = 1 if ((row_dir_east and local_px == P - 1) or (not row_dir_east and local_px == 0)) else 0

    def bc_word(b, is_ep):
        ep_rx, ep_tx, rl_rx, rl_tx0, rl_tx1, _ = b
        return w1(ep_rx, ep_tx) if is_ep else w2(rl_rx, rl_tx0, rl_tx1)

    words = [
        w1(Y1[0], Y1[1]), w1(Y1[2], Y1[3]), w1(Y2[0], Y2[1]), w1(Y2[2], Y2[3]), bc_word(Yb, Y_is_endpoint),
        w1(X1[0], X1[1]), w1(X1[2], X1[3]), w1(X2[0], X2[1]), w1(X2[2], X2[3]), bc_word(Xb, X_is_endpoint),
        w1(KV1[0], KV1[1]), w1(KV1[2], KV1[3]), bc_word(KVb, KVb[5]),
    ]

    role_outer_lx = P - 1 if row_dir_east else 0
    is_result_sender = 1 if (role_attn == 0 and row_y == P_Y_BLOCK_NUM - 1 and local_px == role_outer_lx) else 0
    is_x_receiver = 1 if (role_attn != 0 and row_y == 0 and local_px == root_2nd_phase) else 0

    static = [UNUSED] * 7
    # intra_row_bcast
    if is_inter_row_recv_block:
        static[0] = w1(DIR_IN, RAMP) if far_edge else w2(DIR_IN, RAMP, DIR_OUT)
    elif X_is_endpoint:
        static[0] = w1(Xb[0], Xb[1])
    else:
        static[0] = w2(Xb[2], Xb[3], Xb[4])
    if role_attn:
        if row_dir_east:
            if local_px == P - 1:
                static[1] = w1(RAMP, EAST)
            static[2] = w1(EAST, RAMP) if local_px == 0 else w2(EAST, RAMP, WEST)
        else:
            if local_px == 0:
                static[1] = w1(RAMP, WEST)
            static[2] = w1(WEST, RAMP) if local_px == P - 1 else w2(WEST, RAMP, EAST)
        if wafer_x % 2 == 0:
            static[3], static[4] = w1(EAST, RAMP), w1(RAMP, WEST)
        else:
            static[4], static[3] = w1(EAST, RAMP), w1(RAMP, WEST)
    else:
        if row_dir_east:
            static[1] = w1(WEST, RAMP) if local_px == P - 1 else w2(WEST, RAMP, EAST)
            if local_px == 0:
                static[2] = w1(RAMP, WEST)
            elif local_px == P - 1 and row_y < P_Y_BLOCK_NUM - 1:
                static[2] = w1(RAMP, EAST)
            static[5] = w1(EAST, WEST)
        else:
            static[1] = w1(EAST, RAMP) if local_px == 0 else w2(EAST, RAMP, WEST)
            if local_px == P - 1:
                static[2] = w1(RAMP, EAST)
            elif local_px == 0 and row_y < P_Y_BLOCK_NUM - 1:
                static[2] = w1(RAMP, WEST)
    if is_result_sender:
        static[6] = w1(RAMP, EAST if row_dir_east else WEST)
    if wafer_x % 2 != 0:
        ing_iq, ing_oq = kv_ingress_color_1, kv_ingress_color_0
    else:
        ing_iq, ing_oq = kv_ingress_color_0, kv_ingress_color_1

    row = [local_px, local_py, quotient_x, remainder_x, quotient_y, remainder_y,
           px_in_kv_head, is_inter_row_recv_block, is_result_sender, is_x_receiver,
           row_y, row_dir_east] + words + static + [ing_iq, ing_oq]
    assert len(row) == PE_CFG_WORDS
    return row


def region_table(origin_x, origin_y, role_attn, **kw):
    """(H, P*PE_CFG_WORDS) uint16 table for one P-wide x H-tall code region
    placed at (origin_x, origin_y). H = kw P_y (defaults to P: square)."""
    P = kw["P"]
    H = kw.get("P_y") or P
    t = np.zeros((H, P, PE_CFG_WORDS), dtype=np.uint16)
    for ly in range(H):
        for lx in range(P):
            t[ly, lx, :] = pe_cfg_row(origin_x + lx, origin_y + ly, role_attn, **kw)
    return t.reshape(H, P * PE_CFG_WORDS)
