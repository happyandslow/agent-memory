#!/usr/bin/env python3
"""Seeded-defect suite for check_records.py.

Per the checker plan: "a checker that has never been observed failing is not
evidence." Every assertion in check_records.py gets one deliberately broken
fixture here, plus a demonstration it is rejected with the RIGHT reason tag —
and a couple of positive controls proving the checker does not false-positive
on legitimate archives (FORCED_PRODUCTION short rounds; --model omitted).

Self-contained: synthesises its own request/model JSON and .npz archives
under a tempdir. No device, no simulator, no cs_python. Run directly:

    python3 scripts/test_check_records.py

Exits 0 iff every case's outcome (exit code + expected tag substring in
stdout) matched. Prints one PASS/FAIL line per case and a final VERDICT line.
"""
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np

HERE = Path(__file__).parent.resolve()
CHECKER = HERE / "check_records.py"

BSZ = 1
TOP_K = 2
VOCAB = 10


def write_json(path, obj):
    import json
    path.write_text(json.dumps(obj))


def round_arrays(steps, bsz=BSZ, top_k=TOP_K, vocab=VOCAB, seed=0):
    """A well-formed round: distinct-ish values, all in range."""
    rng = np.random.default_rng(seed)
    sampled = (rng.integers(0, vocab, size=(steps, bsz))).astype(np.int32)
    args = (rng.integers(0, vocab, size=(steps, bsz, top_k))).astype(np.int32)
    vals = rng.integers(0, 2**16, size=(steps, bsz, top_k), dtype=np.uint16)
    return sampled, args, vals


HOST_STOP_TOK = -2   # must match check_records.py's HOST_STOP_TOK


def round_arrays_with_stop_row(steps, stop_row, bsz=BSZ, top_k=TOP_K, vocab=VOCAB, seed=0):
    """Like round_arrays, but forces row `stop_row` of `sampled` to be
    HOST_STOP_TOK across every batch lane -- topk_args/topk_vals stay
    ordinary in-range data at every row, matching what the launcher's
    _parse_token actually writes (only r_sampled ever carries the
    sentinel)."""
    sampled, args, vals = round_arrays(steps, bsz=bsz, top_k=top_k, vocab=vocab, seed=seed)
    sampled = sampled.copy()
    sampled[stop_row, :] = HOST_STOP_TOK
    return sampled, args, vals


def make_archive(path, rounds):
    """rounds: dict round_idx -> (sampled, args, vals) or dict of the subset
    of {"sampled","topk_args","topk_vals_u16"} keys to include (for
    missing-key fixtures)."""
    payload = {}
    for r, content in rounds.items():
        if isinstance(content, tuple):
            sampled, args, vals = content
            payload[f"round{r}_sampled"] = sampled
            payload[f"round{r}_topk_args"] = args
            payload[f"round{r}_topk_vals_u16"] = vals
        else:
            for suf, arr in content.items():
                payload[f"round{r}_{suf}"] = arr
    np.savez(path, **payload)


def run_checker(records, request, model=None):
    cmd = [sys.executable, str(CHECKER), str(records), "--request", str(request)]
    if model is not None:
        cmd += ["--model", str(model)]
    p = subprocess.run(cmd, capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


CASES = []


def case(name):
    def deco(fn):
        CASES.append((name, fn))
        return fn
    return deco


# --------------------------------------------------------------------- #
# Positive controls
# --------------------------------------------------------------------- #

@case("golden: well-formed 2-round archive passes")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4, 4], "DECODE_LENS": [3, 2], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    make_archive(arc, {0: round_arrays(3, seed=1), 1: round_arrays(2, seed=2)})
    rc, out = run_checker(arc, req, mdl)
    return rc == 0 and "VERDICT: PASS" in out, rc, out


@case("golden: FORCED_PRODUCTION archive (round length 1, DECODE_LENS large) passes")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [8, 8], "DECODE_LENS": [24, 24], "token_ids": [0],
                      "FORCED_TOKENS": [[0] * 23], "FORCED_PRODUCTION": True})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    make_archive(arc, {0: round_arrays(1, seed=3), 1: round_arrays(1, seed=4)})
    rc, out = run_checker(arc, req, mdl)
    return rc == 0 and "VERDICT: PASS" in out, rc, out


@case("golden: --model omitted skips TOPK-WIDTH/TOKEN-RANGE but still passes")
def _(d):
    req = d / "request.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4], "DECODE_LENS": [3], "token_ids": [0]})
    # deliberately wrong TOP_K width and an out-of-any-reasonable-vocab id --
    # with no --model given neither check runs, so this must still PASS.
    sampled, args, vals = round_arrays(3, top_k=5, vocab=99999, seed=5)
    make_archive(arc, {0: (sampled, args, vals)})
    rc, out = run_checker(arc, req, model=None)
    return (rc == 0 and "VERDICT: PASS" in out and "NOTE: no --model given" in out), rc, out


# --------------------------------------------------------------------- #
# ERROR class (exit 2): unusable inputs, refused rather than judged
# --------------------------------------------------------------------- #

@case("ERROR: records.npz does not exist")
def _(d):
    req = d / "request.json"
    write_json(req, {"PREFILL_LENS": [4], "DECODE_LENS": [3], "token_ids": [0]})
    rc, out = run_checker(d / "nope.npz", req)
    return rc == 2 and "VERDICT: ERROR" in out, rc, out


@case("ERROR: records.npz is empty")
def _(d):
    req = d / "request.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4], "DECODE_LENS": [3], "token_ids": [0]})
    arc.write_bytes(b"")
    rc, out = run_checker(arc, req)
    return rc == 2 and "VERDICT: ERROR" in out, rc, out


@case("ERROR: request.json has no DECODE_LENS")
def _(d):
    req = d / "request.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4], "token_ids": [0]})
    make_archive(arc, {0: round_arrays(3)})
    rc, out = run_checker(arc, req)
    return rc == 2 and "VERDICT: ERROR" in out and "DECODE_LENS" in out, rc, out


@case("ERROR: model.json missing TOP_K")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4], "DECODE_LENS": [3], "token_ids": [0]})
    write_json(mdl, {"vocab_size": VOCAB})
    make_archive(arc, {0: round_arrays(3)})
    rc, out = run_checker(arc, req, mdl)
    return rc == 2 and "VERDICT: ERROR" in out and "TOP_K" in out, rc, out


# --------------------------------------------------------------------- #
# FAIL class (exit 1): one seeded defect per assertion
# --------------------------------------------------------------------- #

@case("assertion 1 (ROUND-COUNT): archive has 1 round, request expects 3")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4, 4, 4], "DECODE_LENS": [3, 3, 3], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    make_archive(arc, {0: round_arrays(3, seed=6)})
    rc, out = run_checker(arc, req, mdl)
    return rc == 1 and "FAIL[ROUND-COUNT]" in out and "VERDICT: FAIL" in out, rc, out


@case("assertion 2a (ROUND-KEYS): round 1 missing topk_vals_u16")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4, 4], "DECODE_LENS": [3, 2], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    s0, a0, v0 = round_arrays(3, seed=7)
    s1, a1, v1 = round_arrays(2, seed=8)
    make_archive(arc, {0: (s0, a0, v0), 1: {"sampled": s1, "topk_args": a1}})
    rc, out = run_checker(arc, req, mdl)
    return (rc == 1 and "FAIL[ROUND-KEYS]" in out and "round1_topk_vals_u16" in out
            and "VERDICT: FAIL" in out), rc, out


@case("assertion 2b (ROUND-GAP/ROUND-EXTRA): round 1 skipped, round 3 present instead")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4, 4, 4], "DECODE_LENS": [3, 3, 3], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    make_archive(arc, {0: round_arrays(3, seed=9), 2: round_arrays(3, seed=10),
                        3: round_arrays(3, seed=11)})
    rc, out = run_checker(arc, req, mdl)
    return (rc == 1 and "FAIL[ROUND-GAP]" in out and "FAIL[ROUND-EXTRA]" in out
            and "VERDICT: FAIL" in out), rc, out


@case("assertion 3 (SAMPLED-LEN): round 0 has 2 steps, DECODE_LENS[0]=3")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4], "DECODE_LENS": [3], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    make_archive(arc, {0: round_arrays(2, seed=12)})
    rc, out = run_checker(arc, req, mdl)
    return rc == 1 and "FAIL[SAMPLED-LEN]" in out and "VERDICT: FAIL" in out, rc, out


@case("assertion 3 negative-control: FORCED_PRODUCTION round with 2 steps (should be 1)")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [8], "DECODE_LENS": [24], "token_ids": [0],
                      "FORCED_TOKENS": [[0] * 23], "FORCED_PRODUCTION": True})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    make_archive(arc, {0: round_arrays(2, seed=13)})   # should be exactly 1
    rc, out = run_checker(arc, req, mdl)
    return (rc == 1 and "FAIL[SAMPLED-LEN]" in out and "FORCED_PRODUCTION" in out
            and "VERDICT: FAIL" in out), rc, out


@case("carve-out positive: legitimate early stop (trailing all -2) passes")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [8], "DECODE_LENS": [5], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    # 3 of 5 budgeted steps: rows 0-1 real tokens, row 2 (trailing) is the
    # HOST_STOP_TOK terminator in every lane -- topk_args/vals stay in-range.
    sampled, args, vals = round_arrays_with_stop_row(3, stop_row=2, seed=20)
    make_archive(arc, {0: (sampled, args, vals)})
    rc, out = run_checker(arc, req, mdl)
    return rc == 0 and "VERDICT: PASS" in out, rc, out


@case("carve-out positive, bsz>1: terminator must hold across every lane")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [8], "DECODE_LENS": [5], "token_ids": [0, 0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    sampled, args, vals = round_arrays_with_stop_row(3, stop_row=2, bsz=2, seed=21)
    make_archive(arc, {0: (sampled, args, vals)})
    rc, out = run_checker(arc, req, mdl)
    return rc == 0 and "VERDICT: PASS" in out, rc, out


@case("carve-out negative I: short round, trailing row is NOT a terminator -> still fails")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [8], "DECODE_LENS": [5], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    sampled, args, vals = round_arrays(3, seed=22)   # ordinary in-range data, no -2 anywhere
    make_archive(arc, {0: (sampled, args, vals)})
    rc, out = run_checker(arc, req, mdl)
    return (rc == 1 and "FAIL[SAMPLED-LEN]" in out
            and "not a HOST_STOP_TOK terminator" in out and "VERDICT: FAIL" in out), rc, out


@case("carve-out negative II: full-length round with a NON-trailing all-(-2) row -> still fails")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [8], "DECODE_LENS": [4], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    # steps == DECODE_LENS[0] == 4 (so SAMPLED-LEN is satisfied on its own),
    # but row 1 (not the trailing row 3) is an all-(-2) row -- not a legal
    # position for the terminator, must not be excused by the carve-out.
    sampled, args, vals = round_arrays_with_stop_row(4, stop_row=1, seed=23)
    make_archive(arc, {0: (sampled, args, vals)})
    rc, out = run_checker(arc, req, mdl)
    return (rc == 1 and "FAIL[TOKEN-RANGE]" in out and "sampled has id(s)" in out
            and "trailing HOST_STOP_TOK row excluded" not in out
            and "VERDICT: FAIL" in out), rc, out


@case("carve-out negative III: only SOME lanes are -2 -> not a terminator, must fail both ways")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [8], "DECODE_LENS": [5], "token_ids": [0, 0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    sampled, args, vals = round_arrays(3, bsz=2, seed=24)
    sampled = sampled.copy()
    sampled[-1, 0] = HOST_STOP_TOK   # lane 0 stops, lane 1 does not -- not "every lane"
    make_archive(arc, {0: (sampled, args, vals)})
    rc, out = run_checker(arc, req, mdl)
    return (rc == 1 and "FAIL[SAMPLED-LEN]" in out and "FAIL[TOKEN-RANGE]" in out
            and "VERDICT: FAIL" in out), rc, out


@case("carve-out (assertion 6) positive: step-0 termination, bsz>1, all -2 passes")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [8], "DECODE_LENS": [5], "token_ids": [0, 0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    # Stops on the very first step: sampled is (1, 2), entirely -2 -- a real
    # one-step-generation round, not a stuck run.
    sampled, args, vals = round_arrays_with_stop_row(1, stop_row=0, bsz=2, seed=30)
    make_archive(arc, {0: (sampled, args, vals)})
    rc, out = run_checker(arc, req, mdl)
    return rc == 0 and "VERDICT: PASS" in out, rc, out


@case("carve-out (assertion 6) negative A: all-zero sampled (not -2) still fails")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [8], "DECODE_LENS": [5], "token_ids": [0, 0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    _, args, vals = round_arrays(1, bsz=2, seed=31)
    zeros = np.zeros((1, 2), dtype=np.int32)   # legitimate-looking but degenerate: all-zero, not -2
    make_archive(arc, {0: (zeros, args, vals)})
    rc, out = run_checker(arc, req, mdl)
    return (rc == 1 and "FAIL[DEGENERATE]" in out and "all-zero" in out
            and "VERDICT: FAIL" in out), rc, out


@case("carve-out (assertion 6) negative B: exemption is sampled-only -- constant topk_args still fails")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [8], "DECODE_LENS": [5], "token_ids": [0, 0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    # sampled IS the legitimate one-row terminator (exempt on its own), but
    # topk_args is constant -- the exemption must not bleed into it.
    sampled, _, vals = round_arrays_with_stop_row(1, stop_row=0, bsz=2, seed=32)
    const_args = np.full((1, 2, TOP_K), 3, dtype=np.int32)
    make_archive(arc, {0: (sampled, const_args, vals)})
    rc, out = run_checker(arc, req, mdl)
    return (rc == 1 and "FAIL[DEGENERATE]" in out and "topk_args" in out
            and "VERDICT: FAIL" in out), rc, out


@case("carve-out (assertion 6) negative C: multi-row all -2 (stuck, not a single-row terminator) still fails")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [8], "DECODE_LENS": [5], "token_ids": [0, 0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    # Every row is -2, not just the trailing one -- got=3 != 1, so the
    # got==1 exemption does not apply; this must still be flagged.
    sampled, args, vals = round_arrays(3, bsz=2, seed=33)
    sampled = np.full((3, 2), -2, dtype=np.int32)
    make_archive(arc, {0: (sampled, args, vals)})
    rc, out = run_checker(arc, req, mdl)
    return (rc == 1 and "FAIL[DEGENERATE]" in out and "sampled" in out
            and "VERDICT: FAIL" in out), rc, out


@case("assertion 4 (TOPK-WIDTH): topk_args last axis 3, TOP_K=2")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4], "DECODE_LENS": [3], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    sampled, _, vals = round_arrays(3, top_k=TOP_K, seed=14)
    _, bad_args, _ = round_arrays(3, top_k=3, seed=15)   # wrong width
    make_archive(arc, {0: (sampled, bad_args, vals)})
    rc, out = run_checker(arc, req, mdl)
    return rc == 1 and "FAIL[TOPK-WIDTH]" in out and "VERDICT: FAIL" in out, rc, out


@case("assertion 5 (DTYPE): sampled written as float32 instead of int32")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4], "DECODE_LENS": [3], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    sampled, args, vals = round_arrays(3, seed=16)
    make_archive(arc, {0: {"sampled": sampled.astype(np.float32),
                           "topk_args": args, "topk_vals_u16": vals}})
    rc, out = run_checker(arc, req, mdl)
    return rc == 1 and "FAIL[DTYPE]" in out and "sampled dtype" in out and "VERDICT: FAIL" in out, rc, out


@case("assertion 6a (DEGENERATE): sampled all-zero")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4], "DECODE_LENS": [3], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    _, args, vals = round_arrays(3, seed=17)
    zeros = np.zeros((3, BSZ), dtype=np.int32)
    make_archive(arc, {0: (zeros, args, vals)})
    rc, out = run_checker(arc, req, mdl)
    return (rc == 1 and "FAIL[DEGENERATE]" in out and "all-zero" in out
            and "VERDICT: FAIL" in out), rc, out


@case("assertion 6b (DEGENERATE): topk_args entirely one nonzero repeated value")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4], "DECODE_LENS": [3], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    sampled, _, vals = round_arrays(3, seed=18)
    const = np.full((3, BSZ, TOP_K), 4, dtype=np.int32)
    make_archive(arc, {0: (sampled, const, vals)})
    rc, out = run_checker(arc, req, mdl)
    return (rc == 1 and "FAIL[DEGENERATE]" in out and "constant value" in out
            and "VERDICT: FAIL" in out), rc, out


@case("assertion 7 (TOKEN-RANGE): sampled id == vocab_size (out of range)")
def _(d):
    req = d / "request.json"
    mdl = d / "model.json"
    arc = d / "records.npz"
    write_json(req, {"PREFILL_LENS": [4], "DECODE_LENS": [3], "token_ids": [0]})
    write_json(mdl, {"TOP_K": TOP_K, "vocab_size": VOCAB})
    sampled, args, vals = round_arrays(3, seed=19)
    sampled = sampled.copy()
    sampled[0, 0] = VOCAB   # exactly out of range (valid range is [0, VOCAB))
    make_archive(arc, {0: (sampled, args, vals)})
    rc, out = run_checker(arc, req, mdl)
    return (rc == 1 and "FAIL[TOKEN-RANGE]" in out and "VERDICT: FAIL" in out), rc, out


def main():
    n_pass = 0
    with tempfile.TemporaryDirectory(prefix="check_records_test_") as tmp:
        for i, (name, fn) in enumerate(CASES):
            d = Path(tmp) / f"case{i}"
            d.mkdir()
            try:
                ok, rc, out = fn(d)
            except Exception as exc:                # noqa: BLE001
                ok, rc, out = False, None, f"<test harness raised: {exc}>"
            status = "PASS" if ok else "FAIL"
            if ok:
                n_pass += 1
            print(f"[{status}] {name}  (checker rc={rc})")
            if not ok:
                print("  ----- checker output -----")
                for line in out.splitlines():
                    print(f"  {line}")
                print("  ---------------------------")
    total = len(CASES)
    print(f"\n{n_pass}/{total} case(s) passed")
    print("VERDICT:", "PASS" if n_pass == total else "FAIL")
    sys.exit(0 if n_pass == total else 1)


if __name__ == "__main__":
    main()
