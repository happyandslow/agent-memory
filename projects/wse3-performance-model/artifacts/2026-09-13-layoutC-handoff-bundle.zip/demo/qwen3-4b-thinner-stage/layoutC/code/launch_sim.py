#!/usr/bin/env cs_python
"""Local simfab entry for one model/request pair."""
import argparse
import os
from pathlib import Path

from launch import load_config, run


def parse_args():
    p = argparse.ArgumentParser(
        description="Local sim: qwen3_4b on-chip pipeline via SdkLayout (cmaddr=None).")
    p.add_argument("--model", required=True, help="Path to model_config/*.json")
    p.add_argument("--request", required=True, help="Path to request_config/*.json")
    p.add_argument("--name", default=None,
                   help="Artifact directory. Default: out_<model>__<request>.")
    p.add_argument("--cslc-prefix", type=str, default="")
    p.add_argument("--compile-only", action="store_true",
                   help="Run layout.compile only; skip runtime.load/run/oracle.")
    p.add_argument("--prefill-len", type=int, default=None,
                   help="Run one round with this prefill and decode the remaining capacity.")
    p.add_argument("--dump-records", action="store_true",
                   help="Save every D2H token record to device_records.npz.")
    p.add_argument("--prof-block-tsc", action="store_true",
                   help="Instrument one ATTN and one FFN block PE with per-step TSC segment stamps.")
    p.add_argument("--prof-ring", type=int, default=512, help="Steps retained per profiled block (even).")
    p.add_argument("--prof-shift", type=int, default=6,
                   help="Ring entries are cycles >> this (u16). 6 fits a bsz-8 step period.")
    p.add_argument("--prof-row", type=int, default=0, help="Block row to instrument.")
    p.add_argument("--prof-broken", action="store_true",
                   help="Negative control: stamp the compute segment before the layer body.")
    args = p.parse_args()
    if args.dump_records: os.environ["DUMP_RECORDS"] = "1"
    if args.prof_block_tsc: os.environ["PROF_BLOCK_TSC"] = "1"
    os.environ["PROF_RING"] = str(args.prof_ring)
    os.environ["PROF_ROW"] = str(args.prof_row)
    os.environ["PROF_SHIFT"] = str(args.prof_shift)
    if args.prof_broken: os.environ["PROF_BROKEN"] = "1"
    if args.name is None:
        args.name = f"out_{Path(args.model).stem}__{Path(args.request).stem}"
        if args.prefill_len is not None:
            args.name += f"_pf{args.prefill_len}"
    return args


HERE = Path(__file__).parent.resolve()


def main():
    args = parse_args()
    cfg = load_config(args.model, args.request)
    if args.prefill_len is not None:
        cfg["PREFILL_LEN"] = args.prefill_len
        cfg["PREFILL_LENS"] = [args.prefill_len]
        cfg["DECODE_LENS"] = [cfg["MAX_SEQ_LEN"] - args.prefill_len]
    artifact_dir = (HERE / args.name).resolve()
    run(cfg, cmaddr=None, artifact_dir=artifact_dir,
        cslc_prefix=args.cslc_prefix, compile_only=args.compile_only)


if __name__ == "__main__":
    main()
