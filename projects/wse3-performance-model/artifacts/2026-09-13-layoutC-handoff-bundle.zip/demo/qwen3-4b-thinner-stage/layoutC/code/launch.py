#!/usr/bin/env cs_python
"""Build and run the Qwen3-4B on-chip decode pipeline with SdkLayout.

Defines `run(cfg, *, cmaddr, artifact_dir, ...)` which compiles via
SdkLayout and executes via SdkRuntime. Imported by:
  - launch_sim.py    (cmaddr=None, local simfab)
  - launch_device.py (cmaddr="%CMADDR%" by default, EIDF-substituted)

The compute mesh is split into one ATTN and one FFN region per block row.
Static row multicast carries ATTN/FFN activations; standalone strip regions
carry cross-row traffic. The module uses direct streams and does not import
the memcpy library.
"""
import argparse
import functools
import json
import math
import os
import shutil
import time
from pathlib import Path

import numpy as np
import ml_dtypes

from cerebras.sdk.runtime.sdkruntimepybind import (  # pylint: disable=no-name-in-module
    Color,
    Edge,
    Route,
    RoutingPosition,
    SdkLayout,
    SdkTarget,
    SdkRuntime,
    SimfabConfig,
    get_platform,
    FP16TYPE,
)
from cerebras.geometry.geometry import IntVector, IntRectangle  # pylint: disable=no-name-in-module

import sys
sys.path.insert(0, str(Path(__file__).parent / "host"))
from oracle_fp16 import numpy_decode_oracle  # noqa: E402


# ---------------------------------------------------------------------------- #
# Constants
# ---------------------------------------------------------------------------- #

WEIGHT_SCALE = 0.05  # deterministic mock-weight magnitude

# Qwen3 RoPE constant. Qwen3-4B sets rope_scaling=null, so RoPE is the plain
# (non-NTK) base^(-2i/d) formula with theta=1e6.
ROPE_THETA = 1000000.0

_ACTIVE_RUNTIME = None


def _stop_active_runtime():
    global _ACTIVE_RUNTIME
    runtime, _ACTIVE_RUNTIME = _ACTIVE_RUNTIME, None
    if runtime is not None:
        runtime.stop()


def _with_runtime_cleanup(fn):
    @functools.wraps(fn)
    def guarded(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        finally:
            _stop_active_runtime()
    return guarded


# ---------------------------------------------------------------------------- #
# Helpers
# ---------------------------------------------------------------------------- #

def bf16_view_uint16(arr_bf16: np.ndarray) -> np.ndarray:
    """Return uint16 view of a bf16 numpy array (set_symbol_all rejects bf16)."""
    assert arr_bf16.dtype == ml_dtypes.bfloat16
    return arr_bf16.view(np.uint16)


def _qwen3_inv_freq(head_dim: int) -> np.ndarray:
    """Qwen3 plain RoPE inv_freq (no NTK scaling). Mirrors HF transformers
    _compute_default_rope_parameters. Returns np.float64 of shape (head_dim//2,).
    """
    return 1.0 / (
        ROPE_THETA ** (np.arange(0, head_dim, 2, dtype=np.float64) / head_dim)
    )


# ---------------------------------------------------------------------------- #
# Layer distribution + per-block param injection helpers
# ---------------------------------------------------------------------------- #

def distribute_layers(n_layers: int, N: int) -> tuple[list[int], list[int]]:
    """Split n_layers total layers across N pipeline blocks.

    With x = ceil(n_layers/N) and y = N*x - n_layers:
      - middle blocks (b in [1, N-2]) take x layers each
      - first block takes  x - ceil(y/2) layers
      - last  block takes  x - floor(y/2) layers  (one more than first if y odd)
    N=1 degenerates to a single block holding all n_layers.

    Returns (counts, offsets) — each length N. offsets[b] is the global layer
    index where block b's layer range begins.
    """
    if N == 1:
        return [n_layers], [0]
    x = math.ceil(n_layers / N)
    y = N * x - n_layers
    counts = [x] * N
    counts[0]  = x - (y + 1) // 2   # ceil(y/2)
    counts[-1] = x - y // 2          # floor(y/2)
    assert counts[0] >= 1, (
        f"distribute_layers: n_layers={n_layers} too small for N={N} blocks "
        f"(first block would get {counts[0]} layers)"
    )
    offsets = [0]
    for c in counts[:-1]:
        offsets.append(offsets[-1] + c)
    return counts, offsets


def strip_realness(row_y, P_Y_BLOCK_NUM):
    """Return which strip sides carry cross-row K-pipe traffic.

    Every role row has standalone west/east strip regions. Whether a side
    carries real inter-row traffic depends on the serpentine geometry:

      - Even rows snake east (head=west, tail=east). Incoming at west (if
        not first); outgoing at east (if not last).
      - Odd rows snake west. Incoming at east (if not first); outgoing at
        west (if not last).

    Inactive sides are one-column routing placeholders. Row 0's west placeholder
    carries the embedded input, and the final row's west placeholder carries the
    decode result.
    """
    is_first = (row_y == 0)
    is_last  = (row_y == P_Y_BLOCK_NUM - 1)
    is_even  = (row_y % 2 == 0)
    if is_even:
        real_west = not is_first   # incoming from row above (if any)
        real_east = not is_last    # outgoing to row below (if any)
    else:
        real_east = not is_first   # incoming from row above (if any)
        real_west = not is_last    # outgoing to row below (if any)
    return real_west, real_east


# ---------------------------------------------------------------------------- #
# In-launcher check verdict sink (K2)
# ---------------------------------------------------------------------------- #
# KV-SEED / ROUTE-CHECK / QKV-COL used to print a verdict and let the run
# continue -- a caller reading only the exit code saw success even on a real
# defect. record_verdict() accumulates every outcome (PASS / FAIL /
# SKIPPED-with-reason); finalize_checks() prints the full set and, in the
# default STRICT mode, raises if any is FAIL (INCONCLUSIVE counts as FAIL --
# see the QKV-COL call site in run()). CHECK_ADVISORY=1 restores the old
# print-and-continue behaviour for exploratory runs. `ok` is tri-state:
# True=PASS, False=FAIL, None=SKIPPED (never counted as passing, never forces
# a non-zero exit by itself).
#
# Factored to module scope (rather than left as closures inside run()) so
# `scripts/test_verdict_sink.py` can exercise this exact logic directly --
# real code, not a reimplementation -- without running a simulator.
def make_verdict_sink():
    """Return (record_verdict, finalize_checks, records) sharing one list."""
    records = []

    def record_verdict(name, ok, detail):
        records.append({"name": name, "ok": ok, "detail": str(detail)})

    def finalize_checks():
        print(f"\n{'=' * 62}")
        print("  in-launcher check summary")
        print(f"{'=' * 62}")
        failed = []
        for rec in records:
            ok = rec["ok"]
            outcome = "SKIPPED" if ok is None else ("PASS" if ok else "FAIL")
            if ok is False:
                failed.append(rec["name"])
            print(f"  [{outcome:7s}] {rec['name']}: {rec['detail']}")
        if failed:
            print(f"  VERDICT: {len(failed)} check(s) FAILED: {failed}")
        else:
            print("  VERDICT: all checks PASSED or SKIPPED")
        print(f"{'=' * 62}")
        advisory = bool(int(os.environ.get("CHECK_ADVISORY", "0")))
        if failed and advisory:
            print(f"  [CHECK_ADVISORY=1] continuing despite {len(failed)} failed "
                  f"check(s) above (exit code will be 0)")
        elif failed:
            raise RuntimeError(
                f"in-launcher check(s) failed (strict mode; set CHECK_ADVISORY=1 "
                f"to downgrade to advisory): {failed}")
        return failed

    return record_verdict, finalize_checks, records


def qkv_col_n_dummy_cols(head_dim, pes_per_kv_head, n_kv_heads):
    """Total PE-columns (out of P_BLOCK_SIZE = n_kv_heads * pes_per_kv_head)
    that hold NO real K/V data at all: entirely the zero-filled RoPE-pair
    padding tail (launch.py:665-682, `_pairs_per_pe_max` / `head_dim_shard`).
    Real pairs (head_dim // 2 of them, per kv-head) are ceil-divided across
    `pes_per_kv_head` PE-columns; this leaves at most ONE column per kv-head
    PARTIALLY padded (some real pairs, some zero pairs -- still distinct
    from every other column via its real portion), but when
    pes_per_kv_head is large relative to head_dim // 2 it can ALSO leave one
    or more trailing columns per kv-head with ZERO real pairs. Those are
    byte-identical (all zero) to each other, and -- since the K cache's
    host-seeded QKV-COL control is resharded through the exact same
    padding pipeline as the real Q/K weights (`_reshard_K_dim`,
    `_expand_pairs`) -- NOT mutually distinct even on a perfectly healthy
    build. K3's follow-up (2026-09-09, raised in review): the original
    `npre == P` / `npost == P` exact-match rule assumed no such columns
    exist; every config shipped in this tree today has
    `head_dim_shard == head_dim` (no padding at all, verified: layout C's
    target P=128/n_kv_heads=8/head_dim=128 gives head_dim_shard=128
    exactly), so this returns 0 for all of them and qkv_col_verdict_word's
    threshold reduces to the original flat P. See
    scripts/test_qkv_col_check.py's dummy-column cases for a config where
    it would not.
    """
    H2 = head_dim // 2
    K = pes_per_kv_head
    if H2 <= 0 or K <= 0:
        return 0
    pairs_per_pe = -(-H2 // K)                 # ceil division; same formula as _pairs_per_pe_max
    n_full_real = H2 // pairs_per_pe
    n_partial = 1 if H2 % pairs_per_pe else 0
    n_full_dummy_per_group = K - n_full_real - n_partial
    return n_full_dummy_per_group * n_kv_heads


def qkv_col_expected_distinct(P, n_dummy_cols):
    """Expected number of distinct byte-contents across P PE-columns when
    n_dummy_cols of them are entirely zero-padding (qkv_col_n_dummy_cols):
    the (P - n_dummy_cols) real columns are each host-seeded distinctly by
    column index, contributing one distinct value each; the n_dummy_cols
    padding columns are all-zero and therefore byte-identical to EACH
    OTHER, contributing exactly one more distinct value if any exist (zero
    is never a real host-seeded value, so it never collides with a real
    column). n_dummy_cols=0 reduces to the original flat P.
    """
    real = P - n_dummy_cols
    return real + (1 if n_dummy_cols > 0 else 0)


def qkv_col_row_high_water(ly, rounds, H_ROWS):
    """Highest local kv_len_per_pe position (exclusive) EVER written to row
    `ly` across ALL rounds run so far in this session, not just the last.

    `rounds`: iterable of (plen_per_pe, decode_len) -- one pair per round
    processed, in any order; `decode_len` is the ACTUAL generated count for
    that round (round_summary[...]["generated"], not its configured
    budget, since early EOS stop can end a round short of it).

    K3 follow-up (review, 2026-09-09), 2nd pass: the first version of this
    (superseded) used only the LAST round's decode length, reasoning that a
    short-vs-long decode run leaves later rows at their "never written"
    placeholder. That is right for a SINGLE round, but wrong across
    multiple: verified in `decode.csl` that `XKCache_tile` is `@zeros(...)`
    only ONCE at compile/load (not per round), `kv_ingress_layer_phase`
    only overwrites `[0, prefill_len_per_pe_rt)` on re-ingress (the DSD
    lengths there are `prefill_len_per_pe_rt`, not `kv_len_per_pe`), and
    `round_reset()` resets the decode write cursor (`iter_num_bank[li]`) to
    THIS round's OWN `prefill_len_per_pe_rt` -- it does not clear anything
    beyond it. So an EARLIER round's decode-written suffix PERSISTS through
    a LATER round with a smaller decode length, or even a smaller prefill:
    a round only ever overwrites `[0, its own plen)` and appends from
    there; it never retracts what a previous round wrote further out. A
    row is therefore real (not a zero placeholder) at every local position
    below the MAX reach any round ever gave it -- hence this takes the max
    over rounds, not just the last one.

    Per round, prefill always fills every row's local `[0, plen)` uniformly
    (PREFILL_LEN is required to be a multiple of H_ROWS -- see the
    Y-striding note in qkv_col_row_reached), and decode token d (0-indexed
    from the end of THAT round's prefill) lands in row `d % H_ROWS` at
    local offset `plen + d // H_ROWS`. So row `ly` gets `ceil((decode_len -
    ly) / H_ROWS)` writes from a round whose decode_len > ly, reaching up
    to local position `plen + ceil((decode_len - ly) / H_ROWS)`.
    """
    hi = 0
    for plen, dlen in rounds:
        reach = -(-max(0, dlen - ly) // H_ROWS) if dlen > ly else 0   # ceil division
        hi = max(hi, plen + reach)
    return hi


def qkv_col_row_reached(ly, rounds, H_ROWS, last_plen):
    """Whether local row `ly` (0-indexed within [0, H_ROWS)) holds REAL
    (non-placeholder) data anywhere in `[last_plen, kv_len_per_pe)` --
    the "post" region run()'s _qkv_col_check actually examines, bounded by
    the LAST round's OWN prefill boundary (`last_plen`) since that round's
    re-ingress freshly overwrote `[0, last_plen)` with real, per-column-
    distinct prefill data regardless of decode history.

    See qkv_col_row_high_water for why this must look across ALL rounds,
    not just the last -- a row can hold real, per-column-distinct data left
    by an EARLIER, longer-decode round even when the LAST round's own
    decode never reached it. A short decode run (fewer tokens than H_ROWS,
    in a run's FIRST and only round) never reaches its later rows at all --
    their post-prefill suffix stays at the original compile-time zero
    placeholder, which is CORRECT, not a defect. Empirically confirmed on
    `model_config/sim_2x2_bsz1.json` (H_ROWS=8, PREFILL_LEN=8, single
    round): DECODE_LENS=[2] leaves exactly rows 0-1 written and 2-7
    untouched; DECODE_LENS=[3] leaves 0-2 written, 3-7 untouched;
    DECODE_LENS=[24] (>= H_ROWS) reaches every row. Before the first pass
    of this fix, the K3 full-height sweep misread every not-yet-reached row
    as a DEFECT on these otherwise-healthy runs -- exactly the "checker
    that fails everything" anti-pattern K1's plan warns against, just
    discovered on this checker instead; before this second pass, it would
    have wrongly flagged a healthy MULTI-round run (long round then a
    shorter one) the same way. See scripts/test_qkv_col_check.py's
    row-reach cases for synthetic reproductions of all three directions.
    """
    return qkv_col_row_high_water(ly, rounds, H_ROWS) > last_plen


def qkv_col_verdict_word(npre, npost, P, is_idle=False, n_dummy_cols=0, decode_reached=True):
    """Classify one (row, ly, layer) QKV-COL sample from its distinct-value
    counts out of P columns.

    Pulled out as a pure function so `scripts/test_verdict_sink.py` and
    `scripts/test_qkv_col_check.py` can exercise the exact classification --
    including the INCONCLUSIVE case, which real device data rarely produces
    -- without a simulator run.

    K3 (2026-09-09) tightened this from the original ("npre==1 ->
    INCONCLUSIVE, npost==1 -> DEFECT, else healthy", which called 2/128
    distinct columns "healthy"): both counts must now equal the EXPECTED
    distinct count (see qkv_col_expected_distinct) exactly -- P columns when
    n_dummy_cols=0 (every config shipped today), fewer when the RoPE-pair
    padding leaves whole columns zero (n_dummy_cols>0, see
    qkv_col_n_dummy_cols). npre is the CONTROL (host-seeded, must be
    all-distinct-among-real-columns by construction); a shortfall there
    beyond what padding already explains means the instrument itself is
    compromised upstream of decode, not just "blind" -- so it is folded
    into the same INCONCLUSIVE bucket as full collapse, not treated as a
    reliable control. npost is the thing under test; anything short of the
    expected count is a DEFECT, full collapse or partial -- UNLESS
    decode_reached=False (see qkv_col_row_reached), in which case npost==1
    is the expected, healthy reading (nothing has been written there yet)
    and anything else is itself a defect (decode wrote where it should not
    have yet).

    is_idle marks a sample taken from a row the layout deliberately leaves
    inactive (ly >= H_ROWS, see qkv_col_sample_rows) -- a DIFFERENT kind of
    "expected non-distinctness" than n_dummy_cols (a whole row never baked,
    vs specific padding columns within any row) or decode_reached=False (a
    row within the active height whose PREFIX is real, only the SUFFIX is
    not yet written) -- so it is checked first and ignores both. An idle
    row is EXPECTED to look boring -- no per-column data was ever baked
    there, so npre==npost==1 is the correct, healthy-for-idle reading,
    reported as "inert" rather than routed through the active-row rules
    (which would misclassify it as INCONCLUSIVE for the same reading that
    is exactly right). If an idle row instead shows per-column variation,
    something wrote real data where the layout says nothing should run --
    that is its own DEFECT, distinct from the active-row ones.
    """
    if is_idle:
        if npre == 1 and npost == 1:
            return "inert — idle row shows no per-column data (expected, layout inactive here)"
        return (f"DEFECT — idle row is NOT inert: prefix {npre}/{P} distinct, "
                f"decode {npost}/{P} distinct (idle PEs must not vary per column)")
    expected = qkv_col_expected_distinct(P, n_dummy_cols)
    _pad_note = f" ({n_dummy_cols} zero-padding col(s) among {P})" if n_dummy_cols else ""
    if npre != expected:
        return (f"INCONCLUSIVE — control (prefix) only {npre}/{expected} distinct{_pad_note}, "
                f"instrument unreliable here")
    if not decode_reached:
        if npost == 1:
            return ("inert — row not yet reached by this run's decode length "
                     "(expected, no decode write here yet)")
        return (f"DEFECT — row not yet reached by decode, but decode-written K shows "
                f"{npost}/{expected} distinct{_pad_note} (should be untouched, npost==1)")
    if npost != expected:
        return (f"DEFECT — decode-written K only {npost}/{expected} distinct{_pad_note} "
                f"(need {expected}/{expected})")
    return f"healthy — {expected}/{expected} distinct pre and post{_pad_note}"


def qkv_col_sample_rows(H_ROWS, P_BLOCK_SIZE):
    """Local row indices (ly) to QKV-COL-sample within one block, each
    tagged with whether the row is idle: [(ly, is_idle), ...].

    K3 (2026-09-09) replaced the original `(0, min(1, H_ROWS - 1))` -- rows 0
    and 1 only -- which is blind to any defect confined to another row. This
    covers the WHOLE active height [0, H_ROWS) so a defect confined to a
    single active row anywhere in the block (not just its first two) is
    seen, plus at least one idle row [H_ROWS, P_BLOCK_SIZE) when idle rows
    exist (both the first and last idle row, cheaply, to also catch an
    off-by-one that only shows up at the far edge of the idle range) -- see
    qkv_col_verdict_word's is_idle branch for why an idle row's expected
    "no per-column data" reading must NOT be scored as INCONCLUSIVE.

    Cost note: this makes the row sweep the same shape as the KV-SEED
    check's full-H_ROWS sweep (see the P*P*P_Y_BLOCK_NUM guard at its call
    site in run()) -- QKV-COL reuses that same guard rather than inventing
    its own, since at equal grid size it does strictly less read_symbol work
    than KV-SEED already does (K only, not K+V).
    """
    rows = [(ly, False) for ly in range(H_ROWS)]
    if H_ROWS < P_BLOCK_SIZE:
        rows.append((H_ROWS, True))                # first idle row
        if P_BLOCK_SIZE - 1 != H_ROWS:
            rows.append((P_BLOCK_SIZE - 1, True))   # last idle row
    return rows


def qkv_col_extract_npre_npost(col_arrays, bsz, kv_cols, kv_len_per_pe, plen, n_layers):
    """From P per-column raw XKCache_tile uint16 reads (col_arrays: a list
    of P 1-D arrays, each >= n_layers * bsz*kv_cols*kv_len_per_pe elements,
    one read_symbol per column), return [(layer, npre, npost), ...] -- one
    triple per layer bank in [0, n_layers) -- by replicating the exact
    prefix/suffix column-distinctness slicing run() always performed, now
    generalized from bank 0 only to every bank the caller asks for.

    K3 (2026-09-09) pulled this out of run()'s QKV-COL block as a pure
    function (same slicing, same byte-content set()-distinctness test) so
    `scripts/test_qkv_col_check.py` can seed a defect straight into synthetic
    per-column buffers -- including "only layer 3 is broken" -- and exercise
    the exact extraction real device readback feeds into
    qkv_col_verdict_word, without a simulator run.
    """
    slab = bsz * kv_cols * kv_len_per_pe
    out = []
    for l in range(n_layers):
        off = l * slab
        pre, post = [], []
        for col in col_arrays:
            k = np.asarray(col[off:off + slab]).reshape(bsz, kv_cols, kv_len_per_pe)
            pre.append(k[:, :, :plen].copy().tobytes())
            post.append(k[:, :, plen:].copy().tobytes())
        out.append((l, len(set(pre)), len(set(post))))
    return out


def qkv_col_aggregate(samples, P, n_dummy_cols=0):
    """samples: iterable of (by, ly, layer, npre, npost, is_idle,
    decode_reached). Returns (ok, detail) for ONE aggregate QKV-COL
    record_verdict() call: healthy only if every sampled (row, ly, layer)
    came back healthy or (for idle / not-yet-reached samples) inert --
    DEFECT and INCONCLUSIVE both fail, since INCONCLUSIVE means the
    instrument couldn't see a defect if there was one, which is not
    evidence of health.

    K3 (2026-09-09) extended the sample tuple from (by, ly, npre, npost) to
    also carry `layer` (which bank, of possibly several per row -- see
    qkv_col_extract_npre_npost) and `is_idle` (see qkv_col_sample_rows /
    qkv_col_verdict_word). Existing callers must pass both explicitly now;
    see scripts/test_verdict_sink.py's updated QKV-COL cases.

    n_dummy_cols (K3 follow-up, 2026-09-09): forwarded to qkv_col_verdict_word
    for every non-idle sample -- a single run-wide constant (the RoPE-pair
    padding, launch.py:665-682, is the same for every row/layer), not
    per-sample, so it is a parameter here rather than part of the tuple.
    Defaults to 0 (no padding, every config shipped today), which reduces
    every threshold back to the original flat P.

    decode_reached (K3 follow-up, 2026-09-09): the sample tuple's 7th field,
    per-row (see qkv_col_row_reached) since a short decode run reaches
    different rows differently, unlike n_dummy_cols. Existing callers must
    now pass 7-tuples; True (the old, only-ever-implicit behavior) for every
    row means "assume fully reached".
    """
    scored = [(by, ly, layer, npre, npost, is_idle,
               qkv_col_verdict_word(npre, npost, P, is_idle=is_idle,
                                     n_dummy_cols=n_dummy_cols, decode_reached=decode_reached))
              for by, ly, layer, npre, npost, is_idle, decode_reached in samples]
    bad = [s for s in scored if not (s[6].startswith("healthy") or s[6].startswith("inert"))]
    ok = len(bad) == 0
    n_idle = sum(1 for s in scored if s[5])
    detail = (f"{len(scored)} (row,ly,layer) sample(s) checked "
              f"({len(scored) - n_idle} active, {n_idle} idle), {len(bad)} not healthy/inert")
    if bad:
        # Cap the enumerated list: a widespread defect (e.g. full collapse
        # across every sampled row/layer) can produce thousands of `bad`
        # entries now that the sweep covers the whole active height -- see
        # scripts/test_qkv_col_check.py case (a), which is exactly this
        # shape. The COUNT above already says how bad it is; the examples
        # are for locating it, not exhausting it.
        _cap = 8
        detail += "; " + "; ".join(
            f"row={by} ly={ly}{'[idle]' if idle else ''} layer={layer} "
            f"pre={npre}/{P} post={npost}/{P} -> {v.split(' — ')[0]}"
            for by, ly, layer, npre, npost, idle, v in bad[:_cap])
        if len(bad) > _cap:
            detail += f"; ... and {len(bad) - _cap} more"
    return ok, detail


def kv_seed_cut_owner_bx(row, chain, p_block_size):
    """Physical X-block index (0 or 1) of the role that owns KV on `row`,
    read from `chain[(row, role)]`'s `owns_kv` flag (CHAIN's 5th tuple
    field) -- NOT the vanilla assumption that the owner is always role 1
    (the "attn slot") at the row-parity column `0 if row%2==0 else 1`.

    K4 (2026-09-09): placement (launch.py:1750-1822) pins role 1 at that
    parity-derived column and role 0 at the other one, for EVERY row
    regardless of CHAIN -- `for _rg, _role_bit in ((attn_rg, 1), (ffn_rg,
    0))`. Every CHAIN variant shipped in this tree today happens to put
    owns_kv on role 1 wherever it appears at all (verified: stage_cut in
    {2,3,5,6,7} all pair `owns_kv=True` with role 1 only; stage_cut 4 has no
    KV owner at all), so reading the role from CHAIN and reading it from the
    row-parity "attn slot" shortcut give the same physical column today --
    but the vanilla-derived shortcut would silently read the WRONG PE's
    cache (the FFN slot's, which never runs kv_ingress) the day a CHAIN
    variant puts owns_kv on role 0, with no assertion to catch it. This
    reads the role from CHAIN so that case fails loudly instead (the assert
    below) rather than reading stale zeros and calling it a PASS.
    """
    attn_bx = 0 if row % 2 == 0 else 1
    owners = [role for role in (0, 1) if chain[(row, role)][4]]
    assert len(owners) == 1, (
        f"row {row}: expected exactly one KV-owning role in CHAIN, got "
        f"{owners} (CHAIN[{row},0]={chain.get((row, 0))}, "
        f"CHAIN[{row},1]={chain.get((row, 1))})")
    role = owners[0]
    return attn_bx if role == 1 else (1 - attn_bx)


def kv_seed_cut_inj_index(kv_rows):
    """Map each KV-owning block row to its position along inj_xk/inj_xv's
    first axis.

    inj_xk/inj_xv (launch.py:2687-2692) are built by filtering
    `range(P_Y_BLOCK_NUM)` down to the rows actually present in
    `kv_inj_rows` -- which is exactly `kv_rows`, in ascending order -- not
    by indexing the full P_Y_BLOCK_NUM range. In vanilla mode `kv_rows ==
    range(P_Y_BLOCK_NUM)` so a row's inj_xk slot equals its own row number
    and the two coincide; in cut mode they diverge (e.g. `kv_rows=[1, 3]`
    for STAGE_CUT=2 -- row 1's data lives at inj_xk[0], row 3's at
    inj_xk[1]) and indexing `inj_xk[row]` directly either reads a
    DIFFERENT KV-owning row's data (when a lower-indexed owner row exists)
    or raises IndexError (once `row >= len(kv_rows)`, e.g. row 3 against an
    array of length 2).
    """
    return {row: i for i, row in enumerate(kv_rows)}


# ---------------------------------------------------------------------------- #
# Core entry
# ---------------------------------------------------------------------------- #

@_with_runtime_cleanup
def run(cfg: dict, *, cmaddr=None,
        artifact_dir: Path,
        cslc_prefix: str = "",
        compile_only: bool = False) -> dict:
    """Compile and execute the SdkLayout artifact.

    Args:
      cfg          : config dict with Pw/Ph/P_*_BLOCK_NUM/bsz/dim/... fields
      cmaddr       : None for local simfab; "IP:PORT" for appliance/real WSE-3
      artifact_dir : where to chdir + emit compile artifacts (sim.log etc.)
      cslc_prefix  : optional override for cslc driver path
      compile_only : if True, return immediately after `layout.compile(...)`
                     without instantiating SdkRuntime / runtime.run / oracle.
                     Useful for build-only validation (e.g. CI smoke tests).

    Returns:
      {"compile_s": float, "run_s": float}  (run_s=0.0 in compile_only mode)
    """
    # Host wall-clock stage timing (perf_counter, stage order). Phase 1..4 host prep
    # (sizing + region build + weight tiling + set_symbol bake) is measured as one
    # "host_build" stage up to t_compile; compile/load and the per-round decode stages
    # are timed individually below. perf_counter is ~ns-cheap and only whole-stage
    # boundaries are timed (never inside a hot per-token step), so it never perturbs the
    # device pipeline (the host drains logits without back-pressuring HT_tail).
    _t_run_entry = time.perf_counter()
    # ====================================================================== #
    # Phase 1: sizing / derived / paths / platform                          #
    # ====================================================================== #

    # --- Sizing / derived dimensions --- #
    Pw = cfg["Pw"]
    Ph = cfg["Ph"]
    P_X_BLOCK_NUM = cfg["P_X_BLOCK_NUM"]
    P_Y_BLOCK_NUM = cfg["P_Y_BLOCK_NUM"]
    assert P_X_BLOCK_NUM == 2, (
        "decode role-split requires exactly two block columns (one ATTN and one FFN)"
    )
    assert Pw // P_X_BLOCK_NUM == Ph // P_Y_BLOCK_NUM, "blocks must be square"
    assert P_Y_BLOCK_NUM % 2 == 0, (
        "P_Y_BLOCK_NUM must be even so last_row is odd, which keeps "
        "HT_tail/mux on the WEST side (sharing X with HT_head/demux). Odd "
        "P_Y_BLOCK_NUM pushes HT_tail+mux east of the block region and "
        "blows up the fabric width budget."
    )
    P_BLOCK_SIZE = Pw // P_X_BLOCK_NUM

    bsz        = cfg["bsz"]
    dim        = cfg["dim"]
    head_dim   = cfg["head_dim"]
    max_seq_len    = cfg["MAX_SEQ_LEN"]
    ffn_dim    = cfg["ffn_dim"]
    n_heads    = cfg["n_heads"]
    n_kv_heads = cfg["n_kv_heads"]
    group_num  = cfg["group_num"]
    top_k      = cfg["TOP_K"]
    # On-chip sampling (mirror HF generation_config). The autoregressive token is
    # a categorical SAMPLE from the top-k nucleus, not argmax. min_p omitted.
    temperature = cfg["temperature"]
    top_p       = cfg["top_p"]
    sample_seed = cfg["seed"]
    # Device-side EOS detection pads finished lanes and stops once all lanes finish.
    eos_token_ids = cfg["eos_token_ids"]
    pad_token_id = cfg["pad_token_id"]
    eos_id_0 = int(eos_token_ids[0]) if len(eos_token_ids) > 0 else -1
    eos_id_1 = int(eos_token_ids[1]) if len(eos_token_ids) > 1 else -1
    n_layers        = cfg["n_layers"]
    prefill_lens    = [int(v) for v in cfg["PREFILL_LENS"]]
    decode_lens     = [int(v) for v in cfg["DECODE_LENS"]]
    assert prefill_lens and len(prefill_lens) == len(decode_lens), (
        "PREFILL_LENS and DECODE_LENS must be non-empty and have equal length")
    num_rounds = len(prefill_lens)
    # First-round values seed host-side diagnostics. Compile capacities remain
    # request-independent.
    prefill_len = prefill_lens[0]
    max_output_len = decode_lens[0]
    # Benchmark TSC timing window. step 0 = prefill is always excluded; WARMUP
    # skips that many additional decode tokens. Start is sampled at
    # tail_step==warmup_cycles, end at the last step → counted_tokens timed.
    warmup          = cfg["WARMUP"]
    warmup_cycles   = warmup + 1

    # ================== P_BLOCK_SIZE constraints (Qwen3-4B) ============ #
    # This path is dedicated to Qwen3-4B (hidden dim=2560, head_dim=128, n_heads=32,
    # n_kv_heads=8 -> gqa=4; attn_dim=n_heads*head_dim=4096 DECOUPLED from hidden 2560).
    # P_BLOCK_SIZE = Pw/P_X_BLOCK_NUM is NOT free; when
    # generating a sim or device config, pick P_BLOCK_SIZE to satisfy ALL of:
    #
    #   (1) P_BLOCK_SIZE % 8 == 0  and  >= 8           [K-pipe: KPIPE_M = P/8 >= 1]
    #   (2) Padding preserves n_heads/n_kv_heads, and each PE shard satisfies
    #       attn_per_pe == gqa_group_size * kv_cols.
    #   (3) group_num | P_BLOCK_SIZE                    [2-phase Y-reduce tree]
    #   (4) P_BLOCK_SIZE % n_kv_heads == 0              [kv-head X band]
    #   (5) wafer fit, 2x4 layout: 4*P+2 <= ~1172 height; width = HT_WIDTH_tail +
    #       2*P + strips <= ~762 on the WSE-3 fabric.
    #
    # P_BLOCK_SIZE must be >= 256: the HT_head embedding table is 2*vocab*dim/P^2
    # per PE, which at P=128 is 76 KB/PE (overflows the i16 array dim + the 48 KB
    # SRAM); P=256 brings it to 19 KB/PE. So the device configs use P_BLOCK_SIZE=256:
    #   - 2x4 (Pw512/Ph1024, four role rows): real 36-layer geometry, [9,9,9,9];
    #     4*256+2 = 1026 PE rows <= ~1172.
    #   - 2x2 (Pw512/Ph512, two role rows): 36 layers become [18,18] and require
    #     a separate capacity check; it is not a smaller equivalent layer split.
    # dim_per_pe=10, kv_cols=4, gqa=4; vocab 151936 pads to 152064 (next
    # multiple of P_BLOCK_SIZE = lcm(256, HT_WIDTH_tail=128)). Constraints (1)/(3)/(4)
    # and the GQA ratio are enforced by asserts; (5) by the geometry.
    #
    # SIM configs scale every dimension down but retain GQA (n_heads=8,
    # n_kv_heads=2) so QK-Norm and the KV-head band reduce stay exercised. Constraint
    # (1) (P%8==0, P>=8) ALWAYS applies, device and sim alike — a P<8 or
    # non-multiple-of-8 (e.g. 6) makes KPIPE_M=0 and SEGFAULTS, so sim blocks must
    # be P=8,16,24,... never 6.
    # ==================================================================== #
    # ================== P_BLOCK_SIZE padding resolution ================== #
    # P_BLOCK_SIZE need not divide the model dims. Pad each sharded dim UP to
    # a multiple of P_BLOCK_SIZE; for head-structured dims (dim, kv_dim) pad to
    # a multiple of lcm(P_BLOCK_SIZE, head_dim) so head boundaries stay PE-
    # aligned (dim_per_pe / kv_dim_per_pe / pes_per_kv_head / gqa_group_size
    # then equal their divisible-case values). Padding is zero-filled in the
    # weights (heads 32..35 / kv-head 8 / dummy dims / dummy vocab carry zeros),
    # so the device per-PE structure is unchanged. head_dim is NEVER padded.
    # When a dimension already divides, _pad_to is the identity. The _true values
    # are kept for (a) RNG draws (draw true, then zero-pad), (b) the RMSNorm
    # divisor (true hidden dim), (c) restricting top-K to real vocab.
    from math import gcd as _gcd
    def _pad_to(x, m):
        return ((x + m - 1) // m) * m
    def _lcm(a, b):
        return a * b // _gcd(a, b)
    def _zpad(a, shape):
        # Zero-pad ndarray `a` up to `shape`; real data sits at the origin, the
        # tail (dummy heads / dims / vocab) is exactly zero. Identity when equal.
        shape = tuple(shape)
        if a.shape == shape:
            return a
        out = np.zeros(shape, dtype=a.dtype)
        out[tuple(slice(0, s) for s in a.shape)] = a
        return out

    HT_WIDTH_tail_cfg = cfg["HT_WIDTH_tail"]
    _head_mult        = _lcm(P_BLOCK_SIZE, head_dim)
    _vocab_mult       = _lcm(P_BLOCK_SIZE, HT_WIDTH_tail_cfg)

    dim_true      = dim
    kv_dim_true   = n_kv_heads * head_dim
    n_heads_true  = n_heads
    n_kv_heads_true = n_kv_heads
    attn_dim_true = n_heads * head_dim   # DECOUPLED from hidden at 4B (32*128=4096 != 2560)
    ffn_true      = ffn_dim
    seq_true      = max_seq_len
    vocab_true    = cfg["vocab_size"]
    # prefill_len is NOT auto-padded: it is the RoPE start position (a real
    # token position), so padding it would shift every RoPE angle. Configs must
    # keep PREFILL_LEN divisible by P_BLOCK_SIZE (the assert below enforces it).

    dim           = _pad_to(dim_true,    _head_mult)
    kv_dim_pad    = _pad_to(kv_dim_true, _head_mult)
    ffn_dim       = _pad_to(ffn_true,    P_BLOCK_SIZE)
    max_seq_len       = _pad_to(seq_true,    P_BLOCK_SIZE)
    vocab_pad     = _pad_to(vocab_true,  _vocab_mult)
    attn_dim_pad  = _pad_to(attn_dim_true, _head_mult)
    # Head counts derive from the attention dimensions, not the hidden dimension.
    # Padding preserves whole head boundaries; head_dim itself is unchanged.
    n_heads       = attn_dim_pad // head_dim
    n_kv_heads    = kv_dim_pad  // head_dim

    is_padded = (dim != dim_true or kv_dim_pad != kv_dim_true or ffn_dim != ffn_true
                 or max_seq_len != seq_true or vocab_pad != vocab_true)
    print(f"      [pad] padded={is_padded}: dim {dim_true}->{dim} "
          f"n_heads {n_heads_true}->{n_heads} n_kv_heads {n_kv_heads_true}->{n_kv_heads} "
          f"kv_dim {kv_dim_true}->{kv_dim_pad} ffn {ffn_true}->{ffn_dim} "
          f"seq {seq_true}->{max_seq_len} vocab {vocab_true}->{vocab_pad}")
    # ==================================================================== #

    # ---- Sub-block heights (one-layer-cuts budget B'): ACTIVE_ROWS ---- #
    # H_ROWS = the number of ACTIVE rows per stage block (uniform across
    # roles for now; the A/B hand-offs then need no resharding, only the
    # head-entry and tail-exit funnels change sharding). Default = square.
    H_ROWS = int(cfg.get("ACTIVE_ROWS", P_BLOCK_SIZE))
    if H_ROWS != P_BLOCK_SIZE:
        assert P_BLOCK_SIZE % H_ROWS == 0, "ACTIVE_ROWS must divide P_BLOCK_SIZE (funnel groups)"
        assert dim % H_ROWS == 0, f"dim {dim} % ACTIVE_ROWS {H_ROWS} != 0"
        assert max_seq_len % H_ROWS == 0, f"MAX_SEQ_LEN % ACTIVE_ROWS != 0"

    # The first round seeds host-side oracle state. Every round is validated
    # against the same constraints below.
    assert prefill_len % H_ROWS == 0, (
        f"PREFILL_LEN ({prefill_len}) must be divisible by ACTIVE_ROWS ({H_ROWS})"
    )
    prefill_len_per_pe = prefill_len // H_ROWS

    # GQA dims. kv_dim = n_kv_heads * head_dim; in dense (n_kv_heads==n_heads), kv_dim == dim.
    assert attn_dim_pad == n_heads * head_dim, f"attn_dim_pad ({attn_dim_pad}) must equal n_heads*head_dim ({n_heads}*{head_dim})"
    kv_dim = n_kv_heads * head_dim
    assert dim % n_kv_heads == 0 and n_heads % n_kv_heads == 0, (
        f"GQA requires n_heads ({n_heads}) divisible by n_kv_heads ({n_kv_heads})"
    )

    # Block shards are ROW shards at the active height; the head/tail band and
    # the strips stay 256-lane and use the LANE shard.
    dim_per_pe       = dim // H_ROWS
    dim_per_pe_lane  = dim // P_BLOCK_SIZE
    kv_dim_per_pe    = kv_dim // P_BLOCK_SIZE
    # KV-cache context cap: the on-chip XKCache/XVCache tiles are sized
    # kv_len_per_pe = MAX_SEQ_LEN / P_BLOCK_SIZE, so the cache holds exactly
    # MAX_SEQ_LEN positions. Request validation enforces prefill + decode within
    # this capacity. MAX_SEQ_LEN must divide evenly or the cache
    # silently under-sizes and decode would drop positions past the cap — assert
    # it so a bad config fails fast instead of corrupting attention.
    assert max_seq_len % H_ROWS == 0, (
        f"MAX_SEQ_LEN ({max_seq_len}) must be divisible by ACTIVE_ROWS ({H_ROWS}) "
        f"so the per-PE KV cache holds the full context"
    )
    kv_len_per_pe   = max_seq_len // H_ROWS
    # ffn inner dim is WIDTH-sharded (out bands = 256 columns); height changes
    # scale FFN work through dim_per_pe only.
    ffn_dim_per_pe   = ffn_dim // P_BLOCK_SIZE
    # Compile-time capacities cover every request round. KV metadata carries
    # the live prefill rows and independent decode budget.
    max_output_len_worst = max_seq_len - H_ROWS
    prefill_max_per_pe   = kv_len_per_pe - 1
    assert 2 <= max_output_len_worst <= 32765, (
        f"worst-case budget {max_output_len_worst} must fit i16 with +2 strip headroom")
    for rnd, (pl, dl) in enumerate(zip(prefill_lens, decode_lens)):
        assert pl % H_ROWS == 0, (
            f"round {rnd}: prefill {pl} must be divisible by P_BLOCK_SIZE {P_BLOCK_SIZE}")
        pl_per_pe = pl // H_ROWS
        assert 1 <= pl_per_pe <= prefill_max_per_pe, (
            f"round {rnd}: prefill rows/PE {pl_per_pe} must be in [1, {prefill_max_per_pe}]")
        assert 2 <= dl <= max_output_len_worst, (
            f"round {rnd}: decode length {dl} must be in [2, {max_output_len_worst}]")
        assert pl + dl <= seq_true, (
            f"round {rnd}: prefill {pl} + decode {dl} exceeds MAX_SEQ_LEN {seq_true}")

    # ------------------- forced-prefill mode (step1-forced) ------------------ #
    # Optional request key FORCED_TOKENS: bsz lists of token ids. When present,
    # the HT head embeds these instead of draining the sampled token (steps
    # 1..N-1 of every round), and the HT tail skips its north emit — the rows
    # then pipeline (decoder as prefiller). The compiled image is identical in
    # both modes (FORCED_CAP is sized from DECODE_LENS either way).
    forced_tokens_cfg = cfg.get("FORCED_TOKENS")
    forced_mode_flag = 1 if forced_tokens_cfg is not None else 0
    forced_production_flag = 1 if cfg.get("FORCED_PRODUCTION") else 0
    assert not (forced_production_flag and not forced_mode_flag), (
        "FORCED_PRODUCTION requires FORCED_TOKENS")
    forced_cap = max(1, max(decode_lens) - 1)
    if forced_mode_flag:
        assert isinstance(forced_tokens_cfg, list) and len(forced_tokens_cfg) == bsz, (
            f"FORCED_TOKENS must be a list of bsz={bsz} lane lists")
        for lane, seq in enumerate(forced_tokens_cfg):
            assert isinstance(seq, list) and len(seq) >= forced_cap, (
                f"FORCED_TOKENS lane {lane}: need >= {forced_cap} tokens, got {len(seq)}")
            assert all(isinstance(t, int) and 0 <= t < cfg["vocab_size"] for t in seq[:forced_cap]), (
                f"FORCED_TOKENS lane {lane}: token ids must be ints in [0, {cfg['vocab_size']})")
    _htw = int(cfg["HT_WIDTH_tail"])
    print(f"  [forced] forced_mode={forced_mode_flag} production={forced_production_flag} "
          f"FORCED_CAP={forced_cap} (sharded: "
          f"{((forced_cap + _htw - 1) // _htw) * bsz * 4} B/head-PE)")
    # GQA ratio from HEAD COUNTS (decoupled at 4B: dim_per_pe=10, kv_dim_per_pe=4 would
    # wrongly give 2; real ratio n_heads//n_kv_heads=4). The assert below re-checks vs true.
    gqa_group_size = n_heads // n_kv_heads
    KV_DSD_EXTENT_CAP = 32766            # < INFINITE_DSD_LEN (0x7fff)
    # The score collective narrows its fabric DSDs every decode step to
    # G*batch*iter_num.  0x7fff is the infinite-length sentinel, not a finite
    # transfer size; fail at configuration time instead of risking a silent
    # runtime hang.  The 16K Qwen3-4B geometry is far below this bound because
    # KV sequence rows are sharded across P_BLOCK_SIZE.
    score_collective_max = gqa_group_size * bsz * kv_len_per_pe
    assert score_collective_max <= KV_DSD_EXTENT_CAP, (
        f"score collective max extent ({gqa_group_size}*{bsz}*{kv_len_per_pe}="
        f"{score_collective_max}) exceeds finite fabric DSD cap {KV_DSD_EXTENT_CAP}; "
        "add deterministic score-collective chunking for this geometry")
    # Padding must PRESERVE the GQA ratio: dim and kv_dim are padded independently
    # to multiples of lcm(P_BLOCK_SIZE, head_dim), which for pathological dims could
    # change n_heads_pad/n_kv_heads_pad. Fail fast rather than silently decode with
    # the wrong head grouping.
    assert gqa_group_size == n_heads_true // n_kv_heads_true, (
        f"padding changed the GQA ratio: padded gqa={gqa_group_size} but true "
        f"gqa={n_heads_true // n_kv_heads_true} (n_heads {n_heads_true}->{n_heads}, "
        f"n_kv_heads {n_kv_heads_true}->{n_kv_heads}); pick a P_BLOCK_SIZE/head_dim "
        "whose padding keeps dim_pad a multiple of kv_dim_pad."
    )
    # head_dim is passed through as a scalar (not sharded by P_BLOCK_SIZE);
    # decode.csl uses it only for `1/sqrt(head_dim)` and `value/head_dim` math.
    assert P_BLOCK_SIZE % group_num == 0, (
        f"group_num ({group_num}) must divide P_BLOCK_SIZE ({P_BLOCK_SIZE}) so the "
        "2-phase Y-reduce tree covers every PE with exactly one role (a stranded "
        "PE = reduce wavelet-count deadlock)."
    )
    pe_num_per_group = P_BLOCK_SIZE // group_num
    root_1st_phase = pe_num_per_group // 2
    # Y-axis tree geometry at the active height (== the square values when
    # H_ROWS == P_BLOCK_SIZE). Keep the group SIZE >= 2 by shrinking the Y
    # group count if needed.
    group_num_y = group_num
    while group_num_y > 1 and (H_ROWS % group_num_y != 0 or H_ROWS // group_num_y < 2):
        group_num_y //= 2
    pe_group_y = H_ROWS // group_num_y
    if H_ROWS != P_BLOCK_SIZE:
        # The two-phase Y tree needs >= 2 groups (the 2nd phase reduces
        # ACROSS group roots) and >= 2 PEs per group (the 1st-phase root
        # unconditionally receives from its group). Sub-heights below 4 rows
        # are structurally unsupported — compiled fact from the H=2 sim wedge
        # (single group -> 2nd-phase root waits forever).
        assert group_num_y >= 2 and pe_group_y >= 2, (
            f"ACTIVE_ROWS={H_ROWS}: Y tree needs >=2 groups x >=2 PEs "
            f"(got {group_num_y} x {pe_group_y}); minimum height is 4")
    assert pe_group_y >= 1 and H_ROWS % group_num_y == 0
    root_1st_y = pe_group_y // 2
    root_2nd_y = (group_num_y // 2) * pe_group_y + root_1st_y
    # KV-head Y-axis scoping. pes_per_kv_head = Y-PEs serving one KV head; the
    # kv-head-scoped score reduce runs across those rows (not full Ph).
    assert P_BLOCK_SIZE % n_kv_heads == 0, (
        f"P_BLOCK_SIZE ({P_BLOCK_SIZE}) must be divisible by n_kv_heads ({n_kv_heads})"
    )
    pes_per_kv_head = P_BLOCK_SIZE // n_kv_heads
    assert pes_per_kv_head >= 1, f"pes_per_kv_head must be >=1, got {pes_per_kv_head}"

    # ======== Attention-column shard, decoupled from the hidden shard ======== #
    # RoPE-pair atomicity: _perm_WQ / _reshard_K_dim co-locate each (lo,hi) pair
    # (positions i, i+head_dim/2) on ONE X-band, so every band must hold a WHOLE
    # number of pairs. When (head_dim/2) % pes_per_kv_head != 0, the
    # attention/Q/K/V columns are sharded over a
    # PADDED head_dim_shard (next multiple of 2*pes_per_kv_head), the dummy tail
    # (head positions head_dim..head_dim_shard) zero-filled in the weights so it
    # contributes 0 to Q·K / QK-norm / V. The HIDDEN dim is NOT padded: it stays
    # dim_per_pe everywhere (Z/FFN/Wo-out/residual/embedding). attn_per_pe and
    # kv_cols are the (possibly padded) Q and K/V column widths per X-PE; head_dim
    # (true) still feeds the QK-norm divisor and 1/sqrt(head_dim) scale.
    # The hidden and attention shards remain independent; only the attention
    # shard may gain zero-filled tail positions for RoPE-pair alignment.
    _pairs_per_pe_max = -(-(head_dim // 2) // pes_per_kv_head)        # ceil division
    head_dim_shard    = 2 * pes_per_kv_head * _pairs_per_pe_max
    hidden_per_pe     = dim_per_pe                                    # TRUE hidden Y-shard
    attn_per_pe       = (n_heads    * head_dim_shard) // P_BLOCK_SIZE
    kv_cols           = (n_kv_heads * head_dim_shard) // P_BLOCK_SIZE
    # ---------------- one-layer-cuts stage chain (STAGE_CUT) ---------------- #
    # 0 = vanilla. 2 = cut (ii) A1 | A2 | FFN mapped onto the serpentine with
    # A2 on the vanilla ATTN slots (KV ingress unchanged) and wide relays:
    #   r0: A1(L0)@attn | relay34@ffn      r1: A2(L0)@attn | FFN(L0)@ffn
    #   r2: A1(L1)@attn | relay34@ffn      r3: A2(L1)@attn | FFN(L1)@ffn
    stage_cut = int(cfg.get("STAGE_CUT", 0))
    qkv_chunk_host = bsz * (attn_per_pe + 2 * kv_cols)
    wide = qkv_chunk_host + bsz * dim_per_pe
    narrow = 0   # 0 -> default bsz*dim_per_pe in the kernel
    if stage_cut == 2:
        assert P_Y_BLOCK_NUM == 4 and n_layers == 2, "cut (ii) needs 4 rows / 2 layers"
        assert all(p == prefill_lens[0] for p in prefill_lens) and \
               all(d == decode_lens[0] for d in decode_lens), \
            "cut chains support uniform-shape rounds only (budget/prefill are baked)"
        # (row, role): (stage_kind, in_elems, out_elems, layer, owns_kv)
        CHAIN = {
            (0, 1): (1, narrow, wide, 0, False),   # A1 L0 @ attn slot
            (0, 0): (4, wide, wide, None, False),  # relay34 @ ffn slot
            (1, 1): (2, wide, narrow, 0, True),    # A2 L0 @ attn slot (KV)
            (1, 0): (0, narrow, narrow, 0, False), # vanilla FFN L0
            (2, 1): (1, narrow, wide, 1, False),
            (2, 0): (4, wide, wide, None, False),
            (3, 1): (2, wide, narrow, 1, True),
            (3, 0): (0, narrow, narrow, 1, False),
        }
        kv_rows = [1, 3]
        STRIP_ELEMS = {(r, 1): wide for r in range(4)}   # all east hops wide
    elif stage_cut == 3:
        # Minimal bring-up chain: one layer, 4 stages on 2 rows.
        assert P_Y_BLOCK_NUM == 2 and n_layers == 1
        CHAIN = {
            (0, 1): (1, narrow, wide, 0, False),   # A1 @ r0-attn
            (0, 0): (4, wide, wide, None, False),  # relay34 @ r0-ffn
            (1, 1): (2, wide, narrow, 0, True),    # A2 @ r1-attn (KV)
            (1, 0): (0, narrow, narrow, 0, False), # vanilla FFN, result row
        }
        kv_rows = [1]
        # BOTH ends of the row0->row1 hop are wide: (0,1) is the SENDER strip
        # (even row, east) and (1,1) the RECEIVER strip (odd row, east) that
        # broadcasts into A2. Strips re-frame the stream by their own width,
        # so a narrow receiver exhausts its per-round record budget after
        # ~26*narrow halves (~7 wide tokens) and the chain wedges — the
        # token-6 crash of 2026-09-05.
        STRIP_ELEMS = {(0, 1): wide, (1, 1): wide}
        if int(os.environ.get("DIAG_NARROW", "0")):
            # Diagnostic: same chain, all hand-offs narrow (contents stubbed
            # upstream; isolates the wide path from the stage-kind skeleton).
            CHAIN = {k: (v[0], narrow, narrow, v[3], v[4]) for k, v in CHAIN.items()}
            STRIP_ELEMS = {}
    elif stage_cut == 4:
        # Diagnostic skeleton: every square a narrow relay (no model content).
        assert P_Y_BLOCK_NUM == 2
        CHAIN = {
            (0, 1): (4, narrow, narrow, None, False),
            (0, 0): (4, narrow, narrow, None, False),
            (1, 1): (4, narrow, narrow, None, False),
            (1, 0): (4, narrow, narrow, None, False),
        }
        kv_rows = []
        STRIP_ELEMS = {}
    elif stage_cut == 6:
        # Diagnostic hybrid: cut layer 0 on rows 0-1, vanilla layers 1-2 on
        # rows 2-3. Separates "two chained cut layers" from "cut layer + deep
        # pipe" for the round-1 re-arm stall (2026-09-05).
        assert P_Y_BLOCK_NUM == 4 and n_layers == 3
        CHAIN = {
            (0, 1): (1, narrow, wide, 0, False),   # A1 L0
            (0, 0): (4, wide, wide, None, False),  # relay34
            (1, 1): (2, wide, narrow, 0, True),    # A2 L0 (KV)
            (1, 0): (0, narrow, narrow, 0, False), # vanilla FFN L0
            (2, 1): (0, narrow, narrow, 1, True),  # vanilla L1 (KV)
            (2, 0): (0, narrow, narrow, 1, False),
            (3, 1): (0, narrow, narrow, 2, True),  # vanilla L2 (KV)
            (3, 0): (0, narrow, narrow, 2, False),
        }
        kv_rows = [1, 2, 3]
        STRIP_ELEMS = {(0, 1): wide, (1, 1): wide}
    elif stage_cut == 7:
        # Diagnostic mirror of 6: vanilla layers 0-1 on rows 0-1, cut layer 2
        # on rows 2-3.
        assert P_Y_BLOCK_NUM == 4 and n_layers == 3
        CHAIN = {
            (0, 1): (0, narrow, narrow, 0, True),
            (0, 0): (0, narrow, narrow, 0, False),
            (1, 1): (0, narrow, narrow, 1, True),
            (1, 0): (0, narrow, narrow, 1, False),
            (2, 1): (1, narrow, wide, 2, False),   # A1 L2
            (2, 0): (4, wide, wide, None, False),  # relay34
            (3, 1): (2, wide, narrow, 2, True),    # A2 L2 (KV)
            (3, 0): (0, narrow, narrow, 2, False), # vanilla FFN L2 (result)
        }
        kv_rows = [0, 1, 3]
        STRIP_ELEMS = {(2, 1): wide, (3, 1): wide}
        if int(os.environ.get("DIAG_NARROW", "0")):
            CHAIN = {k: (v[0], narrow, narrow, v[3], v[4]) for k, v in CHAIN.items()}
            STRIP_ELEMS = {}
    elif stage_cut == 5:
        # Diagnostic: cut-mode machinery with all-vanilla stages (must equal
        # the vanilla 2-row build bit for bit).
        assert P_Y_BLOCK_NUM == 2 and n_layers == 2
        CHAIN = {
            (0, 1): (0, narrow, narrow, 0, True),
            (0, 0): (0, narrow, narrow, 0, False),
            (1, 1): (0, narrow, narrow, 1, True),
            (1, 0): (0, narrow, narrow, 1, False),
        }
        kv_rows = [0, 1]
        STRIP_ELEMS = {}
    else:
        CHAIN = None
        kv_rows = list(range(P_Y_BLOCK_NUM))
        STRIP_ELEMS = {}
    if CHAIN is not None:
        assert H_ROWS == P_BLOCK_SIZE, "STAGE_CUT chains do not support ACTIVE_ROWS yet"
        assert all(p == prefill_lens[0] for p in prefill_lens) and \
               all(d == decode_lens[0] for d in decode_lens), \
            "cut chains support uniform-shape rounds only (budget/prefill are baked)"

    assert kv_cols % 2 == 0 and attn_per_pe == gqa_group_size * kv_cols, (
        f"attn shard broken: attn_per_pe={attn_per_pe} kv_cols={kv_cols} "
        f"gqa={gqa_group_size} head_dim {head_dim}->shard {head_dim_shard}"
    )
    head_dim_pad = head_dim_shard != head_dim
    print(f"      [attn] head_dim {head_dim}->shard {head_dim_shard} "
          f"hidden_per_pe={hidden_per_pe} attn_per_pe={attn_per_pe} kv_cols={kv_cols} "
          f"(kv_dim_per_pe_true={kv_dim_per_pe}, pad={head_dim_pad})")

    # Token embedding on HT_head: vocab_size must divide evenly across the
    # P_BLOCK_SIZE Y rows (each row owns V_per_pe_y vocab entries). Use the
    # padded vocab (true vocab rows + dummy zero rows at the tail).
    vocab_size = vocab_pad
    assert vocab_size % P_BLOCK_SIZE == 0, (
        f"vocab_size ({vocab_size}) must be divisible by P_BLOCK_SIZE ({P_BLOCK_SIZE})"
    )
    assert P_BLOCK_SIZE % 2 == 0, (
        f"P_BLOCK_SIZE ({P_BLOCK_SIZE}) must be even — HT_head diagonal pairing "
        "places diag PEs at py=2x and py=2x+1, requires P_BS even."
    )
    V_per_pe_y = vocab_size // P_BLOCK_SIZE
    HT_W_E_K   = V_per_pe_y * 2 * dim_per_pe_lane   # per-PE W_E tile size (V_per_pe_y rows × 2·dim_per_pe_lane cols)
    # Band middle as the chain-reduce root for the kv-head-scoped allreduce
    # (single-phase bidirectional chain + scoped broadcast). KV-head bands
    # lie along X.
    kv_head_root = pes_per_kv_head // 2
    root_2nd_phase = (group_num // 2) * pe_num_per_group + root_1st_phase
    # One logical transformer block lives in each block row: the row's ATTN and
    # FFN regions own the same layer slice and exchange activations on static
    # multicast colors. The two physical block columns are roles, not two
    # independent layer-pipeline stages.
    N_blocks       = P_Y_BLOCK_NUM
    if stage_cut == 0:
        assert n_layers >= N_blocks, (
            f"n_layers ({n_layers}) must be >= block rows ({N_blocks})"
        )
        layer_counts, layer_offsets = distribute_layers(n_layers, N_blocks)
        max_layers_per_block = max(layer_counts)
    else:
        # Cut chains: one layer per compute stage. CHAIN supplies each region's
        # local_layer_count; total n_layers must not drive vanilla edge-shaving.
        layer_counts  = [1] * N_blocks
        layer_offsets = list(range(N_blocks))
        max_layers_per_block = 1
        # MEASUREMENT SCAFFOLD ONLY — see MODEL_OPTIONAL_KEYS. Default is unchanged.
        _sram_scaffold = int(cfg.get("SRAM_SCAFFOLD_MAX_LAYERS", 0))
        if _sram_scaffold > 0:
            print(f"*** SRAM SCAFFOLD: max_layers_per_block {max_layers_per_block} -> "
                  f"{_sram_scaffold}. Build is COMPILE-ONLY and NOT runnable. ***")
            max_layers_per_block = _sram_scaffold

    # --- Z (raw hidden state) ingress wavelet sizing --- #
    #   Decode's last row streams raw Z into HT_tail (the lm_head input), one
    #   per-PE per-step batch = bsz*dim_per_pe f16 = (bsz*dim_per_pe)/2 32-bit
    #   wavelets, re-sent max_output_len times. Sizes the decode→HT_tail ports.
    assert (bsz * dim_per_pe_lane) % 2 == 0, (
        f"bsz*dim_per_pe_lane={bsz*dim_per_pe_lane} must be even for u16-pair packing"
    )
    batch_per_pe_step   = (bsz * dim_per_pe_lane) // 2
    per_step_wavelets   = batch_per_pe_step * P_BLOCK_SIZE
    # Ports use the compile-time worst-case budget; each round transfers only its
    # runtime token count N. The STOP-Z terminator adds one frame per round.
    # Per-round port (re-armed each round, no *num_rounds). +1 step: the per-round STOP-Z
    # terminator (block relays X[0]=NEG_INF on result_color when it detects the flood).
    total_wavelets      = per_step_wavelets * (max_output_len_worst + 1)

    # --- X (host_in) wavelet sizing --- #
    # Same packing as the logits mux (2 f16 per 32-bit wavelet).
    batch_per_xpe_step  = (bsz * dim_per_pe_lane) // 2
    per_step_x_wavelets = batch_per_xpe_step * P_BLOCK_SIZE
    # Per-round port. +1 step: the per-round HT_head flood terminator on post_embed_x.
    x_total_wavelets    = per_step_x_wavelets * (max_output_len_worst + 1)

    print(f"Host: Pw={Pw} Ph={Ph} P_BLOCK_SIZE={P_BLOCK_SIZE} "
          f"role_rows={N_blocks} (2 physical role columns)")
    print(f"      bsz={bsz} dim={dim} dim_per_pe={dim_per_pe}")
    print(f"      n_heads={n_heads} n_kv_heads={n_kv_heads} head_dim={head_dim}")
    print(f"      kv_dim={kv_dim} kv_dim_per_pe={kv_dim_per_pe} gqa_group_size={gqa_group_size}")
    print(f"      MAX_SEQ_LEN={max_seq_len} kv_len_per_pe={kv_len_per_pe}")
    print(f"      ffn_dim={ffn_dim} ffn_dim_per_pe={ffn_dim_per_pe}")
    print(f"      rounds={list(zip(prefill_lens, decode_lens))} "
          f"n_layers(total)={n_layers}")
    print(f"      layer_counts={layer_counts} layer_offsets={layer_offsets} "
          f"max_layers_per_block={max_layers_per_block}")
    print(f"      pes_per_kv_head={pes_per_kv_head} kv_head_root={kv_head_root}")
    print(f"      cmaddr={cmaddr!r}")

    # --- Output dir / chdir --- #
    here = Path(__file__).parent.resolve()
    artifact_dir = Path(artifact_dir).resolve()
    # Wipe stale compile artifacts so SdkRuntime cannot pick up an ELF from
    # a previous run with a different fabric rectangle.
    if artifact_dir.exists():
        shutil.rmtree(artifact_dir)
    artifact_dir.mkdir(parents=True)
    os.chdir(artifact_dir)

    # --- Platform / layout --- #
    platform = get_platform(cmaddr, SimfabConfig(dump_core=True), SdkTarget.WSE3)
    layout = SdkLayout(platform)

    # ====================================================================== #
    # Phase 2: layout-global resources                                       #
    #   (a) Geometry constants (region placement coords)                    #
    #   (b) Layout-global Colors (shared fabric ids across regions)         #
    #   (c) K-pipe Colors (16 ids; first 5 alias collective ids)            #
    #   (d) Snake-end / mux / HT_tail / demux placement coordinates         #
    # ====================================================================== #

    # --- (a) Geometry --- #
    # Intra-column blocks share one CodeRegion; inter-column fabric flows
    # through layout-global inter_block_{a,b}_color (same physical ID across
    # regions). 5 collective colors stay region-scoped (do not leak across
    # region edges).
    # HT (head/tail) block — inserted between demux↔row_0 (HT_head) and
    # last_row↔mux (HT_tail). HT_head hosts the token-embedding lookup;
    # HT_tail hosts lm_head mesh-gemv.
    #
    # Decoupled widths: the embedding diagonal (col x ↔ rows 2x,2x+1, covering
    # P_BLOCK_SIZE rows) + hidden sharding (HT_WIDTH_head*2*dim_per_pe = dim)
    # lock the EMBEDDING to P_BLOCK_SIZE/2 columns. The tail (lm_head) has no
    # such constraint and shards vocab over MORE X cols so V_per_pe_x
    # (= vocab/HT_WIDTH_tail) and lm_head_tile shrink — letting the fp32 logits
    # partials fit the 48KB PE budget. SdkLayout's connect requires equal port
    # PE counts, so BOTH regions span the full HT_WIDTH_tail-wide band from the
    # west origin HT_HEAD_X. The head runs its embedding on the EAST
    # HT_WIDTH_head columns (x_local in [HT_X_OFFSET, HT_WIDTH_tail)) — adjacent
    # to the decode block so post_embed_x (C2, every step) stays 1-hop, and the
    # tok_bcast token rides the east columns aligned with the tail's emitters.
    # The extra WEST columns only relay pre_embed_x (C1) eastward at step 0;
    # they are idle every step after. When HT_WIDTH_tail == HT_WIDTH_head,
    # HT_X_OFFSET == 0 and there are no west relay-only columns.
    HT_WIDTH_head = P_BLOCK_SIZE // 2
    HT_WIDTH_tail = cfg["HT_WIDTH_tail"]
    assert HT_WIDTH_tail >= HT_WIDTH_head, (
        f"HT_WIDTH_tail ({HT_WIDTH_tail}) must be >= HT_WIDTH_head ({HT_WIDTH_head})"
    )
    HT_X_OFFSET = HT_WIDTH_tail - HT_WIDTH_head   # embedding active cols start at this x_local
    # Embedding identity: the diag pairing makes each of HT_WIDTH_head cols own
    # 2*dim_per_pe hidden positions, which MUST tile the full (padded) dim, else
    # post_embed_x (C2) into row_0 has a wavelet-count mismatch -> hang.
    assert HT_WIDTH_head * 2 * dim_per_pe_lane == dim, (
        f"embed identity broken: HT_WIDTH_head({HT_WIDTH_head})*2*dim_per_pe({dim_per_pe}) "
        f"!= padded dim ({dim}); need P_BLOCK_SIZE*dim_per_pe == dim"
    )
    DEMUX_FAB_X = 2                          # demux pinned at fabric_x=2
    HT_HEAD_X   = DEMUX_FAB_X + 1            # HT band west origin (head/tail/mux), fabric_x=3
    PLACE_X     = HT_HEAD_X + HT_WIDTH_tail + 1   # decode block col 0 fabric_x
    PLACE_Y     = 1
    default_routing_pos = RoutingPosition().set_input([Route.RAMP]).set_output([Route.RAMP])

    # --- (b) Layout-global Colors --- #
    # Layout-global inter-block colors — must have the same physical ID in
    # all row_y regions so wavelets traverse the row_y -> row_y+1 boundary
    # on the same color. Pin 19/20 (user-routable range, no memcpy halo
    # since memcpy_required=False, no collision with collective/result/IO).
    inter_block_a_color = Color("inter_block_a_color", 19)
    inter_block_b_color = Color("inter_block_b_color", 20)
    # Sub-height funnels (H_ROWS < P): block-facing colours crossing the
    # funnel-column -> block boundary (registered Colors + host paints per
    # the 2026-09-05 landmine rules). Ids 7/8 are free on the funnel columns
    # and on the adjacent decode regions.
    funnel_x_out_c = Color("funnel_x_out", 7)
    funnel_r_in_c  = Color("funnel_r_in", 8)

    # Layout-global id 18 — pre-embed X wire. Cargo: the X stream BEFORE
    # HT_head's embedding stage. Used as `out_color` in demux and `pre_embed_x_color`
    # in ht_head (both regions see the same fabric id, just under different
    # local device-param names).
    pre_embed_x_color = Color("pre_embed_x_color", 18)

    # Collective colors — layout-global with pinned IDs 1–6. IDs 1–5 are
    # reused by the K-pipe strip routes below; block PEs and strip PEs live
    # at disjoint X coordinates with disjoint router directions, so the two
    # uses never collide on a wafer-physical wire.
    reduce_1st_0_c   = Color("reduce_1st_color_0",   1)
    reduce_1st_1_c   = Color("reduce_1st_color_1",   2)
    reduce_2nd_0_c   = Color("reduce_2nd_color_0",   3)
    reduce_2nd_1_c   = Color("reduce_2nd_color_1",   4)
    broadcast_c      = Color("broadcast_color",      5)
    intra_row_bcast_c = Color("intra_row_bcast_color", 6)

    # HT_head + HT_tail colors.
    #   tok_bcast_color (tail.TOP→head.BOTTOM token_id channel, also head's
    #     interior SOUTH→{RAMP, NORTH} multicast paint): id 7. Cannot alias
    #     tail's reduce_2nd_color_1 because tail's Y allreduce shares the X
    #     column band.
    #   UP_A_color, UP_B_color (HT_head NORTH chain for W_E gather:
    #     case_src_south + case_src_at_lower_diag): ids 21, 22.
    #   post_embed_x_color (id 23): post-embed X wire. Cargo: the X stream
    #     AFTER HT_head's embedding stage. Used as `post_embed_x_color` in ht_head and
    #     `x_input_color` in decode (same fabric id, different local names).
    tok_bcast_color = Color("tok_bcast_color", 7)
    UP_A_color      = Color("UP_A_color",      21)
    UP_B_color      = Color("UP_B_color",      22)
    post_embed_x_color = Color("post_embed_x_color", 23)

    # The final FFN -> west strip -> HT_tail path crosses region boundaries and
    # therefore uses one layout-global Color object throughout. It reuses id 22;
    # the HT_head UP_B route and result route occupy disjoint fabric rows.
    decode_result_color = UP_B_color

    # ht_ready_color (id 0): single-hop sentinel from HT_head col=0 PEs
    # to the adjacent demux col, gating demux's main task until HT_head's
    # runtime route paint finishes in init(). HT_head spans the band from the
    # west origin HT_HEAD_X (its col 0 is the band's west edge), adjacent to
    # the demux at DEMUX_FAB_X, so the distance is exactly 1 hop and the WSE-3
    # "avoid id 0 for long-distance routes" caveat does not apply.
    ht_ready_color = Color("ht_ready_color", 0)

    # KV-cache runtime ingress: stream the prefill K/V prefix in at decode startup.
    # The two transfer colors REUSE ids 17/21 (= kpipe_b k7 / UP_A_color): those live
    # on strip / HT_head cells, while the KV west-shift lives on block-column cells, so
    # the same wafer-global ids are wafer-physically disjoint (no router conflict).
    # Budget header (1 i32 wavelet) rides result_color (block->ht_tail) and the logits
    # color (ht_tail->mux) ahead of the per-step stream, once per round -> +1 on each
    # per-round port.
    kv_hdr = 1   # one N-header per round on each Z/logits port
    kv_ingress_0_c = Color("kv_ingress_color_0", 17)
    kv_ingress_1_c = Color("kv_ingress_color_1", 21)

    # --- (c) K-pipe Colors --- #
    # K-pipe colors for inter-col strip transfer. Each pipe k uses a parity
    # pair (kpipe_color_a_k, kpipe_color_b_k); within a column the per-pipe
    # M = P_BLOCK_SIZE/K "own" cells alternate rx/tx between the pair, and
    # non-own cells are pure router pass-through on both colors. K=8 needs
    # 2K=16 layout-global ids — reuse collective ids 1–5 plus 11 fresh ids
    # 7–17.
    KPIPE_K = 8
    # Each pipe needs an integral, non-empty set of owner PEs.
    assert P_BLOCK_SIZE % KPIPE_K == 0 and P_BLOCK_SIZE >= KPIPE_K, (
        f"P_BLOCK_SIZE ({P_BLOCK_SIZE}) must be >= KPIPE_K ({KPIPE_K}) and divisible "
        f"by it (KPIPE_M_PER_PIPE = P_BLOCK_SIZE/KPIPE_K must be >= 1)."
    )
    # 16 layout-global ids for K-pipe (a/b interleaved per pipe k):
    #   pipe k=0: a=1 (reuse reduce_1st_0), b=2 (reuse reduce_1st_1)
    #   pipe k=1: a=3 (reuse reduce_2nd_0), b=4 (reuse reduce_2nd_1)
    #   pipe k=2: a=5 (reuse broadcast),    b=7
    #   pipe k=3: a=8,  b=9
    #   ... pipe k=7: a=16, b=17
    _kpipe_ids = [
        (1, 2), (3, 4), (5, 7), (8, 9),
        (10, 11), (12, 13), (14, 15), (16, 17),
    ]
    assert len(_kpipe_ids) == KPIPE_K
    # The first 5 ids (1, 2, 3, 4, 5) ALIAS the collective Color objects so
    # SdkLayout sees one wafer-global id per slot. The remaining 11 ids
    # (7..17 minus the 5 already-aliased) need fresh Color objects.
    _collective_aliases = {
        1: reduce_1st_0_c, 2: reduce_1st_1_c,
        3: reduce_2nd_0_c, 4: reduce_2nd_1_c,
        5: broadcast_c,
    }
    kpipe_a_colors = []  # 8 Color objects (per-pipe rx-a / tx-a side)
    kpipe_b_colors = []  # 8 Color objects (per-pipe rx-b / tx-b side)
    _kpipe_fresh = {}    # id -> Color obj, to avoid duplicate Color creation
    for k, (a_id, b_id) in enumerate(_kpipe_ids):
        for side, the_id, target_list in (
            ("a", a_id, kpipe_a_colors),
            ("b", b_id, kpipe_b_colors),
        ):
            if the_id in _collective_aliases:
                target_list.append(_collective_aliases[the_id])
            elif the_id in _kpipe_fresh:
                target_list.append(_kpipe_fresh[the_id])
            else:
                c = Color(f"kpipe_color_{side}_{k}", the_id)
                _kpipe_fresh[the_id] = c
                target_list.append(c)

    # HT_head SOUTH chain colors (case_src_north + case_src_at_upper_diag).
    # Alias K-pipe pipe 3 IDs (8, 9): K-pipe paints these on standalone strip
    # cells beside the role mesh, HT_head paints them on its own column
    # band (fabric_x in [HT_HEAD_X, HT_HEAD_X+HT_WIDTH_head)). Wafer-physical
    # disjoint, same wafer-global color id ⇒ no router conflict.
    DOWN_A_c = kpipe_a_colors[3]  # id 8
    DOWN_B_c = kpipe_b_colors[3]  # id 9

    # --- (c2) Per-block TSC profiler colors (measurement build only) --- #
    # Carry one profiled block's TSC ring north out of its region's top edge and
    # west along the otherwise-empty y=0 row to a host output port. They ALIAS
    # K-pipe pipe-4 ids 10/11: the K-pipe paints those only on the standalone
    # strip columns (x = PLACE_X-1 / PLACE_X+Pw, y >= PLACE_Y), while the profile
    # route lives on block cells and on row y = PLACE_Y-1, so the two uses are
    # wafer-physically disjoint. Reusing the existing Color objects keeps one
    # object per wafer-global id, as the K-pipe aliasing comment above requires.
    prof_attn_color = kpipe_a_colors[4]  # id 10
    prof_ffn_color  = kpipe_b_colors[4]  # id 11
    PROF          = int(os.environ.get("PROF_BLOCK_TSC", "0"))
    PROF_RING     = int(os.environ.get("PROF_RING", "512"))
    PROF_ROW      = int(os.environ.get("PROF_ROW", "0"))
    PROF_BROKEN   = int(os.environ.get("PROF_BROKEN", "0"))
    # Ring entries are cycles >> PROF_SHIFT as u16 (halves the ring SRAM so the
    # profiled ATTN PE still fits at bsz 8, where a step period is millions of
    # cycles). 6 -> a 64-cycle quantum and a 4.19M-cycle ceiling per entry.
    PROF_SHIFT    = int(os.environ.get("PROF_SHIFT", "6"))
    assert PROF_RING % 2 == 0, "PROF_RING must be even (D2H port needs an even count)"
    PROF_HDR   = 10
    prof_words = PROF_HDR + 3 * (PROF_RING // 2)
    if PROF:
        # <time>.get_timestamp unrolls an `inline for` over the 3 TSC words, which
        # does not fit the repo cslc-driver's default cap of 8. Raising it to 16 is
        # code-neutral here: the unmodified decode.csl compiles to a byte-identical
        # ELF at 8 and at 16 (every existing `inline for` already fits under 8, so a
        # higher cap cannot change any of them).
        os.environ.setdefault("CSLC_MAX_INLINED_ITERS", "16")
        print(f"      [prof] block TSC profiler ON row={PROF_ROW} ring={PROF_RING} "
              f"broken={PROF_BROKEN} shift={PROF_SHIFT} words/block={prof_words} "
              f"cslc_max_inlined_iters={os.environ['CSLC_MAX_INLINED_ITERS']}")

    # --- (d) Placement coordinates (snake-end / mux / HT_tail / demux) --- #
    # All purely arithmetic on (Pw, Ph, P_*_BLOCK_NUM, P_BLOCK_SIZE). Region
    # objects don't exist yet; consumed in Phase 3 by each region's place().
    last_row       = P_Y_BLOCK_NUM - 1   # odd (P_Y_BLOCK_NUM even, asserted above)
    # P_Y-even invariant ⇒ last_row odd ⇒ the last row's snake-tail exits WEST.
    # Block col 0 sits at lcl_x=1 (lcl_x=0 = fake west strip, the raw-Z producer
    # column). HT_tail sits at the west band origin HT_HEAD_X (shares the X column
    # band with HT_head, disjoint Y; both span the full HT_WIDTH_tail band).
    edge_dir_out   = Route.WEST
    # mux_y: top row of HT_tail's last-row block; the logits mux sits one
    # P_BLOCK_SIZE below it (see Region 5/5 placement).
    mux_y          = PLACE_Y + last_row * P_BLOCK_SIZE
    ht_tail_x         = HT_HEAD_X
    ht_tail_in_edge   = Edge.RIGHT
    # Token emit: NORTH through the blank HT column-band to head.BOTTOM (same X col).
    ht_tail_emit_edge = Edge.TOP
    # Demux placement: at DEMUX_FAB_X, immediately west of the HT band's west
    # edge (HT_HEAD_X), so the id-0 ready barrier and the pre_embed_x C1 feed
    # into the band's west edge stay 1-hop. (C1 then relays east across the HT
    # band's west columns to reach the embedding's east columns; that traversal
    # happens once, at step 0.)
    demux_x = DEMUX_FAB_X
    demux_y = PLACE_Y

    # ====================================================================== #
    # Phase 3: Regions (in pipeline order: host -> device -> host)          #
    # ====================================================================== #

    # ====================================================================== #
    # Region 1/5: demux  (host -> 1xP demux, X input)                        #
    # ---------------------------------------------------------------------- #
    # 1 col × P_BLOCK_SIZE store-and-forward chain. PE 0 receives full P*B    #
    # u32/cycle from host stream via Edge.TOP; each PE keeps its own B u32   #
    # slice, forwards rest south via chain colors, and sends own slice east  #
    # on pre_embed_x_color into HT_head's west edge. Two alternating chain   #
    # colors (A on even hops, B on odd hops) avoid adjacent-PE color         #
    # conflict — same trick as mux.                                          #
    # ====================================================================== #
    demux_rg = layout.create_code_region(
        str(here / "src" / "demux.csl"), "x_demux", 1, P_BLOCK_SIZE,
    )
    demux_rg.set_param_all("batch_per_pe_step", batch_per_xpe_step)
    demux_rg.set_param_all("P_BLOCK_SIZE",      P_BLOCK_SIZE)
    demux_rg.set_param_all("region_origin_y",   demux_y)

    demux_in_color  = demux_rg.color("in_color")        # host -> PE 0 only
    demux_chain_a   = demux_rg.color("chain_color_a")   # even hops
    demux_chain_b   = demux_rg.color("chain_color_b")   # odd hops
    demux_rg.set_param_all(demux_in_color)
    demux_rg.set_param_all(demux_chain_a)
    demux_rg.set_param_all(demux_chain_b)
    demux_rg.set_param_all("out_color", pre_embed_x_color)  # layout-global east
    demux_rg.set_param_all(ht_ready_color)  # ready barrier from HT_head

    # Chain queue bindings and alternating N->S routes are installed by each
    # PE at boot from its fabric Y coordinate. Give both colors a neutral base
    # config so the code region has one uniform layout image.
    demux_rg.paint_all(demux_chain_a, [default_routing_pos])
    demux_rg.paint_all(demux_chain_b, [default_routing_pos])

    # out_color: each demux PE drains own batch EAST into row_y==0.
    demux_out_route = RoutingPosition().set_input([Route.RAMP]).set_output([Route.EAST])
    demux_rg.paint_all(pre_embed_x_color, [demux_out_route])

    # Single-PE input port at PE 0 (Edge.TOP). Host stream connects directly.
    demux_in_port = demux_rg.create_input_port(
        demux_in_color, Edge.TOP,
        [RoutingPosition().set_output([Route.RAMP])],
        x_total_wavelets,
    )

    # Multi-PE output port on east edge to row_y==0.
    demux_out_port = demux_rg.create_output_port(
        pre_embed_x_color, Edge.RIGHT,
        [RoutingPosition().set_input([Route.RAMP])],
        x_total_wavelets,
    )
    # Ready-barrier input port on east edge: each demux PE receives 1 wavelet
    # from the HT_head col=0 PE at the same fabric_y. SdkLayout auto-routes
    # ht_ready_color across the 1-col gap.
    demux_ready_in_port = demux_rg.create_input_port(
        ht_ready_color, Edge.RIGHT,
        [RoutingPosition().set_output([Route.RAMP])],
        P_BLOCK_SIZE,  # 1 wavelet per row
        prefix="ready_east",
    )
    demux_rg.place(demux_x, demux_y)

    # ====================================================================== #
    # Region 2/5: HT_head  (token embedding, HT_W x P)                       #
    # ---------------------------------------------------------------------- #
    # P_BLOCK_SIZE rows × HT_WIDTH_tail cols (full band, to match the tail   #
    # for the token connect). The embedding runs on the EAST HT_WIDTH_head   #
    # cols (x_local in [HT_X_OFFSET, HT_WIDTH_tail)); the west cols only relay#
    # C1 east at step 0. See src/ht_head.csl; src/ht_tail.csl is the tail.   #
    #                                                                       #
    # Per-PE topology in HT_head (effective col eff = x_local - HT_X_OFFSET):#
    #   - vocab sharded along Y: each PE row py owns V_per_pe_y vocab       #
    #     entries of W_E (the slice [py*V_per_pe_y : (py+1)*V_per_pe_y, :]).#
    #   - hidden sharded along X: each PE col x_local owns 2*dim_per_pe    #
    #     hidden positions of W_E.                                          #
    #   - Diagonal: col x has TWO diag PEs at py=2x (upper) and py=2x+1    #
    #     (lower). The diagonal collectively holds the embedded X for the   #
    #     current step.                                                     #
    #                                                                       #
    # Routing colors painted on HT_head:                                    #
    #   - pre_embed_x_color (id 18, = C1): per-row east-going from west     #
    #     port, terminates at the row's diag col (x_local = head_my_py / 2,#
    #     computed in init()).                                              #
    #   - post_embed_x_color (id 23): diag PE -> EAST out to row_0 west    #
    #     port. Used every step to emit the embedded X.                     #
    #   - UP_A, UP_B (ids 21, 22): NORTH-going W_E relay chain              #
    #     (case_src_south + case_src_at_lower_diag).                        #
    #   - DOWN_A, DOWN_B (ids 8, 9, aliased from K-pipe pipe 3): SOUTH-     #
    #     going W_E relay chain.                                            #
    #   - tok_bcast (id 7): south->north single-color fanout for bsz       #
    #     token-id delivery.                                                #
    # ====================================================================== #
    ht_head_rg = layout.create_code_region(
        str(here / "src" / "ht_head.csl"), "ht_head", HT_WIDTH_tail, P_BLOCK_SIZE,
    )
    # Region spans the full HT_WIDTH_tail band (to match the tail for the token
    # connect); the embedding runs on the EAST HT_WIDTH_head columns, and the
    # west columns only relay pre_embed_x (C1) east at step 0.
    ht_head_rg.set_param_all("HT_WIDTH",        HT_WIDTH_tail)
    ht_head_rg.set_param_all("HT_WIDTH_head",   HT_WIDTH_head)
    ht_head_rg.set_param_all("bsz",             bsz)
    ht_head_rg.set_param_all("dim_per_pe",        dim_per_pe_lane)
    ht_head_rg.set_param_all("V_per_pe_y",      V_per_pe_y)
    # Keep the step loop runtime-sized. The initial value is the compile ceiling;
    # the per-round header replaces it with the request's token budget.
    ht_head_rg.set_symbol_all(
        "n_steps", np.full((P_BLOCK_SIZE, HT_WIDTH_tail), max_output_len_worst, dtype=np.int16),
        HT_WIDTH_tail, P_BLOCK_SIZE)
    # Forced-prefill bake: flag + token feed SHARDED by band column (column c
    # owns forced steps fs % HT_WIDTH == c; ~128 B/PE at a 4096-step budget).
    # The owner column row-broadcasts each id on two dedicated colors.
    forced_shard_cap = (forced_cap + HT_WIDTH_tail - 1) // HT_WIDTH_tail
    ht_head_rg.set_param_all("FORCED_SHARD_CAP", forced_shard_cap)
    # Forced-id relay: two ping-pong CE-relay chains (east/west), the W_E
    # gather parity pattern. All routes static; colors must be registered
    # Color objects with host paints (raw-int color params leave the router
    # entry disabled -> silent stall, 2026-09-05). Ids 10-13 alias kpipe
    # colors that never route on head-band PEs.
    fwd_ea_c = Color("fwd_ea_color", 10)
    fwd_eb_c = Color("fwd_eb_color", 11)
    fwd_wa_c = Color("fwd_wa_color", 12)
    fwd_wb_c = Color("fwd_wb_color", 13)
    for _c in (fwd_ea_c, fwd_eb_c, fwd_wa_c, fwd_wb_c):
        ht_head_rg.set_param_all(_c)
    _rp_rx_w = RoutingPosition().set_input([Route.WEST]).set_output([Route.RAMP])
    _rp_tx_e = RoutingPosition().set_input([Route.RAMP]).set_output([Route.EAST])
    _rp_rx_e = RoutingPosition().set_input([Route.EAST]).set_output([Route.RAMP])
    _rp_tx_w = RoutingPosition().set_input([Route.RAMP]).set_output([Route.WEST])
    for _fx in range(HT_WIDTH_tail):
        _even = (_fx % 2 == 0)
        for _fy in range(P_BLOCK_SIZE):
            _fcell = IntVector(_fx, _fy)
            # East chain: even columns receive on EA / send on EB; odd swap.
            ht_head_rg.paint(_fcell, fwd_ea_c, [_rp_rx_w if _even else _rp_tx_e])
            ht_head_rg.paint(_fcell, fwd_eb_c, [_rp_tx_e if _even else _rp_rx_w])
            # West chain mirror.
            ht_head_rg.paint(_fcell, fwd_wa_c, [_rp_rx_e if _even else _rp_tx_w])
            ht_head_rg.paint(_fcell, fwd_wb_c, [_rp_tx_w if _even else _rp_rx_e])
    ht_head_rg.set_symbol_all(
        "forced_mode", np.full((P_BLOCK_SIZE, HT_WIDTH_tail), forced_mode_flag, dtype=np.int16),
        HT_WIDTH_tail, P_BLOCK_SIZE)
    _forced_flat = np.zeros(forced_cap * bsz, dtype=np.int32)   # [step][lane]
    if forced_mode_flag:
        for lane, seq in enumerate(forced_tokens_cfg):
            _forced_flat[lane::bsz] = np.asarray(seq[:forced_cap], dtype=np.int32)
    _forced_steps = _forced_flat.reshape(forced_cap, bsz)
    _shard_row = np.zeros((HT_WIDTH_tail, forced_shard_cap, bsz), dtype=np.int32)
    for c in range(HT_WIDTH_tail):
        # Contiguous ownership window [c*K, (c+1)*K) — must match ht_head.csl.
        _own = _forced_steps[c * forced_shard_cap:(c + 1) * forced_shard_cap]
        _shard_row[c, :len(_own)] = _own
    _shard_row = _shard_row.reshape(HT_WIDTH_tail * forced_shard_cap * bsz)
    ht_head_rg.set_symbol_all(
        "forced_tokens",
        np.tile(_shard_row, (P_BLOCK_SIZE, 1)),
        HT_WIDTH_tail * forced_shard_cap * bsz, P_BLOCK_SIZE)
    ht_head_rg.set_param_all("pre_embed_x_color",        pre_embed_x_color)
    ht_head_rg.set_param_all("post_embed_x_color",        post_embed_x_color)
    ht_head_rg.set_param_all(UP_A_color)
    ht_head_rg.set_param_all(UP_B_color)
    # DOWN_{A,B}_c are aliases of kpipe_{a,b}_colors[3] (id 8, 9), so the host
    # Color name carries the kpipe label; the explicit device-name binding
    # maps that fabric id to ht_head's local DOWN_{A,B}_color param.
    ht_head_rg.set_param_all("DOWN_A_color",    DOWN_A_c)
    ht_head_rg.set_param_all("DOWN_B_color",    DOWN_B_c)
    ht_head_rg.set_param_all(tok_bcast_color)
    ht_head_rg.set_param_all(ht_ready_color)

    # HT_head's init() reads tile_config.get_fabric_coord at runtime and
    # subtracts region_origin to derive head_my_x_local / head_my_py.
    ht_head_rg.set_param_all("region_origin_x", HT_HEAD_X)
    ht_head_rg.set_param_all("region_origin_y", PLACE_Y)

    # Default routes — init() overrides per-PE for C1 (pre_embed_x_color) and
    # C2 (post_embed_x_color) at startup. UP/DOWN colors are statically painted
    # per (local_px, local_py) below.
    # tok_bcast is painted uniformly further below.
    # ht_ready_color is wired via create_output_port + connect (see below);
    # cells not on col=0 default to RAMP+RAMP and never see traffic.
    for c in (pre_embed_x_color, post_embed_x_color, UP_A_color, UP_B_color,
              DOWN_A_c, DOWN_B_c, ht_ready_color):
        ht_head_rg.paint_all(c, [default_routing_pos])

    # UP_A / UP_B / DOWN_A / DOWN_B static paint per (color, local_px, local_py) for the
    # W_E gather relay chain. Position is determined by local_py vs the column's
    # diag pair (2*local_px, 2*local_px+1):
    #   P1 (local_py == 2*local_px,        even): upper_diag
    #   P2 (local_py == 2*local_px+1,      odd):  lower_diag
    #   P3 (local_py >  2*local_px+1, even):       south of diag, even
    #   P4 (local_py >  2*local_px+1, odd):        south of diag, odd
    #   P5 (local_py <  2*local_px,   even):       north of diag, even
    #   P6 (local_py <  2*local_px,   odd):        north of diag, odd
    #
    # Each Position has fixed (rx, tx) per color across all embed_gather_dispatch
    # cases that share that color.
    _rp_S_R   = RoutingPosition().set_input([Route.SOUTH]).set_output([Route.RAMP])
    _rp_R_N   = RoutingPosition().set_input([Route.RAMP ]).set_output([Route.NORTH])
    _rp_N_R   = RoutingPosition().set_input([Route.NORTH]).set_output([Route.RAMP])
    _rp_R_S   = RoutingPosition().set_input([Route.RAMP ]).set_output([Route.SOUTH])
    for _eff in range(HT_WIDTH_head):
        _local_px = _eff + HT_X_OFFSET     # embedding active col (east subset of the band)
        _upper_diag = 2 * _eff
        _lower_diag = 2 * _eff + 1
        for _local_py in range(P_BLOCK_SIZE):
            _cell = IntVector(_local_px, _local_py)
            _local_py_even = (_local_py % 2 == 0)
            if _local_py == _upper_diag:
                # P1: UP_A=(S,R); UP_B default; DOWN_A=(N,R); DOWN_B=(R,S)
                ht_head_rg.paint(_cell, UP_A_color,   [_rp_S_R])
                ht_head_rg.paint(_cell, DOWN_A_c, [_rp_N_R])
                ht_head_rg.paint(_cell, DOWN_B_c, [_rp_R_S])
            elif _local_py == _lower_diag:
                # P2: UP_A=(R,N); UP_B=(S,R); DOWN_A default; DOWN_B=(N,R)
                ht_head_rg.paint(_cell, UP_A_color,   [_rp_R_N])
                ht_head_rg.paint(_cell, UP_B_color,   [_rp_S_R])
                ht_head_rg.paint(_cell, DOWN_B_c, [_rp_N_R])
            elif _local_py > _lower_diag:
                if _local_py_even:
                    # P3: UP_A=(S,R); UP_B=(R,N); DOWN both default
                    ht_head_rg.paint(_cell, UP_A_color, [_rp_S_R])
                    ht_head_rg.paint(_cell, UP_B_color, [_rp_R_N])
                else:
                    # P4: UP_A=(R,N); UP_B=(S,R); DOWN both default
                    ht_head_rg.paint(_cell, UP_A_color, [_rp_R_N])
                    ht_head_rg.paint(_cell, UP_B_color, [_rp_S_R])
            else:  # _local_py < _upper_diag
                if _local_py_even:
                    # P5: UP both default; DOWN_A=(N,R); DOWN_B=(R,S)
                    ht_head_rg.paint(_cell, DOWN_A_c, [_rp_N_R])
                    ht_head_rg.paint(_cell, DOWN_B_c, [_rp_R_S])
                else:
                    # P6: UP both default; DOWN_A=(R,S); DOWN_B=(N,R)
                    ht_head_rg.paint(_cell, DOWN_A_c, [_rp_R_S])
                    ht_head_rg.paint(_cell, DOWN_B_c, [_rp_N_R])

    # tok_bcast — uniform south->{RAMP, NORTH} fanout on ALL band columns (the
    # tail emits on the full width to keep the token connect uniform; west
    # columns drain+discard). Top row (py=0) terminates SOUTH->RAMP.
    ht_head_rg.paint_all(tok_bcast_color, [
        RoutingPosition().set_input([Route.SOUTH]).set_output([Route.RAMP, Route.NORTH])
    ])
    ht_head_rg.paint_range(
        IntRectangle(IntVector(0, 0), IntVector(HT_WIDTH_tail, 1)),
        tok_bcast_color,
        [RoutingPosition().set_input([Route.SOUTH]).set_output([Route.RAMP])],
    )

    # West input port — C1 (pre_embed_x_color) from demux. Each Y row enters
    # WEST and continues via the per-row paint configured at runtime in
    # ht_head.csl init() (WEST->EAST through cols [0, head_my_py/2),
    # WEST->RAMP at col head_my_py/2, no paint east of that).
    ht_head_in_port = ht_head_rg.create_input_port(
        pre_embed_x_color, Edge.LEFT,
        [RoutingPosition().set_output([Route.EAST])],
        x_total_wavelets,
        prefix="ingress",
    )
    # East output port — C2 (diag PE -> row_0 west port).
    ht_head_c2_out_port = ht_head_rg.create_output_port(
        post_embed_x_color, Edge.RIGHT,
        [RoutingPosition().set_input([Route.WEST])],
        x_total_wavelets,
        prefix="c2_east",
    )
    # South input port — receives bsz token_ids per step from HT_tail's emitter
    # PE row (top row for P_Y even, sharing same X column band). Head's main
    # loop drains bsz wavelets per step for s=1..MAX-1 (s=0 uses C1 host-seed
    # instead, no south drain). The tail emits on all HT_WIDTH_tail columns
    # (uniform connect), so the drain count is bsz * HT_WIDTH_tail * (MAX-1).
    ht_head_tok_in_port = ht_head_rg.create_input_port(
        tok_bcast_color, Edge.BOTTOM,
        [RoutingPosition().set_output([Route.NORTH, Route.RAMP])],
        # + per-round N header (bsz tile, slot 0 = N) ahead of tokens.
        # (W tiles/round = 1 header + (W-1) tokens).
        bsz * HT_WIDTH_tail * max_output_len_worst,
        prefix="tok_south",
    )
    # West output port — ready barrier sentinel from col=0 PEs (1 wavelet per
    # row) to the adjacent demux. Bridges the runtime-route-paint vs first-
    # wavelet-arrival race that would otherwise stall bsz=1 configs.
    ht_head_ready_out_port = ht_head_rg.create_output_port(
        ht_ready_color, Edge.LEFT,
        [RoutingPosition().set_input([Route.RAMP])],
        P_BLOCK_SIZE,  # 1 wavelet per row
        prefix="ready_west",
    )

    # --- HT_head W_E weight upload --- #
    # Token embedding table in the Qwen3 row-major nn.Embedding layout, with no
    # permutation before input_layernorm.
    #
    # Per-PE (py, x_local) tile: W_E[py*V_per_pe_y : (py+1)*V_per_pe_y,
    #                                x_local*2*dim_per_pe : (x_local+1)*2*dim_per_pe]
    # flattened to V_per_pe_y * 2*dim_per_pe fp16 values. Seed 2024 is disjoint
    # from per-layer seeds (2025 + global_l) so W_E and layer weights are
    # independent.
    def _gen_W_E_tile_array():
        rng = np.random.RandomState(2024)
        # Draw at true (vocab, dim); zero-pad to (vocab_pad, dim_pad). Dummy vocab
        # rows [vocab_true:] are never selected (token_id < vocab_true); dummy dim
        # cols [dim_true:] feed zero into the hidden state's padded positions.
        W_E_full = _zpad((rng.rand(vocab_true, dim_true) * WEIGHT_SCALE).astype(ml_dtypes.bfloat16),
                         (vocab_size, dim))
        # Full HT_WIDTH_tail-wide tile; the embedding lives on the EAST
        # HT_WIDTH_head columns (fabric col eff + HT_X_OFFSET), west columns
        # zero (they only relay C1, never read W_E).
        arr = np.zeros((P_BLOCK_SIZE, HT_WIDTH_tail * HT_W_E_K), dtype=ml_dtypes.bfloat16)
        for py in range(P_BLOCK_SIZE):
            vocab_lo = py * V_per_pe_y
            vocab_hi = vocab_lo + V_per_pe_y
            for eff in range(HT_WIDTH_head):
                x_local = eff + HT_X_OFFSET
                h_lo = eff * 2 * dim_per_pe_lane
                h_hi = h_lo + 2 * dim_per_pe_lane
                tile = W_E_full[vocab_lo:vocab_hi, h_lo:h_hi]
                arr[py, x_local*HT_W_E_K : (x_local+1)*HT_W_E_K] = tile.reshape(-1)
        return arr

    W_E_arr = _gen_W_E_tile_array()
    ht_head_rg.set_symbol_all(
        "W_E_tile", bf16_view_uint16(W_E_arr), HT_WIDTH_tail * HT_W_E_K, P_BLOCK_SIZE,
    )

    ht_head_rg.place(HT_HEAD_X, PLACE_Y)

    # ====================================================================== #
    # Region 3/5: role-pure ATTN / FFN blocks + standalone strips
    # ---------------------------------------------------------------------- #
    # Each block row owns one transformer layer slice. Roles alternate in X:
    # even row: [ATTN | FFN], odd row: [FFN | ATTN]. A (id 19) is a direct
    # ATTN->FFN row multicast; B (id 20) is a direct FFN->ATTN row multicast
    # for intermediate local layers and an FFN->strip send for the final layer.
    # Cross-row traffic remains the existing strip/K-pipe transport.
    strip_real = [strip_realness(ry, P_Y_BLOCK_NUM)
                  for ry in range(P_Y_BLOCK_NUM)]
    print(f"      strip_real (real_west, real_east) per row_y = {strip_real}")

    # The ATTN east-edge ingress color is row-invariant because P is even.
    # Compute it once and pass the same value to every role image; the PEs
    # derive their actual ingress/transit routes from runtime coordinates.
    attn_entry_colors = []
    for row_y in range(P_Y_BLOCK_NUM):
        attn_bx = 0 if row_y % 2 == 0 else 1
        east_fab_x = PLACE_X + (attn_bx + 1) * P_BLOCK_SIZE - 1
        attn_entry_colors.append(
            kv_ingress_0_c if east_fab_x % 2 == 0 else kv_ingress_1_c)
    assert all(c.get_value() == attn_entry_colors[0].get_value()
               for c in attn_entry_colors), (
        "ATTN KV ingress entry color must be row-invariant; P_BLOCK_SIZE must stay even")
    scatter_c = attn_entry_colors[0]
    # Color 17 is a K-pipe color on real strip cells.  The shipped geometry
    # resolves the KV scatter to color 21, so strip transit stays disjoint.
    assert scatter_c.get_value() != 17, (
        "KV scatter resolved to color 17, which conflicts with K-pipe on strip cells; "
        "adjust placement parity or allocate a disjoint ingress color")

    attn_regions = []
    ffn_regions = []
    west_strips = []
    east_strips = []
    ROUTE_TABLE = int(os.environ.get("ROUTE_TABLE", "1"))      # default ON (CS-3 verified 2026-09-02); --legacy-init turns it off
    SHARED_REDUCE_LEN = int(os.environ.get("SHARED_REDUCE_LEN", "0"))
    ROUTE_CHECK = int(os.environ.get("ROUTE_CHECK", "0"))
    if ROUTE_TABLE:
        import sys as _sys
        _sys.path.insert(0, str(here / "host"))
        import route_table as _rt
        print(f"      [route_table] use_route_table=1 route_check={ROUTE_CHECK} "
              f"({_rt.PE_CFG_WORDS} u16/PE)")

    def _set_role_common(rg, role_is_attn, row_y):
        # Profiler placement. The sampling PE is the block's own multicast source
        # column (ATTN: the A source; FFN: the inner B source) on the block's TOP
        # row, so its burst leaves the region straight north with no in-block
        # relay. Both are ordinary compute PEs; neither is a collective root.
        _prof_on = 1 if (PROF and row_y == PROF_ROW) else 0
        _outer_lx = (P_BLOCK_SIZE - 1) if (row_y % 2 == 0) else 0
        _inner_lx = 0 if (row_y % 2 == 0) else (P_BLOCK_SIZE - 1)
        _prof_c = prof_attn_color if role_is_attn else prof_ffn_color
        rg.set_param_all("prof_enabled", _prof_on)
        rg.set_param_all("prof_ring_len", PROF_RING if _prof_on else 2)
        rg.set_param_all("prof_lx", _outer_lx if role_is_attn else _inner_lx)
        rg.set_param_all("prof_ly", 0)
        rg.set_param_all("prof_broken", PROF_BROKEN if _prof_on else 0)
        rg.set_param_all("prof_shift", PROF_SHIFT)
        rg.set_param_all("prof_color", _prof_c)
        if _prof_on:
            rg.paint_all(_prof_c, [default_routing_pos])
        rg.set_param_all("use_route_table", ROUTE_TABLE)
        rg.set_param_all("route_check", ROUTE_CHECK)
        rg.set_param_all("shared_reduce_len", SHARED_REDUCE_LEN)
        rg.set_param_all("P_BLOCK_SIZE", P_BLOCK_SIZE)
        rg.set_param_all("role_attn", 1 if role_is_attn else 0)
        rg.set_param_all("bsz", bsz)
        rg.set_param_all("dim_per_pe", dim_per_pe)
        rg.set_param_all("attn_per_pe", attn_per_pe)
        rg.set_param_all("kv_cols", kv_cols)
        rg.set_param_all("gqa_group_size", gqa_group_size)
        rg.set_param_all("head_dim_total", head_dim)
        rg.set_param_all("true_model_dim", dim_true)
        rg.set_param_all("kv_len_per_pe", kv_len_per_pe)
        rg.set_param_all("ffn_dim_per_pe", ffn_dim_per_pe)
        rg.set_param_all("pe_num_per_group", pe_num_per_group)
        rg.set_param_all("root_1st_phase", root_1st_phase)
        rg.set_param_all("root_2nd_phase", root_2nd_phase)
        rg.set_symbol_all(
            "n_steps",
            np.full((H_ROWS, P_BLOCK_SIZE), max_output_len_worst, dtype=np.int16),
            P_BLOCK_SIZE, H_ROWS,
        )
        # Step 1b: pair-interleaved ATTN/FFN schedule under forced prefill.
        rg.set_symbol_all(
            "forced_mode",
            np.full((H_ROWS, P_BLOCK_SIZE), forced_mode_flag, dtype=np.int16),
            P_BLOCK_SIZE, H_ROWS,
        )
        # Diagnostic: FORCED_VARIANT=1 keeps the pair order but serializes the
        # ATTN<->FFN handshake (no concurrency; isolates timing races).
        rg.set_symbol_all(
            "forced_variant",
            np.full((H_ROWS, P_BLOCK_SIZE),
                    int(os.environ.get("FORCED_VARIANT", "0")), dtype=np.int16),
            P_BLOCK_SIZE, H_ROWS,
        )
        rg.set_param_all("max_layers_per_block", max_layers_per_block)
        rg.set_param_all("n_layers", n_layers)
        rg.set_param_all("prefill_max_per_pe", prefill_max_per_pe)
        rg.set_param_all("pes_per_kv_head", pes_per_kv_head)
        rg.set_param_all("kv_head_root", kv_head_root)
        rg.set_param_all("region_origin_x", PLACE_X)
        rg.set_param_all("region_origin_y", PLACE_Y)
        rg.set_param_all("P_X_BLOCK_NUM", P_X_BLOCK_NUM)
        rg.set_param_all("P_Y_BLOCK_NUM", P_Y_BLOCK_NUM)
        rg.set_param_all("reduce_1st_color_0", reduce_1st_0_c)
        rg.set_param_all("reduce_1st_color_1", reduce_1st_1_c)
        rg.set_param_all("reduce_2nd_color_0", reduce_2nd_0_c)
        rg.set_param_all("reduce_2nd_color_1", reduce_2nd_1_c)
        rg.set_param_all("broadcast_color", broadcast_c)
        rg.set_param_all("intra_row_bcast_color", intra_row_bcast_c)
        rg.set_param_all(inter_block_a_color)
        rg.set_param_all(inter_block_b_color)
        rg.set_param_all("x_input_color", post_embed_x_color)
        rg.set_param_all("kv_ingress_color_0", kv_ingress_0_c.get_value())
        rg.set_param_all("kv_ingress_color_1", kv_ingress_1_c.get_value())
        rg.set_param_all("kv_ingress_entry_color", scatter_c.get_value())
        rg.set_param_all("result_color", decode_result_color)
        for c in (
            reduce_1st_0_c, reduce_1st_1_c, reduce_2nd_0_c,
            reduce_2nd_1_c, broadcast_c, intra_row_bcast_c,
            inter_block_a_color, inter_block_b_color, post_embed_x_color,
            kv_ingress_0_c, kv_ingress_1_c, decode_result_color,
        ):
            rg.paint_all(c, [default_routing_pos])

    # Create role-pure P x P compute regions. Endpoint identities and A/B/KV
    # routes are installed at boot from each PE's runtime fabric coordinate.
    for row_y in range(P_Y_BLOCK_NUM):
        row_even = (row_y % 2 == 0)
        attn_bx = 0 if row_even else 1
        ffn_bx = 1 - attn_bx
        y0 = PLACE_Y + row_y * P_BLOCK_SIZE

        attn_rg = layout.create_code_region(
            str(here / "src" / "decode.csl"), f"decode_attn_r{row_y}",
            P_BLOCK_SIZE, H_ROWS,
        )
        ffn_rg = layout.create_code_region(
            str(here / "src" / "decode.csl"), f"decode_ffn_r{row_y}",
            P_BLOCK_SIZE, H_ROWS,
        )
        _set_role_common(attn_rg, True, row_y)
        _set_role_common(ffn_rg, False, row_y)
        if H_ROWS != P_BLOCK_SIZE:
            for _rg in (attn_rg, ffn_rg):
                _rg.set_param_all("block_rows", H_ROWS)
                _rg.set_param_all("pe_group_y", pe_group_y)
                _rg.set_param_all("root_1st_y", root_1st_y)
                _rg.set_param_all("root_2nd_y", root_2nd_y)

        if CHAIN is not None:
            _diag_full = int(os.environ.get("DIAG_FULL", "0"))
            for _rg, _role_bit in ((attn_rg, 1), (ffn_rg, 0)):
                _k, _in, _out, _lyr, _kv = CHAIN[(row_y, _role_bit)]
                _rg.set_param_all("stage_kind", _k)
                _rg.set_param_all("local_layer_count", 0 if _lyr is None else 1)
                _rg.set_param_all("stage_in_elems", _in)
                _rg.set_param_all("stage_out_elems", _out)
                if _diag_full:
                    _rg.set_param_all("diag_full", 1)
                _diag_a2 = int(os.environ.get("DIAG_A2_PHASE", "0"))
                if _diag_a2 and _k == 2:
                    _rg.set_param_all("diag_a2_phase", _diag_a2)
                _das = int(os.environ.get("DIAG_A1_STUB", "0"))
                if _das and _k == 1:
                    _rg.set_param_all("diag_a1_stub", _das)

        # Row 0 host X enters the west ATTN block and terminates at the
        # root_2nd_phase column; all ATTN PEs then join the block broadcast.
        # At sub heights the entry colour is the gather funnel's block-facing
        # colour and the block's x_input_color param follows it.
        if row_y == 0:
            assert attn_bx == 0
            _x_entry_c = funnel_x_out_c if H_ROWS != P_BLOCK_SIZE else post_embed_x_color
            if H_ROWS != P_BLOCK_SIZE:
                attn_rg.set_param_all("x_input_color", funnel_x_out_c)
            if root_2nd_phase > 0:
                attn_rg.paint_range(
                    IntRectangle(IntVector(0, 0),
                                 IntVector(root_2nd_phase, H_ROWS)),
                    _x_entry_c,
                    [RoutingPosition().set_input([Route.WEST]).set_output([Route.EAST])])
            attn_rg.paint_range(
                IntRectangle(IntVector(root_2nd_phase, 0),
                             IntVector(root_2nd_phase + 1, H_ROWS)),
                _x_entry_c,
                [RoutingPosition().set_input([Route.WEST]).set_output([Route.RAMP])])

        # The final FFN row keeps the external result ABI. Its outer endpoint
        # and result route are coordinate-derived in comm_pe.init(). At sub
        # heights the result leaves on the scatter funnel's block-facing
        # colour instead of decode_result_color (the funnel re-emits on
        # decode_result_color toward the tail).
        if row_y == P_Y_BLOCK_NUM - 1:
            assert not row_even and ffn_bx == 0
            if H_ROWS != P_BLOCK_SIZE:
                ffn_rg.set_param_all("result_color", funnel_r_in_c)
                ffn_rg.paint_all(funnel_r_in_c, [default_routing_pos])

        attn_rg.place(PLACE_X + attn_bx * P_BLOCK_SIZE, y0)
        ffn_rg.place(PLACE_X + ffn_bx * P_BLOCK_SIZE, y0)
        if ROUTE_TABLE:
            _kw = dict(P=P_BLOCK_SIZE, P_X_BLOCK_NUM=P_X_BLOCK_NUM, P_Y_BLOCK_NUM=P_Y_BLOCK_NUM,
                       pe_num_per_group=pe_num_per_group, root_1st_phase=root_1st_phase,
                       root_2nd_phase=root_2nd_phase, pes_per_kv_head=pes_per_kv_head,
                       kv_head_root=kv_head_root, region_origin_x=PLACE_X, region_origin_y=PLACE_Y,
                       kv_ingress_color_0=kv_ingress_0_c.get_value(),
                       kv_ingress_color_1=kv_ingress_1_c.get_value(),
                       P_y=H_ROWS, group_y=pe_group_y,
                       root_1st_y=root_1st_y, root_2nd_y=root_2nd_y)
            for _rg, _bx, _role in ((attn_rg, attn_bx, 1), (ffn_rg, ffn_bx, 0)):
                _tab = _rt.region_table(PLACE_X + _bx * P_BLOCK_SIZE, y0, _role, **_kw)
                _rg.set_symbol_all("pe_cfg", _tab, P_BLOCK_SIZE * _rt.PE_CFG_WORDS, H_ROWS)
        attn_regions.append(attn_rg)
        ffn_regions.append(ffn_rg)

    # Active sides run the standalone strip image. Inactive sides use a minimal
    # routing-only region. A sender receives its row-final activation on B.
    KPIPE_M_PER_PIPE = P_BLOCK_SIZE // KPIPE_K

    def _make_strip(row_y, side, real, role):
        if not real:
            if (H_ROWS != P_BLOCK_SIZE and side == 0
                    and row_y in (0, P_Y_BLOCK_NUM - 1)):
                # Sub-height lane<->row funnel replaces the inactive relay.
                rg = layout.create_code_region(
                    str(here / "src" / "funnel_pe.csl"),
                    f"decode_strip_{'w' if side == 0 else 'e'}_r{row_y}",
                    1, P_BLOCK_SIZE,
                )
                return rg
            rg = layout.create_code_region(
                str(here / "src" / "kv_fwd.csl"),
                f"decode_strip_{'w' if side == 0 else 'e'}_r{row_y}",
                1, P_BLOCK_SIZE,
            )
            return rg

        rg = layout.create_code_region(
            str(here / "src" / "decode_strip_pe.csl"),
            f"decode_strip_{'w' if side == 0 else 'e'}_r{row_y}",
            1, P_BLOCK_SIZE,
        )
        rg.set_param_all("bsz", bsz)
        # Cut chains: a strip's payload follows its hop's width. At sub
        # heights the inter-row records are the H active lanes' G*B-half
        # rows and the K-pipe multiplex shrinks with the active height.
        if H_ROWS != P_BLOCK_SIZE:
            _strip_elems = (bsz * dim) // H_ROWS // bsz
            _kpipe_m = max(1, H_ROWS // KPIPE_K)
        else:
            _strip_elems = STRIP_ELEMS.get((row_y, side), bsz * dim_per_pe_lane) // bsz
            _kpipe_m = KPIPE_M_PER_PIPE
        rg.set_param_all("dim_per_pe", _strip_elems)
        rg.set_param_all("MAX_OUTPUT_LEN", max_output_len_worst + 2)
        rg.set_param_all("KPIPE_M_PER_PIPE", _kpipe_m)
        if H_ROWS != P_BLOCK_SIZE:
            rg.set_param_all("active_rows", H_ROWS)
            rg.set_param_all("num_rows_per_block", P_BLOCK_SIZE)
        rg.set_param_all("strip_role", role)
        rg.set_param_all("region_origin_y", PLACE_Y)
        rg.set_param_all(
            "block_color",
            inter_block_b_color.get_value() if role == 0
            else intra_row_bcast_c.get_value(),
        )

        block_facing = Route.EAST if side == 0 else Route.WEST
        pass_route = RoutingPosition().set_input([Route.NORTH]).set_output([Route.SOUTH])
        for k in range(KPIPE_K):
            a_c, b_c = kpipe_a_colors[k], kpipe_b_colors[k]
            rg.paint_all(a_c, [pass_route])
            rg.paint_all(b_c, [pass_route])

        if role == 0:
            rg.paint_all(
                inter_block_b_color,
                [RoutingPosition().set_input([block_facing]).set_output([Route.RAMP])])
        else:
            rg.paint_all(
                intra_row_bcast_c,
                [RoutingPosition().set_input([Route.RAMP]).set_output([block_facing])])
        return rg

    for row_y in range(P_Y_BLOCK_NUM):
        real_west, real_east = strip_real[row_y]
        row_even = (row_y % 2 == 0)
        west_role = 1 if row_even else 0
        east_role = 0 if row_even else 1
        west_strips.append(_make_strip(row_y, 0, real_west, west_role))
        east_strips.append(_make_strip(row_y, 1, real_east, east_role))

    # KV enters from the east on every block row.  Paint the east strip E->W;
    # for even rows the FFN block already has the same pure transit above.
    kv_transit = RoutingPosition().set_input([Route.EAST]).set_output([Route.WEST])
    for row_y, strip_rg in enumerate(east_strips):
        strip_rg.paint_all(scatter_c, [kv_transit])

    # Row-0 embedded X crosses the inactive west strip into ATTN. At sub
    # heights the strip column becomes the lane->row GATHER funnel: lanes
    # enter per-PE from the head (band side), the north-flowing parity
    # ping-pong chain concatenates each owner row's G lanes, and the owner
    # emits G*B halves east on funnel_x_out (the row-0 block's overridden
    # x_input_color).
    row0_west_strip = west_strips[0]
    if H_ROWS != P_BLOCK_SIZE:
        fx = row0_west_strip
        fx_chain_a = fx.color("funnel_x_chain_a")
        fx_chain_b = fx.color("funnel_x_chain_b")
        fx.set_param_all("chain_color_a", fx_chain_a)
        fx.set_param_all("chain_color_b", fx_chain_b)
        fx.set_param_all("band_color", post_embed_x_color.get_value()
                         if hasattr(post_embed_x_color, "get_value") else post_embed_x_color)
        fx.set_param_all("block_color", funnel_x_out_c.get_value())
        fx.set_param_all("B", bsz * dim_per_pe_lane)
        fx.set_param_all("H", H_ROWS)
        fx.set_param_all("P", P_BLOCK_SIZE)
        fx.set_param_all("n_tokens_max", max_output_len_worst + 1)
        fx.set_param_all("n_rounds_max", len(prefill_lens))
        fx.set_param_all("gather", 1)
        if int(os.environ.get("DIAG_FUNNEL_BYPASS", "0")):
            fx.set_param_all("diag_bypass", 1)
            fx.set_param_all("n_tokens_actual", decode_lens[0] + 1)
        fx.set_param_all("region_origin_y", PLACE_Y)
        # band in: west -> ramp; block out: ramp -> east.
        fx.paint_all(post_embed_x_color,
            [RoutingPosition().set_input([Route.WEST]).set_output([Route.RAMP])])
        fx.paint_all(funnel_x_out_c,
            [RoutingPosition().set_input([Route.RAMP]).set_output([Route.EAST])])
        # parity chains, north-flowing: even cells recv A / send B.
        for yy in range(P_BLOCK_SIZE):
            a_pos = ([RoutingPosition().set_input([Route.SOUTH]).set_output([Route.RAMP])]
                     if yy % 2 == 0 else
                     [RoutingPosition().set_input([Route.RAMP]).set_output([Route.NORTH])])
            b_pos = ([RoutingPosition().set_input([Route.RAMP]).set_output([Route.NORTH])]
                     if yy % 2 == 0 else
                     [RoutingPosition().set_input([Route.SOUTH]).set_output([Route.RAMP])])
            rect = IntRectangle(IntVector(0, yy), IntVector(1, yy + 1))
            fx.paint_range(rect, fx_chain_a, a_pos)
            fx.paint_range(rect, fx_chain_b, b_pos)
        row0_x_in_port = fx.create_input_port(
            post_embed_x_color, Edge.LEFT,
            [RoutingPosition().set_output([Route.RAMP])],
            x_total_wavelets,
        )
    else:
        row0_west_strip.paint_all(
            post_embed_x_color,
            [RoutingPosition().set_input([Route.WEST]).set_output([Route.EAST])])
        row0_x_in_port = row0_west_strip.create_input_port(
            post_embed_x_color, Edge.LEFT,
            [RoutingPosition().set_output([Route.EAST])],
            x_total_wavelets,
        )

    # The final result crosses the inactive west strip into HT_tail. At sub
    # heights the strip column is the row->lane SCATTER funnel: owner rows
    # receive G*B-half records (+1 u32 header/round) from the last FFN on
    # funnel_r_in, the south-flowing parity chain distributes per-lane
    # slices, and every cell emits B halves west on decode_result_color.
    last_west_strip = west_strips[P_Y_BLOCK_NUM - 1]
    if H_ROWS != P_BLOCK_SIZE:
        fr = last_west_strip
        fr_chain_a = fr.color("funnel_r_chain_a")
        fr_chain_b = fr.color("funnel_r_chain_b")
        fr.set_param_all("chain_color_a", fr_chain_a)
        fr.set_param_all("chain_color_b", fr_chain_b)
        fr.set_param_all("band_color", decode_result_color.get_value()
                         if hasattr(decode_result_color, "get_value") else decode_result_color)
        fr.set_param_all("block_color", funnel_r_in_c.get_value())
        fr.set_param_all("B", bsz * dim_per_pe_lane)
        fr.set_param_all("H", H_ROWS)
        fr.set_param_all("P", P_BLOCK_SIZE)
        fr.set_param_all("n_tokens_max", max_output_len_worst + 1)
        fr.set_param_all("n_rounds_max", len(prefill_lens))
        fr.set_param_all("gather", 0)
        if int(os.environ.get("DIAG_FUNNEL_BYPASS", "0")) >= 2:
            fr.set_param_all("diag_bypass", 1)
            fr.set_param_all("n_tokens_actual", decode_lens[0] + 1)
        fr.set_param_all("region_origin_y", PLACE_Y + (P_Y_BLOCK_NUM - 1) * P_BLOCK_SIZE)
        fr.paint_all(funnel_r_in_c,
            [RoutingPosition().set_input([Route.EAST]).set_output([Route.RAMP])])
        fr.paint_all(decode_result_color,
            [RoutingPosition().set_input([Route.RAMP]).set_output([Route.WEST])])
        for yy in range(P_BLOCK_SIZE):
            a_pos = ([RoutingPosition().set_input([Route.NORTH]).set_output([Route.RAMP])]
                     if yy % 2 == 0 else
                     [RoutingPosition().set_input([Route.RAMP]).set_output([Route.SOUTH])])
            b_pos = ([RoutingPosition().set_input([Route.RAMP]).set_output([Route.SOUTH])]
                     if yy % 2 == 0 else
                     [RoutingPosition().set_input([Route.NORTH]).set_output([Route.RAMP])])
            rect = IntRectangle(IntVector(0, yy), IntVector(1, yy + 1))
            fr.paint_range(rect, fr_chain_a, a_pos)
            fr.paint_range(rect, fr_chain_b, b_pos)
        decode_out_port = fr.create_output_port(
            decode_result_color, Edge.LEFT,
            [RoutingPosition().set_input([Route.RAMP])],
            total_wavelets + kv_hdr,
        )
    else:
        last_west_strip.paint_all(
            decode_result_color,
            [RoutingPosition().set_input([Route.EAST]).set_output([Route.WEST])])
        decode_out_port = last_west_strip.create_output_port(
            decode_result_color, Edge.LEFT,
            [RoutingPosition().set_input([Route.EAST])],
            total_wavelets + kv_hdr,
        )

    # Complete all route/port mutation before placement.  This mirrors the
    # ordering used by the other SdkLayout regions and avoids relying on
    # post-place paint semantics for the inactive strips or KV transit.
    for row_y, (west_rg, east_rg) in enumerate(zip(west_strips, east_strips)):
        y0 = PLACE_Y + row_y * P_BLOCK_SIZE
        west_rg.place(PLACE_X - 1, y0)
        east_rg.place(PLACE_X + Pw, y0)

    # ---------------------------------------------------------------------- #
    # Block-TSC profile collector (measurement build only).                  #
    # ---------------------------------------------------------------------- #
    # The row directly above block row 0 (y = PLACE_Y-1) is empty across the
    # block band, so a routing-only strip there catches each profiled block's
    # northbound burst and carries it west to a host output port. This adds no
    # PE code and touches no existing color, port, stream or wavelet count.
    prof_port_attn = None
    prof_port_ffn = None
    if PROF:
        assert PROF_ROW == 0, "profile collector row is only free above block row 0"
        assert PLACE_Y >= 1
        prof_lane_attn = P_BLOCK_SIZE - 1          # ATTN block's east column
        prof_lane_ffn  = P_BLOCK_SIZE              # FFN block's west column
        prof_row_rg = layout.create_code_region(
            str(here / "src" / "kv_fwd.csl"), "prof_row", P_BLOCK_SIZE + 1, 1,
        )
        _pass_w = RoutingPosition().set_input([Route.EAST]).set_output([Route.WEST])
        _inj_w = RoutingPosition().set_input([Route.SOUTH]).set_output([Route.WEST])
        for _c, _lane in ((prof_attn_color, prof_lane_attn),
                          (prof_ffn_color, prof_lane_ffn)):
            prof_row_rg.paint_all(_c, [_pass_w])
            prof_row_rg.paint(IntVector(_lane, 0), _c, [_inj_w])
        prof_port_attn = prof_row_rg.create_output_port(
            prof_attn_color, Edge.LEFT,
            [RoutingPosition().set_input([Route.EAST])],
            prof_words, prefix="prof_attn",
        )
        prof_port_ffn = prof_row_rg.create_output_port(
            prof_ffn_color, Edge.LEFT,
            [RoutingPosition().set_input([Route.EAST])],
            prof_words, prefix="prof_ffn",
        )
        prof_row_rg.place(PLACE_X, PLACE_Y - 1)


    # KV-cache runtime ingress feeder: NS = P_Y_BLOCK_NUM parallel               #
    # per-band host input ports.                                              #
    # ---------------------------------------------------------------------- #
    # One-shot per decode round. Each band's host TOP-edge port feeds a 1-PE
    # kv_ingress_adaptor (relays the band's rows SOUTH one row-slice at a time +
    # SWITCH_ADV) into a 1xP_BLOCK_SIZE kv_ingress_injector (vertical switch demux: PE
    # ly takes row ly NORTH->RAMP, forwards the rest NORTH->SOUTH) in the free column
    # east of the block, staircase-offset by `by`. The injector scatters each row WEST
    # across the staircase gap (kv_fwd extenders, E->W) + the block east strip into the
    # block's east edge, where decode.csl's kv_ingress west-shift fans it across the
    # columns. NS parallel host streams provide one ingress path per block row.
    kv_ingress_streams = []
    # fp16 operands per (layer, K|V) tile = the on-chip kv_ingress_tile, sized at the
    # compile maximum; the host zero-pads short prefills.
    kv_in_tile_len = bsz * kv_cols * prefill_max_per_pe
    # Per (row, column) cell: 1 phase-0 metainfo tile (KV_META_LEN=2 fp16 = 1 u32,
    # carrying [decode_len | plen]) + K/V for every
    # layer. A row-slice contains only the P ATTN columns; FFN has no cache.
    KV_META_LEN  = 2
    # Varlen ingress packs each per-tile KV payload at the runtime prefill_len (no MAX pad),
    # so bsz*kv_cols*plen fp16 must be even to pack whole u32 wavelets at any plen.
    assert (bsz * kv_cols) % 2 == 0, (
        f"bsz*kv_cols ({bsz}*{kv_cols}) must be even for varlen KV-ingress u32 tile parity")
    kv_cell_fp16 = KV_META_LEN + 2 * max_layers_per_block * kv_in_tile_len   # one (row,col) cell (MAX)
    kv_row_fp16  = P_BLOCK_SIZE * kv_cell_fp16                                # one row-slice (ATTN only)
    assert kv_row_fp16 % 2 == 0, f"kv_row_fp16 {kv_row_fp16} must be even (2 fp16/u32 pack)"
    kv_row_u32   = kv_row_fp16 // 2                                           # per-row wavelets (per round)
    # KV ingress re-arms each round, so the host stream port is per-round sized.
    kv_band_total = H_ROWS * kv_row_u32
    # Variable-length transfer: runtime segment count x compile-time segment length.
    # The P metainfo u32 (one per ATTN column) are relayed as a fixed
    # comptime block; only the KV is segmented. Per-row KV u32 = C_kv * plen_per_pe, so a comptime
    # seg_len dividing C_kv gives a clean runtime count n_segs_rt = D_kv * plen_per_pe (D_kv
    # comptime, computed on-device from the peeled meta[0]). §11.7: seg_len <= 32766 (>= 0x7fff =
    # INFINITE_DSD_LEN hangs). n_segs_rt==1 reduces to one @mov32.
    C_kv = P_BLOCK_SIZE * max_layers_per_block * bsz * kv_cols
    kv_seg_max = int(cfg["KV_DSD_SEG_MAX"])
    assert 1 <= kv_seg_max <= KV_DSD_EXTENT_CAP, (
        f"KV_DSD_SEG_MAX ({kv_seg_max}) must be in [1, {KV_DSD_EXTENT_CAP}] (fabric DSD extent < 0x7fff)")
    # kv_seg_len := largest divisor of C_kv that is <= the cap (equal comptime segments).
    kv_seg_len = 1
    divisor = 1
    while divisor * divisor <= C_kv:
        if C_kv % divisor == 0:
            cofactor = C_kv // divisor
            if divisor <= kv_seg_max:
                kv_seg_len = max(kv_seg_len, divisor)
            if cofactor <= kv_seg_max:
                kv_seg_len = max(kv_seg_len, cofactor)
        divisor += 1
    assert C_kv % kv_seg_len == 0 and kv_seg_len <= kv_seg_max, (
        f"KV varlen segmentation failed: C_kv={C_kv} (Pw*layers*bsz*kv_cols) has no divisor "
        f"<= {kv_seg_max} other than {kv_seg_len}. Pick a geometry whose C_kv factorizes "
        f"better, or lower KV_DSD_SEG_MAX.")
    kv_D = C_kv // kv_seg_len            # comptime; runtime n_segs_rt = kv_D * plen_per_pe
    # u16 guard: only kv_seg_len is bounded above (KV_DSD_SEG_MAX), NOT the segment COUNT.
    # The runtime count n_segs_rt = kv_D * plen_per_pe is a u16 on device; if it exceeds
    # 65535 it wraps silently and the KV-ingress fabric chain hangs (no error). Bound it at
    # the compile envelope prefill_max_per_pe (the largest plen_per_pe). Cheap startup check.
    assert kv_D * prefill_max_per_pe <= 65535, (
        f"KV n_segs_rt would overflow u16: D_kv={kv_D} * prefill_max_per_pe={prefill_max_per_pe} "
        f"= {kv_D * prefill_max_per_pe} > 65535 -> silent device hang; lower kv geometry or prefill_max_per_pe.")
    assert P_BLOCK_SIZE <= KV_DSD_EXTENT_CAP, (
        f"P_BLOCK_SIZE ({P_BLOCK_SIZE}) > {KV_DSD_EXTENT_CAP}: meta block needs one fabric op")
    print(f"      [kv] KV coeff C_kv={C_kv} u32/plen -> seg_len={kv_seg_len} x D_kv={kv_D} "
          f"(n_segs_rt = D_kv*plen_per_pe; cap {kv_seg_max}); "
          f"P={P_BLOCK_SIZE} ATTN meta u32/row; "
          f"NS={P_Y_BLOCK_NUM} parallel bands")

    # KV-ingress staircase in the free column east of the block. The +1 leaves
    # space for decode's east strip.
    STAIR_X0 = PLACE_X + Pw + 1
    # scatter_c was resolved from every row's actual ATTN east edge above.
    kv_io_locs = cfg.get("KV_INGRESS_IO_LOCS")
    rp_e2w = RoutingPosition().set_input([Route.EAST]).set_output([Route.WEST])
    for by in range(P_Y_BLOCK_NUM):
        if by not in kv_rows:
            kv_ingress_streams.append(None)   # cut mode: this row has no KV stage
            continue
        y0 = PLACE_Y + by * P_BLOCK_SIZE
        # Extender (by cols): transparent E->W relay bridging the staircase gap so the
        # injector's WEST scatter reaches the east strip / block east edge (none for by==0).
        if by > 0:
            ext = layout.create_code_region(
                str(here / "src" / "kv_fwd.csl"), f"kv_fwd_{by}", by, P_BLOCK_SIZE)
            ext.paint_all(scatter_c, [rp_e2w, rp_e2w])
            ext.place(STAIR_X0, y0)

        # --- injector (1 x P_BLOCK_SIZE): vertical switch demux, scatter WEST --- #
        inj = layout.create_code_region(
            str(here / "src" / "kv_ingress_injector.csl"), f"kv_inj_{by}", 1, H_ROWS)
        inj.set_param_all("seg_len", kv_seg_len)
        inj.set_param_all("D_kv",    kv_D)        # runtime n_segs_rt = D_kv * plen (peeled from meta[0])
        inj.set_param_all("num_cols", P_BLOCK_SIZE)
        inj.set_param_all("num_rows", H_ROWS)
        inj.set_param_all("region_origin_y", PLACE_Y)
        inj_in_color = inj.color("in_color")              # adaptor -> injector (switchable)
        inj.set_param_all("in_color",      inj_in_color)
        inj.set_param_all("scatter_color", scatter_c)
        inj_take = RoutingPosition().set_input([Route.NORTH]).set_output([Route.RAMP])
        inj_fwd  = RoutingPosition().set_input([Route.NORTH]).set_output([Route.SOUTH])
        inj.paint_all(inj_in_color, [inj_take, inj_fwd])  # switch pos0 take, pos1 forward
        inj.paint_all(scatter_c,
            [RoutingPosition().set_input([Route.RAMP]).set_output([Route.WEST])])
        # Per-round switch reset: south-most PE (took the last row) sources round_sync
        # NORTH (S->N stays behind the southward data). source (tail) RAMP->N; middle
        # S->RAMP+N; sink (north-most) S->RAMP.
        inj_round_sync = inj.color("kv_inj_round_sync")
        inj.set_param_all("round_sync_color", inj_round_sync)
        inj.paint_all(inj_round_sync, [default_routing_pos])
        inj_in_port = inj.create_input_port(
            inj_in_color, Edge.TOP,
            [RoutingPosition().set_output([Route.RAMP]),
             RoutingPosition().set_output([Route.SOUTH])],
            kv_band_total,
        )
        inj.place(STAIR_X0 + by, y0)

        # --- adaptor (1x1, directly north of the injector): host TOP -> relay SOUTH --- #
        adp = layout.create_code_region(
            str(here / "src" / "kv_ingress_adaptor.csl"), f"kv_adp_{by}", 1, 1)
        adp.set_param_all("seg_len",  kv_seg_len)
        adp.set_param_all("D_kv",     kv_D)        # runtime n_segs_rt = D_kv * plen (peeled from meta[0])
        adp.set_param_all("num_cols", P_BLOCK_SIZE)
        adp.set_param_all("num_rows", H_ROWS)
        adp_host_color = adp.color("kv_adp_host")         # host -> adaptor
        adp_out_color  = adp.color("kv_adp_out")          # adaptor -> injector
        adp.set_param_all("host_in_color", adp_host_color)
        adp.set_param_all("inj_out_color", adp_out_color)
        adp.paint_all(adp_out_color,
            [RoutingPosition().set_input([Route.RAMP]).set_output([Route.SOUTH])])
        adp_host_port = adp.create_input_port(            # host stream entry (TOP edge)
            adp_host_color, Edge.TOP,
            [RoutingPosition().set_output([Route.RAMP])],
            kv_band_total,
        )
        adp_out_port = adp.create_output_port(
            adp_out_color, Edge.BOTTOM,
            [RoutingPosition().set_input([Route.RAMP])],
            kv_band_total,
        )
        adp.place(STAIR_X0 + by, y0 - 1)
        layout.connect(adp_out_port, inj_in_port)
        io_loc = None if kv_io_locs is None else IntVector(int(kv_io_locs[by][0]), int(kv_io_locs[by][1]))
        kv_ingress_streams.append(
            layout.create_input_stream(adp_host_port, io_loc=io_loc) if io_loc is not None
            else layout.create_input_stream(adp_host_port))

    # --- Per-row weight gen helpers --- #
    # Each global layer keeps its deterministic np.random.RandomState(2025+l)
    # bundle.  A block row owns one layer slice; its ATTN and FFN images receive
    # only their role-specific symbols.
    #
    # Axis assignment: dim is sharded along Y, KV-head bands along X. The
    # per-PE shard band indexing (kv*pes_per_kv_head + s) lives on X.

    # ---- head_dim sharding-pad (Step 1: uniform pad to head_dim_shard) ---- #
    # When head_dim/2 is not divisible by pes_per_kv_head, each X-band cannot
    # hold a whole number of RoPE pairs at the
    # TRUE head_dim. We shard over a PADDED head_dim_shard (next 2*pes_per_kv_head
    # multiple) and zero-fill the dummy head positions. The reshard functions
    # below run in head_dim_shard space (the kernel computes over the padded
    # width; dummy cols are 0 so Q·K / QK-norm / V / output get 0 from them).
    # Two padding shapes, matching the two on-chip layouts:
    #   _expand_pairs  : RoPE-pair (lo/hi-split) layout — Q,K,q_norm,k_norm,
    #                    RoPE freqs, K cache. True lo-half -> shard [0,H/2),
    #                    true hi-half -> shard [HS/2, HS/2+H/2); the two dummy
    #                    bands [H/2,HS/2) and [HS/2+H/2,HS) are 0. This keeps the
    #                    shard pair (i, i+HS/2) aligned with true pair (i, i+H/2).
    #   _expand_contig : contiguous (non-RoPE) layout — V, V cache, O input rows.
    #                    Zero-pad each head's TAIL [head_dim, head_dim_shard).
    # All are identity when head_dim_shard == head_dim (every shipped config).
    def _expand_pairs(arr, axis, n_h):
        if head_dim_shard == head_dim:
            return arr
        src = np.moveaxis(arr, axis, 0)
        rest = src.shape[1:]
        s = src.reshape(n_h, head_dim, *rest)
        o = np.zeros((n_h, head_dim_shard, *rest), dtype=arr.dtype)
        h2, hs2 = head_dim // 2, head_dim_shard // 2
        o[:, 0:h2]        = s[:, 0:h2]
        o[:, hs2:hs2 + h2] = s[:, h2:head_dim]
        return np.moveaxis(o.reshape(n_h * head_dim_shard, *rest), 0, axis)

    def _expand_contig(arr, axis, n_h):
        if head_dim_shard == head_dim:
            return arr
        src = np.moveaxis(arr, axis, 0)
        rest = src.shape[1:]
        s = src.reshape(n_h, head_dim, *rest)
        o = np.zeros((n_h, head_dim_shard, *rest), dtype=arr.dtype)
        o[:, 0:head_dim] = s
        return np.moveaxis(o.reshape(n_h * head_dim_shard, *rest), 0, axis)

    def _expand_pairs_vec(vec):
        if head_dim_shard == head_dim:
            return vec
        out = np.zeros(head_dim_shard, dtype=vec.dtype)
        h2, hs2 = head_dim // 2, head_dim_shard // 2
        out[0:h2] = vec[0:h2]
        out[hs2:hs2 + h2] = vec[h2:head_dim]
        return out

    def _expand_freq(base):
        # inv_freq-derived (length head_dim/2 -> head_dim_shard/2, tail 0). The
        # dummy freqs are unused on chip (their Q/K cols are 0 -> RoPE result 0).
        if head_dim_shard == head_dim:
            return base
        out = np.zeros(head_dim_shard // 2, dtype=base.dtype)
        out[0:head_dim // 2] = base
        return out

    _kv_dim_shard = n_kv_heads * head_dim_shard      # = P_BLOCK_SIZE * kv_cols

    def _perm_WQ(W):
        """Reorder Q-weight's OUTPUT columns into HF-pair-aligned +
        kv-head-interleaved layout. `W` is already head-expanded
        (_expand_pairs, output dim = n_heads*head_dim_shard). Output cols
        correspond to X-PE bands. Composite of two permutations:

        (1) HF-pair-aligned (A.2 reshard): within each head, PE-band `s_idx`
            holds HF positions
              [s_idx*pairs_per_pe + i, s_idx*pairs_per_pe + i + H/2]
            for i in [0, pairs_per_pe).
        (2) kv-head-interleaved (GQA): each PE owns gqa_group_size
            Q-heads' partial slices.
        """
        result = np.empty_like(W)
        H = head_dim_shard
        pairs_per_pe = kv_cols // 2
        for head_idx in range(n_heads):
            kv_head_idx, gqa_group_idx = head_idx // gqa_group_size, head_idx % gqa_group_size
            for s_idx in range(pes_per_kv_head):
                # HF positions for this PE-band within this head, HF-pair-interleaved.
                hf_positions = []
                for i in range(pairs_per_pe):
                    hf_positions.append(s_idx * pairs_per_pe + i)
                    hf_positions.append(s_idx * pairs_per_pe + i + H // 2)
                old_cols = [head_idx * H + i for i in hf_positions]
                new_col_start = (kv_head_idx * pes_per_kv_head * attn_per_pe
                                 + s_idx * attn_per_pe
                                 + gqa_group_idx * kv_cols)
                result[:, new_col_start:new_col_start + kv_cols] = W[:, old_cols]
        return result

    def _reshard_K_dim(W, axis):
        """Apply A.2 HF-pair-aligned reshuffle to a kv_dim_shard-spanning axis.
        `W` is already head-expanded (_expand_pairs, n_kv_heads). Builds a
        permutation index of length `_kv_dim_shard` such that PE band pe_x
        (= kv_head_idx*pes_per_kv_head + s_idx within block-X) owns HF positions
          [kv_head_idx*H + s_idx*pairs_per_pe + i,
           kv_head_idx*H + s_idx*pairs_per_pe + i + H/2  for i in [0, pairs_per_pe)]
        interleaved as [pair_0_lo, pair_0_hi, pair_1_lo, pair_1_hi, ...].
        Used by K weight (axis=1, output cols) and K cache prefill
        (axis=0, kv_dim rows).
        """
        H = head_dim_shard
        pairs_per_pe = kv_cols // 2
        new_idx = np.empty(_kv_dim_shard, dtype=np.int64)
        for kv_head_idx in range(n_kv_heads):
            for s_idx in range(pes_per_kv_head):
                pe_x = kv_head_idx * pes_per_kv_head + s_idx
                for i in range(pairs_per_pe):
                    new_idx[pe_x * kv_cols + 2 * i + 0] = kv_head_idx * H + s_idx * pairs_per_pe + i
                    new_idx[pe_x * kv_cols + 2 * i + 1] = kv_head_idx * H + s_idx * pairs_per_pe + i + H // 2
        return np.take(W, new_idx, axis=axis)

    def _perm_WO(W):
        """Reorder O-weight's INPUT rows to match perm_WQ's output layout, so O
        consumes attention output in the same permuted dim ordering. `W` is
        already head-expanded (_expand_contig — O input rows are contiguous /
        V-aligned, NOT pair-interleaved).
        """
        result = np.empty_like(W)
        for head_idx in range(n_heads):
            kv_head_idx, gqa_group_idx = head_idx // gqa_group_size, head_idx % gqa_group_size
            for s_idx in range(pes_per_kv_head):
                old_row_start = head_idx * head_dim_shard + s_idx * kv_cols
                new_row_start = (kv_head_idx * pes_per_kv_head * attn_per_pe
                                 + s_idx * attn_per_pe
                                 + gqa_group_idx * kv_cols)
                result[new_row_start:new_row_start + kv_cols, :] = (
                    W[old_row_start:old_row_start + kv_cols, :])
        return result

    def _gen_block_tensors_single_layer(global_l: int):
        """Generate one global layer's per-PE sharded weights.
        Seed = 2025 + global_l, so the same global layer always produces the
        same weights regardless of which block it ends up in (this lets the
        oracle reproduce by global layer index alone).
        """
        rng = np.random.RandomState(2025 + global_l)

        def rand_f16(*shape):
            return (rng.rand(*shape) * WEIGHT_SCALE).astype(ml_dtypes.bfloat16)

        def in_block_replicate(per_pe):
            # per_pe shape (P_BLOCK_SIZE, dim_per_pe) where axis 0 is the Y-PE
            # band (dim shard). All X-PEs in the same Y row share the same
            # shard, so tile per_pe along the X (col) axis P_BLOCK_SIZE times.
            return np.tile(per_pe, reps=(1, P_BLOCK_SIZE))

        def shard_3d(weight_full, in_per_pe, out_per_pe, swap_xy=False):
            """Shard a (P_BLOCK_SIZE*in_per_pe, P_BLOCK_SIZE*out_per_pe) weight
            matrix into per-PE tiles shaped (axis0, axis1, in_per_pe*out_per_pe).
              swap_xy=False: axis0 = input_band (Y owns input rows, X owns output cols).
              swap_xy=True : axis0 = output_band (Y owns output cols, X owns input rows).
            Use swap_xy=True for the K cache, where X owns kv_dim (rows) and Y
            owns seq (cols).
            """
            transpose_order = (2, 0, 1, 3) if swap_xy else (0, 2, 1, 3)
            # Band counts inferred from the 2D shape: rows split into
            # in_bands x in_per_pe, cols into out_bands x out_per_pe. At sub
            # heights the dim-sharded axis has H_ROWS bands, width stays 256.
            n_in, n_out = weight_full.shape[0] // in_per_pe, weight_full.shape[1] // out_per_pe
            a0, a1 = (n_out, n_in) if swap_xy else (n_in, n_out)
            return (weight_full
                    .reshape(n_in, in_per_pe, n_out, out_per_pe)
                    .transpose(*transpose_order)
                    .reshape(a0, a1, in_per_pe * out_per_pe))

        def flatten_shard(arr_3d):
            """Final reshape from (axis0=fabric_Y, axis1=fabric_X, K) → (Y, X*K)
            for set_symbol_all. After shard_3d, axis0 is the Y-PE dimension
            and axis1 is the X-PE dimension (per-PE band slot).
            """
            return arr_3d.reshape(arr_3d.shape[0], arr_3d.shape[1] * arr_3d.shape[-1])

        out = {}
        # Qwen3 has two independent RMSNorm weights per layer:
        #   W_attn_norm = input_layernorm        (pre-attention)
        #   W_ffn_norm  = post_attention_layernorm (pre-FFN)
        # Draw order must match oracle._gen_block_weights exactly. Every draw is
        # taken at the TRUE (unpadded) dims, then zero-padded up to the padded
        # dimensions so padding does not change the RNG stream
        # AND makes the dummy heads / dims (the padded tail) exactly zero.
        out["W_attn_norm_tile"] = in_block_replicate(
            _zpad(rand_f16(1, dim_true), (1, dim)).reshape(H_ROWS, dim_per_pe))
        out["W_ffn_norm_tile"]  = in_block_replicate(
            _zpad(rand_f16(1, dim_true), (1, dim)).reshape(H_ROWS, dim_per_pe))

        # Q: head-pad output cols (RoPE-pair) -> kv-head-interleaved column
        #    permutation BEFORE sharding. Out shard width = attn_per_pe.
        WQ = _expand_pairs(_zpad(rand_f16(dim_true, attn_dim_true), (dim, attn_dim_pad)), axis=1, n_h=n_heads)
        WQp = _perm_WQ(WQ)
        out["Q_weight_tile"] = flatten_shard(shard_3d(WQp, dim_per_pe, attn_per_pe))

        # O: head-pad input rows (contiguous / V-aligned) -> permute input rows +
        #    .transpose(1, 0, 2) after sharding. In shard width = attn_per_pe.
        WO = _expand_contig(_zpad(rand_f16(attn_dim_true, dim_true), (attn_dim_pad, dim)), axis=0, n_h=n_heads)
        WOp = _perm_WO(WO)
        out["O_weight_tile"] = flatten_shard(
            shard_3d(WOp, attn_per_pe, dim_per_pe).transpose(1, 0, 2)
        )

        # K: head-pad output cols (RoPE-pair) -> HF-pair-aligned reshuffle along
        #    kv_dim_shard (output) so the on-chip interleaved RoPE produces HF
        #    rotate_half equivalent K values. RNG order: one rand_f16() draw,
        #    then expand+reshard. Out shard width = kv_cols.
        # V: no RoPE, no reshuffle. Head-pad output cols (contiguous / tail-zero)
        #    so it stays HF contiguous-per-PE; output_matvec(score @ V) produces
        #    HF-order attention output and feeds the (contig-padded) O matvec.
        out["K_weight_tile"] = flatten_shard(
            shard_3d(_reshard_K_dim(
                         _expand_pairs(_zpad(rand_f16(dim_true, kv_dim_true), (dim, kv_dim)),
                                       axis=1, n_h=n_kv_heads),
                         axis=1),
                     dim_per_pe, kv_cols))
        out["V_weight_tile"] = flatten_shard(
            shard_3d(_expand_contig(_zpad(rand_f16(dim_true, kv_dim_true), (dim, kv_dim)),
                                    axis=1, n_h=n_kv_heads),
                     dim_per_pe, kv_cols))

        # Qwen3 QK-Norm weights: per-head RMSNorm (over head_dim) on Q and K,
        # applied after q_proj/k_proj and before RoPE. q_norm / k_norm are head_dim
        # learnable vectors, shared across all heads. Reshard to the interleaved
        # RoPE-pair layout per X-PE band so they align with the post-_perm_WQ /
        # _reshard_K_dim Q/K head slices. RNG order MUST match oracle: one
        # rand_f16(head_dim) for q_norm, then one for k_norm (right after V).
        q_norm_vec = rand_f16(head_dim)
        k_norm_vec = rand_f16(head_dim)

        def _tile_head_vec(vec, is_q):
            # `vec` is head-expanded (_expand_pairs_vec, length head_dim_shard).
            # Per X-PE band pe_x (s_idx = pe_x % pes_per_kv_head), gather the band's
            # kv_cols head_dim_shard positions in interleaved RoPE-pair order
            # [pair_lo, pair_hi, ...] — the same per-band head-dim ordering _perm_WQ
            # / _reshard_K_dim impose on Q/K. Q tiles the slice gqa_group_size times
            # (attn_per_pe); K keeps kv_cols. Replicate across all Y rows.
            # Result (P_BLOCK_SIZE = fabric Y, P_BLOCK_SIZE * K) for set_symbol_all.
            pairs_per_pe = kv_cols // 2
            K = attn_per_pe if is_q else kv_cols
            per_pe = np.zeros((P_BLOCK_SIZE, K), dtype=vec.dtype)
            for pe_x in range(P_BLOCK_SIZE):
                s_idx = pe_x % pes_per_kv_head
                band = np.empty(kv_cols, dtype=vec.dtype)
                for i in range(pairs_per_pe):
                    band[2 * i + 0] = vec[s_idx * pairs_per_pe + i]
                    band[2 * i + 1] = vec[s_idx * pairs_per_pe + i + head_dim_shard // 2]
                per_pe[pe_x, :] = np.tile(band, gqa_group_size) if is_q else band
            one_row = per_pe.reshape(1, P_BLOCK_SIZE * K)
            return np.tile(one_row, reps=(H_ROWS, 1))

        out["q_norm_tile"] = _tile_head_vec(_expand_pairs_vec(q_norm_vec), True)
        out["k_norm_tile"] = _tile_head_vec(_expand_pairs_vec(k_norm_vec), False)

        # RoPE state from Qwen3 plain (non-NTK) inv_freq.
        #   cos_cur / sin_cur       : initial cos/sin at position `prefill_len`
        #   delta_cos / delta_sin   : single-step deltas (cos(θ), sin(θ))
        # Kv-head-interleaved per-PE tiling: each PE owns pair-indices
        # `[(pe_x%pes_per_kv_head)*kv_cols_half : (pe_x%pes_per_kv_head+1)*kv_cols_half)`,
        # tiled gqa_group_size times for the GQA Q-heads on that PE. All four
        # arrays are f32.
        kv_cols_half = kv_cols // 2
        inv_freq = _qwen3_inv_freq(head_dim)            # (head_dim/2,) fp64
        base_cos = _expand_freq(np.cos(prefill_len * inv_freq))   # initial pos -> shard
        base_sin = _expand_freq(np.sin(prefill_len * inv_freq))
        base_delta_cos = _expand_freq(np.cos(inv_freq))           # single-step delta
        base_delta_sin = _expand_freq(np.sin(inv_freq))
        # Per-round P_BLOCK_SIZE-position rotation, prefill-independent.
        # rope_init_from_delta_p rotates (1,0) by this prefill_len_per_pe times on-device
        # to land cos_cur/sin_cur at position prefill_len = prefill_len_per_pe*P_BLOCK_SIZE.
        base_delta_p_cos = _expand_freq(np.cos(H_ROWS * inv_freq))
        base_delta_p_sin = _expand_freq(np.sin(H_ROWS * inv_freq))

        def _tile_per_pe(base):
            # `base` is freq-expanded (length head_dim_shard/2, dummy tail 0).
            # KV-head bands live on X. Each X-PE band pe_x gets its own RoPE
            # tile; all Y-PEs in the same X column share the same tile.
            # Final arr shape: (P_BLOCK_SIZE = fabric Y, P_BLOCK_SIZE * K_per_pe)
            # such that arr[local_py, local_px*K:(local_px+1)*K] = band-local_px tile.
            per_pe = np.zeros((P_BLOCK_SIZE, attn_per_pe // 2), dtype=np.float32)
            for pe_x in range(P_BLOCK_SIZE):
                band_start = (pe_x % pes_per_kv_head) * kv_cols_half
                band_end   = band_start + kv_cols_half
                tile = np.tile(base[band_start:band_end], gqa_group_size).astype(np.float32)
                per_pe[pe_x, :len(tile)] = tile
            # per_pe[pe_x, :] is the band-pe_x RoPE tile (K = attn_per_pe // 2).
            # Flatten per-band tiles into one row, then replicate across Y rows.
            one_row = per_pe.reshape(1, P_BLOCK_SIZE * (attn_per_pe // 2))
            return np.tile(one_row, reps=(H_ROWS, 1))

        out["cos_cur_f32"]   = _tile_per_pe(base_cos)
        out["sin_cur_f32"]   = _tile_per_pe(base_sin)
        out["delta_cos_f32"] = _tile_per_pe(base_delta_cos)
        out["delta_sin_f32"] = _tile_per_pe(base_delta_sin)
        out["delta_p_cos_f32"] = _tile_per_pe(base_delta_p_cos)
        out["delta_p_sin_f32"] = _tile_per_pe(base_delta_p_sin)
        # KV cache: K has kv_dim rows; V has kv_dim cols. Each batch gets its
        # own random prefill state (independent KV history). Per-PE layout
        # inside a layer slab is batch-inner: [batch_0_K | batch_1_K | ...].
        # RNG order MUST match oracle: bsz consecutive `rand_f16(kv_dim, max_seq_len)`
        # draws followed by bsz consecutive `rand_f16(max_seq_len, kv_dim)` draws.
        # K cache rows are reshuffled (A.2) so they match the live K layout
        # written by process_kv after RoPE. V cache stays HF-contiguous.
        xk_shards = [shard_3d(_reshard_K_dim(
                                  _expand_pairs(_zpad(rand_f16(kv_dim_true, seq_true), (kv_dim, max_seq_len)),
                                                axis=0, n_h=n_kv_heads),
                                  axis=0),
                              kv_cols, kv_len_per_pe, swap_xy=True)
                     for _ in range(bsz)]
        xv_shards = [shard_3d(_expand_contig(_zpad(rand_f16(seq_true, kv_dim_true), (max_seq_len, kv_dim)),
                                             axis=1, n_h=n_kv_heads),
                              kv_len_per_pe, kv_cols)
                     for _ in range(bsz)]
        # Stack bsz shards on axis 2 → (P_BLOCK_SIZE, P_BLOCK_SIZE, bsz, K_per_pe)
        # then reshape to (P_BLOCK_SIZE, P_BLOCK_SIZE * bsz * K_per_pe). Per-PE
        # in-layer memory layout matches kernel's `[bsz * kv_cols * kv_len_per_pe]`.
        xk_stacked = np.stack(xk_shards, axis=2)
        xv_stacked = np.stack(xv_shards, axis=2)
        out["XKCache_tile"] = xk_stacked.reshape(xk_stacked.shape[0], -1)
        out["XVCache_tile"] = xv_stacked.reshape(xv_stacked.shape[0], -1)

        # UP, GATE: input-dim sharded, output-dim contiguous (ffn_dim has no
        # head structure). No permutation.
        for name in ("UP_weight_tile", "GATE_weight_tile"):
            out[name] = flatten_shard(shard_3d(
                _zpad(rand_f16(dim_true, ffn_true), (dim, ffn_dim)), dim_per_pe, ffn_dim_per_pe))

        # DOWN: same .transpose(1, 0, 2) post-shard as O — down_matvec reduces
        # along Y, so the (out_pe, in_pe) tile assignment swaps.
        out["DOWN_weight_tile"] = flatten_shard(
            shard_3d(_zpad(rand_f16(ffn_true, dim_true), (ffn_dim, dim)),
                     ffn_dim_per_pe, dim_per_pe).transpose(1, 0, 2)
        )
        return out

    # RoPE state is layer-invariant in Qwen3 (inv_freq depends only on
    # head_dim, not on layer). Skip the per-layer stacking for these keys
    # so the kernel can declare them as `[_attn_per_pe / 2]f32` (no n_layers
    # outer dim) and host upload sizes match.
    LAYER_INVARIANT_KEYS = frozenset(
        {"cos_cur_f32", "sin_cur_f32", "delta_cos_f32", "delta_sin_f32",
         "delta_p_cos_f32", "delta_p_sin_f32"}
    )

    def _gen_block_tensors(layer_count: int, layer_offset: int,
                           pad_layers: int):
        """Generate this block's layer-stacked, per-PE-sharded weights.

        Walks global layer indices [layer_offset, layer_offset + layer_count)
        and stacks them in layer-outermost per-PE layout. The result is
        zero-padded along the layer axis up to `pad_layers` so every block
        shares the same on-chip buffer size (matches decode.csl's
        max_layers_per_block sizing).

        Layer-invariant keys (RoPE state) take the first layer's value with
        no stacking (kernel declares them as `[_attn_per_pe / 2]f32`, no layer
        axis).
        """
        assert layer_count <= pad_layers
        per_layers = [_gen_block_tensors_single_layer(layer_offset + lo)
                      for lo in range(layer_count)]
        out = {}
        for name in per_layers[0].keys():
            if name in LAYER_INVARIANT_KEYS:
                out[name] = per_layers[0][name]
                continue
            # Reshape each layer's (P_BLOCK_SIZE, P_BLOCK_SIZE*K_per_pe) array
            # to (P_BLOCK_SIZE, P_BLOCK_SIZE, K_per_pe), stack on a new layer
            # axis between in_pe and K, then flatten back so the per-PE layout
            # is [l_0_K | l_1_K | ... | 0-pad | ... ]. Padding bumps the layer
            # axis from layer_count up to pad_layers.
            stacked = [arr.reshape(arr.shape[0], P_BLOCK_SIZE, -1)
                       for arr in (lay[name] for lay in per_layers)]
            stack3d = np.stack(stacked, axis=2)  # (out_pe, in_pe, layer_count, K)
            if pad_layers > layer_count:
                pad_block = np.zeros(
                    (stack3d.shape[0], stack3d.shape[1],
                     pad_layers - layer_count, stack3d.shape[3]),
                    dtype=stack3d.dtype,
                )
                stack3d = np.concatenate([stack3d, pad_block], axis=2)
            out[name] = stack3d.reshape(stack3d.shape[0], -1)
        return out

    # --- Per-row, role-filtered weight upload --- #
    # Generate each GLOBAL layer bundle exactly once in the established RNG call
    # order, then split its symbols between the row's ATTN and FFN images. This
    # preserves the oracle's seed/order contract while physically omitting the
    # other role's max-layer banks from each specialized ELF.
    FFN_SYMBOLS = frozenset({
        "W_ffn_norm_tile", "UP_weight_tile",
        "GATE_weight_tile", "DOWN_weight_tile",
    })
    kv_inj_rows: dict = {}
    def _bake(target_rg, name, arr):
        k_total = arr.shape[1]
        assert arr.shape[0] == H_ROWS, (
            f"bake {name}: rows {arr.shape[0]} != active height {H_ROWS}")
        if arr.dtype == ml_dtypes.bfloat16:
            target_rg.set_symbol_all(name, bf16_view_uint16(arr), k_total, H_ROWS)
        elif arr.dtype == np.float32:
            target_rg.set_symbol_all(name, arr, k_total, H_ROWS)
        else:
            raise TypeError(f"unsupported set_symbol_all dtype for {name}: {arr.dtype}")

    if CHAIN is None:
        for row_y, (attn_rg, ffn_rg) in enumerate(zip(attn_regions, ffn_regions)):
            row_tensors = _gen_block_tensors(
                layer_counts[row_y], layer_offsets[row_y], max_layers_per_block)
            for name, arr in row_tensors.items():
                if name in ("XKCache_tile", "XVCache_tile"):
                    kv_inj_rows[(row_y, name)] = bf16_view_uint16(arr)
                    continue
                _bake(ffn_rg if name in FFN_SYMBOLS else attn_rg, name, arr)
    else:
        # Cut mode: generate each layer's bundle once (preserving the RNG call
        # order = ascending global layer), then split the symbols by stage:
        # A2 gets the O weights and the caches (via its row's KV band), the
        # FFN stage its vanilla set, the A1 stage everything else (Q/K/V,
        # norms, rope tables).
        layer_bundles = [
            _gen_block_tensors(1, l, max_layers_per_block) for l in range(n_layers)]
        for row_y, (attn_rg, ffn_rg) in enumerate(zip(attn_regions, ffn_regions)):
            for _rg, _role_bit in ((attn_rg, 1), (ffn_rg, 0)):
                _k, _in, _out, _lyr, _kv = CHAIN[(row_y, _role_bit)]
                if _lyr is None:
                    continue   # relay: no weights
                bundle = layer_bundles[_lyr]
                for name, arr in bundle.items():
                    if name in ("XKCache_tile", "XVCache_tile"):
                        if _kv:
                            kv_inj_rows[(row_y, name)] = bf16_view_uint16(arr)
                        continue
                    is_ffn_sym = name in FFN_SYMBOLS
                    if _k == 0:
                        # Vanilla stage: bake by role exactly like the non-cut path.
                        if (_role_bit == 0) == is_ffn_sym:
                            _bake(_rg, name, arr)
                    elif _k == 2 and name == "O_weight_tile":
                        _bake(_rg, name, arr)          # A2
                    elif _k == 1 and not is_ffn_sym and name != "O_weight_tile":
                        _bake(_rg, name, arr)          # A1: qkv/norms/rope
        # Non-KV stages: bake the (single-round) budget and prefill.
        _pf_per_pe = prefill_lens[0] // H_ROWS
        for row_y, (attn_rg, ffn_rg) in enumerate(zip(attn_regions, ffn_regions)):
            for _rg, _role_bit in ((attn_rg, 1), (ffn_rg, 0)):
                _k, _in, _out, _lyr, _kv = CHAIN[(row_y, _role_bit)]
                if _k == 0 or _kv:
                    continue
                _rg.set_symbol_all("n_steps",
                    np.full((P_BLOCK_SIZE, P_BLOCK_SIZE), decode_lens[0], dtype=np.int16),
                    P_BLOCK_SIZE, P_BLOCK_SIZE)
                _rg.set_symbol_all("prefill_len_per_pe_rt",
                    np.full((P_BLOCK_SIZE, P_BLOCK_SIZE), _pf_per_pe, dtype=np.int16),
                    P_BLOCK_SIZE, P_BLOCK_SIZE)
                _rg.set_symbol_all("decode_len_rt",
                    np.full((P_BLOCK_SIZE, P_BLOCK_SIZE), decode_lens[0], dtype=np.int16),
                    P_BLOCK_SIZE, P_BLOCK_SIZE)

    # [block-row, local-y, P ATTN columns * per-PE cache slab].
    _xk_list = [kv_inj_rows[(ry, "XKCache_tile")] for ry in range(P_Y_BLOCK_NUM)
                if (ry, "XKCache_tile") in kv_inj_rows]
    _xv_list = [kv_inj_rows[(ry, "XVCache_tile")] for ry in range(P_Y_BLOCK_NUM)
                if (ry, "XVCache_tile") in kv_inj_rows]
    inj_xk = np.stack(_xk_list, axis=0) if _xk_list else np.zeros((0, 1, 1), dtype=np.uint16)
    inj_xv = np.stack(_xv_list, axis=0) if _xv_list else np.zeros((0, 1, 1), dtype=np.uint16)

    # ====================================================================== #
    # Region 4/5: HT_tail  (lm_head + token emit, HT_W x P)                  #
    # ---------------------------------------------------------------------- #
    # P_BLOCK_SIZE rows × HT_WIDTH_tail cols. Hosts lm_head mesh-gemv compute#
    # (vocab sharded along X, dim along Y, Y-axis allreduce contracting dim).#
    # result_color is painted as MULTICAST (input=transit-dir, output={RAMP, #
    # transit-dir}) so the router fans wavelets to RAMP (drained by the tail   #
    # kernel for matvec input) AND to the next tail PE along transit-dir       #
    # (chain continues to the mux for host streaming).                         #
    # ====================================================================== #
    ht_tail_rg = layout.create_code_region(
        str(here / "src" / "ht_tail.csl"), "ht_tail", HT_WIDTH_tail, P_BLOCK_SIZE,
    )
    # Common sizing and colors.
    ht_tail_rg.set_param_all("z_drain_color",      decode_result_color)
    ht_tail_rg.set_param_all("P_BLOCK_SIZE",       P_BLOCK_SIZE)
    ht_tail_rg.set_param_all("HT_WIDTH",           HT_WIDTH_tail)
    ht_tail_rg.set_param_all("bsz",                bsz)
    ht_tail_rg.set_param_all("dim_per_pe",           dim_per_pe_lane)
    ht_tail_rg.set_symbol_all(
        "n_steps", np.full((P_BLOCK_SIZE, HT_WIDTH_tail), max_output_len_worst, dtype=np.int16),
        HT_WIDTH_tail, P_BLOCK_SIZE)
    # Forced-prefill: the tail keeps top-k + sampling + south records + TSC,
    # but skips the north sampled-token emit (the head never drains it).
    ht_tail_rg.set_symbol_all(
        "forced_mode", np.full((P_BLOCK_SIZE, HT_WIDTH_tail), forced_mode_flag, dtype=np.int16),
        HT_WIDTH_tail, P_BLOCK_SIZE)
    # Production forced prefill: per-step logits math skipped (final step only).
    ht_tail_rg.set_symbol_all(
        "forced_production",
        np.full((P_BLOCK_SIZE, HT_WIDTH_tail), forced_production_flag, dtype=np.int16),
        HT_WIDTH_tail, P_BLOCK_SIZE)
    ht_tail_rg.set_param_all("TOP_K",              top_k)
    # Device-side EOS detection and padding.
    ht_tail_rg.set_param_all("eos_id_0",           eos_id_0)
    ht_tail_rg.set_param_all("eos_id_1",           eos_id_1)
    ht_tail_rg.set_param_all("pad_id",             pad_token_id)
    # Tail vocab X-shard.
    assert vocab_size % HT_WIDTH_tail == 0, (
        f"vocab_size ({vocab_size}) must be divisible by HT_WIDTH_tail ({HT_WIDTH_tail})"
    )
    V_per_pe_x = vocab_size // HT_WIDTH_tail
    ht_tail_rg.set_param_all("V_per_pe_x",         V_per_pe_x)
    # True hidden dimension for the final RMSNorm divisor.
    ht_tail_rg.set_param_all("true_model_dim", dim_true)
    # Each PE derives its local trailing padding count from x_local and the
    # true vocabulary size at boot.
    ht_tail_rg.set_param_all("true_vocab_size", vocab_true)
    # Y allreduce chain params (reuse same values as row regions — Y axis depth
    # is P_BLOCK_SIZE for both regions, chain structure identical).
    ht_tail_rg.set_param_all("pe_num_per_group",     pe_num_per_group)
    ht_tail_rg.set_param_all("root_1st_phase",     root_1st_phase)
    ht_tail_rg.set_param_all("root_2nd_phase",     root_2nd_phase)
    # X-axis 2-phase chain params for the top-K merge-reduce. Chain depth is
    # HT_WIDTH_tail (the lm_head vocab X-shard spans the full tail width).
    # Cap the group size at 16 PEs; smaller tail widths use proportionally
    # smaller groups (for example, width 4 uses two PEs per group).
    # HT_WIDTH_tail<4 disables the X chain (kernel falls back to local top-K).
    assert HT_WIDTH_tail >= 1
    if HT_WIDTH_tail < 4:
        # Degenerate: width 1 (local top-K only), 2 (no 2nd phase). Kernel
        # handles via comptime guard; we still pass placeholder values.
        pe_num_per_group_x = HT_WIDTH_tail
        root_1st_phase_x   = 0
        root_2nd_phase_x   = 0
    else:
        pe_num_per_group_x = min(16, HT_WIDTH_tail // 2)
        assert HT_WIDTH_tail % pe_num_per_group_x == 0, (
            f"HT_WIDTH_tail ({HT_WIDTH_tail}) must be divisible by pe_num_per_group_x ({pe_num_per_group_x})"
        )
        group_num_x        = HT_WIDTH_tail // pe_num_per_group_x
        assert group_num_x == 1 or group_num_x % 2 == 0, (
            f"group_num_x ({group_num_x}) must be 1 or even for valid 2nd-phase chain"
        )
        root_1st_phase_x   = pe_num_per_group_x // 2
        root_2nd_phase_x   = (group_num_x // 2) * pe_num_per_group_x + root_1st_phase_x
    ht_tail_rg.set_param_all("pe_num_per_group_x", pe_num_per_group_x)
    ht_tail_rg.set_param_all("root_1st_phase_x",   root_1st_phase_x)
    ht_tail_rg.set_param_all("root_2nd_phase_x",   root_2nd_phase_x)
    # On-chip sampling params. temperature/top_p passed as f32 bit patterns
    # (SdkLayout set_param takes ints); the kernel bitcasts them back to f32.
    import struct as _struct
    def _f32_bits(x):
        return _struct.unpack("<I", _struct.pack("<f", float(x)))[0]
    ht_tail_rg.set_param_all("temperature_bits", _f32_bits(temperature))
    ht_tail_rg.set_param_all("top_p_bits",       _f32_bits(top_p))
    ht_tail_rg.set_param_all("sample_seed",      int(sample_seed))
    # Y allreduce colors (layout-global ids 1-5, physically disjoint from row
    # regions because tail X column band [3, 3+HT_W) ≠ row regions' band).
    ht_tail_rg.set_param_all("reduce_1st_color_0", reduce_1st_0_c)
    ht_tail_rg.set_param_all("reduce_1st_color_1", reduce_1st_1_c)
    ht_tail_rg.set_param_all("reduce_2nd_color_0", reduce_2nd_0_c)
    ht_tail_rg.set_param_all("reduce_2nd_color_1", reduce_2nd_1_c)
    ht_tail_rg.set_param_all("broadcast_color",    broadcast_c)
    # Tail emit / head south drain share tok_bcast_color (id 7).
    ht_tail_rg.set_param_all(tok_bcast_color)
    # Region origin: tail_init reads tile_config.get_fabric_coord at runtime
    # and subtracts these to derive per-PE (tail_my_py, tail_my_x_local).
    ht_tail_rg.set_param_all("region_origin_x", ht_tail_x)
    ht_tail_rg.set_param_all("region_origin_y", PLACE_Y + last_row * P_BLOCK_SIZE)
    # logits_south_color: HT_tail root-row east-most PE → mux ingress (one row
    # south). Region-scoped output-port color; connect() routes the south hops
    # to the mux TOP edge.
    logits_south_c = ht_tail_rg.color("logits_south_color")
    ht_tail_rg.set_param_all("logits_south_color", logits_south_c)

    # tail_xready_color: cross-column X-phase barrier. Region-local, kernel-painted
    # (static E→W multicast tree on the root row, never repainted). Makes the
    # per-column write_X reconfig race-free — the X-reduce sink column signals "in
    # X mode, go" after its write_X and the other root cols block on it before any
    # X send, so no column emits an X-mode wavelet into a neighbor still in Y mode.
    tail_xready_c = ht_tail_rg.color("tail_xready_color")
    ht_tail_rg.set_param_all("tail_xready_color", tail_xready_c)

    # Benchmark TSC: the root-row east-most cell (the south top-K emitter) samples
    # start+end and piggybacks an 8-u32 burst on the logits south emit (the mux
    # drains 8 extra after the per-step stream). No separate color/port/stream —
    # uses the existing HT_tail -> mux -> host logits path.
    ht_tail_rg.set_param_all("warmup_cycles", warmup_cycles)

    # Default paint RAMP/RAMP for ALL of tail's colors (Y reduce/broadcast,
    # emit, and the Z multicast/transit channel). Tail's init task overrides
    # per-PE at runtime via set_route_1tx / set_route_2tx. Painting multi-tx
    # directly at compile
    # time on a port-constrained color confuses the SdkLayout router (see
    # AI-Knowledge-Base/common_errors.md E-29).
    for c in (reduce_1st_0_c, reduce_1st_1_c, reduce_2nd_0_c, reduce_2nd_1_c,
              broadcast_c, tok_bcast_color, decode_result_color, logits_south_c,
              tail_xready_c):
        ht_tail_rg.paint_all(c, [default_routing_pos])

    ht_tail_in_port = ht_tail_rg.create_input_port(
        decode_result_color, ht_tail_in_edge,
        [RoutingPosition().set_output([edge_dir_out])],
        total_wavelets + kv_hdr,
        prefix="ingress",
    )
    # Tail emit port: bsz sampled token_ids per root-row PE per step ×
    # HT_WIDTH_tail cols × (MAX_OUTPUT_LEN - 1) steps (skip last so emit count
    # == head drain). Every root-row column emits (uniform connect with the
    # head's full-width tok port). The emit originates on the phase-2 root row
    # (interior) and transits up to Edge.TOP, so the edge cell takes the wavelet
    # from SOUTH (not RAMP).
    tail_token_emit_out_port = ht_tail_rg.create_output_port(
        tok_bcast_color, ht_tail_emit_edge,
        [RoutingPosition().set_input([Route.SOUTH])],
        # matches ht_head_tok_in_port: per round 1 N-header tile + (W-1) tokens = W tiles
        # of bsz (per-round; the terminator step emits no north token).
        bsz * HT_WIDTH_tail * max_output_len_worst,
        prefix="token_emit",
    )

    # Top-k egress: ONLY the root-row east-most cell emits (the global top-k is
    # replicated across the root row). tail_init paints RAMP→SOUTH on that cell
    # and NORTH→SOUTH transit on the east-most cells below it down to Edge.BOTTOM,
    # so the edge cell takes the wavelet from NORTH (not RAMP). Per step it sends
    # TOP_K*bsz f16 values (= TOP_K*bsz/2 u32 via @fmovh) + TOP_K*bsz i32 indices
    # (= TOP_K*bsz u32 via @mov32) = topk_wavelets_per_step u32. Total = that × steps.
    # f16 values pack 2-per-u32; pad the value count to even so an odd TOP_K*bsz
    # (greedy = 1) fills whole u32 words. val_pad/val_wavelets mirror ht_tail.csl.
    val_pad               = (top_k * bsz) % 2
    val_wavelets              = (top_k * bsz + val_pad) // 2
    topk_wavelets_per_step    = val_wavelets + (top_k * bsz)
    # Each token's south record also carries the bsz sampled token ids (i32, @mov32) so the host
    # can replay the device's autoregressive sequence in the oracle. The D2H egress
    # requires an EVEN per-step wavelet count, so pad to even (the kernel emits a
    # matching dummy u32 via SOUTH_PAD). The host ignores the trailing pad word(s).
    south_raw_per_step = topk_wavelets_per_step + bsz
    south_pad = south_raw_per_step % 2
    south_wavelets_per_step = south_raw_per_step + south_pad
    sampled_off_val = topk_wavelets_per_step
    # Per-round egress capacity; early stop emits fewer records.
    south_total_wavelets = south_wavelets_per_step * max_output_len_worst
    # +8 per round for the TSC burst the root-row east emitter piggybacks on the last
    # step (drained by the mux's tsc tail-relay and the host's final receive).
    south_total_with_tsc  = south_total_wavelets + 8   # 1 TSC burst (8 u32) per round
    ht_tail_logits_egress = ht_tail_rg.create_output_port(
        logits_south_c, Edge.BOTTOM,
        [RoutingPosition().set_input([Route.NORTH])],
        south_total_with_tsc + kv_hdr,   # +1 X' budget header (ht_tail -> mux)
        prefix="logits_egress",
    )

    # --- HT_tail weight uploads (lm_head_tile) --- #
    #   lm_head_tile per PE (py, x_local): shape (dim_per_pe, V_per_pe_x) f16,
    #     row-major (dim-outer, vocab-inner) to match the GEMV's K=dim outer read
    #     (ht_tail vecmat_computation_lm). Sharded from full lm_head matrix
    #     of shape (vocab_size, dim). vocab axis sharded along X (each x_local
    #     owns V_per_pe_x vocab rows), dim axis sharded along Y (each py owns
    #     dim_per_pe hidden positions). Qwen3-4B ties lm_head to embed_tokens
    #     (tie_word_embeddings=true), so this draws the SAME (vocab, dim) matrix
    #     as W_E (seed 2024) — bit-identical, just resharded vocab-on-X/dim-on-Y.
    HT_LM_HEAD_K = V_per_pe_x * dim_per_pe_lane   # per-PE tile size in f16
    def _gen_lm_head_tile_array():
        rng = np.random.RandomState(2024)   # tied to W_E (Qwen3 tie_word_embeddings)
        # Draw true (vocab, dim); zero-pad. Dummy vocab rows [vocab_true:] are zero
        # -> their logit = 0; ht_tail derives and masks local padding before top-K so
        # a padded zero-logit can never outrank a real token.
        lm_head_full = _zpad((rng.rand(vocab_true, dim_true) * WEIGHT_SCALE).astype(ml_dtypes.bfloat16),
                             (vocab_size, dim))
        arr = np.empty((P_BLOCK_SIZE, HT_WIDTH_tail * HT_LM_HEAD_K), dtype=ml_dtypes.bfloat16)
        for py in range(P_BLOCK_SIZE):
            dim_lo = py * dim_per_pe_lane
            dim_hi = dim_lo + dim_per_pe_lane
            for x_local in range(HT_WIDTH_tail):
                vocab_lo = x_local * V_per_pe_x
                vocab_hi = vocab_lo + V_per_pe_x
                # .T -> (dim_per_pe, V_per_pe_x): store dim-outer/vocab-inner so the
                # GEMV (ht_tail vecmat_computation_lm) reads K=dim outer. Without .T the
                # weight uploads transposed -> scrambled logits.
                tile = lm_head_full[vocab_lo:vocab_hi, dim_lo:dim_hi].T
                arr[py, x_local*HT_LM_HEAD_K : (x_local+1)*HT_LM_HEAD_K] = tile.reshape(-1)
        return arr

    lm_head_arr = _gen_lm_head_tile_array()
    ht_tail_rg.set_symbol_all(
        "lm_head_tile", bf16_view_uint16(lm_head_arr),
        HT_WIDTH_tail * HT_LM_HEAD_K, P_BLOCK_SIZE,
    )

    # --- HT_tail final RMSNorm weight upload --- #
    # Final RMSNorm weight applied on the last decoder hidden state before
    # lm_head. Per Y-PE owns dim_per_pe of the dim-length weight vector
    # (same dim shard as that Y-PE's z_slice); replicated across HT_WIDTH_tail
    # X cols (all X-PEs in a Y row share the same dim shard). Seed 2028 —
    # disjoint from W_E (2024), per-layer (2025+l); lm_head is tied to W_E (2024).
    def _gen_W_final_norm_tile_array():
        rng = np.random.RandomState(2028)
        # Draw true dim; zero-pad. Padded norm-weight entries multiply zero hidden
        # dims, so their value is irrelevant; zero is cleanest.
        W_full = _zpad((rng.rand(dim_true) * WEIGHT_SCALE).astype(ml_dtypes.bfloat16), (dim,))
        arr = np.empty((P_BLOCK_SIZE, HT_WIDTH_tail * dim_per_pe_lane), dtype=ml_dtypes.bfloat16)
        for py in range(P_BLOCK_SIZE):
            dim_lo = py * dim_per_pe_lane
            dim_hi = dim_lo + dim_per_pe_lane
            tile = W_full[dim_lo:dim_hi]
            for x_local in range(HT_WIDTH_tail):
                arr[py, x_local*dim_per_pe_lane : (x_local+1)*dim_per_pe_lane] = tile
        return arr

    W_final_norm_arr = _gen_W_final_norm_tile_array()
    ht_tail_rg.set_symbol_all(
        "W_final_norm_tile", bf16_view_uint16(W_final_norm_arr),
        HT_WIDTH_tail * dim_per_pe_lane, P_BLOCK_SIZE,
    )

    assert max_output_len >= 2, (
        f"MAX_OUTPUT_LEN ({max_output_len}) must be >= 2: tail emit + head south "
        "drain require at least one autoregressive step (s=1)."
    )

    ht_tail_rg.place(ht_tail_x, PLACE_Y + last_row * P_BLOCK_SIZE)

    # ====================================================================== #
    # Region 5/5: mux  (HT_WIDTH_tail x 1 logits egress)                    #
    # ---------------------------------------------------------------------- #
    # The east-most PE aligns under HT_tail's sole south emitter, receives   #
    # each global top-k record from NORTH, and forwards it to the host at    #
    # Edge.RIGHT. Other PEs share the image but return from init after their #
    # runtime X-coordinate check.                                           #
    # ====================================================================== #
    mux_rg = layout.create_code_region(
        str(here / "src" / "mux.csl"), "logits_mux", HT_WIDTH_tail, 1,
    )
    mux_in_color   = mux_rg.color("in_color")        # from HT_tail east-most north -> RAMP
    mux_host_color = mux_rg.color("host_out_color")  # east-most PE -> host (east)
    mux_rg.set_param_all(mux_in_color)
    mux_rg.set_param_all(mux_host_color)
    mux_rg.set_param_all("host_color", mux_host_color)
    mux_rg.set_param_all("wavelets_per_step", south_wavelets_per_step)
    mux_rg.set_param_all("MAX_OUTPUT_LEN", max_output_len_worst)
    mux_rg.set_param_all("HT_WIDTH", HT_WIDTH_tail)
    mux_rg.set_param_all("region_origin_x", HT_HEAD_X)
    # Early-stop: sampled-token slot offset in a token record (val_wavelets +
    # arg_wavelets). The mux watches it to detect HT_tail's STOP_TOK and switch to
    # the TSC drain instead of waiting for tokens that never arrive.
    mux_rg.set_param_all("sampled_off", sampled_off_val)

    # The global top-k is replicated across X, so only the east-most HT_tail
    # bottom PE emits it. This mux row therefore has ONE active PE — the
    # east-most, derived from its runtime coordinate. It receives the
    # per-step token record from the north and forwards it east to the host edge; all
    # other mux PEs are inert (see src/mux.csl).
    # in_color: NORTH->RAMP (only the east-most cell actually receives; harmless
    # elsewhere). host_color's endpoint route is kept in the layout graph so
    # SdkLayout can wire the code-region edge to its external output port. This
    # paint changes fabric configuration only; it does not specialize the CSL
    # image. The kernel still derives the sole active PE from its runtime X.
    mux_rg.paint_all(mux_in_color,
                     [RoutingPosition().set_input([Route.NORTH]).set_output([Route.RAMP])])
    mux_rg.paint_all(mux_host_color, [default_routing_pos])
    mux_rg.paint(
        IntVector(HT_WIDTH_tail - 1, 0), mux_host_color,
        [RoutingPosition().set_input([Route.RAMP]).set_output([Route.EAST])],
    )

    # Ingress port (Edge.TOP) matching ht_tail_logits_egress; only the east-most
    # lane carries data, the rest are unused.
    mux_in_port = mux_rg.create_input_port(
        mux_in_color, Edge.TOP,
        [RoutingPosition().set_output([Route.RAMP])],
        south_total_with_tsc + kv_hdr,   # +1 X' budget header (mux consumes it, not forwarded)
        prefix="logits_ingress",
    )
    # Host egress: 1-PE Edge.RIGHT port at the east-most cell.
    mux_host_port = mux_rg.create_output_port(
        mux_host_color, Edge.RIGHT,
        [RoutingPosition().set_input([Route.RAMP])],
        south_total_with_tsc,
        prefix="host_logits",
    )

    # Mux sits at the band west origin (same X span as HT_tail), so its
    # east-most PE aligns under HT_tail's east-most (logits south emitter).
    mux_rg.place(HT_HEAD_X, mux_y + P_BLOCK_SIZE)

    # ====================================================================== #
    # Phase 4: Inter-region connects + streams                              #
    # ---------------------------------------------------------------------- #
    # All cross-region wiring in one place. Connect ordering doesn't matter #
    # — SdkLayout treats this as a wiring graph, not a sequence.            #
    # ====================================================================== #

    # X path: host -> demux -> HT_head -> row_0
    layout.connect(demux_out_port,      ht_head_in_port)
    layout.connect(ht_head_c2_out_port, row0_x_in_port)
    # Z path: last_row -> HT_tail (raw Z ingress for the lm_head matvec).
    layout.connect(decode_out_port, ht_tail_in_port)
    # Logits path: HT_tail bottom row -> mux -> host (post-lm_head logits).
    layout.connect(ht_tail_logits_egress, mux_in_port)
    # Ready barrier: HT_head col=0 -> demux east edge. Demux's init() awaits
    # this wavelet before activating main and emitting any C1 wavelet.
    layout.connect(ht_head_ready_out_port, demux_ready_in_port)
    # Token-id channel: HT_tail emitter row -> HT_head bottom edge.
    layout.connect(tail_token_emit_out_port, ht_head_tok_in_port)

    # Host I/O streams. Adding the NS KV-ingress regions perturbs ALL adaptor
    # placements globally (§7.3), so the token (demux) input and logits (mux) output can
    # be pinned to known-good lvds_ports via TOKEN_IO_LOC / LOGITS_IO_LOC (coords from a
    # prior save_port_map dump); None -> auto-place. The NS per-band KV feeder streams
    # were built above (kv_ingress_streams), each pinnable via KV_INGRESS_IO_LOCS.
    _tok_loc = cfg.get("TOKEN_IO_LOC")
    tok_io_loc = None if _tok_loc is None else IntVector(int(_tok_loc[0]), int(_tok_loc[1]))
    x_stream = (layout.create_input_stream(demux_in_port, io_loc=tok_io_loc)
                if tok_io_loc is not None else layout.create_input_stream(demux_in_port))
    # Logits stream: mux easternmost PE -> host (full bsz*vocab per step + the
    # piggybacked 8-u32 TSC burst after the last step).
    _log_loc = cfg.get("LOGITS_IO_LOC")
    log_io_loc = None if _log_loc is None else IntVector(int(_log_loc[0]), int(_log_loc[1]))
    logits_stream = (layout.create_output_stream(mux_host_port, io_loc=log_io_loc)
                     if log_io_loc is not None else layout.create_output_stream(mux_host_port))
    prof_stream_attn = (layout.create_output_stream(prof_port_attn)
                        if prof_port_attn is not None else None)
    prof_stream_ffn = (layout.create_output_stream(prof_port_ffn)
                       if prof_port_ffn is not None else None)

    # ====================================================================== #
    # Phase 5: Compile                                                      #
    # ====================================================================== #
    print("\nCompiling...")
    t_compile = time.perf_counter()
    host_build_s = t_compile - _t_run_entry   # Phase 1..4 host prep (sizing/regions/weight bake)
    # The local driver wrapper caps inlining and places hot polynomial scratch
    # in D-cache. SdkLayout expects cslc_prefix to be its containing directory.
    if not cslc_prefix:
        cslc_prefix = str(here / "scripts" / "cslc_bin")
    # Preserve the port map for appliance-only stream-adaptor placement recovery.
    def _report_port_map(*, include_contents):
        _pm = Path("sim_port_map.json")
        if _pm.is_file():
            print(f"  port map: {_pm.resolve()}", flush=True)
            if include_contents:
                print("=== SIM_PORT_MAP-BEGIN ===", flush=True)
                print(_pm.read_text(), flush=True)
                print("=== SIM_PORT_MAP-END ===", flush=True)
    try:
        artifacts = layout.compile(out_prefix="sim", cslc_prefix=cslc_prefix,
                                   f16_type=FP16TYPE.BF16, save_port_map=True)
    except Exception:
        _report_port_map(include_contents=True)
        raise
    compile_s = time.perf_counter() - t_compile
    print(f"  compile took {compile_s:.1f}s")
    if int(os.environ.get("MSIZE", "0")):
        # Per-coordinate PE memory totals from the linked whole-fabric image; runs
        # inside the SDK container where cs-readelf lives. Written next to the artifact.
        import subprocess as _sp
        _elf = Path(artifact_dir) / "sim.elf"
        try:
            _ms = _sp.run(["cs-readelf", "-m", str(_elf)], capture_output=True, text=True, timeout=1800)
            (Path(artifact_dir) / "msize.txt").write_text(_ms.stdout)
            print(f"  [msize] cs-readelf -m rc={_ms.returncode}: {len(_ms.stdout.splitlines())} lines -> msize.txt", flush=True)
            # The per-role ELFs are small; bundle them so one download_artifact call fetches all.
            _tar = _sp.run(["tar", "czf", str(Path(artifact_dir) / "executables.tgz"), "-C", str(artifact_dir),
                            "executables", "sim.map", "colors.json"], capture_output=True, text=True)
            print(f"  [msize] executables.tgz rc={_tar.returncode}", flush=True)
        except Exception as _e:
            print(f"  [msize] failed: {_e}", flush=True)
    _report_port_map(include_contents=False)

    if compile_only:
        print("  [compile_only] skipping runtime.load/run/oracle")
        return {"compile_s": compile_s, "run_s": 0.0, "aligned": None}

    # ====================================================================== #
    # Phase 6: Runtime (load + send/recv loop + stop)                        #
    # ====================================================================== #
    global _ACTIVE_RUNTIME
    runtime = SdkRuntime(artifacts, platform, memcpy_required=False)
    _ACTIVE_RUNTIME = runtime
    _t_load = time.perf_counter()
    runtime.load()                             # one-time: ELF -> wafer program+weight load
    load_s = time.perf_counter() - _t_load
    print(f"  runtime.load took {load_s:.2f}s")
    print("\nRunning...")
    t_run = time.perf_counter()
    runtime.run()

    # Host I/O is decoupled from the on-chip pipeline.
    #   * X[0] (the pre-embedded hidden vector for the seed token_ids) is sent
    #     ONCE before the receive loop. demux propagates X[0] into HT_head's
    #     diag PE on step 0, then goes idle for the rest of decoding.
    #   * Steps 1..MAX_OUTPUT_LEN-1 are pure on-chip autoregressive: HT_tail's
    #     sampled-token emit → tok_bcast_color → HT_head north-bound drain → embedding
    #     lookup, no host involvement. So the host only RECEIVES the per-step
    #     top-K token record from the mux, which drains at host speed without
    #     back-pressuring HT_tail.
    per_pe_step_dim = bsz * dim_per_pe_lane
    # Must match device W_E generation (seed 2024, draw true then zero-pad). The
    # seed token embeddings carry zero in the padded dim cols [dim_true:].
    W_E_full = _zpad(
        (np.random.RandomState(2024).rand(vocab_true, dim_true) * WEIGHT_SCALE).astype(ml_dtypes.bfloat16),
        (vocab_size, dim))
    token_ids = cfg["token_ids"]
    assert len(token_ids) == bsz, (
        f"cfg['token_ids'] length {len(token_ids)} != bsz {bsz}"
    )
    host_x_f16 = np.stack([W_E_full[t] for t in token_ids], axis=0).astype(ml_dtypes.bfloat16)
    x_per_col = host_x_f16.reshape(bsz, P_BLOCK_SIZE, dim_per_pe_lane).transpose(1, 0, 2)
    x_step_buf_u32 = (
        x_per_col.reshape(P_BLOCK_SIZE * per_pe_step_dim)
                 .astype(ml_dtypes.bfloat16)
                 .view(np.uint16)
                 .view(np.uint32)
                 .copy()
    )
    assert x_step_buf_u32.shape == (per_step_x_wavelets,), (
        f"x_step_buf shape {x_step_buf_u32.shape} != ({per_step_x_wavelets},)"
    )

    # KV ingress FIRST: block PEs run a synchronous kv_ingress at startup and
    # backpressure until the feeder demux delivers the prefill prefix. Stream the
    # whole prefix once, before the X[0] seed.
    def _repack_kv_band(inj_xk, inj_xv, band, n_abs, decode_len):
        # Flatten one band's KV cache into its per-band injector host stream order.
        # Row-outer (ly = injector PE, NORTH->SOUTH), then within a row-slice the
        # west-shift order — PHASE 0 metas then per (layer,K|V) the P ATTN tiles
        # WEST->EAST, so the east-most block column (shift entry) keeps the LAST tile
        # (its own) and forwards the rest west:
        #   row ly = 0..P_BLOCK_SIZE-1 (injector PE ly)
        #     PHASE 0: P metainfo tiles (one per ATTN column, W->E).
        #              meta[0] is ALSO peeled by the adaptor/injector, which read its
        #              HIGH half (plen) for the runtime
        #              segment count (n_segs_rt = D_kv * plen), then re-emitted.
        #       layer l = 0..max_layers_per_block-1
        #       phase K then V                          (kv_ingress phase order)
        #         column c = 0..P-1 (WEST->EAST)
        #           KV tile = bsz*kv_cols*plen fp16 (VARLEN — no MAX pad).
        # K tile order [b][f][p]; V tile order [b][p][f]. fp16 packed 2-per-u32.
        kc   = kv_cols
        n    = n_abs
        plen = -(-n // H_ROWS)                     # ceil: actual prefill rows per PE
        sq   = kv_len_per_pe
        mlpb = max_layers_per_block
        k_per_pe   = mlpb * bsz * kc * sq         # XKCache/XVCache per-PE width
        layer_span = bsz * kc * sq               # one layer's slab (K and V same size)
        # Phase-0 metainfo tile (one u32): [decode_len, plen], low then high i16.
        #
        # Both slots are load-bearing and they are read by DIFFERENT consumers:
        #   slot 0 = decode_len — per-round generation budget read by block PEs.
        #   slot 1 = plen — per-PE prefill ROW count = ceil(n / P_BLOCK_SIZE). Read by
        #                   the two relay stages that size their segment counts,
        #                   kv_ingress_adaptor.csl and kv_ingress_injector.csl
        #                   (n_segs_rt = D_kv * plen).
        meta_tile = np.array([decode_len, plen], dtype=np.int16).view(np.uint16)
        tiles = []
        for ly in range(H_ROWS):                 # injector PE (NORTH->SOUTH)
            for _c in range(P_BLOCK_SIZE):
                tiles.append(meta_tile)
            for l in range(mlpb):
                for is_k in (True, False):
                    src = inj_xk if is_k else inj_xv
                    for c in range(P_BLOCK_SIZE):
                        l_off = c * k_per_pe + l * layer_span
                        seg = src[band, ly, l_off:l_off + layer_span]
                        if is_k:
                            t  = seg.reshape(bsz, kc, sq)[:, :, :plen]      # [b][f][:plen] (varlen, no pad)
                        else:
                            t  = seg.reshape(bsz, sq, kc)[:, :plen, :]      # [b][:plen][f] (varlen, no pad)
                        tiles.append(np.ascontiguousarray(t).reshape(-1))
        return np.concatenate(tiles).astype(np.uint16).view(np.uint32)

    # Serve num_rounds decode rounds from one run(): each round streams a fresh KV +
    # X[0]; the host serializes rounds (drains a round's N tokens + TSC before the next
    # send), so the device is re-armed by send-time (backpressure covers residual skew).
    # Per-round prefill values are runtime request data.
    for _pl in prefill_lens:
        assert _pl % H_ROWS == 0 and 1 <= _pl // H_ROWS <= prefill_max_per_pe, (
            f"per-round prefill {_pl} must be a P_BLOCK_SIZE multiple in "
            f"[{P_BLOCK_SIZE}, {prefill_max_per_pe * P_BLOCK_SIZE}]")

    val_wavelets = (top_k * bsz + val_pad) // 2  # u32 words holding packed f16 values (odd rounds up)
    arg_wavelets = top_k * bsz                   # u32 words holding the i32 indices
    HOST_STOP_TOK = -2  # HT_tail emits this for every lane once finished, then halts.
    # Per-request host-stage timing, accumulated across rounds (stage order). Means are
    # reported in the summary table after the round loop. recv_first = pipeline-fill wait
    # (KV ingress + prefill compute + first decode token) isolated from recv_steady (the
    # per-token generation-gated wait — this is what should track the device TSC).
    _stg = {"kv_repack": 0.0, "kv_send": 0.0, "x_send": 0.0,
            "recv_first": 0.0, "recv_steady": 0.0, "hostproc": 0.0, "tsc_drain": 0.0}
    _stg_tok = 0                    # total generated tokens across rounds (per-token means)
    _stg_steady_tok = 0            # tokens counted in recv_steady (excludes each round's first)
    per_round_sampled = []          # sampled-token sequences, one per round (re-arm check)
    per_round_topk_args = []        # per-round top-K indices  (re-arm: model output vs draw)
    per_round_topk_vals = []        # per-round top-K logits   (re-arm: model output vs draw)
    per_round_prof = {}             # per-round raw block-TSC bursts, keyed by role
    round_summary = []              # per-round {round,prefill,N,generated} for the durable verdict file
    rearm_results = []              # per-round (rnd, prefill, bit_identical) for the durable verdict file
    # Round 0's full results feed the existing oracle / merge-reduce checks below.
    topk_vals = topk_args = sampled_tokens = None
    n_generated = None
    tsc_ngen = None            # generated-token count of the round the TSC burst measured
    last_plen_per_pe = prefill_len_per_pe   # the LAST round's prefill (KV-SEED reads post-stop)

    for rnd in range(num_rounds):
        pl = prefill_lens[rnd]
        pl_per_pe = pl // H_ROWS
        n_rnd = decode_lens[rnd]
        last_plen_per_pe = pl_per_pe
        # NS per-band KV blobs: build (numpy repack) then send in parallel (nonblock)
        # -> ~NS x aggregate ingress BW. Split for stage timing (repack = host CPU tiling,
        # send = H2D stream enqueue).
        _t = time.perf_counter()
        _kv_bands = {}
        for _bi, _by in enumerate(kv_rows):
            kv_band = _repack_kv_band(
                inj_xk, inj_xv, _bi, n_abs=pl, decode_len=n_rnd)
            _row_u32 = P_BLOCK_SIZE + C_kv * pl_per_pe
            assert kv_band.size == H_ROWS * _row_u32, (
                f"per-band[{_by}] kv_stream {kv_band.size} != {H_ROWS * _row_u32} "
                f"(H={H_ROWS} + C_kv={C_kv}*plen={pl_per_pe})")
            _kv_bands[_by] = kv_band
        _stg["kv_repack"] += time.perf_counter() - _t
        _t = time.perf_counter()
        for _by in kv_rows:
            runtime.send(kv_ingress_streams[_by], _kv_bands[_by], nonblock=True)
        _stg["kv_send"] += time.perf_counter() - _t
        # X[0] seed (blocking so the seed is queued before the receive loop).
        _t = time.perf_counter()
        runtime.send(x_stream, x_step_buf_u32, nonblock=False)
        _stg["x_send"] += time.perf_counter() - _t
        # Flushed progress marker: survives a tee-buffered timeout kill so a stall
        # in KV-ingress (no logits ever emitted) is distinguishable from slow-but-
        # progressing decode. (flush=True bypasses tee's 4 KB pipe buffer.)
        print(f"  [round {rnd}] KV({P_Y_BLOCK_NUM} bands)+X sent; awaiting {n_rnd} logit steps...",
              flush=True)
        if int(os.environ.get("DIAG_NO_RECV", "0")):
            # Wedge-frontier probe (sim only): let the fabric run, then read
            # progress state from every stage instead of receiving records —
            # the host never blocks on a recv, so read_symbol works.
            time.sleep(float(os.environ.get("DIAG_NO_RECV_SLEEP", "20")))
            try:
                runtime.stop()
                print("  [DIAG_NO_RECV] runtime stopped for post-mortem reads", flush=True)
            except Exception as _e:
                print(f"  [DIAG_NO_RECV] stop failed: {_e}", flush=True)
            print("  [DIAG_NO_RECV] wedge frontier (step_bank[0] / iter_num_bank[0] at probe PEs):", flush=True)
            for _ry in range(P_Y_BLOCK_NUM):
                _abx = 0 if _ry % 2 == 0 else 1
                _fbx = 1 - _abx
                for _lbl, _bx in (("attn", _abx), ("ffn", _fbx)):
                    for _lx, _ly in ((0, 0), (P_BLOCK_SIZE - 1, 0), (root_2nd_phase, 0), (0, H_ROWS - 1)):
                        try:
                            _sb = np.asarray(runtime.read_symbol(
                                PLACE_X + _bx * P_BLOCK_SIZE + _lx, PLACE_Y + _ry * P_BLOCK_SIZE + _ly,
                                "step_bank", dtype="int16"))
                            _ib = np.asarray(runtime.read_symbol(
                                PLACE_X + _bx * P_BLOCK_SIZE + _lx, PLACE_Y + _ry * P_BLOCK_SIZE + _ly,
                                "iter_num_bank", dtype="int16"))
                            print(f"    r{_ry}-{_lbl} ({_lx},{_ly}): step={_sb[:1].tolist()} iter={_ib[:1].tolist()}", flush=True)
                        except Exception as _e:
                            print(f"    r{_ry}-{_lbl} ({_lx},{_ly}): <{_e}>", flush=True)
            # Strip progress: strip_iter on the east strips (sender r0 / receiver r1).
            _strip_x = PLACE_X + 2 * P_BLOCK_SIZE   # east strip column
            for _ry in range(P_Y_BLOCK_NUM):
                for _ly in (0, 1, 2, H_ROWS - 1, H_ROWS, P_BLOCK_SIZE - 1):
                    try:
                        _si = np.asarray(runtime.read_symbol(
                            _strip_x, PLACE_Y + _ry * P_BLOCK_SIZE + _ly,
                            "strip_iter", dtype="int16"))
                        print(f"    e-strip r{_ry} ly={_ly}: strip_iter={_si[:1].tolist()}", flush=True)
                    except Exception as _e:
                        print(f"    e-strip r{_ry} ly={_ly}: <{str(_e)[:60]}>", flush=True)
            # FFN progress: result_hdr_buf (set when ffn_main receives the A
            # header) and Z content; r1-attn X_tile content.
            for _ry in range(P_Y_BLOCK_NUM):
                _abx = 0 if _ry % 2 == 0 else 1
                _fbx = 1 - _abx
                for _lx in (0, P_BLOCK_SIZE - 1):
                    try:
                        _h = np.asarray(runtime.read_symbol(
                            PLACE_X + _fbx * P_BLOCK_SIZE + _lx, PLACE_Y + _ry * P_BLOCK_SIZE,
                            "dbg_ffn_steps", dtype="int32"))
                        print(f"    r{_ry}-ffn lx={_lx}: ffn_steps={_h[:1].tolist()}", flush=True)
                    except Exception as _e:
                        print(f"    r{_ry}-ffn lx={_lx}: <{str(_e)[:50]}>", flush=True)
                try:
                    _x = np.asarray(runtime.read_symbol(
                        PLACE_X + _abx * P_BLOCK_SIZE, PLACE_Y + _ry * P_BLOCK_SIZE,
                        "dbg_attn_recv", dtype="int32"))
                    print(f"    r{_ry}-attn (0,0): attn_recv={_x[:1].tolist()}", flush=True)
                except Exception as _e:
                    print(f"    r{_ry}-attn recv: <{str(_e)[:50]}>", flush=True)
            print("  [DIAG_NO_RECV] done; exiting.", flush=True)
            return {"compile_s": compile_s, "run_s": 0.0, "aligned": None}

        # Receive-only decode loop. Each step emits south_wavelets_per_step u32:
        # TOP_K*bsz/2 u32 packed-f16 VALUES, TOP_K*bsz u32 i32 INDICES, bsz u32 i32
        # SAMPLED ids (round-outer/batch-inner: slot r*bsz+b = r-th-largest of batch b).
        # +1 slot: the first STOP token lands at index p (p==n_rnd in the budget path).
        r_topk_vals = np.empty((n_rnd + 1, bsz, top_k), dtype=ml_dtypes.bfloat16)
        r_topk_args = np.empty((n_rnd + 1, bsz, top_k), dtype=np.int32)
        r_sampled   = np.empty((n_rnd + 1, bsz), dtype=np.int32)
        r_ngen = n_rnd
        # Production forced prefill: the tail emits only the final step's record
        # (the mux was told "1" by the south header); the TSC still spans the
        # whole budget of steps.
        n_recv = 1 if forced_production_flag else n_rnd

        def _parse_token(_b, _s):
            r_topk_vals[_s] = _b[:val_wavelets].view(np.uint16)[:top_k * bsz].view(ml_dtypes.bfloat16).reshape(top_k, bsz).T
            r_topk_args[_s] = _b[val_wavelets:val_wavelets + arg_wavelets].view(np.int32).reshape(top_k, bsz).T
            r_sampled[_s] = _b[val_wavelets + arg_wavelets:val_wavelets + arg_wavelets + bsz].view(np.int32)

        # Bring-up diagnostics: on a cut-chain sim stall, read the per-stage
        # progress markers post-mortem instead of dying uselessly.
        _dbg_cut = CHAIN is not None and cmaddr is None and os.environ.get("DBG_CUT") == "1"
        # Receive-only decode loop. Timing separates the first receive (KV ingress,
        # prefill, and pipeline fill) from steady-state token receives. Only the receive
        # call is timed per step; parsing and loop overhead remain in the wall residual.
        _t_dec = time.perf_counter()
        _recv_first = 0.0                      # first receive of the round (pipeline fill)
        _recv_steady = 0.0                     # sum of the remaining per-token receives
        for s in range(n_recv):
            buf = np.empty(south_wavelets_per_step, dtype=np.uint32)
            _tr = time.perf_counter()
            try:
                runtime.receive(logits_stream, buf, south_wavelets_per_step, nonblock=False)
            except Exception as _e:
                if not _dbg_cut:
                    raise
                print(f"  [DBG_CUT] stall at record {s}: {_e}", flush=True)
                for _ry in range(P_Y_BLOCK_NUM):
                    for _bx, _tag in ((0, 'west'), (1, 'east')):
                        _vals = []
                        for _py in (0, P_BLOCK_SIZE - 1):
                            for _px in (0, P_BLOCK_SIZE - 1):
                                try:
                                    _v = np.asarray(runtime.read_symbol(
                                        PLACE_X + _bx * P_BLOCK_SIZE + _px,
                                        PLACE_Y + _ry * P_BLOCK_SIZE + _py,
                                        "dbg_stage", dtype="int32"))
                                    _vals.append(int(_v.ravel()[0]))
                                except Exception as _e2:
                                    _vals.append(None)
                        print(f"    [DBG_CUT] r{_ry}-{_tag} dbg_stage corners: {_vals}", flush=True)
                raise
            _dt = time.perf_counter() - _tr
            if s == 0:
                _recv_first = _dt
            else:
                _recv_steady += _dt
            if s % 256 == 0 or int(os.environ.get("DBG_STEP_PRINT", "0")) != 0:
                print(f"    [round {rnd}] step {s}/{n_recv} logits received (recv {_dt*1e6:.0f}us)", flush=True)
            _parse_token(buf, s)
            if bool(np.all(r_sampled[s] == HOST_STOP_TOK)):
                r_ngen = s + 1
                break
        if forced_production_flag:
            # One record received; the device processed the full budget.
            r_ngen = 1
        _decode_wall_s = time.perf_counter() - _t_dec
        _recv_tot   = _recv_first + _recv_steady
        _hostproc_s = _decode_wall_s - _recv_tot       # host loop + parse (residual, untimed)
        _steady_us  = _recv_steady / max(r_ngen - 1, 1) * 1e6
        # Accumulate per-request stage timing (means reported in the summary table below).
        _stg["recv_first"]  += _recv_first
        _stg["recv_steady"] += _recv_steady
        _stg["hostproc"]    += _hostproc_s
        _stg_tok        += r_ngen
        _stg_steady_tok += max(r_ngen - 1, 0)
        print(f"    [round {rnd}] decode wall {_decode_wall_s:.4f}s ({r_ngen} tok) | "
              f"recv_first={_recv_first * 1e6:.0f}us | recv_steady={_steady_us:.1f}us/tok | "
              f"host-proc={_hostproc_s / max(r_ngen, 1) * 1e6:.1f}us/tok", flush=True)
        # Benchmark TSC: one 8-u32 burst piggybacks the logits stream after this
        # round's tokens (the mux forwards it). Drain it before the next round.
        tsc_burst = np.empty(8, dtype=np.uint32)
        _t = time.perf_counter()
        runtime.receive(logits_stream, tsc_burst, 8, nonblock=False)
        _stg["tsc_drain"] += time.perf_counter() - _t
        # Per-block TSC profile: one burst per profiled block, emitted after that
        # block's step loop exits. Drain both before the next round re-arms.
        if PROF:
            _t = time.perf_counter()
            for _name, _stream in (("attn", prof_stream_attn), ("ffn", prof_stream_ffn)):
                _buf = np.empty(prof_words, dtype=np.uint32)
                runtime.receive(_stream, _buf, prof_words, nonblock=False)
                per_round_prof.setdefault(_name, []).append(_buf.copy())
            _stg["prof_drain"] = _stg.get("prof_drain", 0.0) + (time.perf_counter() - _t)
            print(f"    [round {rnd}] prof drained 2 x {prof_words} u32", flush=True)
        # This round's TSC-counted tokens; last round wins (matches tsc_burst).
        # In production the device timed the whole budget though only 1 record came south.
        tsc_ngen = n_rnd if forced_production_flag else r_ngen
        per_round_sampled.append(r_sampled[:r_ngen].copy())
        # Keep the per-round LOGITS evidence too, not just the sampled ids. A re-arm
        # mismatch on `sampled` alone cannot say whether the model output changed or
        # only the categorical draw landed elsewhere — top-K args/vals separate them.
        per_round_topk_args.append(r_topk_args[:r_ngen].copy())
        per_round_topk_vals.append(r_topk_vals[:r_ngen].copy())
        round_summary.append({
            "round": rnd,
            "prefill": int(pl),
            "decode_budget": int(n_rnd),
            "generated": int(r_ngen),
        })
        print(f"  [round {rnd}] prefill={pl} N={n_rnd}: generated {r_ngen} steps "
              f"(top-{top_k} + sampled: {south_wavelets_per_step} u32/step)", flush=True)
        # Compact sequence sample for re-arm and sampling diagnostics.
        _ids = r_sampled[:min(r_ngen, 12), 0].tolist()
        print(f"  [sampled] round {rnd} ids[:12]={_ids}", flush=True)
        if rnd == 0:
            topk_vals, topk_args, sampled_tokens, n_generated = (
                r_topk_vals, r_topk_args, r_sampled, r_ngen)
            max_output_len = n_rnd   # downstream oracle/checks use round 0's budget

    # Repeated request shapes must be bit-identical after re-arm. Compare logits,
    # top-k ordering, and sampled IDs so state drift cannot hide behind the same
    # categorical draw.
    # Each mismatch is localized three ways so the next step is not a guess:
    #   topk_vals differ  -> the model's own output changed (real state carry-over)
    #   only args differ  -> equal logits, different order (tie-break / reduce order)
    #   only sampled      -> identical logits, the categorical draw landed elsewhere
    #                        (sampling PRNG re-seed, NOT the decode path)
    def _first_diff_step(a, b):
        """First leading-axis index where a and b differ bitwise, else None."""
        if a.shape != b.shape:
            return -1
        d = np.nonzero(np.any((a.reshape(a.shape[0], -1)
                               != b.reshape(b.shape[0], -1)), axis=1))[0]
        return int(d[0]) if d.size else None

    first_round_by_shape = {}
    for rnd, (pl, dl) in enumerate(zip(prefill_lens, decode_lens)):
        shape = (pl, dl)
        if shape not in first_round_by_shape:
            first_round_by_shape[shape] = rnd
            continue
        baseline = first_round_by_shape[shape]
        _s_val = _first_diff_step(
            per_round_topk_vals[rnd].view(np.uint16),
            per_round_topk_vals[baseline].view(np.uint16),
        )
        _s_arg = _first_diff_step(
            per_round_topk_args[rnd], per_round_topk_args[baseline])
        _s_sam = _first_diff_step(
            per_round_sampled[rnd], per_round_sampled[baseline])
        same = (_s_val is None) and (_s_arg is None) and (_s_sam is None)
        rearm_results.append({
            "round": rnd,
            "baseline_round": baseline,
            "prefill": int(pl),
            "decode_budget": int(dl),
            "bit_identical": same,
            "first_diff_topk_vals": _s_val,
            "first_diff_topk_args": _s_arg,
            "first_diff_sampled": _s_sam,
        })
        print(f"  [re-arm] round {rnd} vs round {baseline} "
              f"(prefill={pl}, decode={dl}): "
              f"{'BIT-IDENTICAL ✓' if same else 'MISMATCH ✗'}", flush=True)
        if not same:
            print(f"    first-diff step: topk_vals={_s_val} topk_args={_s_arg} "
                  f"sampled={_s_sam}", flush=True)
    for _r in rearm_results:
        assert _r["bit_identical"], (
            f"re-arm round {_r['round']} diverged from round "
            f"{_r['baseline_round']} — stale state across re-arm")

    _stop_active_runtime()
    run_s = time.perf_counter() - t_run
    print(f"  generated_topk.shape = {topk_args[:n_generated].shape}")
    print(f"  run took {run_s:.1f}s")

    # ---------------- Host wall-clock stage timing (stage order) ----------------
    # One-time cost (build/compile/load, amortized over all requests) + per-request
    # means. recv_steady is the per-token generation-gated host wait — the metric
    # that should track the device TSC (compared head-to-head in the TSC block below).
    # Everything else (KV/X send, TSC drain, parse) is per-request setup/teardown that
    # overlaps or bounds generation, not per-token cost.
    _nr = max(num_rounds, 1)
    host_timing = {
        "host_build_s": round(host_build_s, 4),   # Phase 1..4: sizing + regions + weight bake
        "compile_s":    round(compile_s, 3),      # layout.compile (cslc)
        "load_s":       round(load_s, 4),         # runtime.load (program+weights -> wafer)
        "per_round_kv_repack_ms": round(_stg["kv_repack"] / _nr * 1e3, 3),
        "per_round_kv_send_ms":   round(_stg["kv_send"]   / _nr * 1e3, 3),
        "per_round_x_send_ms":    round(_stg["x_send"]    / _nr * 1e3, 3),
        "per_round_recv_first_ms": round(_stg["recv_first"] / _nr * 1e3, 3),
        "per_round_tsc_drain_us":  round(_stg["tsc_drain"]  / _nr * 1e6, 1),
        "per_token_recv_steady_us": round(_stg["recv_steady"] / max(_stg_steady_tok, 1) * 1e6, 1),
        "per_token_host_proc_us":   round(_stg["hostproc"]    / max(_stg_tok, 1)        * 1e6, 1),
        "tokens": int(_stg_tok),
    }
    print(f"\n{'=' * 62}")
    print(f"  qwen3_4b {Path(artifact_dir).name}  host wall-clock (stage order)")
    print(f"{'=' * 62}")
    print(f"  [one-time]")
    print(f"{'    host build (sizing/regions/weight bake):':<46}{host_build_s:8.2f} s")
    print(f"{'    compile (layout.compile):':<46}{compile_s:8.2f} s")
    print(f"{'    runtime load:':<46}{load_s:8.2f} s")
    print(f"  [per-request mean over {num_rounds} round(s), {_stg_tok} tok total]")
    print(f"{'    KV repack (numpy tiling):':<46}{_stg['kv_repack'] / _nr * 1e3:8.3f} ms")
    print(f"{'    KV send (NS bands, H2D):':<46}{_stg['kv_send'] / _nr * 1e3:8.3f} ms")
    print(f"{'    X[0] seed send (H2D):':<46}{_stg['x_send'] / _nr * 1e3:8.3f} ms")
    print(f"{'    recv first token (pipeline fill):':<46}{_stg['recv_first'] / _nr * 1e3:8.3f} ms")
    print(f"{'    recv steady (per-token gen-gated):':<46}{host_timing['per_token_recv_steady_us']:8.1f} us/tok")
    print(f"{'    host proc (parse+loop residual):':<46}{host_timing['per_token_host_proc_us']:8.1f} us/tok")
    print(f"{'    TSC drain:':<46}{_stg['tsc_drain'] / _nr * 1e6:8.1f} us")
    print(f"{'=' * 62}")

    # In-launcher check verdict sink (K2) -- see make_verdict_sink() above.
    record_verdict, _finalize_checks, _verdict_records = make_verdict_sink()

    # KV-seed bit-exact check (sim only, POST-stop — read_symbol requires a
    # stopped sim): the un-mutated prefill prefix of the decode-seeded XKCache/
    # XVCache must equal the host KV (decode never writes cache cols [:plen]).
    # Directly confirms the runtime stream delivered the cache bit-exactly.
    # O(P^2) read_symbol -> small grids only; device has no read_symbol.
    #
    # K4 (2026-09-09): this used to unconditionally skip whenever CHAIN is not
    # None ("stage-cut geometry") -- i.e. NEVER ran on layout C, the cut
    # geometry this whole effort exists to build. See
    # scripts/test_kv_seed_check.py's docstring for the full defect writeup.
    # Cut mode differs from vanilla in exactly two ways, both handled below:
    #   1. only `kv_rows` (not every row) owns a cache at all -- a row absent
    #      from kv_rows never ran kv_ingress, and CHAIN(row, role) may not
    #      even have an entry for a stage_kind that doesn't need one.
    #   2. the KV-owning role for a given row is a CHAIN fact, not a row-parity
    #      assumption -- see kv_seed_cut_owner_bx's docstring for why the
    #      parity shortcut is not safe to keep implicit even though it
    #      happens to agree with CHAIN for every config shipped today.
    # inj_xk/inj_xv's own row-axis is compacted to kv_rows (kv_seed_cut_inj_index's
    # docstring), which is the second, independent place a raw `by` index would
    # silently read the wrong row's host-seeded reference.
    def _kv_seed_check(rt, plen):
        P = P_BLOCK_SIZE
        if P * P * P_Y_BLOCK_NUM > 4096:
            detail = f"grid too large for O(P^2) read_symbol (P={P}, P_Y_BLOCK_NUM={P_Y_BLOCK_NUM})"
            print(f"  [decode] KV-seed check skipped ({detail})")
            record_verdict("KV-SEED", None, detail)
            return
        mode = "cut" if CHAIN is not None else "vanilla"
        if CHAIN is not None and not kv_rows:
            detail = f"no KV-owning row in this CHAIN (mode={mode}, kv_rows=[])"
            print(f"  [decode] KV-seed check skipped ({detail})")
            record_verdict("KV-SEED", None, detail)
            return
        # Bit-exact: the un-mutated prefill prefix [:plen] of the streamed cache == host KV.
        if CHAIN is None:
            # Vanilla: every row owns KV, always on the row-parity "attn slot".
            owners = [(by, 0 if by % 2 == 0 else 1, by) for by in range(P_Y_BLOCK_NUM)]
        else:
            _inj_idx = kv_seed_cut_inj_index(kv_rows)
            owners = [(by, kv_seed_cut_owner_bx(by, CHAIN, P), _inj_idx[by])
                      for by in kv_rows]
        kc, sq, mlpb = kv_cols, kv_len_per_pe, max_layers_per_block
        slab = bsz * kc * sq
        # TEST-ONLY fault injection for the K4 seeded-defect demonstration
        # (see scripts/test_kv_seed_check.py): _TEST_FORCE_KV_SEED_FAIL below
        # only proves the verdict-sink wiring (a flat count bump); this
        # exercises the REAL per-row/per-tile np.array_equal path -- and this
        # fix's owners/inj_row indexing specifically -- by corrupting exactly
        # one tile of the HOST reference for one named KV-owning row (`by`,
        # mapped through the same kv_seed_cut_inj_index the real comparison
        # loop uses) before the comparison runs. Off by default (env var
        # unset -> _corrupt_xk/_corrupt_xv alias the real arrays, no copy).
        _corrupt_row_env = os.environ.get("_TEST_FORCE_KV_SEED_CORRUPT_ROW")
        _corrupt_xk, _corrupt_xv = inj_xk, inj_xv
        if _corrupt_row_env is not None:
            _crow = int(_corrupt_row_env)
            _cidx_map = {by: inj_row for by, _bx, inj_row in owners}
            assert _crow in _cidx_map, (
                f"_TEST_FORCE_KV_SEED_CORRUPT_ROW={_crow} is not a KV-owning row "
                f"this check examines (rows={[o[0] for o in owners]})")
            _cri = _cidx_map[_crow]
            _corrupt_xk = inj_xk.copy()
            _corrupt_xk[_cri, 0, 0] ^= np.uint16(0xFFFF)
            print(f"  [decode] KV-SEED TEST-ONLY: corrupting host reference tile "
                  f"row={_crow} (inj index {_cri}) ly=0 lx=0 layer=0", flush=True)
        bad = 0
        # Print budgets are PER (kind, row), not one shared cap. A shared cap is
        # not a display nicety -- on sim_cut2 (two chained cut layers) row 1's K
        # failures exhausted a single `bad <= 8` budget before any V detail was
        # printed, so the ~16 non-K bad tiles in that config could not be seen at
        # all from the debug output. The instrument was hiding the one symptom
        # that distinguished cut2 from cut3/cut6.
        _dbg = int(os.environ.get("_DEBUG_KV_SEED", "0"))
        _dbg_seen = {}          # (kind, by) -> count printed
        _DBG_PER = 4            # per kind, per row

        def _dbg_ok(kind, by):
            if not _dbg:
                return False
            n = _dbg_seen.get((kind, by), 0)
            if n >= _DBG_PER:
                return False
            _dbg_seen[(kind, by)] = n + 1
            return True

        for by, attn_bx, inj_row in owners:
            for ly in range(H_ROWS):
                for lx in range(P_BLOCK_SIZE):
                    gk = np.asarray(rt.read_symbol(
                        PLACE_X + attn_bx * P + lx, PLACE_Y + by * P + ly,
                        "XKCache_tile", dtype="uint16"))
                    gv = np.asarray(rt.read_symbol(
                        PLACE_X + attn_bx * P + lx, PLACE_Y + by * P + ly,
                        "XVCache_tile", dtype="uint16"))
                    base = lx * mlpb * slab
                    for l in range(mlpb):
                        off = base + l * slab
                        ek = _corrupt_xk[inj_row, ly, off:off + slab].reshape(bsz, kc, sq)[:, :, :plen]
                        ev = _corrupt_xv[inj_row, ly, off:off + slab].reshape(bsz, sq, kc)[:, :plen, :]
                        gk_l = gk[l * slab:(l + 1) * slab].reshape(bsz, kc, sq)[:, :, :plen]
                        gv_l = gv[l * slab:(l + 1) * slab].reshape(bsz, sq, kc)[:, :plen, :]
                        if not np.array_equal(ek, gk_l):
                            bad += 1
                            if _dbg_ok("K", by):
                                print(f"    [K MISMATCH DEBUG] by={by} ly={ly} lx={lx} l={l} "
                                      f"ek={ek.ravel().tolist()} gk_l={gk_l.ravel().tolist()}")
                                # The prefix slice [:plen] CANNOT distinguish "written one
                                # position late" (data present at plen..) from "never written"
                                # (all zero everywhere). At plen=1 those are identical from
                                # the prefix alone, and reporting the first as though it were
                                # established sends the investigation at index arithmetic
                                # when the bug may be a dead ingress. So dump the FULL seq
                                # extent of channel 0 and say where the expected value is,
                                # if it is anywhere at all.
                                _gk_full = gk[l * slab:(l + 1) * slab].reshape(bsz, kc, sq)
                                _want = ek.ravel()[0]
                                _hits = np.argwhere(_gk_full == _want)
                                print(f"      [K WHERE] full seq (b=0,c=0) = "
                                      f"{_gk_full[0, 0, :].tolist()}")
                                print(f"      [K WHERE] nonzero anywhere in slab = "
                                      f"{int(np.count_nonzero(_gk_full))}/{_gk_full.size}; "
                                      f"expected head value {int(_want)} found at "
                                      f"{[tuple(int(x) for x in h) for h in _hits[:4]]}"
                                      f"{' (NOWHERE -> not an off-by-one)' if len(_hits) == 0 else ''}")
                        if not np.array_equal(ev, gv_l):
                            bad += 1
                            if _dbg_ok("V", by):
                                print(f"    [V MISMATCH DEBUG] by={by} ly={ly} lx={lx} l={l} "
                                      f"ev={ev.ravel().tolist()} gv_l={gv_l.ravel().tolist()}")
                                _gv_full = gv[l * slab:(l + 1) * slab].reshape(bsz, sq, kc)
                                _wantv = ev.ravel()[0]
                                _hitsv = np.argwhere(_gv_full == _wantv)
                                print(f"      [V WHERE] full seq (b=0,c=0) = "
                                      f"{_gv_full[0, :, 0].tolist()}")
                                print(f"      [V WHERE] nonzero anywhere in slab = "
                                      f"{int(np.count_nonzero(_gv_full))}/{_gv_full.size}; "
                                      f"expected head value {int(_wantv)} found at "
                                      f"{[tuple(int(x) for x in h) for h in _hitsv[:4]]}"
                                      f"{' (NOWHERE)' if len(_hitsv) == 0 else ''}")
        # TEST-ONLY fault injection for the K2 seeded-defect demonstration (see
        # scripts/test_verdict_sink.py's docstring): off by default (adds 0),
        # so this does not change what the check computes on a real defect.
        bad += int(os.environ.get("_TEST_FORCE_KV_SEED_FAIL", "0"))
        _rows_checked = [o[0] for o in owners]
        print(f"  [decode] KV-SEED {'PASS' if bad == 0 else f'FAIL ({bad} tiles)'} "
              f"(prefill_len_per_pe={plen}, mode={mode}, rows={_rows_checked}): "
              f"streamed cache prefix == host KV (bit-exact)", flush=True)
        record_verdict("KV-SEED", bad == 0,
                        f"prefill_len_per_pe={plen}, {bad} bad tile(s), "
                        f"mode={mode}, rows={_rows_checked}")

    if cmaddr is None and not (ROUTE_TABLE and ROUTE_CHECK):
        record_verdict("ROUTE-CHECK", None,
                        f"not enabled (ROUTE_TABLE={ROUTE_TABLE}, ROUTE_CHECK={ROUTE_CHECK}; "
                        f"set ROUTE_TABLE=1 ROUTE_CHECK=1 to run)")
    elif cmaddr is None and ROUTE_TABLE and ROUTE_CHECK:
        _bad = 0; _first = None
        for by in range(P_Y_BLOCK_NUM):
            for bx in range(2):
                for ly in range(P_BLOCK_SIZE):
                    for lx in range(P_BLOCK_SIZE):
                        mm = np.asarray(runtime.read_symbol(PLACE_X + bx * P_BLOCK_SIZE + lx,
                                                            PLACE_Y + by * P_BLOCK_SIZE + ly,
                                                            "route_mismatch", dtype="int16"))
                        if int(mm[0]) != 0:
                            _bad += 1
                            if _first is None: _first = (by, bx, lx, ly, int(mm[0]), int(mm[1]))
        # TEST-ONLY fault injection, see the KV-SEED comment above.
        _bad += int(os.environ.get("_TEST_FORCE_ROUTE_CHECK_FAIL", "0"))
        print(f"  [route_table] ROUTE-CHECK {'PASS' if _bad == 0 else 'FAIL'}: "
              f"{_bad} PEs disagree with the host table; first={_first}", flush=True)
        record_verdict("ROUTE-CHECK", _bad == 0, f"{_bad} PE(s) disagree with host table; first={_first}")
    if cmaddr is None:
        # read_symbol is post-stop, so the on-chip cache holds the LAST round's KV
        # (after its ingress) — check against that round's prefill.
        _kv_seed_check(runtime, last_plen_per_pe)

    # --- QKV column-sharding check (sim only, POST-stop; QKV_COL_CHECK=1) ----
    # Q/K/V are X-sharded — `attn_per_pe`/`kv_cols` divide by P_BLOCK_SIZE
    # (:492-493) — while the hidden state is Y-sharded, `dim_per_pe = dim //
    # H_ROWS` (:358). So every COLUMN must hold a DIFFERENT K. A build that moves
    # the QKV record along X (one-column send + X-broadcast) would give every
    # column the source column's K, and this check names it.
    #
    # The run carries its own control: the prefill prefix [:plen] is seeded
    # per-column by the host (see `_kv_seed_check`'s `base = lx * mlpb * slab`),
    # so it MUST come back distinct across columns. The decode-written suffix
    # [plen:] is the thing under test. Prefix distinct + suffix identical is the
    # defect; both distinct is healthy; prefix identical means the instrument is
    # blind and the result says nothing.
    #
    # K3 (2026-09-09): the original version sampled rows (0, min(1, H_ROWS-1))
    # only, read layer bank 0 only, and accepted ANY npost != 1 as "healthy"
    # (2/128 distinct columns passed) -- all three verified blind on seeded
    # defects the original checker missed, see scripts/test_qkv_col_check.py.
    # Row coverage now matches KV-SEED's full-H_ROWS sweep (qkv_col_sample_rows,
    # plus idle rows which must read back inert), so this reuses KV-SEED's
    # exact P*P*P_Y_BLOCK_NUM grid-size guard rather than inventing a new one:
    # at equal grid size this check does strictly less read_symbol work than
    # KV-SEED already does (K only, not K+V), and the layer-bank loop is free
    # (it re-slices a read_symbol call that already fetched the whole per-PE
    # array; see qkv_col_extract_npre_npost).
    def _qkv_col_check(rt):
        if not int(os.environ.get("QKV_COL_CHECK", "0")):
            record_verdict("QKV-COL", None, "QKV_COL_CHECK not enabled (set QKV_COL_CHECK=1 to run)")
            return
        P = P_BLOCK_SIZE
        if P * P * P_Y_BLOCK_NUM > 4096:
            detail = (f"grid too large for O(P^2) read_symbol (P={P}, "
                       f"P_Y_BLOCK_NUM={P_Y_BLOCK_NUM}) -- same guard as KV-SEED")
            print(f"  [qkv-col] QKV-COL check skipped ({detail})")
            record_verdict("QKV-COL", None, detail)
            return
        # K3 follow-up (2026-09-09, review): RoPE-pair padding (:665-682) can
        # leave whole PE-columns zero-filled, which would make a perfectly
        # healthy build read npre/npost < P and misfire INCONCLUSIVE/DEFECT.
        # 0 for every config shipped in this tree today (head_dim_shard ==
        # head_dim everywhere) -- see qkv_col_n_dummy_cols's docstring.
        _n_dummy_cols = qkv_col_n_dummy_cols(head_dim, pes_per_kv_head, n_kv_heads)
        # K3 follow-up (2026-09-09, LIVE-SIM finding, not from review): the KV
        # cache is Y-strided (qkv_col_row_reached's docstring), so a decode
        # run shorter than H_ROWS never writes rows past its own length --
        # confirmed live on model_config/sim_2x2_bsz1.json (H_ROWS=8):
        # DECODE_LENS=[2]/[3] falsely DEFECTed rows >= 2/3 before this fix;
        # DECODE_LENS=[24] (>= H_ROWS) already read clean.
        #
        # 2nd-pass follow-up (review, 2026-09-09): a single round's ACTUAL
        # generated count is not enough -- decode.csl's round_reset() only
        # resets the write cursor to THAT round's own prefill boundary, it
        # never clears anything beyond it, so an earlier, longer round's
        # decode-written suffix persists through a later, shorter one. Use
        # every round's (plen_per_pe, ACTUAL generated count) -- not the
        # configured budget, since early EOS stop can end a round short of
        # it -- and take the max reach across all of them (qkv_col_row_high_water).
        _all_rounds_reach = [(r["prefill"] // H_ROWS, r["generated"]) for r in round_summary]
        # K3 follow-up (2026-09-09, review): cap the per-(row,ly,layer) print
        # volume too, not just the aggregate's bad-sample list -- the full
        # H_ROWS*layers sweep can otherwise emit thousands of lines on a real
        # run, and skimmed output is exactly how a checker that never fails
        # goes unnoticed. QKV_COL_VERBOSE=1 restores the unabridged dump.
        _print_cap = int(os.environ.get("QKV_COL_PRINT_CAP", "40"))
        _verbose = bool(int(os.environ.get("QKV_COL_VERBOSE", "0")))
        _n_printed = 0
        _n_suppressed = 0
        def _qkv_print(msg):
            nonlocal _n_printed, _n_suppressed
            if _verbose or _n_printed < _print_cap:
                print(msg, flush=True)
                _n_printed += 1
            else:
                _n_suppressed += 1
        _plen = int(last_plen_per_pe)
        _rows = kv_rows if CHAIN is not None else list(range(P_Y_BLOCK_NUM))
        _sample_rows = qkv_col_sample_rows(H_ROWS, P)
        _idle_lys = [ly for ly, idle in _sample_rows if idle]
        print(f"  [qkv-col] P={P} kv_cols={kv_cols} kv_len_per_pe={kv_len_per_pe} "
              f"prefill_per_pe={_plen} rows={_rows} n_dummy_cols={_n_dummy_cols} "
              f"all_rounds_reach={_all_rounds_reach} "
              f"sampled_ly={[ly for ly, _ in _sample_rows]} idle_ly={_idle_lys}", flush=True)
        _qkv_samples = []   # (row, ly, layer, npre, npost, is_idle, decode_reached) for the aggregate record
        for by in _rows:
            _bx = 0 if by % 2 == 0 else 1          # KV owner sits on the attn slot
            _real_layers = 1 if CHAIN is not None else layer_counts[by]
            for _ly, _is_idle in _sample_rows:
                # Idle rows were never baked at all (_bake only writes H_ROWS
                # rows), so "real layer count" is moot there -- sweep every
                # physical bank to prove none of them leaked per-column data.
                _n_layers = max_layers_per_block if _is_idle else _real_layers
                _decode_reached = _is_idle or qkv_col_row_reached(
                    _ly, _all_rounds_reach, H_ROWS, _plen)
                _cols = [np.asarray(rt.read_symbol(
                    PLACE_X + _bx * P + lx, PLACE_Y + by * P + _ly,
                    "XKCache_tile", dtype="uint16")) for lx in range(P)]
                _slab = bsz * kv_cols * kv_len_per_pe
                _qkv_print(f"  [qkv-col]   raw: row {by} ly {_ly}{' [idle]' if _is_idle else ''}"
                           f"{'' if _decode_reached else ' [not-yet-reached]'} "
                           f"layer0 nonzero={int(np.count_nonzero(_cols[0][:_slab]))}/{_slab} "
                           f"col0={_cols[0][:_slab].tolist()[:6]} "
                           f"col1={_cols[1][:_slab].tolist()[:6]}")
                _triples = qkv_col_extract_npre_npost(
                    _cols, bsz, kv_cols, kv_len_per_pe, _plen, _n_layers)
                for _layer, npre, npost in _triples:
                    verdict = qkv_col_verdict_word(npre, npost, P, is_idle=_is_idle,
                                                    n_dummy_cols=_n_dummy_cols,
                                                    decode_reached=_decode_reached)
                    _qkv_print(f"  [qkv-col] row {by} bx {_bx} ly {_ly}"
                               f"{' [idle]' if _is_idle else ''}"
                               f"{'' if _decode_reached else ' [not-yet-reached]'} layer {_layer}: "
                               f"prefix {npre}/{P} distinct (control), "
                               f"decode {npost}/{P} distinct  ->  {verdict}")
                    _qkv_samples.append((by, _ly, _layer, npre, npost, _is_idle, _decode_reached))
        if _n_suppressed:
            print(f"  [qkv-col] ... {_n_suppressed} further diagnostic line(s) suppressed "
                  f"(set QKV_COL_VERBOSE=1 for the full dump)", flush=True)
        # TEST-ONLY fault injection, see the KV-SEED comment above: appends a
        # synthetic (npre=1) sample, which qkv_col_verdict_word classifies as
        # INCONCLUSIVE -- off by default, does not touch real samples.
        if int(os.environ.get("_TEST_FORCE_QKV_COL_INCONCLUSIVE", "0")):
            _qkv_samples.append((-1, -1, -1, 1, 1, False, True))
        # Aggregate to ONE verdict for the sink -- see qkv_col_aggregate()'s
        # docstring for why DEFECT and INCONCLUSIVE both fail.
        _qkv_ok, _qkv_detail = qkv_col_aggregate(_qkv_samples, P, n_dummy_cols=_n_dummy_cols)
        record_verdict("QKV-COL", _qkv_ok, _qkv_detail)

    if cmaddr is None:
        _qkv_col_check(runtime)

    # Local top-K accuracy (sim only, POST-stop): independent numpy ground truth on
    # the device's OWN last-step logits. The bounded-insertion tail_local_topk no
    # longer mutates partials_buf, so it holds the clean post-Y-reduce logits;
    # gather the vocab X-shard across the root-row tail PEs, take the global top-K
    # in numpy, and compare to the device merged+broadcast topk_val/topk_arg.
    if cmaddr is None and vocab_size is None:
        record_verdict("LOCAL-TOPK", None, "vocab_size not set in config")
    elif cmaddr is None and vocab_size is not None:
        tail_rootrow_y = PLACE_Y + last_row * P_BLOCK_SIZE + root_2nd_phase
        Vppe = V_per_pe_x
        gathered = np.full((bsz, HT_WIDTH_tail * Vppe), -np.inf, dtype=np.float32)
        for x_local in range(HT_WIDTH_tail):
            pb = np.asarray(runtime.read_symbol(
                ht_tail_x + x_local, tail_rootrow_y, "partials_buf",
                dtype="float32")).reshape(bsz, Vppe)
            v_real = Vppe - max(0, min(Vppe, (x_local + 1) * Vppe - vocab_true))
            gathered[:, x_local * Vppe : x_local * Vppe + v_real] = pb[:, :v_real]
        dv = np.asarray(runtime.read_symbol(
            ht_tail_x + root_2nd_phase_x, tail_rootrow_y, "topk_val", dtype="uint16"))
        da = np.asarray(runtime.read_symbol(
            ht_tail_x + root_2nd_phase_x, tail_rootrow_y, "topk_arg", dtype="float32"))
        dev_val = dv[:top_k * bsz].view(ml_dtypes.bfloat16).astype(np.float32).reshape(top_k, bsz).T
        dev_arg = da.view(np.int32)[:top_k * bsz].reshape(top_k, bsz).T
        bad = 0
        for b in range(bsz):
            ref_arg = np.argsort(-gathered[b], kind="stable")[:top_k]
            if not np.array_equal(dev_arg[b].astype(np.int64), ref_arg.astype(np.int64)):
                bad += 1
                print(f"    b={b} ARG mismatch: dev={dev_arg[b].tolist()} ref={ref_arg.tolist()}")
                print(f"          dev_val={dev_val[b].tolist()} ref_val={gathered[b][ref_arg].tolist()}")
        # TEST-ONLY fault injection, see the KV-SEED comment above.
        bad += int(os.environ.get("_TEST_FORCE_LOCAL_TOPK_FAIL", "0"))
        print(f"  [decode] LOCAL-TOPK {'PASS' if bad == 0 else f'FAIL ({bad}/{bsz} batches)'}: "
              f"device top-{top_k} == numpy top-{top_k} of device logits (last step, all batches)")
        record_verdict("LOCAL-TOPK", bad == 0,
                        f"{bad}/{bsz} batch(es) mismatched (device top-{top_k} vs numpy top-{top_k})")

    # The artifact is prefill-agnostic (prefill delivered at runtime via the KV phase-0
    # metainfo): one compile serves any prefill. Multi-round reuse runs in a single
    # load()/run() (the round loop above); simfab allows only ONE Simfabric per process
    # (Simfabric::Create asserts on a second SdkRuntime), so a fresh load()/run() per
    # prefill (launch_sim --prefill-len) needs separate processes.

    # ---------------- Benchmark: per-token timing (TSC) ----------------
    # 3 of every 4 u32 carry the u16 TSC payload (low 16 bits); slots 3/7 pad.
    # start and end come from the SAME tail PE's counter (cross-PE diffs would be
    # meaningless), so end - start is a valid elapsed-cycle count.
    def _unpack_tsc(b, off):
        return (int(b[off]     & 0xFFFF)
                | (int(b[off + 1] & 0xFFFF) << 16)
                | (int(b[off + 2] & 0xFFFF) << 32))
    tsc_verdict = None   # captured for the durable verdict file (survives client drop)
    # The TSC window covers generated tokens after warmup, which may be fewer
    # than the compile-time budget when EOS stops a round early.
    counted_tokens = max(int(tsc_ngen) - warmup_cycles, 0)
    if counted_tokens >= 1:
        total_cycles = _unpack_tsc(tsc_burst, 4) - _unpack_tsc(tsc_burst, 0)
        per_tok_cyc  = total_cycles / counted_tokens
        # Historical reporting conversion; cycles remain the canonical metric.
        per_tok_sec  = per_tok_cyc / 0.85e9
        per_tok_us   = per_tok_sec * 1e6
        tsc_verdict  = {"counted_tokens": int(counted_tokens), "span_cycles": int(total_cycles),
                        "per_round_cyc": float(per_tok_cyc), "per_round_us": float(per_tok_us),
                        "tok_per_s": (float(1.0 / per_tok_sec) if per_tok_sec > 0 else None)}
        cfg_name = Path(artifact_dir).name
        print(f"\n{'=' * 60}")
        print(f"  qwen3_4b {cfg_name}  (TSC; time assumes 0.85 GHz)")
        print(f"{'=' * 60}")
        print(f"{'Warmup (discarded):':<37}{warmup_cycles}")
        print(f"{'Generated tokens (timed round):':<37}{tsc_ngen}")
        print(f"{'Timed tokens (gen - warmup):':<37}{counted_tokens}")
        print(f"{'Span cycles (end - start):':<37}{total_cycles}")
        print(f"{'Per-token cycles (span / timed):':<37}{per_tok_cyc:.1f}")
        print(f"{'Per-token time @ 0.85 GHz:':<37}{per_tok_us:.4f} us")
        if per_tok_sec > 0:
            print(f"{'Throughput:':<37}{1.0 / per_tok_sec:.1f} tok/s")
        else:
            print(f"{'Throughput:':<37}n/a")
        # Compare host per-token wall time with device TSC. recv_steady is the host
        # wait per token (pipeline fill excluded); the ratio is how close the host tracks
        # the device — 1.0x = the D2H cost is fully hidden behind generation.
        _steady_us = host_timing["per_token_recv_steady_us"]
        print(f"{'Host recv_steady/token:':<37}{_steady_us:.1f} us")
        if per_tok_us > 0:
            print(f"{'Host/device per-token ratio:':<37}{_steady_us / per_tok_us:.2f}x")
        tsc_verdict["host_recv_steady_us"] = float(_steady_us)
        tsc_verdict["host_device_ratio"] = (float(_steady_us / per_tok_us) if per_tok_us > 0 else None)
        print(f"{'=' * 60}")
        print(f"[per-token] qwen3_4b {cfg_name}: "
              f"{per_tok_us:.4f} us ({per_tok_cyc:.1f} cyc)")
    else:
        print(f"  [bench] TSC skipped: timed_tokens={counted_tokens} "
              f"(generated={tsc_ngen}, warmup_cycles={warmup_cycles} — round too short to time)")

    # ====================================================================== #
    # Phase 7: Oracle per-step top-K overlap (diagnostic)                   #
    # ====================================================================== #
    # Pure-numpy HF-standard reference (bf16 multiply, fp32 accumulate). Oracle
    # and device each run their OWN autoregressive chain (oracle feeds
    # argmax(logits); device feeds its on-chip sampled token), so the two
    # trajectories diverge once they pick different tokens: per-step top-K
    # overlap is highest at step 0 (same input) and decays as output grows.
    # Device path: skip — the numpy reference is too slow at device scale.
    # Durable verdict file: launch.py's stdout streams back through the SdkLauncher
    # client, which on this appliance intermittently drops its coordinator connection
    # and exits rc=0 before the worker's final prints flush (cs3-runner notes). Persist
    # the run verdict INTO the artifact dir (run() chdir'd here, so CWD == artifact_dir),
    # which `csctl log-export` always captures under worker-0/ — so the verdict (re-arm
    # + per-round + TSC throughput) survives a client drop and is recoverable from the
    # export even when the live stream is lost.
    if int(os.environ.get("DUMP_RECORDS", "0")):
        try:
            _rec = {}
            for _r, (_s, _a, _v) in enumerate(zip(per_round_sampled, per_round_topk_args, per_round_topk_vals)):
                _rec[f"round{_r}_sampled"] = np.asarray(_s, dtype=np.int32)
                _rec[f"round{_r}_topk_args"] = np.asarray(_a, dtype=np.int32)
                _rec[f"round{_r}_topk_vals_u16"] = np.asarray(_v).view(np.uint16)
            np.savez(Path(artifact_dir) / "device_records.npz", **_rec)
            print(f"  [records] wrote device_records.npz ({len(_rec)} arrays)", flush=True)
        except Exception as _e:
            print(f"  [records] failed: {_e}", flush=True)

    if PROF:
        try:
            _pr = {"prof_ring": np.int32(PROF_RING), "prof_hdr": np.int32(PROF_HDR),
                   "prof_shift": np.int32(PROF_SHIFT), "bsz": np.int32(bsz),
                   "prof_row": np.int32(PROF_ROW), "prof_broken": np.int32(PROF_BROKEN),
                   "warmup_cycles": np.int32(warmup_cycles)}
            for _name, _lst in per_round_prof.items():
                for _r, _b in enumerate(_lst):
                    _pr[f"round{_r}_{_name}"] = np.asarray(_b, dtype=np.uint32)
            np.savez(Path(artifact_dir) / "block_prof.npz", **_pr)
            print(f"  [prof] wrote block_prof.npz ({len(_pr)} arrays)", flush=True)
        except Exception as _e:
            print(f"  [prof] failed: {_e}", flush=True)

    def _write_verdict(extra=None):
        import json as _json
        v = {
            "config": Path(artifact_dir).name,
            "on_device": cmaddr is not None,
            "num_rounds": int(num_rounds),
            "prefill_lens": [int(x) for x in prefill_lens],
            "decode_lens": [int(x) for x in decode_lens],
            "rounds": round_summary,
            "rearm": {"checks": rearm_results,
                      "all_bit_identical": (all(r["bit_identical"] for r in rearm_results)
                                            if rearm_results else None)},
            "tsc": tsc_verdict,
            "compile_s": round(float(compile_s), 3),
            "load_s": round(float(load_s), 3),
            "run_s": round(float(run_s), 3),
            "host_timing": host_timing,
            "checks": _verdict_records,
            "checks_advisory": bool(int(os.environ.get("CHECK_ADVISORY", "0"))),
        }
        if extra:
            v.update(extra)
        try:
            (Path(artifact_dir) / "run_summary.json").write_text(_json.dumps(v, indent=2))
            print(f"  [verdict] wrote run_summary.json (rounds={len(round_summary)}, "
                  f"rearm_all_identical={v['rearm']['all_bit_identical']})", flush=True)
        except Exception as _e:
            print(f"  [verdict] failed to write run_summary.json: {_e}", flush=True)

    if cmaddr is not None:
        print("  [oracle] skipped on device — run under sim for the per-step "
              "top-K overlap diagnostic (numpy reference is slow at device scale)")
        # KV-SEED/ROUTE-CHECK/QKV-COL/LOCAL-TOPK all gate on `cmaddr is None` above
        # (read_symbol is sim-only) and so never ran on this path -- record that
        # explicitly rather than let them be silently absent from the summary.
        for _name in ("KV-SEED", "ROUTE-CHECK", "QKV-COL", "LOCAL-TOPK"):
            record_verdict(_name, None, "device run: read_symbol unavailable on device")
        _write_verdict()
        _finalize_checks()
        print("[run] SUCCESS", flush=True)
        return {"compile_s": compile_s, "run_s": run_s, "aligned": None}
    # Cut-mode geometries spread ONE layer chain over several stage rows; the
    # oracle's math is block-agnostic, so give it a single-block view instead
    # of the vanilla per-row layer distribution (which asserts n_layers >= rows).
    _oracle_cfg = cfg
    if int(cfg.get("STAGE_CUT", 0)) != 0:
        _oracle_cfg = dict(cfg)
        _oracle_cfg["P_Y_BLOCK_NUM"] = 1
    oracle_logits = numpy_decode_oracle(_oracle_cfg)
    assert oracle_logits is not None, (
        "config has no vocab_size — the logits oracle is unavailable"
    )
    # Per step/batch (topk_* are (steps, bsz, top_k)):
    #  - GATE: device top-k ids distinct + values non-increasing (merge-reduce
    #    yields a sorted, dedup'd top-k). Independent of the oracle.
    #  - DIAGNOSTIC: top-k overlap with the oracle's independent argmax chain,
    #    and sampled token ∈ device top-k. Neither gates pass/fail.
    per_step_results = []
    # Early-stop: only the n_generated steps the device actually emitted are
    # comparable (the last one carries STOP_TOK as its sampled id).
    for s in range(n_generated):
        ref = oracle_logits[s].reshape(bsz, vocab_size).astype(np.float32)
        step_logic_ok = True
        step_sample_in = True
        step_overlap_sum = 0.0
        for b in range(bsz):
            dev_idx = topk_args[s][b]                            # device top-k vocab ids
            dev_val = topk_vals[s][b].astype(np.float32)         # device top-k values
            distinct = (len(set(dev_idx.tolist())) == top_k)
            non_incr = bool(np.all(dev_val[:-1] >= dev_val[1:])) if top_k > 1 else True
            step_logic_ok = step_logic_ok and distinct and non_incr
            ref_idx = np.argsort(-ref[b])[:top_k]
            step_overlap_sum += len(set(dev_idx.tolist()) & set(ref_idx.tolist())) / top_k
            step_sample_in = step_sample_in and (int(sampled_tokens[s][b]) in set(dev_idx.tolist()))
        overlap_avg = step_overlap_sum / bsz
        per_step_results.append((overlap_avg, step_logic_ok, step_sample_in))
        print(f"  step {s}: top-{top_k} overlap={overlap_avg:.3f}  "
              f"[invariant] logic={step_logic_ok} sample∈top-k={step_sample_in}")
        print(f"    dev top-k[b0] idx = {topk_args[s][0][:min(top_k,8)]}  sampled[b0] = {int(sampled_tokens[s][0])}")
        print(f"    ref top-k[b0] idx = {np.argsort(-ref[0])[:min(top_k,8)]}")

    logic_pass    = all(r[1] for r in per_step_results)       # device merge-reduce invariant, all steps
    overlap_step0 = per_step_results[0][0]
    overlap_min   = min(r[0] for r in per_step_results)
    overlap_mean  = sum(r[0] for r in per_step_results) / len(per_step_results)
    if logic_pass:
        print(f"\nSUCCESS: on-chip merge-reduce top-{top_k} VALID for all {max_output_len} steps "
              f"(top-k distinct + descending).")
        print(f"  [top-k overlap vs independent HF-chain oracle] step0={overlap_step0:.3f} "
              f"mean={overlap_mean:.3f} min={overlap_min:.3f}.")
        print("  NOTE: oracle (argmax chain) and device (sampled chain) run independently, so overlap "
              "is highest at step 0 (same input) and decays as the two trajectories diverge. Diagnostic only.")
    else:
        print("\nFAIL: a step violated the merge-reduce INVARIANT (top-k not distinct + descending) "
              "— a real kernel bug.")

    _write_verdict({"merge_reduce_logic_pass": bool(logic_pass),
                    "topk_overlap": {"step0": round(float(overlap_step0), 3),
                                     "mean": round(float(overlap_mean), 3),
                                     "min": round(float(overlap_min), 3)}})
    # K2 verdict sink: KV-SEED/ROUTE-CHECK/QKV-COL above only print()'d and let
    # the run continue. Finalize BEFORE the pre-existing merge-reduce assert below
    # so the full check summary is always printed, even if that assert also fails.
    _finalize_checks()
    assert logic_pass, "merge-reduce invariant failed"
    print("[run] SUCCESS", flush=True)
    return {"compile_s": compile_s, "run_s": run_s,
            "aligned": logic_pass, "topk_overlap_step0": overlap_step0,
            "topk_overlap_mean": overlap_mean, "topk_overlap_min": overlap_min}


# ---------------------------------------------------------------------------- #
# Worker-side CLI (invoked on the appliance worker via SdkLauncher, or locally
# by launch_sim.py / launch_device.py for sim runs).
# ---------------------------------------------------------------------------- #

HERE = Path(__file__).parent.resolve()

MODEL_REQUIRED_KEYS = {
    "Pw", "Ph", "P_X_BLOCK_NUM", "P_Y_BLOCK_NUM", "group_num", "bsz",
    "dim", "head_dim", "MAX_SEQ_LEN", "ffn_dim", "n_heads", "n_kv_heads",
    "n_layers", "vocab_size", "HT_WIDTH_tail", "TOP_K", "temperature",
    "top_p", "seed", "eos_token_ids", "pad_token_id", "WARMUP",
    "KV_DSD_SEG_MAX",
}
MODEL_OPTIONAL_KEYS = {"KV_INGRESS_IO_LOCS", "TOKEN_IO_LOC", "LOGITS_IO_LOC", "STAGE_CUT", "ACTIVE_ROWS",
                       # MEASUREMENT SCAFFOLD ONLY (2026-09-09, layout C SRAM audit).
                       # Overrides the cut-mode max_layers_per_block pin so a compile-only
                       # build can size the per-PE weight banks at a realistic layer count.
                       # The resulting build is NOT runnable: the CHAIN map still assigns one
                       # layer per stage and cut_stage_main has no layer loop.
                       "SRAM_SCAFFOLD_MAX_LAYERS"}
REQUEST_KEYS = {"PREFILL_LENS", "DECODE_LENS", "token_ids"}
REQUEST_OPTIONAL_KEYS = {"FORCED_TOKENS", "FORCED_PRODUCTION"}   # forced-prefill feed / production tail


def _load_json_object(path, kind):
    path = Path(path)
    with path.open() as f:
        value = json.load(f)
    if not isinstance(value, dict):
        raise TypeError(f"{kind} config must be a JSON object: {path}")
    return value


def load_config(model_path, request_path):
    """Load one compile model and one runtime request with disjoint schemas."""
    model_cfg = _load_json_object(model_path, "model")
    request_cfg = _load_json_object(request_path, "request")

    model_keys = set(model_cfg)
    missing = MODEL_REQUIRED_KEYS - model_keys
    unknown = model_keys - MODEL_REQUIRED_KEYS - MODEL_OPTIONAL_KEYS
    if missing or unknown:
        raise ValueError(
            f"invalid model config {model_path}: "
            f"missing={sorted(missing)}, unknown={sorted(unknown)}"
        )
    request_keys = set(request_cfg)
    if (REQUEST_KEYS - request_keys) or (request_keys - REQUEST_KEYS - REQUEST_OPTIONAL_KEYS):
        raise ValueError(
            f"invalid request config {request_path}: "
            f"missing={sorted(REQUEST_KEYS - request_keys)}, "
            f"unknown={sorted(request_keys - REQUEST_KEYS - REQUEST_OPTIONAL_KEYS)}"
        )

    prefill_lens = request_cfg["PREFILL_LENS"]
    decode_lens = request_cfg["DECODE_LENS"]
    token_ids = request_cfg["token_ids"]
    if (not isinstance(prefill_lens, list) or not prefill_lens
            or any(type(x) is not int for x in prefill_lens)):
        raise TypeError("PREFILL_LENS must be a non-empty list of integers")
    if (not isinstance(decode_lens, list)
            or any(type(x) is not int for x in decode_lens)):
        raise TypeError("DECODE_LENS must be a list of integers")
    if len(decode_lens) != len(prefill_lens):
        raise ValueError("PREFILL_LENS and DECODE_LENS must have equal length")
    if (not isinstance(token_ids, list)
            or any(type(x) is not int for x in token_ids)):
        raise TypeError("token_ids must be a list of integers")
    if len(token_ids) != model_cfg["bsz"]:
        raise ValueError(
            f"token_ids length {len(token_ids)} != model bsz {model_cfg['bsz']}"
        )

    cfg = dict(model_cfg)
    cfg.update(request_cfg)
    cfg["PREFILL_LEN"] = prefill_lens[0]
    return cfg


def _parse_args():
    p = argparse.ArgumentParser(
        description="Worker-side entry: qwen3_4b SdkLayout run.")
    p.add_argument("--model", required=True,
                   help="Path to model_config/*.json (relative to CWD or absolute).")
    p.add_argument("--request", required=True,
                   help="Path to request_config/*.json (runtime request payload).")
    p.add_argument("--cmaddr", default=None,
                   help="Omit for local simfab; IP:PORT for appliance/real WSE-3.")
    p.add_argument("--name", default=None,
                   help="Artifact directory name. Default: out_<model>__<request>.")
    p.add_argument("--cslc-prefix", type=str, default="")
    p.add_argument("--compile-only", action="store_true",
                   help="Return after layout.compile (build/placement smoke; skip load/run/oracle).")
    p.add_argument("--route-table", action="store_true",
                   help="(default) Use the host-computed per-PE route table (host/route_table.py).")
    p.add_argument("--legacy-init", action="store_true",
                   help="Use the original on-device route derivation instead of the host table.")
    p.add_argument("--shared-reduce-len", action="store_true",
                   help="ATTN: run the O-proj and Score@V reduces through the QKV_FUSION_LEN variant (smaller image, padded wire payload).")
    p.add_argument("--route-check", action="store_true",
                   help="Run both derivations and count per-PE disagreements (simulator verification).")
    p.add_argument("--dump-records", action="store_true",
                   help="Save every D2H token record (top-k vals/args, sampled ids) to device_records.npz.")
    p.add_argument("--forced-variant", action="store_true",
                   help="Step-1b diagnostic: pair order with serial ATTN<->FFN handshake (no concurrency).")
    p.add_argument("--prof-block-tsc", action="store_true",
                   help="Instrument one ATTN and one FFN block PE with per-step TSC segment stamps "
                        "and egress the rings to block_prof.npz (measurement build).")
    p.add_argument("--prof-ring", type=int, default=512,
                   help="Steps retained per profiled block (even). Default 512.")
    p.add_argument("--prof-shift", type=int, default=6,
                   help="Ring entries are cycles >> this (u16). 6 fits a bsz-8 step period.")
    p.add_argument("--prof-row", type=int, default=0,
                   help="Block row to instrument. Only row 0 has a free collector row.")
    p.add_argument("--diag-a1-stub", type=int, default=0,
                   help="A1 diag: 1=stub content, 2=probe split at the QKV-reduce boundary.")
    p.add_argument("--prof-broken", action="store_true",
                   help="Negative control: stamp the compute segment BEFORE the layer body, "
                        "which must collapse the measured block time to ~0.")
    p.add_argument("--msize", action="store_true",
                   help="After compile, run cs-readelf -m on sim.elf and write msize.txt (per-PE memory totals).")
    args = p.parse_args()
    if args.route_table: os.environ["ROUTE_TABLE"] = "1"
    if args.legacy_init: os.environ["ROUTE_TABLE"] = "0"
    if args.shared_reduce_len: os.environ["SHARED_REDUCE_LEN"] = "1"
    if args.route_check: os.environ["ROUTE_CHECK"] = "1"
    if args.dump_records: os.environ["DUMP_RECORDS"] = "1"
    if args.forced_variant: os.environ["FORCED_VARIANT"] = "1"
    if args.prof_block_tsc: os.environ["PROF_BLOCK_TSC"] = "1"
    os.environ["PROF_RING"] = str(args.prof_ring)
    os.environ["PROF_ROW"] = str(args.prof_row)
    os.environ["PROF_SHIFT"] = str(args.prof_shift)
    if args.prof_broken: os.environ["PROF_BROKEN"] = "1"
    if getattr(args, "diag_a1_stub", 0): os.environ["DIAG_A1_STUB"] = str(args.diag_a1_stub)
    if args.msize: os.environ["MSIZE"] = "1"
    if args.name is None:
        args.name = f"out_{Path(args.model).stem}__{Path(args.request).stem}"
    return args


def main():
    args = _parse_args()
    cfg = load_config(args.model, args.request)
    artifact_dir = (HERE / args.name).resolve()
    run(cfg, cmaddr=args.cmaddr, artifact_dir=artifact_dir,
        cslc_prefix=args.cslc_prefix, compile_only=args.compile_only)


if __name__ == "__main__":
    main()
