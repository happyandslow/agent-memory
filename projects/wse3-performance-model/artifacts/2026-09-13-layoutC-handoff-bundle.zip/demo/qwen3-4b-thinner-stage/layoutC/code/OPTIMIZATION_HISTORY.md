# Qwen3-4B decode optimization history

This file preserves attributable performance changes in chronological order.
Cycles/token are device TSC measurements unless noted. Simulator results are
correctness or mechanism evidence only. Historical profile names were removed
from the active config directories in the 8K/4K cleanup; the measurements below
remain tied to their stated context.

## Original optimization sequence

The controlled 16K comparison starts at the exact-exp baseline and ends at the
accepted pre-L1 baseline. A row marked as a bundle was not measured as separate
changes and must not be split into invented per-change gains.

| Change | Context | Before | After | Delta | Evidence |
|---|---:|---:|---:|---:|---|
| Role split, active-prefix attention, KV-owner gating, fused UP/GATE input walk, state/routing reductions (bundle) | 1K | 783,837.7 | 770,339.5 | -1.72% | device |
| Polynomial exp replaces exact exp | 1K | 769,699.6 | 749,756.1 | -2.59% | device |
| Polynomial exp replaces exact exp | 16K | 1,751,122.3 | 1,324,019.7 | -24.39% | device |
| Shared approximate math, fused subtract/scale/clamp/exp, score init without clear pass, exact tail exp/sqrt/div removal (bundle) | 16K | 1,324,019.7 | 1,293,462.5 | -2.31% | device |
| End-to-end SIMD exponent reconstruction | 16K | 1,293,462.5 | 1,082,684.5 | -16.30% | device |
| `EXP_TILE` 32→64 | 16K | 1,082,684.5 | 1,031,762.2 | -4.70% | device |
| Fuse softmax denominator with Score@V numerator Y all-reduce | 16K | 1,031,762.2 | 993,523.4 | -3.71% | device |
| Fuse QKV local input traversal | 16K | 993,523.4 | 985,803.1 | -0.78% | device |
| rsqrt Newton iterations 4→3 | 16K | 985,803.1 | 981,315.8 | -0.46% | device |

The 639.9-cycle gap between 770,339.5 and 769,699.6 is an unattributed
checkpoint or rerun and is not counted as an optimization. The first successful
16K run was 1,751,858.6 cycles/token; 1,751,122.3 is the controlled exact-exp
A/B baseline. The retained sequence reduced that baseline by 43.96%.

## Fold RMSNorm reduction into projection reduction

RMSNorm's local sumsq now rides in the projection reduce tail. The normalization
factor is applied to the f32 projection output before any nonlinear stage. This
removes two Y all-reduces per layer while also avoiding one bf16 rounding.

| Context | Baseline | With fold | Delta | Baseline tok/s | With fold tok/s | Evidence |
|---|---:|---:|---:|---:|---:|---|
| 1K | 731,406.8 | 671,950.3 | -59,456.5 (-8.13%) | 1,162.1 | 1,265.0 | device |
| 16K | 976,908.1 | 916,637.0 | -60,271.1 (-6.17%) | 870.1 | 927.3 | device |

The nearly constant absolute saving is consistent with removing 72 Y
all-reduces from 36 layers. Host `recv_steady` changed from 964.0 to
884.6 us/token at 1K and from 1,291.0 to 1,210.9 us/token at 16K.

## Fix score accumulator initialization

The first K column incorrectly used `@fmuls` with a bf16-populated source DSD.
There is no mixed-width multiply form: mixed bf16×f32 accumulation requires
`@fmachs`. The retained fix zeros the f32 score once and runs every K column
through the same `@fmachs` path.

This was a correctness and re-arm defect, not just an optimization. It appeared
when `bsz == 1` and prefill-per-PE was 1; sampled IDs alone were too weak to
detect the 1–2 ULP logit drift. Re-arm validation therefore compares top-K
values and indices bitwise.

| Context | Pre-fix | Post-fix | Delta | Evidence |
|---|---:|---:|---:|---|
| 1K, one round | 671,950.3 | 671,620.8 | -329.5 (-0.049%) | device |
| 1K, two rounds | 671,950.3 | 671,033.6 | -916.7 (-0.14%) | device |
| 16K | 916,637.0 | 913,460.0 | -3,177.0 (-0.35%) | device |

Two equal-prefill rounds are sufficient to expose the cold-start/re-arm
difference. The active simulator gate is `sim_2x2_bsz1.json` with
`sim_rearm.json`.

## Numerical corrections after the original timing sequence

These corrections are retained for correctness. They were not isolated as
device performance A/B steps, so no speedup is attributed to them.

1. The SIMD exp path removed the scalar path's `-0.5` bias before `@fs2xp16`.
   `@fs2xp16` already rounds to nearest; retaining the bias double-rounded the
   range-reduction integer. The defective chain measured 4.047e-3 maximum
   relative error against a 1.1e-4 budget. Evidence: simulator mechanism.
2. The softmax maximum reduction now loads its source through a DSR before
   `@fmaxs`. The raw-DSD form changed result under unrelated DSR allocation.
   Evidence: simulator mechanism.
3. The obsolete dynamic inter-block send/receive API and its route-state mirrors
   were removed after the role pipeline switched to static multicast endpoints.
   The linker already dropped the zero-caller functions, so no device speedup is
   attributed.

`host/check_approx_math.py` gates scalar exp, SIMD exp, their seam, softmax,
sampling, rsqrt, reciprocal, and the double-rounded regression.

## Rejected or reverted changes

| Change | Before | After | Delta | Decision |
|---|---:|---:|---:|---|
| Root-only softmax with packed bf16 probability broadcast | 1,293,462.5 | 1,296,968.2 | +0.27% | reverted |
| Scalar-fused RMSNorm, QK-Norm, and HT-tail norm | 985,803.1 | 986,123.6 | +0.033% | reverted |
| Fold scalar denominator into Score@V map | 985,803.1 | 1,014,153.0 | +2.88% | reverted |
| Scalar/FMA RoPE rewrite | 985,803.1 | 993,748.4 | +0.81% | reverted |
| SIMD exp for tail `TOP_K=20` | 985,803.1 | 985,991.9 | +0.019% | reverted |
| `LT_BLOCK` 8→16 | 981,315.8 | 981,169.5 | -0.015% | noise; reverted |
| Send global top-K only toward east emitter | 981,315.8 | 981,673.5 | +0.036% | reverted |
| Score@V output-dimension outer traversal | 981,315.8 | 1,224,601.1 | +24.79% | reverted |
| KV-head root-only softmax and probability broadcast | 981,315.8 | 987,370.9 | +0.617% | reverted |

Two proposals were rejected before device timing: a fixed Cauchy attention bound
could clamp real logits to the exp floor, and reducing reciprocal Newton
iterations exceeded the accepted 1-ULP gate.

## Current measurement status

The active production profile is now 8K capacity with 4K prefill. No device
timing in this file was measured on that profile, so none is a current baseline.
The next CS-3 run must establish a new device result; simulator success cannot
substitute for it. The 0.85 GHz time conversion used in historical reports was
an explicit reporting assumption, not a device clock established by the
knowledge base.
