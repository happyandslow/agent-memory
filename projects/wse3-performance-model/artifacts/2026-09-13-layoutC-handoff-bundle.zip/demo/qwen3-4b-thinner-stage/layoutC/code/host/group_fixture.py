"""Independent layer banks and an unsharded mathematical group reference."""

import numpy as np
from .tall_fixture import make_fixture, bake, reference, BF16


def make_group_fixture(steps, g):
    return [make_fixture(steps, g, seed=910 + layer) for layer in range(g.layers)]


def bake_group(regions, fixtures, g):
    class Recorder:
        def __init__(self):
            self.values = {}

        def set_symbol_all(self, name, array, w, h):
            self.values[name] = array.copy()

    all_layers = []
    for fixture in fixtures:
        record = {stage: Recorder() for stage in regions}
        bake(record, fixture, g)
        all_layers.append(record)
    shared = {
        "group_input",
        "delta_cos_f32",
        "delta_sin_f32",
        "delta_p_cos_f32",
        "delta_p_sin_f32",
    }
    for stage, region in regions.items():
        h = g.height(stage)
        for name, first in all_layers[0][stage].values.items():
            value = (
                first
                if name in shared
                else np.concatenate(
                    [
                        layer[stage].values[name].reshape(h, g.width, -1)
                        for layer in all_layers
                    ],
                    axis=2,
                ).reshape(h, -1)
            )
            region.set_symbol_all(name, value, value.shape[1], h)


def reference_group(fixtures, g):
    # Evaluate each layer over the token sequence. Each layer's inputs are the
    # preceding layer's outputs, and each layer has its own independent cache.
    inputs = fixtures[0][1]
    keys = []
    values = []
    for w, _, k, v in fixtures:
        outputs, ek, ev = reference((w, inputs, k, v), g)
        inputs = outputs.astype(BF16)
        keys.append(ek)
        values.append(ev)
    return inputs.astype(np.float32), np.array(keys), np.array(values)
