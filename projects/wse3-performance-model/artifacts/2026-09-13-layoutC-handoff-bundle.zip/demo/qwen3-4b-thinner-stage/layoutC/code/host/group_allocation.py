"""Capture the launcher configuration and reject first-group resource conflicts.

This records the actual region.paint/set_param calls forwarded to SdkLayout.
Compiler outputs remain separate evidence; this checker does not infer drain
from a route or replace device protocol validation.
"""

import json
from pathlib import Path


class Region:
    def __init__(self, raw, name, source, width, height):
        self.raw = raw
        self.name = name
        self.source = source
        self.width = width
        self.height = height
        self.origin = None
        self.params = {}
        self.overrides = {}
        self.routes = {}
        self.collective_table = None

    def __getattr__(self, name):
        return getattr(self.raw, name)

    def set_param_all(self, key, value):
        self.params[key] = int(value)
        return self.raw.set_param_all(key, value)

    def set_param(self, xy, key, value):
        self.overrides.setdefault((xy.x, xy.y), {})[key] = int(value)
        return self.raw.set_param(xy, key, value)

    def place(self, x, y):
        self.origin = (x, y)
        return self.raw.place(x, y)

    def set_symbol_all(self, name, array, width, height):
        if name == "pe_cfg":
            self.collective_table = array.reshape(self.height, self.width, -1).tolist()
        return self.raw.set_symbol_all(name, array, width, height)

    @staticmethod
    def positions(routes):
        return [
            dict(
                rx=[str(x) for x in p.get_input()], tx=[str(x) for x in p.get_output()]
            )
            for p in routes
        ]

    @staticmethod
    def color_id(color):
        return color.get_value()

    def paint(self, xy, color, routes):
        self.routes[(xy.x, xy.y, self.color_id(color))] = self.positions(routes)
        return self.raw.paint(xy, color, routes)

    def paint_all(self, color, routes):
        for y in range(self.height):
            for x in range(self.width):
                self.routes[(x, y, self.color_id(color))] = self.positions(routes)
        return self.raw.paint_all(color, routes)


class Allocation:
    def __init__(self, raw):
        self.raw = raw
        self.regions = []

    def __getattr__(self, name):
        return getattr(self.raw, name)

    def create_code_region(self, source, name, width, height):
        region = Region(
            self.raw.create_code_region(source, name, width, height),
            name,
            source,
            width,
            height,
        )
        self.regions.append(region)
        return region

    def capture(self):
        records = []
        for region in self.regions:
            by_pe = {}
            for (x, y, color), positions in region.routes.items():
                by_pe.setdefault((x, y), {})[str(color)] = positions
            for y in range(region.height):
                for x in range(region.width):
                    params = dict(region.params, **region.overrides.get((x, y), {}))
                    routes = by_pe.get((x, y), {})
                    record = dict(
                        region=region.name,
                        source=region.source,
                        xy=[region.origin[0] + x, region.origin[1] + y],
                        local=[x, y],
                        params=params,
                        routes=routes,
                    )
                    if region.collective_table is not None:
                        record["pe_cfg"] = region.collective_table[y][x]
                    if region.name == "A1":
                        record["r_iq"] = 2
                    if region.name == "feedback_strip" and len(routes["16"]) == 2:
                        record["switch16"] = dict(
                            initial=1 if y == params["height"] - 1 else 0,
                            ring=False,
                            pop="always_pop"
                            if y == params["height"] - params["a3_height"]
                            else "pop_on_advance",
                        )
                    records.append(record)
        return records

    def write(self, path):
        records = self.capture()
        validate(records)
        controls = {}
        # Sanity controls mutate the captured allocation, not the implementation.
        for name, change in [
            ("collective_queue", lambda r: r.update(r_iq=3)),
            (
                "strip_k16_collision",
                lambda r: r["routes"].update(
                    {"16": [{"rx": ["Route.WEST"], "tx": ["Route.SOUTH"]}]}
                ),
            ),
        ]:
            import copy

            bad = [
                copy.deepcopy(
                    next(
                        r
                        for r in records
                        if r["region"]
                        == ("A1" if name == "collective_queue" else "feedback_strip")
                    )
                )
            ]
            change(bad[0])
            try:
                validate(bad)
            except ValueError:
                controls[name] = "rejected"
            else:
                raise AssertionError(f"Vacuous allocation checker: {name}")
        Path(path).write_text(
            json.dumps(
                dict(
                    scope="first group launcher routes; compiler manifests recorded separately",
                    negative_controls=controls,
                    endpoint_contract=ENDPOINT_CONTRACT,
                    pes=records,
                ),
                indent=2,
            )
            + "\n"
        )


def validate(records):
    occupied = set()
    for r in records:
        xy = tuple(r["xy"])
        if xy in occupied:
            raise ValueError(f"Overlapping code region at {xy}")
        occupied.add(xy)
        p = r["params"]
        name = r["region"]
        x, y = r["local"]
        routes = r["routes"]
        if name in ("A1", "A3"):
            if name == "A1" and r["r_iq"] != 2:
                raise ValueError("A1 R input must use IQ2, never collective IQ3..7")
            if p["r_oq"] >= 3:
                raise ValueError("R may not borrow a collective queue")
            expected = 1 if name == "A1" and p["h0_sender_flag"] else 0
            if p["r_oq"] != expected:
                raise ValueError("R aliases a QKV sender queue")
            if p["r_out"] != (19 if x % 2 == 0 else 18):
                raise ValueError("R row alternation mismatch")
        if name == "feedback_strip":
            if len(routes["16"]) != (
                2 if y < p["a1_height"] or y >= p["height"] - p["a3_height"] else 1
            ):
                raise ValueError("Feedback C16 source/target switch overwritten")
            if any("RAMP" in d for pos in routes["16"] for d in pos["rx"] + pos["tx"]):
                raise ValueError("Strip payload entered CE")
        if name == "A2" and x == p["width"] - 1:
            if any("EAST" in d for pos in routes["16"] for d in pos["tx"]):
                raise ValueError("A2 C16 spills beyond its region")
        for color, positions in routes.items():
            if len(positions) > 1 and int(color) not in {
                *range(10),
                12,
                13,
                16,
                17,
                20,
                21,
            }:
                raise ValueError("Switch on unsupported color")


# These source contracts accompany, rather than impersonate, compiler output.
# Per-PE r_oq/r_in/r_out, edge, qkv_color and collective tables are above.
ENDPOINT_CONTRACT = {
    "A1": {
        "IQ": {"0": "dense U16", "2": "R r_in", "3..7": "collective C0..4"},
        "OQ": {
            "r_oq": "R r_out",
            "other of 0/1": "QKV C8/9",
            "2": "X10",
            "3..7": "collective C0..4",
        },
        "tasks": {
            "0": "unexpected data",
            "2": "row ACK",
            "8": "main",
            "9": "receive complete",
            "10/42": "ROW_DONE",
            "11/43": "STREAM_END",
            "13": "truncated frame",
        },
        "closure": "both halves + ROW_DONE -> compute; X consumers complete -> rearm/ACK; row0 also requires STREAM_END",
    },
    "A2": {
        "IQ": {
            "0": "QKV8/9",
            "1": "QKV-column11",
            "2": "edge X10 or X-row16",
            "3..7": "collective0..4",
        },
        "OQ": {
            "0": "Z14",
            "1": "QKV-column11",
            "2": "X-row16",
            "3..7": "collective0..4",
        },
        "tasks": {"8": "main", "OQ3 empty callback": "edge_queue_empty"},
        "edge_phase": "IQ/OQ3 alternate collective0 and vertical12/13 only after counted input drain and output flush; keep vertical binding across Z/X boundary",
    },
    "A3": {
        "IQ": {"0": "Z14", "2": "source START15", "3..7": "collective0..4"},
        "OQ": {
            "0": "ACK19 at col0",
            "1": "dense local U16",
            "2": "boundary exit17",
            "3..7": "collective0..4",
        },
        "tasks": {"2": "START", "8": "main", "12": "payload complete"},
        "closure": "result ready AND matching credit -> async send, ordered markers, ACK; no collective waits for next credit",
    },
    "strip": {
        "IQ": {"0": "ACK19", "1": "R18/23; bottom return23"},
        "OQ": {"0": "R23/18", "1": "bottom START15"},
        "tasks": {"0": "ACK", "1": "R token", "8": "initialize"},
        "closure": "terminal row ACK -> router return -> one reset scan; all local ACKs gate scan; completed scan return gates START",
    },
}
