#!/usr/bin/env cs_python
"""Seeded-defect suite for launch.py's K3 QKV-COL checker rewrite.

Per the checker plan: "a checker that has never been observed failing is not
evidence" -- and per the K3 task specifically: "showing the old checker
PASSING (b), (c) and (d) is the strongest evidence in this plan." This suite
demonstrates exactly that: the SAME synthetic device readback fed through
BOTH the frozen pre-K3 sampling/verdict logic (reimplemented here, since
launch.py no longer has it -- see OLD_* below) and the real, current
launch.py functions (qkv_col_sample_rows, qkv_col_extract_npre_npost,
qkv_col_verdict_word, qkv_col_aggregate), with the outcomes compared.

Everything here is SYNTHETIC: no read_symbol, no simulator, no device. Per
the task's own suggestion, this is a harness around the classification/
extraction/aggregation functions -- the exact pure functions run()'s
_qkv_col_check calls once npre/npost/samples exist -- fed hand-built raw
XKCache_tile-shaped column data instead of a live readback. It does NOT
exercise read_symbol, PE placement, or the actual device/sim KV cache -- a
real QKV_COL_CHECK=1 sim run (see run_sim.sh) is still required to show the
new sampling wired to real device state, the same carve-out
scripts/test_verdict_sink.py documents for KV-SEED/ROUTE-CHECK/LOCAL-TOPK.

Must run under cs_python (launch.py imports the Cerebras SDK bindings at
module scope):

    cs_python scripts/test_qkv_col_check.py

Exit codes: 0 all cases passed, 1 at least one failed, 3 wrong interpreter.
"""
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).parent.resolve()
CODE_DIR = HERE.parent
sys.path.insert(0, str(CODE_DIR))


def _require_cs_python():
    """See scripts/test_verdict_sink.py's docstring for why this guard
    exists: without it, running this under a bare python3 makes every
    `from launch import ...` below traceback, and a naive runner would
    report a false "0/N FAIL" indistinguishable from a real defect."""
    try:
        import cerebras.sdk.runtime.sdkruntimepybind  # noqa: F401  pylint: disable=unused-import,import-outside-toplevel
    except Exception as exc:                          # noqa: BLE001
        print(f"ERROR: this suite must be run under cs_python, not {sys.executable}.")
        print(f"       Import failed here with: {type(exc).__name__}: {exc}")
        print(f"       Run instead:  cs_python {Path(__file__).resolve()}")
        print("VERDICT: ERROR (wrong interpreter -- no case was run)")
        sys.exit(3)


_require_cs_python()

from launch import (                                  # noqa: E402
    qkv_col_sample_rows,
    qkv_col_extract_npre_npost,
    qkv_col_verdict_word,
    qkv_col_aggregate,
    qkv_col_n_dummy_cols,
    qkv_col_expected_distinct,
    qkv_col_row_reached,
    qkv_col_row_high_water,
)


# --------------------------------------------------------------------- #
# Synthetic data generation
# --------------------------------------------------------------------- #

def make_col_arrays(P, bsz, kv_cols, kv_len_per_pe, plen, n_layers,
                     post_distinct_per_layer=None, pre_distinct=True):
    """Build P synthetic per-column raw XKCache_tile uint16 arrays -- the
    same shape a real `read_symbol(..., "XKCache_tile", ...)` per-column
    call returns: n_layers banks of bsz*kv_cols*kv_len_per_pe elements each,
    concatenated layer-major (matching the on-chip [l0 | l1 | ... ] layout
    _kv_seed_check / qkv_col_extract_npre_npost assume).

    The prefix [.., :plen] is column-distinct by construction (mirrors the
    host-seeded control, which a real run always seeds distinctly per
    column) unless pre_distinct=False. The suffix [.., plen:] is
    column-distinct per layer by default (the healthy case) unless
    overridden via post_distinct_per_layer: {layer_index: n_distinct}, which
    folds column index lx into `lx % n_distinct` before generating the
    suffix value -- n_distinct=1 is full collapse (the classic defect),
    n_distinct=2 is the "2 of P" partial collapse the original checker
    missed. A layer index absent from the dict is left healthy (P-distinct).

    Vectorized over columns (one numpy op per layer, not a P-iteration
    Python loop) so sweeping a large H_ROWS in the harness below stays fast.
    """
    post_distinct_per_layer = post_distinct_per_layer or {}
    banks = []
    for l in range(n_layers):
        pre_vals = (np.arange(P, dtype=np.int64) if pre_distinct
                    else np.zeros(P, dtype=np.int64)) + 1000
        nd = post_distinct_per_layer.get(l, P)
        assert 1 <= nd <= P
        post_vals = (np.arange(P, dtype=np.int64) % nd) + 2000 + 10 * l
        bank = np.zeros((P, bsz, kv_cols, kv_len_per_pe), dtype=np.uint16)
        bank[:, :, :, :plen] = pre_vals[:, None, None, None]
        bank[:, :, :, plen:] = post_vals[:, None, None, None]
        banks.append(bank.reshape(P, -1))
    full = np.concatenate(banks, axis=1)          # (P, n_layers*slab)
    return [full[lx] for lx in range(P)]


def zero_col_arrays(P, bsz, kv_cols, kv_len_per_pe, n_layers):
    """An idle row's cache bank: never baked, reads back as background zero
    -- the correct, expected "inert" reading."""
    slab = bsz * kv_cols * kv_len_per_pe
    return [np.zeros(n_layers * slab, dtype=np.uint16) for _ in range(P)]


def zero_out_columns(col_arrays, dummy_lxs):
    """Overwrite specific columns to all-zero -- the RoPE-pair padding tail
    (launch.py's `_expand_pairs`/`_reshard_K_dim`) zero-fills a WHOLE
    PE-column's worth of K data when that column carries no real head_dim
    positions at all (see qkv_col_n_dummy_cols). Both the host-seeded
    prefix AND the decode-written suffix are zero there on a healthy build
    -- decode has nothing real to write into a column that holds no real
    attention data."""
    out = list(col_arrays)
    for lx in dummy_lxs:
        out[lx] = np.zeros_like(out[lx])
    return out


def dummy_col_positions(head_dim, pes_per_kv_head, n_kv_heads):
    """WHICH local column indices (lx, 0..P-1) are fully dummy, mirroring
    launch.py's _reshard_K_dim / _perm_WQ pe_x = kv_head_idx*pes_per_kv_head
    + s_idx indexing: the TRAILING s_idx values in each kv-head group, once
    the earlier ones are exhausted by real + (at most one) partial pairs.
    Test-local only -- exists to construct a realistic synthetic fixture,
    not imported by/into launch.py. Must agree with qkv_col_n_dummy_cols's
    COUNT (asserted at each call site below) even though that function
    (rightly) only returns a count, not positions -- the checker only ever
    needs the count.
    """
    H2 = head_dim // 2
    K = pes_per_kv_head
    pairs_per_pe = -(-H2 // K)
    n_full_real = H2 // pairs_per_pe
    n_partial = 1 if H2 % pairs_per_pe else 0
    dummy_s = list(range(n_full_real + n_partial, K))
    return [kv_head_idx * K + s for kv_head_idx in range(n_kv_heads) for s in dummy_s]


# --------------------------------------------------------------------- #
# Frozen copy of the PRE-K3 checker (for comparison only -- launch.py no
# longer has this version; this reproduces exactly what it did: rows
# (0, min(1, H_ROWS-1)), layer bank 0 only, npost==1 -> DEFECT else
# "healthy" (no exact-match requirement), npre==1 -> INCONCLUSIVE).
# --------------------------------------------------------------------- #

def OLD_qkv_col_verdict_word(npre, npost):
    if npre == 1:
        return "INCONCLUSIVE"
    if npost == 1:
        return "DEFECT"
    return "healthy"


def run_old_checker(H_ROWS, bsz, kv_cols, kv_len_per_pe, plen, row_data):
    """row_data(ly) -> list of P per-column raw arrays (>= 1*slab long).
    Reuses the REAL qkv_col_extract_npre_npost with n_layers=1 to slice out
    bank 0 -- identical to the old inline `_k[:bsz*kv_cols*kv_len_per_pe]`
    -- since extraction itself did not change; only which rows/layers were
    looked at, and the verdict threshold, did."""
    results = []
    for ly in (0, min(1, H_ROWS - 1)):
        cols = row_data(ly)
        (_layer0, npre, npost), = qkv_col_extract_npre_npost(
            cols, bsz, kv_cols, kv_len_per_pe, plen, 1)
        results.append((ly, npre, npost, OLD_qkv_col_verdict_word(npre, npost)))
    ok = all(r[3] == "healthy" for r in results)
    return ok, results


# --------------------------------------------------------------------- #
# The current (K3) checker, driven the same way run()'s _qkv_col_check
# drives it -- real qkv_col_sample_rows/extract/verdict/aggregate, fed
# synthetic per-row column data instead of read_symbol.
# --------------------------------------------------------------------- #

def run_new_checker(H_ROWS, P_BLOCK_SIZE, P_cols, bsz, kv_cols, kv_len_per_pe,
                     plen, max_layers, row_data, real_layers_fn=None, rounds=None):
    """rounds=None means "assume every active row has been decode-reached"
    (qkv_col_row_reached is skipped) -- the right default for every case in
    this file EXCEPT the row-reach cases themselves ((j)-(m) below), which
    pass a real list of (plen_per_pe, decode_len) pairs -- one per round --
    to exercise qkv_col_row_reached/qkv_col_row_high_water exactly as
    run()'s _qkv_col_check does. `plen` doubles as the row-reach boundary
    (last_plen), matching _qkv_col_check's own `_plen`."""
    real_layers_fn = real_layers_fn or (lambda ly: max_layers)
    samples = []
    for ly, is_idle in qkv_col_sample_rows(H_ROWS, P_BLOCK_SIZE):
        cols = row_data(ly)
        n_layers = max_layers if is_idle else real_layers_fn(ly)
        decode_reached = (is_idle or rounds is None
                           or qkv_col_row_reached(ly, rounds, H_ROWS, plen))
        for layer, npre, npost in qkv_col_extract_npre_npost(
                cols, bsz, kv_cols, kv_len_per_pe, plen, n_layers):
            samples.append((0, ly, layer, npre, npost, is_idle, decode_reached))
    return qkv_col_aggregate(samples, P_cols)


# --------------------------------------------------------------------- #
# Shared geometry for (a)-(e): P=128 columns, max_layers_per_block=5,
# H_ROWS=256 + 16 idle rows -- the exact numbers from the K3 defect report
# (analyses/2026-09-09-layoutC-checker-plan.md's K3 section), not
# arbitrary minis, so the demonstration speaks to the real concern.
# --------------------------------------------------------------------- #
P_COLS = 128
BSZ = 1
KV_COLS = 2
KV_LEN_PER_PE = 4
PLEN = 2
MAX_LAYERS = 5
H_ROWS = 256
P_BLOCK_SIZE = H_ROWS + 16   # 16 idle rows, matching the layout's construction

CASES = []


def case(name):
    def deco(fn):
        CASES.append((name, fn))
        return fn
    return deco


def _healthy_row(ly):
    return make_col_arrays(P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, MAX_LAYERS)


def _idle_row(ly):
    return zero_col_arrays(P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, MAX_LAYERS)


def _dispatch(active_defect_rows):
    """Return a row_data(ly) function: idle rows (ly>=H_ROWS) read inert;
    active rows use active_defect_rows.get(ly) as post_distinct_per_layer
    (None -> healthy)."""
    def row_data(ly):
        if ly >= H_ROWS:
            return _idle_row(ly)
        pdpl = active_defect_rows.get(ly)
        return make_col_arrays(P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, MAX_LAYERS,
                                post_distinct_per_layer=pdpl)
    return row_data


def _run_both(row_data):
    old_ok, old_results = run_old_checker(H_ROWS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, row_data)
    new_ok, new_detail = run_new_checker(H_ROWS, P_BLOCK_SIZE, P_COLS, BSZ, KV_COLS,
                                          KV_LEN_PER_PE, PLEN, MAX_LAYERS, row_data)
    return old_ok, old_results, new_ok, new_detail


_UNWRITTEN_PDPL = {l: 1 for l in range(MAX_LAYERS)}   # post_distinct_per_layer for "never written"


def _row_reach_dispatch(rounds, defect_row=None):
    """Return a row_data(ly) function modeling a run whose rounds are given
    as (plen_per_pe, decode_len) pairs (see qkv_col_row_high_water; `plen`
    here is always PLEN, this file's shared boundary, matching every round
    sharing one prefill length -- the common case, and the one the review
    fixture describes: same prompt, a longer round then a shorter one).
    Rows whose high-water mark exceeds PLEN are healthy (decode-reached by
    SOME round, fully distinct); the rest are "not yet reached" -- prefix
    still real/distinct (prefill always runs), suffix uniformly untouched
    (post_distinct_per_layer=1, matching the live all-zero readback
    observed on sim_2x2_bsz1.json). `defect_row`, if given, forces a
    genuine post-collapse at that row regardless of whether it is
    reach-eligible -- used by case (k) to confirm row-reach awareness does
    not mask a real defect in an already-reached row."""
    def row_data(ly):
        if ly >= H_ROWS:
            return _idle_row(ly)
        if defect_row is not None and ly == defect_row:
            return make_col_arrays(P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, MAX_LAYERS,
                                    post_distinct_per_layer=_UNWRITTEN_PDPL)
        reached = qkv_col_row_high_water(ly, rounds, H_ROWS) > PLEN
        pdpl = None if reached else _UNWRITTEN_PDPL
        return make_col_arrays(P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, MAX_LAYERS,
                                post_distinct_per_layer=pdpl)
    return row_data


@case("(a) full collapse (1/128 distinct) everywhere -- OLD rejects, NEW rejects")
def _(_state):
    row_data = _dispatch({ly: {l: 1 for l in range(MAX_LAYERS)} for ly in range(H_ROWS)})
    old_ok, old_results, new_ok, new_detail = _run_both(row_data)
    ok = (old_ok is False) and (new_ok is False)
    detail = f"OLD ok={old_ok} results={old_results}\nNEW ok={new_ok} detail={new_detail}"
    return ok, detail


@case("(b) 2/128 distinct (partial collapse) everywhere -- OLD PASSES, NEW rejects")
def _(_state):
    row_data = _dispatch({ly: {l: 2 for l in range(MAX_LAYERS)} for ly in range(H_ROWS)})
    old_ok, old_results, new_ok, new_detail = _run_both(row_data)
    ok = (old_ok is True) and (new_ok is False) and "2/128" in new_detail
    detail = f"OLD ok={old_ok} results={old_results}\nNEW ok={new_ok} detail={new_detail}"
    return ok, detail


@case("(c) defect only in layer 3 (every row) -- OLD PASSES (layer-0-only), NEW rejects")
def _(_state):
    row_data = _dispatch({ly: {3: 1} for ly in range(H_ROWS)})
    old_ok, old_results, new_ok, new_detail = _run_both(row_data)
    ok = (old_ok is True) and (new_ok is False) and "layer=3" in new_detail
    detail = f"OLD ok={old_ok} results={old_results}\nNEW ok={new_ok} detail={new_detail}"
    return ok, detail


@case("(d) defect only at row 200 (layer 0) -- OLD PASSES (rows 0/1 only), NEW rejects")
def _(_state):
    row_data = _dispatch({200: {0: 1}})
    old_ok, old_results, new_ok, new_detail = _run_both(row_data)
    ok = (old_ok is True) and (new_ok is False) and "ly=200" in new_detail
    detail = f"OLD ok={old_ok} results={old_results}\nNEW ok={new_ok} detail={new_detail}"
    return ok, detail


@case("(e) genuinely healthy build (incl. idle rows) -- OLD passes, NEW passes")
def _(_state):
    row_data = _dispatch({})
    old_ok, old_results, new_ok, new_detail = _run_both(row_data)
    ok = (old_ok is True) and (new_ok is True)
    detail = f"OLD ok={old_ok} results={old_results}\nNEW ok={new_ok} detail={new_detail}"
    return ok, detail


# --------------------------------------------------------------------- #
# Bonus: idle-row inertness itself, isolated at the qkv_col_verdict_word
# level -- OLD has no concept of idle rows at all (it never samples past
# row 1), so this whole class of defect (idle PEs unexpectedly carrying
# per-column data) is entirely outside its reach, not just "missed by
# threshold". Direct pure-function checks rather than a full row sweep,
# since (e) above already exercises this through the full pipeline once.
# --------------------------------------------------------------------- #

@case("(f) idle row correctly inert -- NEW does not flag it")
def _(_state):
    word = qkv_col_verdict_word(1, 1, P_COLS, is_idle=True)
    ok = word.startswith("inert")
    return ok, f"qkv_col_verdict_word(1, 1, {P_COLS}, is_idle=True) -> {word!r}"


@case("(g) idle row contaminated (per-column data where none should exist) -- NEW rejects")
def _(_state):
    word = qkv_col_verdict_word(1, 5, P_COLS, is_idle=True)
    ok = word.startswith("DEFECT")
    return ok, f"qkv_col_verdict_word(1, 5, {P_COLS}, is_idle=True) -> {word!r}"


# --------------------------------------------------------------------- #
# Follow-up (review, 2026-09-09): the original K3 `npre == P` / `npost == P`
# exact-match rule assumed every PE-column carries real per-column data.
# RoPE-pair padding (launch.py:665-682) can leave whole columns entirely
# zero-filled when (head_dim//2) % pes_per_kv_head != 0 -- no config
# shipped in this tree needs that (verified: layout C's target
# P=128/n_kv_heads=8/head_dim=128 gives head_dim_shard=128 exactly, so
# qkv_col_n_dummy_cols returns 0 for it), but the launcher CAN build one,
# so a perfectly healthy build there would misfire INCONCLUSIVE without
# this. Geometry here (head_dim=8, pes_per_kv_head=6, n_kv_heads=2) is
# synthetic specifically to trigger padding -- not a real model shape.
# --------------------------------------------------------------------- #
_D_HEAD_DIM = 8
_D_PES_PER_KV_HEAD = 6
_D_N_KV_HEADS = 2
_D_P = _D_PES_PER_KV_HEAD * _D_N_KV_HEADS      # 12
_D_BSZ, _D_KV_COLS, _D_KV_LEN, _D_PLEN = 1, 2, 4, 2
_D_DUMMY_LXS = dummy_col_positions(_D_HEAD_DIM, _D_PES_PER_KV_HEAD, _D_N_KV_HEADS)


@case("(h) known-zero padding tail: healthy real columns must PASS once n_dummy_cols is known")
def _(_state):
    n_dummy = qkv_col_n_dummy_cols(_D_HEAD_DIM, _D_PES_PER_KV_HEAD, _D_N_KV_HEADS)
    assert n_dummy == len(_D_DUMMY_LXS), (n_dummy, _D_DUMMY_LXS)   # cross-check count vs. positions
    cols = make_col_arrays(_D_P, _D_BSZ, _D_KV_COLS, _D_KV_LEN, _D_PLEN, 1)
    cols = zero_out_columns(cols, _D_DUMMY_LXS)
    (_layer, npre, npost), = qkv_col_extract_npre_npost(
        cols, _D_BSZ, _D_KV_COLS, _D_KV_LEN, _D_PLEN, 1)
    expected = qkv_col_expected_distinct(_D_P, n_dummy)
    word_aware = qkv_col_verdict_word(npre, npost, _D_P, n_dummy_cols=n_dummy)
    word_unaware = qkv_col_verdict_word(npre, npost, _D_P, n_dummy_cols=0)
    ok = (npre == expected and npost == expected
          and word_aware.startswith("healthy")
          and word_unaware.startswith("INCONCLUSIVE"))
    detail = (f"P={_D_P} dummy_lxs={_D_DUMMY_LXS} n_dummy={n_dummy} expected={expected} "
              f"npre={npre} npost={npost}\n"
              f"  n_dummy_cols=4 (aware)   -> {word_aware!r}\n"
              f"  n_dummy_cols=0 (unaware) -> {word_unaware!r}  <- the bug this closes: "
              f"a healthy build would have failed")
    return ok, detail


@case("(i) same padding tail + a REAL collapse among non-padding columns -- must still FAIL")
def _(_state):
    n_dummy = qkv_col_n_dummy_cols(_D_HEAD_DIM, _D_PES_PER_KV_HEAD, _D_N_KV_HEADS)
    # Collapse decode-written K to 6 distinct raw groups (lx % 6) BEFORE
    # zeroing the dummy columns -- lx pairs {0,6},{1,7},{2,8},{3,9} are real
    # (not in _D_DUMMY_LXS) and collide with each other; {4,10} and {5,11}
    # also collide but are moot, both being dummy columns zeroed next.
    cols = make_col_arrays(_D_P, _D_BSZ, _D_KV_COLS, _D_KV_LEN, _D_PLEN, 1,
                            post_distinct_per_layer={0: 6})
    cols = zero_out_columns(cols, _D_DUMMY_LXS)
    (_layer, npre, npost), = qkv_col_extract_npre_npost(
        cols, _D_BSZ, _D_KV_COLS, _D_KV_LEN, _D_PLEN, 1)
    expected = qkv_col_expected_distinct(_D_P, n_dummy)
    word = qkv_col_verdict_word(npre, npost, _D_P, n_dummy_cols=n_dummy)
    # npre unaffected by the post-only collapse: still 8 real (distinct) + 1
    # zero group = expected. npost collapses to 4 real groups + 1 zero
    # group = 5, short of expected -- padding-awareness must not swallow
    # this: a real defect among the non-padding columns is still a DEFECT.
    ok = (npre == expected and npost == 5 and npost != expected
          and word.startswith("DEFECT"))
    detail = (f"P={_D_P} n_dummy={n_dummy} expected={expected} npre={npre} npost={npost} "
              f"-> {word!r}")
    return ok, detail


# --------------------------------------------------------------------- #
# Follow-up (LIVE-SIM finding, 2026-09-09): the K3 fix's full-height row
# sweep was validated against read_symbol for the first time on
# model_config/sim_2x2_bsz1.json (H_ROWS=8) -- see the session report for
# the exact commands. DECODE_LENS=[2] and DECODE_LENS=[3] both showed rows
# beyond the decode length as false DEFECTs (1/8 post-distinct, because the
# KV cache is Y-strided and those rows genuinely have not been decode-
# written yet -- see qkv_col_row_reached's docstring); DECODE_LENS=[24]
# (>= H_ROWS) read clean. That live result is reproduced synthetically
# here so it is checked on every future change, not just observed once.
# --------------------------------------------------------------------- #

@case("(j) short decode run: rows beyond decode length are unwritten, not defective -- NEW passes")
def _(_state):
    rounds = [(PLEN, 50)]   # single round, decode_len=50 < H_ROWS=256: rows [50, 256) genuinely unreached
    row_data = _row_reach_dispatch(rounds)
    aware_ok, aware_detail = run_new_checker(
        H_ROWS, P_BLOCK_SIZE, P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, MAX_LAYERS,
        row_data, rounds=rounds)
    unaware_ok, unaware_detail = run_new_checker(
        H_ROWS, P_BLOCK_SIZE, P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, MAX_LAYERS,
        row_data, rounds=None)   # pre-fix behaviour: assume every row reached
    ok = aware_ok is True and unaware_ok is False
    detail = (f"row-reach aware   (rounds={rounds}) -> ok={aware_ok} detail={aware_detail}\n"
              f"row-reach unaware (assume all reached)  -> ok={unaware_ok} detail={unaware_detail}  "
              f"<- the live-sim bug this closes (model_config/sim_2x2_bsz1.json, DECODE_LENS=[2]/[3])")
    return ok, detail


@case("(k) short decode run + a genuine defect in an ALREADY-reached row -- NEW still rejects")
def _(_state):
    rounds = [(PLEN, 50)]
    row_data = _row_reach_dispatch(rounds, defect_row=10)   # row 10 < 50: reached, but broken
    ok_result, detail_result = run_new_checker(
        H_ROWS, P_BLOCK_SIZE, P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, MAX_LAYERS,
        row_data, rounds=rounds)
    ok = ok_result is False and "ly=10" in detail_result
    return ok, f"ok={ok_result} detail={detail_result}"


# --------------------------------------------------------------------- #
# 2nd-pass follow-up (review, 2026-09-09): a SINGLE round's decode length is
# not enough -- decode.csl's round_reset() only resets the write cursor to
# THAT round's own prefill boundary; it never clears anything beyond it
# (kv_ingress_layer_phase's DSD lengths are prefill_len_per_pe_rt, not
# kv_len_per_pe; XKCache_tile is @zeros(...) only once, at compile/load).
# So an EARLIER, longer-decode round's suffix persists through a LATER,
# shorter one. The reviewer's fixture: a long round then a short one (same
# prompt) must still pass; a genuine defect in a row NEITHER round reached
# must still fail.
# --------------------------------------------------------------------- #

@case("(l) two rounds, long(200)-then-short(16), same prompt: rows 16-199 hold round0's leftover -- NEW passes")
def _(_state):
    rounds = [(PLEN, 200), (PLEN, 16)]   # round 0: 200 tok; round 1 (last): 16 tok
    row_data = _row_reach_dispatch(rounds)
    single_round_ok, single_round_detail = run_new_checker(
        H_ROWS, P_BLOCK_SIZE, P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, MAX_LAYERS,
        row_data, rounds=[rounds[-1]])   # pre-2nd-pass behaviour: only the LAST round's reach
    multi_round_ok, multi_round_detail = run_new_checker(
        H_ROWS, P_BLOCK_SIZE, P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, MAX_LAYERS,
        row_data, rounds=rounds)
    ok = multi_round_ok is True and single_round_ok is False
    detail = (f"multi-round aware (rounds={rounds})    -> ok={multi_round_ok} detail={multi_round_detail}\n"
              f"single-round only (last round's 16 only) -> ok={single_round_ok} detail={single_round_detail}  "
              f"<- the bug this 2nd pass closes: rows 16-199 hold real round-0 data, "
              f"single-round reach called them unreached")
    return ok, detail


@case("(m) same two-round sequence + contamination in a row NEITHER round reached -- NEW still rejects")
def _(_state):
    rounds = [(PLEN, 200), (PLEN, 16)]
    contaminated_row = 250   # > 200: outside BOTH rounds' reach
    def row_data(ly):
        if ly >= H_ROWS:
            return _idle_row(ly)
        if ly == contaminated_row:
            # Nothing should ever have written here -- force it to look
            # like real per-column data anyway: the defect is contamination
            # of a row structurally unreached by any round, not a collapse.
            return make_col_arrays(P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, MAX_LAYERS)
        reached = qkv_col_row_high_water(ly, rounds, H_ROWS) > PLEN
        return make_col_arrays(P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, MAX_LAYERS,
                                post_distinct_per_layer=(None if reached else _UNWRITTEN_PDPL))
    ok_result, detail_result = run_new_checker(
        H_ROWS, P_BLOCK_SIZE, P_COLS, BSZ, KV_COLS, KV_LEN_PER_PE, PLEN, MAX_LAYERS,
        row_data, rounds=rounds)
    ok = ok_result is False and "ly=250" in detail_result
    return ok, f"ok={ok_result} detail={detail_result}"


@case("unit: qkv_col_n_dummy_cols / qkv_col_expected_distinct hand-computed values")
def _(_state):
    checks = [
        # (head_dim, pes_per_kv_head, n_kv_heads) -> n_dummy_cols
        ((128, 16, 8), 0),    # layout C's target geometry: no padding at all
        ((10, 3, 2), 0),      # head_dim/2=5 not divisible by pes_per_kv_head=3,
                               # but ceil-division leaves only a PARTIAL column
                               # per group, no FULLY dummy one
        ((2, 5, 2), 8),       # head_dim/2=1 << pes_per_kv_head=5: 4 fully-dummy
                               # columns per group, 2 groups
        ((_D_HEAD_DIM, _D_PES_PER_KV_HEAD, _D_N_KV_HEADS), 4),   # this file's (h)/(i) geometry
    ]
    results = []
    ok = True
    for (hd, pkh, nkh), want in checks:
        got = qkv_col_n_dummy_cols(hd, pkh, nkh)
        results.append((hd, pkh, nkh, want, got))
        ok = ok and (got == want)
    ok = ok and qkv_col_expected_distinct(128, 0) == 128
    ok = ok and qkv_col_expected_distinct(12, 4) == 9
    detail = "\n    ".join(
        f"n_dummy_cols(head_dim={hd}, pes_per_kv_head={pkh}, n_kv_heads={nkh}) "
        f"= {got} (want {want})" for hd, pkh, nkh, want, got in results)
    detail += ("\n    expected_distinct(128, 0)=" + str(qkv_col_expected_distinct(128, 0))
               + "  expected_distinct(12, 4)=" + str(qkv_col_expected_distinct(12, 4)))
    return ok, detail


@case("unit: qkv_col_row_high_water / qkv_col_row_reached hand-computed values")
def _(_state):
    # (ly, rounds, H_ROWS) -> want_high_water; each round is (plen_per_pe, decode_len)
    hw_checks = [
        (0, [(1, 2)], 8, 2),      # single round, matches the sim_2x2_bsz1.json DECODE_LENS=[2] probe
        (1, [(1, 2)], 8, 2),
        (2, [(1, 2)], 8, 1),      # unreached: high water stays at plen (no decode contribution)
        (2, [(1, 3)], 8, 2),      # DECODE_LENS=[3] probe: ly=2 is the last reached row
        (3, [(1, 3)], 8, 1),      # unreached
        (0, [(1, 24)], 8, 4),     # DECODE_LENS=[24] probe: full kv_len_per_pe=4 reached (24=3*8)
        (199, [(PLEN, 200), (PLEN, 16)], 256, PLEN + 1),   # reviewer's fixture: round 0 alone reaches it
        (15, [(PLEN, 200), (PLEN, 16)], 256, PLEN + 1),    # reached by both rounds
        (200, [(PLEN, 200), (PLEN, 16)], 256, PLEN),       # neither round reaches row 200
        (250, [(PLEN, 200), (PLEN, 16)], 256, PLEN),       # neither round reaches row 250
    ]
    results = []
    ok = True
    for ly, rounds, hrows, want in hw_checks:
        got = qkv_col_row_high_water(ly, rounds, hrows)
        results.append((ly, rounds, hrows, want, got))
        ok = ok and (got == want)
    # qkv_col_row_reached is just high_water > last_plen -- spot-check the boundary directly
    ok = ok and qkv_col_row_reached(199, [(PLEN, 200), (PLEN, 16)], 256, PLEN) is True
    ok = ok and qkv_col_row_reached(200, [(PLEN, 200), (PLEN, 16)], 256, PLEN) is False
    detail = "\n    ".join(
        f"row_high_water(ly={ly}, rounds={rounds}, H_ROWS={hrows}) = {got} (want {want})"
        for ly, rounds, hrows, want, got in results)
    detail += (f"\n    row_reached(199, ..., last_plen={PLEN}) = "
               f"{qkv_col_row_reached(199, [(PLEN, 200), (PLEN, 16)], 256, PLEN)} (want True)")
    detail += (f"\n    row_reached(200, ..., last_plen={PLEN}) = "
               f"{qkv_col_row_reached(200, [(PLEN, 200), (PLEN, 16)], 256, PLEN)} (want False)")
    return ok, detail


def main():
    n_pass = 0
    state = {}
    for name, fn in CASES:
        try:
            ok, detail = fn(state)
        except Exception as exc:                    # noqa: BLE001
            ok, detail = False, f"<harness raised: {type(exc).__name__}: {exc}>"
        status = "PASS" if ok else "FAIL"
        if ok:
            n_pass += 1
        print(f"[{status}] {name}")
        for line in detail.splitlines():
            print(f"    {line}")
    total = len(CASES)
    print(f"\n{n_pass}/{total} case(s) passed")
    print("VERDICT:", "PASS" if n_pass == total else "FAIL")
    sys.exit(0 if n_pass == total else 1)


if __name__ == "__main__":
    main()
