#!/usr/bin/env cs_python
"""Seeded-defect suite for launch.py's K4 KV-SEED-in-cut-mode fix.

The defect (checker plan, K4): `_kv_seed_check` used to open with

    if CHAIN is not None:
        print("KV-seed check skipped (stage-cut geometry)")
        return

-- i.e. the bit-exact "streamed cache prefix == host KV" check NEVER ran on
a cut geometry, which is what layout C IS. Fixed by deriving KV ownership
(which row, and which of its two physical PE-columns) from the CHAIN map
instead of assuming every row owns KV on the row-parity "attn slot" column,
and by indexing inj_xk/inj_xv through kv_rows' actual layout instead of by
raw row number. See kv_seed_cut_owner_bx and kv_seed_cut_inj_index in
launch.py for the two landmines this closes, each verified in source (not
assumed from the plan, per this plan's own K1/K2/K3 track record of finding
the plan wrong and the source right).

This suite is the SYNTHETIC supplement, exercising the two pure helper
functions directly -- no read_symbol, no simulator, no device -- the same
carve-out scripts/test_qkv_col_check.py and scripts/test_verdict_sink.py
document. A REAL cut-mode sim run demonstrating the fixed check actually
EXECUTING (not skipping), passing on a healthy build, and REJECTING a
corrupted one (via the _TEST_FORCE_KV_SEED_CORRUPT_ROW hook launch.py's
_kv_seed_check now supports) is required separately -- see the K4 session
report for the exact commands and real output; that demonstration cannot be
synthesized here because it depends on live device/sim state.

Must run under cs_python (launch.py imports the Cerebras SDK bindings at
module scope):

    cs_python scripts/test_kv_seed_check.py

Exit codes: 0 all cases passed, 1 at least one failed, 3 wrong interpreter.
"""
import sys
from pathlib import Path

HERE = Path(__file__).parent.resolve()
CODE_DIR = HERE.parent
sys.path.insert(0, str(CODE_DIR))


def _require_cs_python():
    """See scripts/test_verdict_sink.py's docstring for why this guard
    exists: without it, running this under a bare python3 makes every
    `from launch import ...` below traceback, and a naive runner would
    report a false "0/N FAIL" indistinguishable from a real defect."""
    try:
        import cerebras.sdk.runtime.sdkruntimepybind  # noqa: F401  pylint: disable=unused-import,import-outside-toplevel
    except Exception as exc:                          # noqa: BLE001
        print(f"ERROR: this suite must be run under cs_python, not {sys.executable}.")
        print(f"       Import failed here with: {type(exc).__name__}: {exc}")
        print(f"       Run instead:  cs_python {Path(__file__).resolve()}")
        print("VERDICT: ERROR (wrong interpreter -- no case was run)")
        sys.exit(3)


_require_cs_python()

from launch import kv_seed_cut_owner_bx, kv_seed_cut_inj_index  # noqa: E402


# --------------------------------------------------------------------- #
# Frozen copies of launch.py's real CHAIN dicts (as of 2026-09-09,
# launch.py:855-946) -- narrow/wide payload widths don't matter for
# kv_seed_cut_owner_bx (only the owns_kv flag, tuple index 4, and the row
# parity do), so those fields are stubbed to 0 here for brevity. Keep this
# list in sync with launch.py's `elif stage_cut == N:` blocks if a new one
# is added; a mismatch here would only make this suite too weak, not
# launch.py wrong (verified against source, not the other way around).
# --------------------------------------------------------------------- #

CHAIN_CUT2 = {   # stage_cut == 2: 4 rows / 2 layers
    (0, 1): (1, 0, 0, 0, False), (0, 0): (4, 0, 0, None, False),
    (1, 1): (2, 0, 0, 0, True),  (1, 0): (0, 0, 0, 0, False),
    (2, 1): (1, 0, 0, 1, False), (2, 0): (4, 0, 0, None, False),
    (3, 1): (2, 0, 0, 1, True),  (3, 0): (0, 0, 0, 1, False),
}
KV_ROWS_CUT2 = [1, 3]

CHAIN_CUT3 = {   # stage_cut == 3: minimal bring-up, 2 rows / 1 layer
    (0, 1): (1, 0, 0, 0, False), (0, 0): (4, 0, 0, None, False),
    (1, 1): (2, 0, 0, 0, True),  (1, 0): (0, 0, 0, 0, False),
}
KV_ROWS_CUT3 = [1]

CHAIN_CUT5 = {   # stage_cut == 5: all-vanilla-in-cut-machinery, 2 rows / 2 layers
    (0, 1): (0, 0, 0, 0, True), (0, 0): (0, 0, 0, 0, False),
    (1, 1): (0, 0, 0, 1, True), (1, 0): (0, 0, 0, 1, False),
}
KV_ROWS_CUT5 = [0, 1]

CHAIN_CUT6 = {   # stage_cut == 6: cut L0 + vanilla L1-2, 4 rows / 3 layers
    (0, 1): (1, 0, 0, 0, False), (0, 0): (4, 0, 0, None, False),
    (1, 1): (2, 0, 0, 0, True),  (1, 0): (0, 0, 0, 0, False),
    (2, 1): (0, 0, 0, 1, True),  (2, 0): (0, 0, 0, 1, False),
    (3, 1): (0, 0, 0, 2, True),  (3, 0): (0, 0, 0, 2, False),
}
KV_ROWS_CUT6 = [1, 2, 3]

CHAIN_CUT7 = {   # stage_cut == 7: vanilla L0-1 + cut L2, 4 rows / 3 layers
    (0, 1): (0, 0, 0, 0, True),  (0, 0): (0, 0, 0, 0, False),
    (1, 1): (0, 0, 0, 1, True),  (1, 0): (0, 0, 0, 1, False),
    (2, 1): (1, 0, 0, 2, False), (2, 0): (4, 0, 0, None, False),
    (3, 1): (2, 0, 0, 2, True),  (3, 0): (0, 0, 0, 2, False),
}
KV_ROWS_CUT7 = [0, 1, 3]

REAL_CHAINS = [
    ("stage_cut=2", CHAIN_CUT2, KV_ROWS_CUT2),
    ("stage_cut=3", CHAIN_CUT3, KV_ROWS_CUT3),
    ("stage_cut=5", CHAIN_CUT5, KV_ROWS_CUT5),
    ("stage_cut=6", CHAIN_CUT6, KV_ROWS_CUT6),
    ("stage_cut=7", CHAIN_CUT7, KV_ROWS_CUT7),
]


CASES = []


def case(name):
    def deco(fn):
        CASES.append((name, fn))
        return fn
    return deco


# --------------------------------------------------------------------- #
# kv_seed_cut_owner_bx
# --------------------------------------------------------------------- #

@case("control: every shipped CHAIN's KV owner is role 1 -> agrees with the "
      "row-parity shortcut (P=8, arbitrary but must divide evenly)")
def _():
    P = 8
    bad = []
    for name, chain, kv_rows in REAL_CHAINS:
        for row in kv_rows:
            got = kv_seed_cut_owner_bx(row, chain, P)
            parity_shortcut = 0 if row % 2 == 0 else 1
            if got != parity_shortcut:
                bad.append((name, row, got, parity_shortcut))
    ok = not bad
    return ok, None, f"mismatches={bad}" if bad else "all agree (as expected today)"


@case("SEEDED DEFECT: owns_kv on role 0 -> parity shortcut would read the "
      "WRONG physical column; kv_seed_cut_owner_bx reads CHAIN and gets it right")
def _():
    # A row where the FFN slot (role 0), not the ATTN slot (role 1), owns KV
    # -- no CHAIN shipped today does this, which is exactly why the vanilla
    # parity shortcut has never been caught being wrong. Row 1 is odd, so
    # the parity shortcut says attn_bx=1; if role 0 (physically at 1-attn_bx
    # = 0) owns KV instead, the shortcut would read column 1 -- the FFN
    # PE, which never ran kv_ingress and holds stale/zero cache -- and
    # silently call whatever garbage it finds "the KV owner's data".
    chain = {(1, 1): (0, 0, 0, 0, False), (1, 0): (2, 0, 0, 0, True)}
    parity_shortcut = 0 if 1 % 2 == 0 else 1   # = 1 (attn slot)
    got = kv_seed_cut_owner_bx(1, chain, 8)
    correct_ffn_bx = 1 - parity_shortcut       # = 0
    ok = (got == correct_ffn_bx) and (got != parity_shortcut)
    detail = (f"kv_seed_cut_owner_bx={got}, correct FFN column={correct_ffn_bx}, "
              f"vanilla-parity-shortcut would have said={parity_shortcut} "
              f"(WRONG column if it had been used)")
    return ok, None, detail


@case("SEEDED DEFECT: malformed CHAIN (no owner, or two owners) -> raises, "
      "does not silently pick one")
def _():
    import launch
    no_owner = {(0, 1): (0, 0, 0, 0, False), (0, 0): (0, 0, 0, 0, False)}
    two_owners = {(0, 1): (0, 0, 0, 0, True), (0, 0): (0, 0, 0, 0, True)}
    raised = []
    for chain in (no_owner, two_owners):
        try:
            kv_seed_cut_owner_bx(0, chain, 8)
            raised.append(False)
        except AssertionError:
            raised.append(True)
    ok = raised == [True, True]
    return ok, None, f"raised={raised} (expect [True, True])"


# --------------------------------------------------------------------- #
# kv_seed_cut_inj_index
# --------------------------------------------------------------------- #

@case("control: vanilla kv_rows == range(P_Y_BLOCK_NUM) -> identity map")
def _():
    kv_rows = list(range(4))
    got = kv_seed_cut_inj_index(kv_rows)
    ok = got == {0: 0, 1: 1, 2: 2, 3: 3}
    return ok, None, f"got={got}"


@case("control: stage_cut=2 kv_rows=[1,3] -> row 1 -> inj slot 0, row 3 -> inj slot 1")
def _():
    got = kv_seed_cut_inj_index(KV_ROWS_CUT2)
    ok = got == {1: 0, 3: 1}
    return ok, None, f"got={got}"


@case("SEEDED DEFECT: raw `by` indexing into inj_xk reads the WRONG row's data "
      "(or goes out of bounds) once kv_rows != range(P_Y_BLOCK_NUM)")
def _():
    import numpy as np
    kv_rows = KV_ROWS_CUT2   # [1, 3]
    # Build a tiny synthetic inj_xk-shaped array tagged by the REAL row
    # identity it belongs to (value == row number), the same compaction
    # inj_xk actually undergoes at launch.py:2687-2692 (filtered to
    # kv_inj_rows -- i.e. exactly kv_rows -- in ascending order).
    inj_xk = np.array([[1.0], [3.0]])   # inj_xk[0] is row 1's data, inj_xk[1] is row 3's
    idx_map = kv_seed_cut_inj_index(kv_rows)
    correct_row3_data = inj_xk[idx_map[3]][0]
    buggy_row3_lookup_raised = False
    buggy_row3_data = None
    try:
        buggy_row3_data = inj_xk[3][0]   # the pre-fix bug: index by raw row number
    except IndexError:
        buggy_row3_lookup_raised = True
    # Either the naive lookup goes out of bounds (as it does here, len=2)
    # or -- for a larger kv_rows list -- silently returns a DIFFERENT row's
    # data. Both are wrong; the fixed map is right either way.
    ok = (correct_row3_data == 3.0) and (
        buggy_row3_lookup_raised or buggy_row3_data != 3.0)
    detail = (f"fixed lookup: row 3 -> inj_xk[{idx_map[3]}] = {correct_row3_data} (correct); "
              f"naive inj_xk[3] "
              + ("raised IndexError" if buggy_row3_lookup_raised
                 else f"= {buggy_row3_data} (WRONG row)"))
    return ok, None, detail


@case("SEEDED DEFECT: naive raw-row indexing silently reads a DIFFERENT row's "
      "data (no IndexError) when a lower-numbered row is absent from kv_rows")
def _():
    import numpy as np
    # kv_rows=[0, 2, 3] (row 1 absent -- e.g. stage_cut=7's KV_ROWS_CUT7 shape):
    # row 3's real data is compacted to inj_xk[2], but a raw-row lookup
    # inj_xk[3] lands IN BOUNDS (len=3, valid indices 0-2... actually 3 is
    # out of bounds here too) -- use a 4-owner-row example so the naive
    # lookup lands in-bounds on the WRONG entry instead of raising, which is
    # the more dangerous failure mode (wrong answer, no exception at all).
    kv_rows = [0, 2, 3, 5]                     # row 1 and row 4 absent
    inj_xk = np.array([[0.0], [2.0], [3.0], [5.0]])   # tagged by real row identity, compacted
    idx_map = kv_seed_cut_inj_index(kv_rows)
    fixed_row5 = inj_xk[idx_map[5]][0]         # -> inj_xk[3] = 5.0 (correct)
    naive_row5 = inj_xk[5] if 5 < len(inj_xk) else "IndexError"   # 5 >= len=4
    # The silent-wrong-value case: row 3 sits at raw index 3 by ACCIDENT
    # here (kv_rows[2]==3), but its inj slot is really 2 -- inj_xk[3] would
    # read row 5's slab and call it row 3's.
    fixed_row3 = inj_xk[idx_map[3]][0]         # -> inj_xk[2] = 3.0 (correct)
    naive_row3 = inj_xk[3][0]                  # -> 5.0 (WRONG row's data, no exception)
    ok = (fixed_row5 == 5.0 and naive_row5 == "IndexError"
          and fixed_row3 == 3.0 and naive_row3 != 3.0)
    detail = (f"kv_rows={kv_rows}: fixed row 5 -> inj_xk[{idx_map[5]}] = {fixed_row5} (correct), "
              f"naive inj_xk[5] = {naive_row5}; "
              f"fixed row 3 -> inj_xk[{idx_map[3]}] = {fixed_row3} (correct), "
              f"naive inj_xk[3] = {naive_row3} (WRONG row's data, silently, no exception)")
    return ok, None, detail


def main():
    _require_cs_python()
    n_pass = 0
    for name, fn in CASES:
        try:
            result = fn()
            if len(result) == 3:
                ok, _unused, detail = result
            else:
                ok, detail = result
        except Exception as exc:                     # noqa: BLE001
            ok, detail = False, f"<raised {type(exc).__name__}: {exc}>"
        status = "PASS" if ok else "FAIL"
        if ok:
            n_pass += 1
        print(f"[{status}] {name}")
        print(f"    {detail}")
    total = len(CASES)
    print(f"\n{n_pass}/{total} case(s) passed")
    print("VERDICT:", "PASS" if n_pass == total else "FAIL")
    sys.exit(0 if n_pass == total else 1)


if __name__ == "__main__":
    main()
